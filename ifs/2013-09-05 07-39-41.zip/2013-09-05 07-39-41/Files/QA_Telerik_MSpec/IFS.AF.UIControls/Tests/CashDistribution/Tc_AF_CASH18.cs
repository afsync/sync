﻿using System;
using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.CashDistribution
{
    /// <summary>
    ///JIRA ALPHA-1877 Can not create cash distribution
    /// Created by: RTalla
    /// description: cash distribution should be equal tobreakups
    /// amount and distribition should be created with out any exception
    /// 09/03/2013
    /// </summary>
    [Subject("AF_CASH_18"), Tags("CashDistribution1", "AF_CASH_18")]
    public class Verify_cash_distribution_should_be_created : AfWebTest
    {
        protected static Browser BrowserId;
        protected static DashboardPage Dashboard;
        protected static ContextMenus ContextMenu;
        protected static ContributionPage ContributionPg;
        protected static ActivityReportPage ActivityReport;
        protected static string ContributionAmount, BreakUpAmount;
        protected static string BreakUpType, ExpNav, ActNav;

        Establish _context = () =>
        {
            BreakUpType = "Capital Call";
            ContributionAmount = "99000000";
            BreakUpAmount = "99000000";
            ExpNav = "1,000.0000";

            TestData = new TestDataSet()
            {
                Client = "Automation Cash Distribution",
                Portfolio = "Automation Cash Distribution 3",
                BaseFund = "Automation Fund 3",
                InvestableFund = "Automation Fund 3 - A",
                Currency = "USD",
                FundIssueDate = "7/31/2013",
                Clearer = "Automation Cash Distribution Clearer"
            };
            Dashboard = AsPage<DashboardPage>();
            ContextMenu = AsPage<ContextMenus>();
        };

        Because _of = () =>
        {
            Login.FullLogin(WebCredentials.Login, WebCredentials.Password, TestData.Client);
            Dashboard.PortfolioName.Select(TestData.Portfolio);
            QuickSearchPage qspg = Dashboard.GoToQuickSearch();
            qspg.QuickSearchSubscription(TestData.InvestableFund);
            ActiveBrowser.WaitUntilReady();
            Browser brwr = BrowserPool.IePopupOpen(PageUrl.ALLOCATION_SUBSCRIPTION_PVT_EQTY, ContributionPage.TITLE);
            ContributionPg = AsPage<ContributionPage>();
            ActiveBrowser.WaitUntilReady();

            ContributionPg.ContributionAmount.Click();
            ContributionPg.ContributionAmount.TypeText(ContributionAmount);

            ContributionPg.TypeValue.SelectByText(BreakUpType);
            ContributionPg.BreakupAmount.Click();
            ContributionPg.BreakupAmount.TypeText(ContributionAmount);
            ContributionPg.AcceptBtn.MouseClick();
            BrowserPool.IePopupClose(brwr.ClientId);

            Dashboard.GoToDashboard();
            Dashboard.Expand(TestData.BaseFund);
            ActNav = Dashboard.GetValue(TestData.BaseFund, Header.CURRENT_NAV);
        };

        It Should_verify_cash_distribution_be_created_with_out_exception = () =>
        {
            ActNav.ShouldEqual(ExpNav);
        };

        private Cleanup _clean = () =>
        {
            try
            {
                ActivityReport = Dashboard.GoToViewActivity(TestData.BaseFund, TestData.InvestableFund);
                ActivityReport.DeleteAllTransactions();
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
        };

    }
}
