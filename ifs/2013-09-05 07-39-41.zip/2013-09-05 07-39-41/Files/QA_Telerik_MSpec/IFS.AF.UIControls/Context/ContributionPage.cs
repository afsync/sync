﻿using System;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications.Annotations;

namespace IFS.AF.UIControls.Context
{
    public class Contribution : BaseTransaction
    {
        private readonly Transaction _baseTransaction;
        public Contribution(Transaction baseTransaction)
        {
            _baseTransaction = baseTransaction;
        }

        public new Transaction Transaction
        {
            get { return _baseTransaction; }
        }
    }

    [UsedImplicitly]
    public class ContributionPage : InvestmentControls
    {

        public ContributionPage(Find find)
            : base(find)
        {}

        public ContributionPage(Find find, Browser browser)
            : base(find)
        {
            Browser = browser;
        }

        //Page properties
        public const string TITLE = "Contribution";

        //Page properties
        private const string UNFUNDED_COMMITMENTS_ID = "~lblUnfundedCommit";
        private const string COMMITMENT_TYPE_ADDITIONAL = "~rdAdditional";
        private const string COMMITMENT_TYPE_REDUCE = "~rdReduce";
        private const string TYPE_VALUE = "~ddlTypeValues0";
        private const string CHECK_CAPITAL_CALL_ID = "~_chkCapitalCall0";
        private const string BREAKUP_AMOUNT_AMOUNT_ID = "~_txtBreakupAmount0";
        private const string CONTRIBUTION_AMOUNT_ID = "~_txtAmount";

        public string UnfundedCommitmentValue
         {
             get
             {
                 return ElementManager.GetElementById(UNFUNDED_COMMITMENTS_ID).As<HtmlSpan>().TextContent.Split(new[] {'('}, 2, StringSplitOptions.None)[0];
             }
         }

        public HtmlInputRadioButton RbCommitmentTypeAdditional
        {
            get
            {
                return ElementManager.GetElementById(COMMITMENT_TYPE_ADDITIONAL).As<HtmlInputRadioButton>();
            }
        }

        public HtmlInputRadioButton RbCommitmentTypeReduce
        {
            get
            {
                return ElementManager.GetElementById(COMMITMENT_TYPE_REDUCE).As<HtmlInputRadioButton>();
            }
        }

        public HtmlInputText BreakupAmount
        {
            get
            {
                return ElementManager.GetElementById(BREAKUP_AMOUNT_AMOUNT_ID).As<HtmlInputText>();
            }
        }
        public HtmlInputText ContributionAmount
        {
            get
            {
                return ElementManager.GetElementById(CONTRIBUTION_AMOUNT_ID).As<HtmlInputText>();
            }
        }
        public HtmlSelect TypeValue
        {
            get
            {
                return ElementManager.GetElementById(TYPE_VALUE).As<HtmlSelect>();
            }
        }

        public HtmlInputCheckBox ChkCapitalCall
        {
            get
            {
                return ElementManager.GetElementById(CHECK_CAPITAL_CALL_ID).As<HtmlInputCheckBox>();
            }
        }


        #region Variables
        public struct ContributionFields2Pass
        {
            public bool Override, CapitalCallOutsideCommitment;
            public string FundExtension, EffectiveDate, TradeDate, ExpMoneyMoveDate, Price, Amount, TransactionId, Clearer, Type;
        }

        #endregion
     


        private void SetShares(ContributionFields2Pass fields2Pass)
        {
            if (!string.IsNullOrEmpty(fields2Pass.FundExtension)) 
                FundSelector.Select(fields2Pass.FundExtension);

            if (!string.IsNullOrEmpty(fields2Pass.EffectiveDate)) 
                EffectiveDate.TypeTextTab(fields2Pass.EffectiveDate);

            if (!string.IsNullOrEmpty(fields2Pass.TradeDate)) 
                TradeDate.TypeText(fields2Pass.TradeDate);

            if (!string.IsNullOrEmpty(fields2Pass.ExpMoneyMoveDate)) 
                MoneyMoveDate.TypeText(fields2Pass.ExpMoneyMoveDate);

            if (fields2Pass.Override)
            {
                PriceOverride.Checked = true;
                if (!string.IsNullOrEmpty(fields2Pass.Price)) 
                    PriceFld.TypeTextTab(fields2Pass.Price);
            }

            Assert.IsTrue(!fields2Pass.Amount.Equals(null));
            AmountFld.TypeText(fields2Pass.Amount);

            if (!string.IsNullOrEmpty(fields2Pass.TransactionId)) 
                TransactionIdFld.TypeTextTab(fields2Pass.TransactionId);

            if (!string.IsNullOrEmpty(fields2Pass.Clearer)) 
                ClearerSelector.Select(fields2Pass.Clearer);
            else
                ClearerSelector.SelectByIndex(ClearerSelector.Options.Count - 1);
            BreakupAmount.TypeText(fields2Pass.Amount);
            Assert.IsTrue(!fields2Pass.Type.Equals(null));
            TypeValue.Select(fields2Pass.Type);
        }

        public Contribution AllocationContribution(BaseTransaction.Transaction transaction, string commitmentAmount, string commitmentType)
        {
            SetShares(transaction, commitmentAmount, commitmentType);
            var resultContribution = GetContribution();

            Save();
            return resultContribution;
        }

        public void SetShares(BaseTransaction.Transaction transaction, string amount, string type)
        {
            FundSelector.Select(StringTransform.GetTailInvestableFund(transaction.InvestableFund, transaction.BaseFund));

            if (!string.IsNullOrEmpty(transaction.EffectiveDate))
                EffectiveDate.TypeTextTab(transaction.EffectiveDate);

            if (!string.IsNullOrEmpty(transaction.TradeDate))
                TradeDate.TypeText(transaction.TradeDate);

            if (!string.IsNullOrEmpty(transaction.MoveMoneyDate))
                MoneyMoveDate.TypeText(transaction.MoveMoneyDate);

            if (!string.IsNullOrEmpty(transaction.Price))
            {
                PriceOverride.Checked = true;
                PriceFld.TypeTextTab(transaction.Price);
            }

            Assert.IsTrue(!transaction.AmountToBePaid.Equals(null));
            AmountFld.TypeText(transaction.AmountToBePaid);

            if (!string.IsNullOrEmpty(transaction.AllocationId))
                TransactionIdFld.TypeTextTab(transaction.AllocationId);

            if (!string.IsNullOrEmpty(transaction.Clearer))
                ClearerSelector.Select(transaction.Clearer);
            else
                ClearerSelector.SelectByIndex(ClearerSelector.Options.Count - 1);
            BreakupAmount.TypeText(amount);
            Assert.IsTrue(!type.Equals(null));
            TypeValue.Select(type);
        }
        
        public Contribution AllocationContribution(ContributionFields2Pass fields2Pass)
        {
            SetShares(fields2Pass);
            var resultContribution = GetContribution();

            Save();
            return resultContribution;
        }

        public Contribution GetContribution()
        {
            var investableFundName = InvestableFund ?? FundSelector.SelectedOption.Text;

            return new Contribution(
                new BaseTransaction.Transaction
                (TransactionType.CONTRIBUTION,
                 BaseFund,
                 StringTransform.GetFullFundName(BaseFund, investableFundName),
                 EffectiveDate.Text, 
                 AmountFld.Text, 
                 PriceCurrency, 
                 StringTransform.ConvertToCurrencyNumber(PriceFld.Text), 
                 SharesQuantityFld.Text,
                 ClearerSelector.SelectedOption.Text, 
                 BackdatedValue, 
                 EnteredBy, 
                 TradeDate.Text, 
                 MMDate, 
                 CommentsText,
                 RegistrarText));
        }

    }
 
}
