﻿using System;
using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications;

namespace GSM_CP.Tests.Reports.REP_GlobalContactsUpdate
{
    /*Removed from regression according to story 4671 Retire Fund Global Contacts Update report*/
    //[Subject("TC_GSM_GCUR_01"), Tags("REP_GlobalContactsUpdate", "TC_GSM_GCUR_01")]
    public class 
        TC_GSM_GCUR_01_Verify_report_structure_and_date_picking : AfWebTest
    {
        protected static DateTime CurrentDate = DateTime.Today.Date;
        protected static DateTime DateFromInitial, DateToInitial;
        protected static DateTime DateFromAfterChange, DateToAfterChange;
        protected static bool DateFromPresent, DateToPresent, ReportPresent;
        protected static List<string> HeaderNames;
        protected static List<string> ExpectedHeaderNames = new List<string>(){ "Fund", "Category", "Company &amp; Office", "Contact Person", "Action", "Status" };

        Because _of = () =>
        {
            var report = UserAction.LoginAsGsmManager().GoToFundGlobalContactsUpdateReport();

            DateFromPresent = report.IsDateFromPresent();
            DateToPresent = report.IsDateToPresent();
            ReportPresent = report.IsGlobalContactUpdatesReportPresent();

            DateFromInitial = report.GetDateFrom().Date;
            DateToInitial = report.GetDateTo().Date;

            report.SetDateFrom(CurrentDate.AddDays(-3).ToShortDateString());
            report.SetDateTo(CurrentDate.AddDays(3).ToShortDateString());

            DateFromAfterChange = report.GetDateFrom().Date;
            DateToAfterChange = report.GetDateTo().Date;

            HeaderNames = report.GlobalContactReportGrid.GetHeaderName();
        };

        It _01_date_from_textfield_is_present = () => DateFromPresent.ShouldBeTrue();
        It _02_date_to_textfield_is_present = () => DateToPresent.ShouldBeTrue();
        It _03_report_table_is_present = () => ReportPresent.ShouldBeTrue();
        It _04_date_from_contains_current_date_minus_7 = () => DateFromInitial.ShouldEqual(CurrentDate.AddDays(-7));
        It _05_date_To_contains_Current_Date = () => DateToInitial.ShouldEqual(CurrentDate);
        It _06_date_from_contains_current_date_minus_3_after_update = () => DateFromAfterChange.ShouldEqual(CurrentDate.AddDays(-3));
        It _07_date_to_contains_current_date_plus_3_after_updete = () => DateToAfterChange.ShouldEqual(CurrentDate.AddDays(3));
        It _08_page_contains_grid_with_correct_columns = () => HeaderNames.ShouldEqualExtended(ExpectedHeaderNames);
    }
}