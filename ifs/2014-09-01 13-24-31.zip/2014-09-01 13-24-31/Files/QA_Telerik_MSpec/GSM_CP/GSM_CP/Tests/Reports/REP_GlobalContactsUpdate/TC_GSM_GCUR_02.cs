﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.FundGlobalContactsUpdateReport;
using IFS.AF.BaseContext.Context.GlobalContacts;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.BaseContext.Helpers.GSM;
using Machine.Specifications;

namespace GSM_CP.Tests.Reports.REP_GlobalContactsUpdate
{
    /*Removed from regression according to story 4671 Retire Fund Global Contacts Update report*/
    //[Subject("TC_GSM_GCUR_02"), Tags("REP_GlobalContactsUpdate", "TC_GSM_GCUR_02")]
    public class TC_GSM_GCUR_02_Verify_correct_appearance_of_added_contacts__approved_and_pending_approval_Status : AfWebTest
    {
        #region Variables
        protected static GsmNavigationPage GsmNavigation;
        protected static FundGlobalContactsUpdateReport GlobalContactsUpdateReport;
        protected static GlobalContactsPage GlobalContacts;

        private const string IM_COMPANY_NAME = "TC_GSM_GCUR_02_IM";
        private const string PB_COMPANY_NAME = "TC_GSM_GCUR_02_PB";
        private const string ADM_COMPANY_NAME = "TC_GSM_GCUR_02_ADM";
        private const string AUD_COMPANY_NAME = "TC_GSM_GCUR_02_AUD";
        private const string LEGAL_COMPANY_NAME = "TC_GSM_GCUR_02_L";
        private const string OTHER_COMPANY_NAME = "TC_GSM_GCUR_02_O";
        
        private const string IM_OFFICE_NAME = "TC_GSM_GCUR_02_IM_Office";
        private const string PB_OFFICE_NAME = "TC_GSM_GCUR_02_PB_Office";
        private const string ADM_OFFICE_NAME = "TC_GSM_GCUR_02_ADM_Office";
        private const string AUD_OFFICE_NAME = "TC_GSM_GCUR_02_AUD_Office";
        private const string LEGAL_OFFICE_NAME = "TC_GSM_GCUR_02_L_Office";
        private const string OTHER_OFFICE_NAME = "TC_GSM_GCUR_02_O_Office";

        private const string CITY = "Kiev";

        private static List<FundGlobalContactUpdateReportData> imContactsList;
        private static List<FundGlobalContactUpdateReportData> pbContactsList;
        private static List<FundGlobalContactUpdateReportData> admContactsList;
        private static List<FundGlobalContactUpdateReportData> audContactsList;
        private static List<FundGlobalContactUpdateReportData> lContactsList;
        private static List<FundGlobalContactUpdateReportData> oContactsList;

        private const string FUND = "TC_GSM_GCUR_02";
        #endregion

        Because _of = () =>
        {
            GsmNavigation = UserAction.LoginAsGsmManager();
            
            var gsm = GsmNavigation.GoToGsm();
            gsm.SelectFund(FUND);

            GlobalContacts = gsm.GoToGlobalContacts();
            GlobalContacts.ApproveCompany(CompanyType.INVESTMENT_MANAGERS);
            GlobalContacts.ApproveCompany(CompanyType.PRIME_BROKERS);
            GlobalContacts.ApproveCompany(CompanyType.ADMINISTRATORS);

            GlobalContactsUpdateReport = GsmNavigation.GoToFundGlobalContactsUpdateReport();

            imContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.INVESTMENT_MANAGERS];
            pbContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.PRIME_BROKERS];
            admContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.ADMINISTRATORS];
            audContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.AUDITORS];
            lContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.LEGAL];
            oContactsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.OTHER];
        };
        
        private It _01_Investment_manager_contacts_listed_as_expected = () =>
        {
            var expectedImContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 IM 1"
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 IM 2"
                    }
            };
            imContactsList.ShouldEqual(expectedImContactsList);
        };

        private It _02_Prime_broker_contacts_listed_as_expected = () =>
        {
            var expectedPbContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.APPROVED
                    }
            };
            pbContactsList.ShouldEqual(expectedPbContactsList);
        };

        private It _03_Administrator_contacts_listed_as_expected = () =>
        {
            var expectedAdmContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME,ADM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME,ADM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 ADM 1"
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME,ADM_OFFICE_NAME,CITY),
                        Status = ContactStatusType.APPROVED,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 ADM 2"
                    }
            };
            admContactsList.ShouldEqual(expectedAdmContactsList);
        };

        private It _04_Auditor_contacts_listed_as_expected = () =>
        {
            var expectedAudContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                {
                    CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME,AUD_OFFICE_NAME,CITY),
                    ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                    Action = ContactActionType.ADDED,
                    Status = ContactStatusType.PENDING_APPROVAL
                }
            };
            audContactsList.ShouldEqual(expectedAudContactsList);
        };

        private It _05_Legal_contacts_listed_as_expected = () =>
        {
            var expectedLContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME,LEGAL_OFFICE_NAME,CITY),
                        Status = ContactStatusType.PENDING_APPROVAL,
                        Action = ContactActionType.ADDED,
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME,LEGAL_OFFICE_NAME,CITY),
                        Status = ContactStatusType.PENDING_APPROVAL,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 L 1"
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME,LEGAL_OFFICE_NAME,CITY),
                        Status = ContactStatusType.PENDING_APPROVAL,
                        Action = ContactActionType.ADDED,
                        ContactPerson = "Person GCUR 02 L 2"
                    }
            };
            lContactsList.ShouldEqual(expectedLContactsList);
        };

        private It _06_Other_contacts_listed_as_expected = () =>
        {
            var expectedOContactsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME,OTHER_OFFICE_NAME,CITY),
                        Status = ContactStatusType.PENDING_APPROVAL,
                        Action = ContactActionType.ADDED,
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE
                    }
            };
            oContactsList.ShouldEqual(expectedOContactsList);
        };
    }
}