﻿using System.Collections.Generic;
using System.Linq;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.FundGlobalContactsUpdateReport;
using IFS.AF.BaseContext.Context.GlobalContacts;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.BaseContext.Helpers.GSM;
using Machine.Specifications;

namespace GSM_CP.Tests.Reports.REP_GlobalContactsUpdate
{
    /*Removed from regression according to story 4671 Retire Fund Global Contacts Update report*/
    //[Subject("TC_GSM_GCUR_03"), Tags("REP_GlobalContactsUpdate", "TC_GSM_GCUR_03")]
    public class TC_GSM_GCUR_03_Verify_correct_appearance_of_removed_global_contacts_in_Global_Contacts_Update_Report : AfWebTest
    {
        #region Variables
        protected static GsmNavigationPage GsmNavigation;
        protected static FundGlobalContactsUpdateReport GlobalContactsUpdateReport;
        protected static GlobalContactsPage GlobalContacts;

        private const string IM_COMPANY_NAME = "TC_GSM_GCUR_03_IM";
        private const string PB_COMPANY_NAME = "TC_GSM_GCUR_03_PB";
        private const string ADM_COMPANY_NAME = "TC_GSM_GCUR_03_ADM";
        private const string AUD_COMPANY_NAME = "TC_GSM_GCUR_03_AUD";
        private const string LEGAL_COMPANY_NAME = "TC_GSM_GCUR_03_L";
        private const string OTHER_COMPANY_NAME = "TC_GSM_GCUR_03_O";
        
        private const string IM_OFFICE_NAME = "TC_GSM_GCUR_03_IM_Office";
        private const string PB_OFFICE_NAME = "TC_GSM_GCUR_03_PB_Office";
        private const string ADM_OFFICE_NAME = "TC_GSM_GCUR_03_ADM_Office";
        private const string AUD_OFFICE_NAME = "TC_GSM_GCUR_03_AUD_Office";
        private const string LEGAL_OFFICE_NAME = "TC_GSM_GCUR_03_L_Office";
        private const string OTHER_OFFICE_NAME = "TC_GSM_GCUR_03_O_Office";

        private const string PB_CONTACT_NAME_1 = "Person GCUR 03 PB 1";
        private const string PB_CONTACT_NAME_2 = "Person GCUR 03 PB 2";
        private const string AUD_CONTACT_NAME_1 = "Person GCUR 03 AUD 1";
        private const string AUD_CONTACT_NAME_2 = "Person GCUR 03 AUD 2";
        private const string OTHER_CONTACT_NAME_1 = "Person GCUR 03 O 1";
        private const string OTHER_CONTACT_NAME_2 = "Person GCUR 03 O 2";

        private const string FUND = "TC_GSM_GCUR_03";
        private const string CITY = "Kiev";

        private static List<FundGlobalContactUpdateReportData> fundContactsBeforeApprovalStatusList;
        private static List<FundGlobalContactUpdateReportData> fundContactsAfterApprovalStatusList;
        #endregion

        Because _of = () =>
        {
            GsmNavigation = UserAction.LoginAsGsmManager();
            
            var gsm = GsmNavigation.GoToGsm();
            gsm.SelectFund(FUND);
            GlobalContacts = gsm.GoToGlobalContacts();

            // Deleting Contacts and Companies
            var imCompanyNameFull = GlobalContacts.GetFullCompanyName(IM_COMPANY_NAME, IM_OFFICE_NAME, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.InvestmentManagers, imCompanyNameFull);

            var pbCompanyNameFull = GlobalContacts.GetFullCompanyName(PB_COMPANY_NAME, PB_OFFICE_NAME, CITY);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.PrimeBrokers, pbCompanyNameFull, PB_CONTACT_NAME_1);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.PrimeBrokers, pbCompanyNameFull, PB_CONTACT_NAME_2);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.PrimeBrokers, pbCompanyNameFull);

            var admCompanyNameFull = GlobalContacts.GetFullCompanyName(ADM_COMPANY_NAME, ADM_OFFICE_NAME, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Administrators, admCompanyNameFull);


            var audCompanyNameFull = GlobalContacts.GetFullCompanyName(AUD_COMPANY_NAME, AUD_OFFICE_NAME, CITY);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.Auditors, audCompanyNameFull, AUD_CONTACT_NAME_1);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.Auditors, audCompanyNameFull, AUD_CONTACT_NAME_2);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Auditors, audCompanyNameFull);

            var legalCompanyNameFull = GlobalContacts.GetFullCompanyName(LEGAL_COMPANY_NAME, LEGAL_OFFICE_NAME, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Legal, legalCompanyNameFull);

            var otherCompanyNameFull = GlobalContacts.GetFullCompanyName(OTHER_COMPANY_NAME, OTHER_OFFICE_NAME, CITY);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.Other, otherCompanyNameFull, OTHER_CONTACT_NAME_1);
            GlobalContacts.DeleteContact(GlobalContactsPage.CompanyType.Other, otherCompanyNameFull, OTHER_CONTACT_NAME_2);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Other, otherCompanyNameFull);

            // Observing changes
            GlobalContactsUpdateReport = GsmNavigation.GoToFundGlobalContactsUpdateReport();
            fundContactsBeforeApprovalStatusList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND];
            GsmNavigation.MakeLogout();

            // Approving changes
            GsmNavigation = UserAction.LoginAsGsmManager(GsmApprover);

            gsm = GsmNavigation.GoToGsm();
            gsm.SelectFund(FUND);

            GlobalContacts = gsm.GoToGlobalContacts();
            GlobalContacts.ApproveCompany(CompanyType.INVESTMENT_MANAGERS);
            GlobalContacts.ApproveCompany(CompanyType.PRIME_BROKERS);
            GlobalContacts.ApproveCompany(CompanyType.ADMINISTRATORS);
            GlobalContacts.ApproveCompany(CompanyType.AUDITORS);
            GlobalContacts.ApproveCompany(CompanyType.LEGAL);
            GlobalContacts.ApproveCompany(CompanyType.OTHER);
            
            GlobalContactsUpdateReport = GsmNavigation.GoToFundGlobalContactsUpdateReport();
            fundContactsAfterApprovalStatusList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND];
        };

        private It _01_Investment_manager_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedImContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var imContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                     (item.Category == CompanyType.INVESTMENT_MANAGERS)).ToList();
            
            imContactsBeforeApprovalStatusList.ShouldEqual(expectedImContacts);
        };

        private It _02_Primary_brokers_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedPbContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME,CITY),
                        ContactPerson = PB_CONTACT_NAME_1,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME,CITY),
                        ContactPerson = PB_CONTACT_NAME_2,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var pbContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                     (item.Category == CompanyType.PRIME_BROKERS)).ToList();
            pbContactsBeforeApprovalStatusList.ShouldEqual(expectedPbContacts);
        };

        private It _03_Administrators_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedAdmContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME,ADM_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var admContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                      (item.Category == CompanyType.ADMINISTRATORS)).ToList();
            admContactsBeforeApprovalStatusList.ShouldEqual(expectedAdmContacts);
        };

        private It _04_Auditors_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedAudContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME,AUD_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME,AUD_OFFICE_NAME,CITY),
                        ContactPerson = AUD_CONTACT_NAME_1,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME,AUD_OFFICE_NAME,CITY),
                        ContactPerson = AUD_CONTACT_NAME_2,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var audContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                      (item.Category == CompanyType.AUDITORS)).ToList();
            audContactsBeforeApprovalStatusList.ShouldEqual(expectedAudContacts);
        };

        private It _05_Legal_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedLegalContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME,LEGAL_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var legalContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                        (item.Category == CompanyType.LEGAL)).ToList();
            legalContactsBeforeApprovalStatusList.ShouldEqual(expectedLegalContacts);
        };

        private It _06_Other_contacts_listed_as_expected_before_approval = () =>
        {
            var expectedOtherContacts = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME,OTHER_OFFICE_NAME,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME,OTHER_OFFICE_NAME,CITY),
                        ContactPerson = OTHER_CONTACT_NAME_1,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME,OTHER_OFFICE_NAME,CITY),
                        ContactPerson = OTHER_CONTACT_NAME_2,
                        Action = ContactActionType.REMOVED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            var otherContactsBeforeApprovalStatusList = fundContactsBeforeApprovalStatusList.Where(item =>
                                                        (item.Category == CompanyType.OTHER)).ToList();
            otherContactsBeforeApprovalStatusList.ShouldEqual(expectedOtherContacts);
        };

        private It _07_No_contacts_listed_for_fund_after_approval = () => 
            fundContactsAfterApprovalStatusList.Count.ShouldEqual(0);

        private Cleanup _cleanup = () => { };
    }
}