﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.FundGlobalContactsUpdateReport;
using IFS.AF.BaseContext.Context.GlobalContacts;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.BaseContext.Helpers.GSM;
using Machine.Specifications;

namespace GSM_CP.Tests.Reports.REP_GlobalContactsUpdate
{
    /*Removed from regression according to story 4671 Retire Fund Global Contacts Update report*/
    //[Subject("TC_GSM_GCUR_04"), Tags("REP_GlobalContactsUpdate", "TC_GSM_GCUR_04")]
    public class TC_GSM_GCUR_04_Verify_correct_appearance_of_removed_and_added_global_contacts_in_Global_Contacts_Update_Report : AfWebTest
    {
        #region Variables
        protected static GsmNavigationPage GsmNavigation;
        protected static FundGlobalContactsUpdateReport GlobalContactsUpdateReport;
        protected static GlobalContactsPage GlobalContacts;

        private const string IM_COMPANY_NAME = "TC_GSM_GCUR_04_IM";
        private const string PB_COMPANY_NAME = "TC_GSM_GCUR_04_PB";
        private const string ADM_COMPANY_NAME = "TC_GSM_GCUR_04_ADM";
        private const string AUD_COMPANY_NAME = "TC_GSM_GCUR_04_AUD";
        private const string LEGAL_COMPANY_NAME = "TC_GSM_GCUR_04_L";
        private const string OTHER_COMPANY_NAME = "TC_GSM_GCUR_04_O";
        
        private const string IM_OFFICE_NAME_1 = "TC_GSM_GCUR_04_IM_Office_1";
        private const string PB_OFFICE_NAME_1 = "TC_GSM_GCUR_04_PB_Office_1";
        private const string ADM_OFFICE_NAME_1 = "TC_GSM_GCUR_04_ADM_Office_1";
        private const string AUD_OFFICE_NAME_1 = "TC_GSM_GCUR_04_AUD_Office_1";
        private const string LEGAL_OFFICE_NAME_1 = "TC_GSM_GCUR_04_L_Office_1";
        private const string OTHER_OFFICE_NAME_1 = "TC_GSM_GCUR_04_O_Office_1";

        private const string IM_OFFICE_NAME_2 = "TC_GSM_GCUR_04_IM_Office_2";
        private const string PB_OFFICE_NAME_2 = "TC_GSM_GCUR_04_PB_Office_2";
        private const string ADM_OFFICE_NAME_2 = "TC_GSM_GCUR_04_ADM_Office_2";
        private const string AUD_OFFICE_NAME_2 = "TC_GSM_GCUR_04_AUD_Office_2";
        private const string LEGAL_OFFICE_NAME_2 = "TC_GSM_GCUR_04_L_Office_2";
        private const string OTHER_OFFICE_NAME_2 = "TC_GSM_GCUR_04_O_Office_2";

        private const string IM_CONTACT_NAME_2 = "Person GCUR 04 IM 2";
        private const string PB_CONTACT_NAME_2 = "Person GCUR 04 PB 2";
        private const string ADM_CONTACT_NAME_2 = "Person GCUR 04 ADM 2";
        private const string AUD_CONTACT_NAME_2 = "Person GCUR 04 AUD 2";
        private const string LEGAL_CONTACT_NAME_2 = "Person GCUR 04 L 2";
        private const string OTHER_CONTACT_NAME_2 = "Person GCUR 04 O 2";

        private const string CITY = "Kiev";

        private static List<FundGlobalContactUpdateReportData> investmentManagersList;
        private static List<FundGlobalContactUpdateReportData> primaryBrokersList;
        private static List<FundGlobalContactUpdateReportData> administratorsList;
        private static List<FundGlobalContactUpdateReportData> auditorsList;
        private static List<FundGlobalContactUpdateReportData> legalList;
        private static List<FundGlobalContactUpdateReportData> otherList;

        private static string FUND = "TC_GSM_GCUR_04";
        #endregion

        Because _of = () =>
        {
            GsmNavigation = UserAction.LoginAsGsmManager();
            
            var gsm = GsmNavigation.GoToGsm();
            gsm.SelectFund(FUND);
            GlobalContacts = gsm.GoToGlobalContacts();

            var imCompanyNameFull = GlobalContacts.GetFullCompanyName(IM_COMPANY_NAME, IM_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.InvestmentManagers, imCompanyNameFull);

            var pbCompanyNameFull = GlobalContacts.GetFullCompanyName(PB_COMPANY_NAME, PB_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.PrimeBrokers, pbCompanyNameFull);

            var admCompanyNameFull = GlobalContacts.GetFullCompanyName(ADM_COMPANY_NAME, ADM_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Administrators, admCompanyNameFull);

            var audCompanyNameFull = GlobalContacts.GetFullCompanyName(AUD_COMPANY_NAME, AUD_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Auditors, audCompanyNameFull);

            var legalCompanyNameFull = GlobalContacts.GetFullCompanyName(LEGAL_COMPANY_NAME, LEGAL_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Legal, legalCompanyNameFull);

            var otherCompanyNameFull = GlobalContacts.GetFullCompanyName(OTHER_COMPANY_NAME, OTHER_OFFICE_NAME_1, CITY);
            GlobalContacts.DeleteCompany(GlobalContactsPage.CompanyType.Other, otherCompanyNameFull);
            GsmNavigation.MakeLogout();

            GsmNavigation = UserAction.LoginAsGsmManager(GsmApprover);
            
            gsm = GsmNavigation.GoToGsm();
            gsm.SelectFund(FUND);
            GlobalContacts = gsm.GoToGlobalContacts();
            GlobalContacts.ApproveCompany(CompanyType.ALL);

            var imFullOfficeName = GlobalContacts.GetFullOfficeName(IM_OFFICE_NAME_2, CITY);
            imCompanyNameFull = GlobalContacts.GetFullCompanyName(IM_COMPANY_NAME, IM_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.InvestmentManagers, IM_COMPANY_NAME, imFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.InvestmentManagers, imCompanyNameFull, IM_CONTACT_NAME_2);

            var pbFullOfficeName = GlobalContacts.GetFullOfficeName(PB_OFFICE_NAME_2, CITY);
            pbCompanyNameFull = GlobalContacts.GetFullCompanyName(PB_COMPANY_NAME, PB_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.PrimeBrokers, PB_COMPANY_NAME, pbFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.PrimeBrokers, pbCompanyNameFull, PB_CONTACT_NAME_2);

            var admFullOfficeName = GlobalContacts.GetFullOfficeName(ADM_OFFICE_NAME_2, CITY);
            admCompanyNameFull = GlobalContacts.GetFullCompanyName(ADM_COMPANY_NAME, ADM_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.Administrators, ADM_COMPANY_NAME, admFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.Administrators, admCompanyNameFull, ADM_CONTACT_NAME_2);

            var audFullOfficeName = GlobalContacts.GetFullOfficeName(AUD_OFFICE_NAME_2, CITY);
            audCompanyNameFull = GlobalContacts.GetFullCompanyName(AUD_COMPANY_NAME, AUD_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.Auditors, AUD_COMPANY_NAME, audFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.Auditors, audCompanyNameFull, AUD_CONTACT_NAME_2);

            var legalFullOfficeName = GlobalContacts.GetFullOfficeName(LEGAL_OFFICE_NAME_2, CITY);
            legalCompanyNameFull = GlobalContacts.GetFullCompanyName(LEGAL_COMPANY_NAME, LEGAL_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.Legal, LEGAL_COMPANY_NAME, legalFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.Legal, legalCompanyNameFull, LEGAL_CONTACT_NAME_2);

            var otherFullOfficeName = GlobalContacts.GetFullOfficeName(OTHER_OFFICE_NAME_2, CITY);
            otherCompanyNameFull = GlobalContacts.GetFullCompanyName(OTHER_COMPANY_NAME, OTHER_OFFICE_NAME_2, CITY);
            GlobalContacts.AddOffice(GlobalContactsPage.CompanyType.Other, OTHER_COMPANY_NAME, otherFullOfficeName);
            GlobalContacts.AddContact(GlobalContactsPage.CompanyType.Other, otherCompanyNameFull, OTHER_CONTACT_NAME_2);

            GlobalContactsUpdateReport = GsmNavigation.GoToFundGlobalContactsUpdateReport();
            investmentManagersList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.INVESTMENT_MANAGERS];
            primaryBrokersList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.PRIME_BROKERS];
            administratorsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.ADMINISTRATORS];
            auditorsList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.AUDITORS];
            legalList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.LEGAL];
            otherList = GlobalContactsUpdateReport.GlobalContactReportGrid[FUND, CompanyType.OTHER];
        };

        private It _01_Investment_manager_contacts_listed_as_expected = () =>
        {
            var expectedInvestmentManagersList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME_2,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(IM_COMPANY_NAME,IM_OFFICE_NAME_2,CITY),
                        ContactPerson = IM_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            investmentManagersList.ShouldEqual(expectedInvestmentManagersList);
        };

        private It _02_Primary_brokers_contacts_listed_as_expected = () =>
        {
            var expectedPrimaryBrokersList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME_2,CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(PB_COMPANY_NAME,PB_OFFICE_NAME_2,CITY),
                        ContactPerson = PB_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            primaryBrokersList.ShouldEqual(expectedPrimaryBrokersList);
        };

        private It _03_Administrators_contacts_listed_as_expected = () =>
        {
            var expectedAdministratorsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME, ADM_OFFICE_NAME_2, CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(ADM_COMPANY_NAME, ADM_OFFICE_NAME_2, CITY),
                        ContactPerson = ADM_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            administratorsList.ShouldEqual(expectedAdministratorsList);
        };

        private It _04_Auditors_contacts_listed_as_expected = () =>
        {
            var expectedAuditorsList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME, AUD_OFFICE_NAME_2, CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(AUD_COMPANY_NAME, AUD_OFFICE_NAME_2, CITY),
                        ContactPerson = AUD_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            auditorsList.ShouldEqual(expectedAuditorsList);
        };
        
        private It _05_Legal_contacts_listed_as_expected = () =>
        {
            var expectedLegalList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME, LEGAL_OFFICE_NAME_2, CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(LEGAL_COMPANY_NAME, LEGAL_OFFICE_NAME_2, CITY),
                        ContactPerson = LEGAL_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            legalList.ShouldEqual(expectedLegalList);
        };

        private It _06_Other_contacts_listed_as_expected = () =>
        {
            var expectedOtherList = new List<FundGlobalContactUpdateReportData>()
            {
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME, OTHER_OFFICE_NAME_2, CITY),
                        ContactPerson = FundGlobalContactUpdateReportData.EMPTY_VALUE,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    },
                new FundGlobalContactUpdateReportData(FUND)
                    {
                        CompanyAndOffice = NamingConvention.ComposeCompanyOfficeCity(OTHER_COMPANY_NAME, OTHER_OFFICE_NAME_2, CITY),
                        ContactPerson = OTHER_CONTACT_NAME_2,
                        Action = ContactActionType.ADDED,
                        Status = ContactStatusType.PENDING_APPROVAL
                    }
            };
            otherList.ShouldEqual(expectedOtherList);
        };

        private Cleanup _cleanup = () => { };
    }
}