﻿using Autofac;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.CloudServices.CentralPricing;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CentralPricing;
using IFS.BusinessLayer.Loader;
using IFS.DataAccess.Entity;
using IFS.DbRepository;
using IFS.Interfaces.DbRepository;

namespace IFS.BusinessLayer.AutoFac
{
    public class GsmCpCommonRegistrations: Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Sequence Providers
            builder.RegisterType<GenericSequenceProvider<SecurityPricingAttachmentSequenceData>>().AsSelf().AsImplementedInterfaces();
            builder.RegisterType<GenericSequenceProvider<SecurityPricingSequenceData>>().AsSelf().AsImplementedInterfaces();
            builder.RegisterType<GenericSequenceProvider<SecurityPricingGroupSequenceData>>().AsSelf().AsImplementedInterfaces();
            builder.RegisterType<GenericSequenceProvider<SecurityPricingAttachmentGroupSequenceData>>().AsSelf().AsImplementedInterfaces();
            #endregion

            builder.RegisterType<CentralPricingGridFactory>().AsSelf();
            builder.RegisterType<CentralPricingDataProviderFactory>().AsSelf();

            builder.Register(c => new SecurityPricingFactory(
                c.Resolve<SecurityPricingGroupRepository>(),
                c.Resolve<GenericSequenceProvider<SecurityPricingGroupSequenceData>>(), 
                c.Resolve<GenericSequenceProvider<SecurityPricingAttachmentGroupSequenceData>>(),
                Organization.Loader,
                InvestableFund.Loader)).AsSelf();

            builder.Register(c => 
                new SecurityPricingGroupRepository(
                    c.Resolve<ISecurityPricingGroupDbRepository>(),
                    c.Resolve<GenericSequenceProvider<SecurityPricingGroupSequenceData>>()))
                .AsSelf().As<SecurityPricingGroupRepository>();
            builder.RegisterType<SecurityPricingGroupDbRepository>().As<ISecurityPricingGroupDbRepository>();


            builder.RegisterType<SecurityPricingAttachmentDbRepository>().AsSelf().As<ISecurityPricingAttachmentDbRepository>();
            builder.RegisterType<SecurityPricingAttachmentLoader>().AsSelf().As<ISecurityPricingAttachmentLoader>().SingleInstance();

            builder.RegisterType<SecurityPricingDbRepository>().AsSelf().As<ISecurityPricingDbRepository>();

            builder.RegisterType<SecurityPricingRepository>().AsSelf().As<ISecurityPricingRepository>();
            builder.RegisterType<DbUpdateNotifier>().AsSelf().As<ICacheUpdateNotifier>();

            builder.RegisterType<SecurityPricingStore>().AsSelf().As<ISecurityPricingStore>().SingleInstance();
        }
    }
}
