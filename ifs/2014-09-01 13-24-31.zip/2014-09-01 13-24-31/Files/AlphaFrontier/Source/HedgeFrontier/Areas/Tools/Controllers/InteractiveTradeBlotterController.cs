﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using IFS.BusinessLayer;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using IFS.Interfaces.CloudContracts.Tools;

namespace HedgeFrontier.Areas.Tools.Controllers
{
    public class InteractiveTradeBlotterController: Controller
    {
        private ITradeBlotterService TradeBlotterService
        {
            get
            {
                return SpringUtil.GetObject<ITradeBlotterService>(ServiceNames.TRADE_BLOTTER_SERVICE_SPRING_NAME);
            }
        }

        private CBaseSession IfsSession
        {
            get
            {
                return (CBaseSession)System.Web.HttpContext.Current.Session["IFS_SESSION"];
            }
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetPageData()
        {
            var parameters = new ItbPageParameters { PortfolioIds = IfsSession.SelectedPortfolioId.ToList()};
            var pageData = TradeBlotterService.GetPageData(parameters, CSession.GetSessionData());
            return Json(new { pageData, SelectedPortfolioIds = parameters.PortfolioIds });
        }

        [HttpPost]
        public ActionResult GenerateGrid(ItbPageParameters parameters)
        {
            var result = TradeBlotterService.GenerateGrid(parameters, CSession.GetSessionData());
            return Content(result.ReportXml);
        }

        
        public class GridChange
        {
            public GridParams IO { get; set; }
            public List<Dictionary<string, string>> Changes { get; set; }
        }

        public class GridParams
        {
            public string GridId { get; set; }
            public int ChecklistId { get; set; }
        }

        [HttpPost]
        public ActionResult UpdateGrid(List<GridChanges> gridChanges)
        {
            var result = TradeBlotterService.ProcessGridChanges(gridChanges, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return Json(result.Value);
        }
    }
}