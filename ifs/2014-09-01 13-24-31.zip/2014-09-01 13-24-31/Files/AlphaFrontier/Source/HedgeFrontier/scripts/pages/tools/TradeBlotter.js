﻿(function () {
    var appUrl = "/" + location.pathname.split("/")[1];
    var baseUrl = appUrl +  "/pages/tools/InteractiveTradeBlotter/";

    $(document).ready(loadPage);

    function loadPage() {
        $.ajax({
            type: "POST",
            url: baseUrl + "GetPageData",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (result) {
                setupControls(result.pageData, result.SelectedPortfolioIds);
            },
            error: function (msg) {
                alert(msg);
            }
        });
    }

    function setupControls(pageData, selectedPortfolioIds) {
        setupPortfolios(pageData.Portfolios, selectedPortfolioIds);
        setupDateFilters();
        setupChecklistTypes(pageData.ChecklistTypes);
        setupTabs(pageData.Tabs);
        createGrid(pageData.GridContent);
        setupSaveButton();
    }

    function setupPortfolios(portfolios, selectedPortfolioIds) {
        var settings = {
            Id: "SelectedPortfolioIds",
            IsSingleSelectionMode: false,
            IsHeaderVisible: true,
            IsDisplayLastSelectedOnUncheckAll: false,
            IsOpenListUpwards: false,
            AutoPostBack: true,
            Filtered: false,
            DataValueField: "Id",
            DataTextField: "Name",
            DataSource: portfolios,
            OnSelectionChanged: function(ddown) {
                reloadGridData(ddown.val());
            }
        };
        var portfolioMultiselect = new MultiselectControl();
        portfolioMultiselect.Init(settings);
        portfolioMultiselect.Select(selectedPortfolioIds);
    }

    function setupDateFilters() {
        var dateTo = $('#DateTo');
        var dateFrom = $('#DateFrom');

        var dateFromControl = new DatePickerControl(dateFrom, $('#DateError'));
        dateFromControl.ShouldBeLessThan(dateTo);
        var dateToControl = new DatePickerControl(dateTo, $('#DateError'));
    }

    function setupChecklistTypes(checklistTypesData) {
        var checklistTypes = $("#SelectedChecklistType");
        $.each(checklistTypesData, function(i, checklistType) {
            var option = $('<option>', {
                value: checklistType,
                text: checklistType
            });
            checklistTypes.append(option);
        });
    }

    function setupTabs(tabsData) {
        var tabs = $("#tabs");
        $.each(tabsData, function(i, tabName) {
            var entry = $('<li>').append(
                $('<a>', {
                    id: tabName.replace(/ /g, ''),
                    text: tabName
                })
            );
            tabs.append(entry);
        });
    }

    function createGrid(content) {
        var gridParams = new TDataIO();
        gridParams.Layout.Url = appUrl + "/pages/tools/TradeBlotterMasterGrid.xml";
        gridParams.Text.Url = appUrl + "/Grid/Text.xml";

        gridParams.Upload.Url = baseUrl + "UpdateGrid";
        gridParams.Upload.Sync = true;
        gridParams.Upload.Format = "JSON";

        Grids.OnValueChanged = function (grid, row, col, val) {
            var cellType = grid.Cols[col].Type;
            if (cellType == "Date")
                row[col + "Format"] = "MM/dd/yyyy";
            else {
                row[col + "Format"] = "!!!!!!";
            }
            return val;
        };

        gridParams.Data.Data = content;
        TreeGrid(gridParams, "divScrolling");

    }

    function setupSaveButton() {
        $("#btnSave").on("click", function() {

            var mainGrid = Grids[0];
            if (mainGrid.HasChanges()) {
                $.ajax({
                    type: "POST",
                    url: baseUrl + "UpdateGrid",
                    contentType: "application/json; charset=utf-8",
                    data: getChanges(),
                    success: updateGrids,
                    error: function (msg) {
                        alert(msg);
                    }
                });
            }

            function getChanges() {
                var gridsChanges = new Array();
                for (var i = 1; i < Grids.length; i++) {
                    var childGrid = Grids[i];
                    if (childGrid.HasChanges()) {
                        childGrid.Data.Upload.Format = "JSON";
                        var gridChange = JSON.parse(childGrid.GetChanges());
                        gridChange.IO.GridId = childGrid.id;
                        var rowId = gridChange.Changes[0].id;
                        gridChange.IO.ChecklistId = rowId.substring(rowId.lastIndexOf["$"]);
                        gridsChanges.push(gridChange);
                    }
                }
                return JSON.stringify(gridsChanges);
            }


            function updateGrids(result) {
                $.each(result, function(i, change) {
                    var childGrid = Grids[change.IO.GridId];
                    childGrid.AddDataFromServer(JSON.stringify(change));
                });
                Grids[0].AcceptChanges();
            }
        });
    }

    function reloadGridData(selectedPortfolioIds) {
        var filters = { "PortfolioIds": selectedPortfolioIds };
        $.ajax({
            type: "POST",
            url: baseUrl + "GenerateGrid",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(filters),
            success: function (result) {
                reloadGrid(result);
            },
            error: function (msg) {
                alert(msg);
            }
        });

        function reloadGrid(content) {
            var grid = Grids[0];
            var gridParams = grid.Data;
            gridParams.Data = { Data: content };
            grid.Reload(null, "");
        }
    }
})()