﻿using System;
using System.Diagnostics;
using System.IO;
using IFS.BusinessLayer.AttributesFramework;
using IFS.BusinessLayer.FundProperty;
using IFS.BusinessLayer.XmlMapping;
using IFS.Interfaces.Rounding;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.XmlMapping
{
    [TestFixture]
    public class XmlSerializersFactoryTests
    {
        [Test]
        public void TestFactoryReturnsSerializerAndItIsNotNull()
        {
            var serializer = XmlSerializersFactory.GetSerializer(typeof(XmlInvestableFundProperties));
            Assert.That(serializer, Is.Not.Null);
        }

        [Test]
        public void TestFactoryReturnsTheSameReference()
        {
            var serializer1 = XmlSerializersFactory.GetSerializer(typeof(XmlInvestableFundProperties));
            var serializer2 = XmlSerializersFactory.GetSerializer(typeof(XmlInvestableFundProperties));
            Assert.That(serializer1, Is.SameAs(serializer2));
        }

        [Test]
        public void TestFactoryReturnsSerializerForXmlFundPropertiesBase()
        {
            var serializer = XmlSerializersFactory.GetSerializer(typeof(XmlFundPropertiesBase));
            Assert.That(serializer, Is.Not.Null);
        }

        [Serializable]
        public class SampleSerializableClass
        {
            
        }

        [Test]
        public void TestFactoryReturnsSerializerForTheUnknownType()
        {
            var serializer = XmlSerializersFactory.GetSerializer(typeof(SampleSerializableClass));
            Assert.That(serializer, Is.Not.Null);
        }

        [Test]
        public void TestFactoryReturnsTheSameSerializerForTheUnknownType()
        {
            var serializer1 = XmlSerializersFactory.GetSerializer(typeof(SampleSerializableClass));
            var serializer2 = XmlSerializersFactory.GetSerializer(typeof(SampleSerializableClass));
            Assert.That(serializer1, Is.SameAs(serializer2));
        }

        [Test]
        [Ignore]
        public void TestXmlSerializerPerformanceForSimpleHierarchy()
        {
            const string str = "<InvestableFundProperties><GsmLastOfferPrice>1.2345</GsmLastOfferPrice><IR>234.5678</IR><OC>1.23</OC><Anton>1</Anton></InvestableFundProperties>";
            var s = XmlSerializersFactory.GetSerializer(typeof (XmlInvestableFundProperties));
            var p = (XmlInvestableFundProperties)s.Deserialize(new StringReader(str));
            Assert.That(p.GsmLastOfferPriceDouble, Is.EqualTo(1.2345));
            Assert.That(p.InitialReturn, Is.EqualTo(234.5678));
            Assert.That(p.OriginalCommitment, Is.EqualTo(new CAmount(1.23)));
            var timer = new Stopwatch();
            timer.Start();
            for(int i = 0; i < 1000; i++)
                s.Deserialize(new StringReader(str));
            timer.Stop();
            Console.WriteLine(@"Time Spent: " + timer.Elapsed.TotalSeconds);
            Assert.That(timer.ElapsedMilliseconds, Is.LessThan(50));
        }

        [Test]
        [Ignore]
        public void TestXmlSerializerPerformanceForComplexHierarchy()
        {//started with 0.446 for 100 iterations
            var path = IfsAttributeFactory.GetAttributesFilePath();
            var atts = XmlSerializersFactory.GetSerializer(typeof(IfsAttributes)).Deserialize(new FileStream(path, FileMode.Open, FileAccess.Read));
            Assert.That(atts, Is.Not.Null);
            var timer = new Stopwatch();
            timer.Start();
            for (int i = 0; i < 10; i++)
                XmlSerializersFactory.GetSerializer(typeof(IfsAttributes)).Deserialize(new FileStream(path, FileMode.Open, FileAccess.Read));
            timer.Stop();
            Console.WriteLine(@"Time Spent: " + timer.Elapsed.TotalSeconds);
            Assert.That(timer.ElapsedMilliseconds, Is.LessThan(200));
        }
    }
}
