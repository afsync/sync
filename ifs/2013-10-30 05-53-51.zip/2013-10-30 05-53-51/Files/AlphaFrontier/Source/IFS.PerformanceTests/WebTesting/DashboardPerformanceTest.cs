﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using DashboardPerformanceTests;
using NUnit.Framework;

namespace DashboardPerformanceTests
{
    [TestFixture, Explicit]
    public class DashboardPerformanceTest
    {
        private void SingleThreadTestRunner(DashboardInvoker invoker, int iterations)
        {
            var runner = new Runner(invoker, iterations);
            Console.WriteLine("Logon ...");
            runner.Initialize();
            Console.WriteLine("Starting iterations ...");
            runner.Run();
            Console.WriteLine("{0}  Avg. response time = {1}", invoker.DashboardAddress, runner.AvgConstructTime);
            Console.WriteLine("{0}  Avg. response time = {1}", invoker.XmlAddress,  runner.AvgXmlTime);
        }

        private void MultiThreadTestRunner(Func<DashboardInvoker> invokerFactory, int threadCount, int iterations)
        {
            var runners = new Runner[threadCount];
            var threads = new Thread[runners.Length];
            Console.WriteLine("Initializing");
            for (int i = 0; i < runners.Length; i++)
            {
                runners[i] = new Runner(invokerFactory(), iterations);
                runners[i].Initialize();
                threads[i] = new Thread(runners[i].Run);
            }
            Console.WriteLine("Starting threads");
            for (int i = 0; i < runners.Length; i++)
                threads[i].Start();
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            for (int i = 0; i < runners.Length; i++)
               threads[i].Join();
            stopWatch.Stop();

            var invoker = invokerFactory();
            Console.WriteLine("Avg time per request = {0}", new TimeSpan( stopWatch.ElapsedTicks/threadCount/iterations));
            Console.WriteLine("{0}: Avg resp time per request = {1}", invoker.DashboardAddress, new TimeSpan((long)runners.Select(i => i.AvgConstructTime.Ticks).Average()));
            Console.WriteLine("{0}: Avg resp time per request = {1}", invoker.XmlAddress, new TimeSpan((long)runners.Select(i => i.AvgXmlTime.Ticks).Average()));
        }

        [Test]
        [Ignore]
        public void SingleThreadTest()
        {
            var invokers = new DashboardInvoker[]
                               {
                                   new CloudInvoker(@"http://localhost/HedgeFrontier", 76),
                                   new OriginalInvoker(@"http://localhost/HedgeFrontier", 76)
                               };

            foreach (var dashboardInvoker in invokers)
            {
                SingleThreadTestRunner(dashboardInvoker, 20);
            }
        }

        [Test]
        [Ignore]
        public void MultiThreadTest()
        {
            var invokers = new Func<DashboardInvoker>[]
                               {
                                   () => new CloudInvoker(@"http://localhost/HedgeFrontier", 76),
                                   () => new OriginalInvoker(@"http://localhost/HedgeFrontier", 76)
                               };

            foreach (var dashboardInvoker in invokers)
            {
                MultiThreadTestRunner(dashboardInvoker, 24, 10);
            }
        }
    }
}
