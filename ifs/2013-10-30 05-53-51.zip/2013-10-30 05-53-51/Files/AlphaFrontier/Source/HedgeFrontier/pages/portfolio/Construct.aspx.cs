using System;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using HedgeFrontier;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.IFSUser.userPreferences;
using IFS.BusinessLayer.Launchpad;
using IFS.BusinessLayer.Loader;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.Common.Enums;
using WebUtilities;
using System.Web.Services;
using IFS.BusinessLayer.AttributesFramework;
using IFS.BusinessLayer.Utilities;
using Common.Logging;

namespace pages.portfolio
{
    public partial class Construct : CBasePage
    {
        private static readonly ILog _log = LogManager.GetLogger("IFS");

        #region Members
        private bool _hasLayoutsChanged;
        private bool _menuColumnsChanged;
        private bool _recalculate;

        private IDashboardService DashboardService 
        {
            get { return SpringUtil.GetObject<IDashboardService>(ServiceNames.DASHBOARD_SERVICE_SPRING_NAME); }
        }

        public int PortfolioId
        {
            get
            {
                var selectedId = IsPostBack ? ddlPortfolios.SelectedItems : IFSSession.SelectedPortfolioId;
                var selectedIdCount = selectedId.Count();
                if (selectedIdCount > 1)
                {
                    //If no select Data (Unselect all)
                    if (!ddlPortfolios.SelectedItems.Any())
                        return -1;

                    // If selected more that one items
                    return 0;
                }
                // If selected one items
                if (1 == selectedIdCount)
                    return ddlPortfolios.SelectedItems.FirstOrDefault();
                // If no selected items
                return -1;
            }
        }

        double MAR
        {
            get { return !string.IsNullOrEmpty(txtMAR.Text) ? Convert.ToDouble(txtMAR.Text) : Analytics.MAR_DEFAULT; }
        }
        double RiskFreeRate
        {
            get
            {
                return string.IsNullOrEmpty(txtRiskFreeRate.Text)
                           ? Analytics.RISK_FREE_RATE_DEFAULT
                           : Convert.ToDouble(txtRiskFreeRate.Text);
            }
        }

        public int GlobalBenchmarkId
        {
            get
            {
                if (ctrlBenchmark.Value.Equals(-1))
                    SetGlobalBenchmark(IFSSession.Portfolio);
                return ctrlBenchmark.Value;
            }
        }

        public EReturnType ReturnType
        {
            get { return (EReturnType)CDropDown.GetInt(ddlReturnType); }
            set { CDropDown.SetValue(ddlReturnType, (int)value); }
        }

        public DateTime ValuationStartDate
        {
            get
            {
                DateTime valuationStartDate;
                DateTime.TryParse(ddlFromDate.SelectedValue, out valuationStartDate);
                return valuationStartDate;
            }
            set
            {
                ddlFromDate.SelectedValue = value.ToShortDateString();
            }
        }

        public DateTime ValuationEndDate
        {
            get
            {
                DateTime valuationEndDate;
                DateTime.TryParse(ddlToDate.SelectedValue, out valuationEndDate);
                return valuationEndDate;
            }
            set
            {
                ddlToDate.SelectedValue = value.ToShortDateString();
            }
        }

        public string RequestAggReturnsCode(Portfolio p)
        {
            string s = p.PortfolioName;
            if (null != p.Parent)
                s += p.Parent.PortfolioName;
            return s.Trim();
        }

        public string RequestAggReturns
        {
            get
            {
                string s = Request["requestAggReturns"];
                if (null == s)
                    return string.Empty;
                return s;
            }
        }

        private static List<Layout> Layouts
        {
            get { return IFSSession.Layouts; }
        }

        private static List<Layout> SharedLayouts
        {
            get { return IFSSession.SharedLayouts; }
        }

        private List<IfsAttribute> _attributes;
        private IEnumerable<IfsAttribute> Attributes
        {
            get { return _attributes ?? (_attributes = IFSSession.CurrentLayout.LayoutProperties.OrderedAttributes()); }
        }

        private static List<string> AggregationKeys
        {
            get { return CurrentLayout.LayoutProperties.AggregationKeys; }
            set { CurrentLayout.LayoutProperties.AggregationKeys = value; }
        }

        private static bool HideInvestmentLevel
        {
            get { return CurrentLayout.LayoutProperties.HideInvestmentLevel; }
            set { CurrentLayout.LayoutProperties.HideInvestmentLevel = value; }
        }

        private static bool ShowTransactions
        {
            get { return CurrentLayout.LayoutProperties.ShowTransactions; }
            set { CurrentLayout.LayoutProperties.ShowTransactions = value; }
        }

        private static bool ShowHistory
        {
            get { return CurrentLayout.LayoutProperties.ShowHistory; }
            set { CurrentLayout.LayoutProperties.ShowHistory = value; }
        }

        private static Layout CurrentLayout
        {
            get { return IFSSession.CurrentLayout; }
        }

        private static bool ShowFullyRedeemed
        {
            get { return CurrentLayout.LayoutProperties.ShowFullyRedeemedInvestments; }
            set { CurrentLayout.LayoutProperties.ShowFullyRedeemedInvestments = value; } 
        }

        private static bool LocalCurrency
        {
            get { return CurrentLayout.LayoutProperties.LocalCurrency; }
            set { CurrentLayout.LayoutProperties.LocalCurrency = value; }
        }

        private static bool ShowCurrency
        {
            get { return CurrentLayout.LayoutProperties.ShowCurrency; }
            set { CurrentLayout.LayoutProperties.ShowCurrency = value; }
        }

        private static bool LookThroughView
        {
            get { return CurrentLayout.LayoutProperties.LookThroughView; }
            set { CurrentLayout.LayoutProperties.LookThroughView = value; }
        }

        private static bool ShowShortNames
        {
            get { return CurrentLayout.LayoutProperties.ShowShortNames; }
            set { CurrentLayout.LayoutProperties.ShowShortNames = value; }
        }

        private static bool UseTradeDate
        {
            get { return CurrentLayout.LayoutProperties.UseTradeDate; }
            set { CurrentLayout.LayoutProperties.UseTradeDate = value; }
        }

        private static bool ViewLockdownSnapshot
        {
            get { return CurrentLayout.LayoutProperties.ViewLockdownSnapshot; }
            set
            {
                CurrentLayout.LayoutProperties.ViewLockdownSnapshot = value;
                //TODO below value is used by ClientLevelPortfoliosSnapshot() in Portfolio.cs
                CSession.ViewLockdownSnapshot = value; 
            }
        }

        private static bool CalculateOnFilter 
        {
            get { return CurrentLayout.LayoutProperties.CalculateOnFilter; }
            set { CurrentLayout.LayoutProperties.CalculateOnFilter = value; }
        }

        private static CSearch DashboardFilter
        {
            get { return CurrentLayout.LayoutProperties.Filter; }
            set { CurrentLayout.LayoutProperties.Filter = value; }
        }
        
        private DateTime SessionValuationStartDate
        {
            get
            {
                DateTime valuationStartDate;
                CSession.ValuationStartDates.TryGetValue(PortfolioId, out valuationStartDate);
                return valuationStartDate;
            }
            set
            {
                if (CSession.ValuationStartDates.ContainsKey(PortfolioId))
                    CSession.ValuationStartDates[PortfolioId] = value;
                else
                    CSession.ValuationStartDates.Add(PortfolioId, value);
            }
        }

        private DateTime SessionValuationEndDate
        {
            get
            {
                DateTime valuationEndDate;
                CSession.ValuationEndDates.TryGetValue(PortfolioId, out valuationEndDate);
                return valuationEndDate;
            }
            set
            {
                if (CSession.ValuationEndDates.ContainsKey(PortfolioId))
                    CSession.ValuationEndDates[PortfolioId] = value;
                else
                    CSession.ValuationEndDates.Add(PortfolioId, value);
            }
        }

        private static bool IsCurrentLayoutsIsShared()
        {
            return null != SharedLayouts.Find(sl => sl.LayoutId == IFSSession.CurrentLayoutId);
        }   

        public bool PortfolioIsTradeExecution
        {
            get { return IFSSession.Portfolio.IsTradeExecution; }
        }

        public bool ShowOmittedPortsDiv { get; set; }

        protected bool ClientSupportsGSM
        {
            get { return Organization.Loader.GetById(CSession.CurrentOrganization.OrganizationID).SupportGsm; }
        }

        #endregion

        #region Event Handlers

        #region Page Events
        protected void Page_Init(object sender, EventArgs e)
        {
            CheckAccessRight(Component.PORTFOLIOS_CONSTRUCT);
        }
      //  Stopwatch watch = new Stopwatch();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack && Request.Params["xml"] == "true")
            {
                WriteXmlResponse();
                return;
            }

            _log.Debug("Beginning Dashboard Page_load");
            //TODO: Move all logic from PopulateOptionsControls(); to business layer
            ((SeriesLoader)Series.Loader).PutAllEmptySeriesIdIntoRequestCache(CSession.CurrentOrganization.Id); //

            if (!Page.IsPostBack)
            {
                //watch.Start();
                SetPortfolio();
                SetSessionValuesAtFirstLoad();
                //SetSessionCache();

                //Show Layouts
                PopulateLayoutDroupdown();
                PopulatePortfolioDropdown(ddlPortfolios);
                PopulateOptionsControls();
                SetDashboardControls();
                PopulateReturnTypeLabel();
            }

            if (SessionValuationEndDate == DateTime.MinValue)
            {
                SessionValuationEndDate = ValuationEndDate;
            }
            _log.Debug("Finished Dashboard Page_load");
        }


        protected void Page_PreRender(object sender, EventArgs e)
        {
            _log.Debug("Beginning Dashboard Page_PreRender");

            //Put state into layout session
            
            if (!_hasLayoutsChanged)
                SetHiddenVariables(IFSSession.CurrentLayout);
            else
                _hasLayoutsChanged = false;

            Display();
            
            pUltrawebMenu.RenderMode = UpdatePanelRenderMode.Inline;
         //   watch.Stop();
          //  var time = watch.Elapsed.TotalSeconds;
            _log.Debug("Finished Dashboard Page_PreRender");
        }

        protected void BtnSubmitMenuColumnsOnClick(object sender, EventArgs e)
        {
            SyncMenuAndLayoutAttributeList();
            _menuColumnsChanged = true;
        }

        #endregion

        #region Aggregation Events
        protected void btnOptionsSubmit_OnClick(object sender, EventArgs e)
        {
            OnSelectedPortfoliosChanged(ddlOptionsPortfolios);

            string aggKeys = hdnAgg.Value;

            var lstAggKeys = new List<string>();
            if (!string.IsNullOrEmpty(aggKeys))
            {
                string[] split = aggKeys.Split(';');
                lstAggKeys.AddRange(split);
            }
            AggregationKeys = lstAggKeys;
            
            HideInvestmentLevel = chkHideInvestments.Checked;
            ShowTransactions = chkShowTransactions.Checked;
            ShowHistory = chkShowHistory.Checked;
            ShowFullyRedeemed = chkShowFullyRedeemed.Checked;
            LocalCurrency = chkLocalCurrency.Checked;
            ShowCurrency = chkShowCurrency.Checked;
            ShowShortNames = chkShorterHeaders.Checked;
            LookThroughView = chkLookThroughView.Checked;
            UseTradeDate = chkUseTradeDate.Checked;
            ViewLockdownSnapshot = chkNavClose.Checked;
            CalculateOnFilter = chkRecalculateFilteredDashboard.Checked;

            LayoutRemoveColumns(IFSSession.CurrentLayout);

            if (chkShowTradeExecutionOnly.Checked)
            {
                bool isShowTradeExecutionOnly = DashboardFilter != null && DashboardFilter.Filters != null &&
                    DashboardFilter.Filters.Find(f => f.AttributeId == Attrib.ALLOCATION_IS_TRADE_EXECUTION) != null;

                if (!isShowTradeExecutionOnly)
                {
                    var filter = new CSearch();
                    CSearchFilter searchFilter = filter.AddFilter();
                    searchFilter.AttributeId = Attrib.ALLOCATION_IS_TRADE_EXECUTION;
                    searchFilter.Criteria = ESearchCriteria.EQUAL;
                    searchFilter.Boolean = true;
                    DashboardFilter = filter;
                }
            }
            else
                DashboardFilter = null;

            CurrentLayout.LayoutProperties.ReturnType = ReturnType;
            CurrentLayout.LayoutProperties.RiskFreeRate = RiskFreeRate;
            CurrentLayout.LayoutProperties.MarRatio = MAR;
            CurrentLayout.LayoutProperties.GlobalBenchmarkId = ctrlBenchmark.Value;
            //Aggregation keys need to be updated after AggregationKeys are populated from the dashboard
            UpdateAggregationKeys();
            UpdateColumns();
            PopulatePortfolioDropdown(ddlPortfolios);
            DateTime date;
            DateTime.TryParse(txtFromDate.Text, out date);
            SessionValuationStartDate = date;
            DateTime.TryParse(txtToDate.Text, out date);
            SessionValuationEndDate = date;
            //Even though the controls on options dialog are populated here, 
            //their values are set by javascript method "OptionsReset" on the client side
            //This method is called to update the hidden variables associated with the controls on the dialog
            PopulateOptionsControls();
            PopulateDates();
            PopulateReturnTypeLabel();
        }
        #endregion

        #region Portfolio Events
        protected void ddlPortfolios_SelectedIndexChanged(object sender, EventArgs e)
        {
            OnSelectedPortfoliosChanged(ddlPortfolios);
            //Aggregation keys need to be updated before SetDashboardControls and PopulateOptionsControls
            UpdateAggregationKeys();

            SetDashboardControls();
            PopulateOptionsControls();
        }

        protected void SetDashboardControls()
        {
            //Setup month/year lists & state        
            Portfolio portfolio = IFSSession.Portfolio;

            tdOpenTrades.Visible = portfolio.HasPendingTradeOrders();
            SetSecurity(portfolio);
            PopulateDates();
        }

        protected void ddlDate_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            SessionValuationStartDate = ValuationStartDate;
            SessionValuationEndDate = ValuationEndDate;
            PopulateOptionsControls();
        }

        protected void btnNewPortfolio_Click(object sender, EventArgs e)
        {
            var portfolioId = int.Parse(hdnPortfolioId.Value);
            IFSSession.PortfolioId = portfolioId;
            PopulatePortfolioDropdown(ddlPortfolios);
        }

       protected void btnRefresh_Click(object sender, EventArgs e)
       {
           _recalculate = true; 
           tdOpenTrades.Visible = IFSSession.Portfolio.HasPendingTradeOrders();
            SetDashboardControls();
            PopulateOptionsControls();
        }

        protected void PopulateOptionsControls()
        {
            PopulatePortfolioDropdown(ddlOptionsPortfolios);
            PopulateReturnTypeDropdown(ddlReturnType);
            PopulateFromDateControl(ddlOptionsFromDate);
            PopulateOptionsToDateControl(ddlOptionsToDate);
            PopulateAggKeysTable();
            PopulateAggregationDropdowns();
            SetHideInvLevelControls();
            SetShowTransactionsControls();
            SetShowHistoryControls();
            SetShowTradeExecutionOnlyControls();
            SetFullyRedeemedInvestmentsControls();
            SetLocalCurrencyControls();
            SetShowCurrencyControls();
            SetLookThroughViewControls();
            SetShorterHeaderControls();
            SetUseTradeDateControls();
            SetUseTradeDateControls();
            SetNavCloseControls();
            SetRecalculateFilteredDashboardControls();
            SetGlobalBenchmark(IFSSession.Portfolio);
            SetMARandRiskFreeRate(IFSSession.Portfolio);
        }

        protected void SetSessionValuesAtFirstLoad()
        {
            if (IFSSession.SelectedPortfolioId != null && IFSSession.SelectedPortfolioId.Any())
            {
                //If user change Portfolio from other place, from Maintain page, for example
                if (IFSSession.SelectedPortfolioId.Count() == 1 && IFSSession.SelectedPortfolioId.FirstOrDefault() != IFSSession.PortfolioId)
                    IFSSession.SelectedPortfolioId = new[] { IFSSession.PortfolioId };
            }
            else if (IFSSession.PortfolioId > 0) // If user create new portfolio for new Client, for example
                IFSSession.SelectedPortfolioId = new[] { IFSSession.PortfolioId };
            else
            {
                var portfolios = CSession.Portfolios;
                var portfolioId = portfolios != null && portfolios.Count > 0 ? portfolios[0].PortfolioID : -1;
                IFSSession.SelectedPortfolioId = portfolioId != -1 ? new[] { portfolioId } : new int[] { };
                IFSSession.PortfolioId = portfolioId;
            }
            UpdateAggregationKeys();
        }

        protected void PopulatePortfolioDropdown(usercontrols_UCMultiselect ucmPortfolios)
        {
            //Load Portfolios List
            ucmPortfolios.DataSource = CSession.Portfolios;
            ucmPortfolios.DataBind();
            SelectPortfolioDropDownItems(ucmPortfolios);
            hdnSelectedPortfolios.Value = String.Join(",", IFSSession.SelectedPortfolioId);
        }

        private void SelectPortfolioDropDownItems(usercontrols_UCMultiselect ucmPortfolios)
        {
            ucmPortfolios.SelectedItems = IFSSession.SelectedPortfolioId;
        }

        protected void OnSelectedPortfoliosChanged(usercontrols_UCMultiselect ucmPortfolios)
        {
            if (!ucmPortfolios.SelectedItems.Any())
                ucmPortfolios.SetDefaultSelectedValue();
            var portfolios = ucmPortfolios.SelectedItems.ToList();
            portfolios.RemoveAll(p => !Portfolio.IsPortfolioAccessibleForUser(p));
            IFSSession.SelectedPortfolioId = portfolios;
            IFSSession.PortfolioId = (portfolios.Count == 1) ? portfolios.FirstOrDefault() : -1;
        }

        private void UpdateAggregationKeys()
        {
            if (LookThroughView)
            {
                if (!AggregationKeys.Contains(Attrib.OWNERSHIP))
                    AggregationKeys.Insert(0, Attrib.OWNERSHIP);
                _imgQuickSearchNew.Attributes["title"] = "Please remove Look Through View on the Tools Menu under Options";
                _quickSerarchNew.Attributes["onclick"] = string.Empty;
            }
            else if(IFSSession.PortfolioId <= 0)
            {
                _imgQuickSearchNew.Attributes["title"] = "Please remove All Portfolios View";
                _quickSerarchNew.Attributes["onclick"] = string.Empty;
            }
            else
            {
                AggregationKeys.Remove(Attrib.OWNERSHIP);
                _imgQuickSearchNew.Attributes["title"] = "Quick-Search for an Investment to Add";
                _quickSerarchNew.Attributes["onclick"] = "Construct_QuickSearchNew()";
            }
        }

        private void UpdateColumns()
        {
            if (ShowTransactions)
                IFSSession.CurrentLayout.LayoutProperties.Columns.AddAfter(Attrib.NAME, Attrib.EFFECTIVE_DATE);
            else
                IFSSession.CurrentLayout.LayoutProperties.Columns.Remove(Attrib.EFFECTIVE_DATE);
        }
        #endregion

        #region Layout Menu
        protected void ddlLayouts_SelectedIndexChanged(object sender, EventArgs e)
        {
            var layout = Layouts[ddlLayouts.SelectedIndex];
            IFSSession.CurrentLayout = layout;
            SetHiddenVariables(layout);
            _hasLayoutsChanged = true;
            //Disable some menu item if current layout is shared (for owner = Delete, Rename, Save, for user = All exclude New...);
            SetLayoutShareMenuForShareLayout();
            SetDashboardControls();
            PopulateOptionsControls();
        }

        protected void btnLayoutDelete_Click(object sender, EventArgs e)
        {
            if (!IsCurrentLayoutsIsShared())
            {
                var layout = IFSSession.CurrentLayout;
                Layouts.Remove(layout);
                Layout.DeleteLayoutWithLayoutShares(layout);
                layout = Layouts[0];
                IFSSession.CurrentLayout = layout;
                SetHiddenVariables(layout);
                _hasLayoutsChanged = true;
                Response.Redirect("~/pages/portfolio/Construct.aspx", true);
            }
        }
        protected void btnLayoutSave_Click(object sender, EventArgs e)
        {
            if (!IsCurrentLayoutsIsShared())
            {
                var layout = IFSSession.CurrentLayout;
                SetHiddenVariables(layout);
                layout.Save();
                _hasLayoutsChanged = true;
            }
        }

        protected void btnLayoutNew_Click(object sender, EventArgs e)
        {
            AddNewLayout(Layout.NewLayout(hdnLayoutName.Value, hdnIsTradeBlotterDefault.Value, LayoutTypes.Dashboard));
        }

        protected void btnLayoutSaveAs_Click(object sender, EventArgs e)
        {
            AddNewLayout(Layout.CopyCurrentLayout(hdnLayoutName.Value, IFSSession.CurrentLayout));
        }

        private void AddNewLayout(Layout layout)
        {
            layout.Save();
            IFSSession.Layouts.Add(layout);
            IFSSession.CurrentLayout = layout;
            Layouts.Sort((x, y) => Comparer<string>.Default.Compare(x.LayoutName, y.LayoutName));
            SetHiddenVariables(IFSSession.CurrentLayout);
            _hasLayoutsChanged = true;
            Response.Redirect("~/pages/portfolio/Construct.aspx", true);
        }

        protected void btnLayoutRename_Click(object sender, EventArgs e)
        {
            if (!IsCurrentLayoutsIsShared())
            {
                var layout = IFSSession.CurrentLayout;
                layout.LayoutName = hdnLayoutName.Value;
                layout.Save();
                Layouts.Sort((x, y) => x.LayoutName.CompareTo(y.LayoutName));
                _hasLayoutsChanged = true;
                Response.Redirect("~/pages/portfolio/Construct.aspx", true);
            }
        }

        private void LayoutRemoveColumns(Layout layoutToEdit)
        {
            string[] attributeIdsRemoved = hdnAttributeIdRemove.Value.Split(',');
            var layoutColumns = layoutToEdit.LayoutProperties.Columns;
            foreach (string attIDRemove in attributeIdsRemoved.Where(a => !string.IsNullOrEmpty(a) && !a.Equals(Attrib.AGG_KEY_BASEFUND)))
            {
                layoutColumns.Remove(attIDRemove);
            }
            SetHiddenVariables(layoutToEdit);
        }

        // Layout methods
        private void PopulateLayoutDroupdown()
        {
            foreach (Layout i in Layouts)
            {
                ddlLayouts.Items.Add(new ListItem(i.LayoutName, i.Id.ToString()));
            }

            if (ddlLayouts.Items.Count == 0)
                ddlLayouts.Items.Add(IFSSession.CurrentLayout.LayoutName);

            if (null != Layouts.FirstOrDefault(l => l.LayoutId == IFSSession.CurrentLayoutId))
                ddlLayouts.SelectedValue = IFSSession.CurrentLayoutId.ToString();

            IFSSession.CurrentLayout = Layouts[ddlLayouts.SelectedIndex];

            //Disable some menu item if current layout is shared (for owner = Delete, Rename, Save);
            SetLayoutShareMenuForShareLayout();
        }

        private void SetLayoutShareMenuForShareLayout()
        {
            var menuManager = new LayoutMenuManager();
           // If current layout is shared ... hide all items in Layout menu exclude "New..." and "Save As..."
            if (IsCurrentLayoutsIsShared())
            {
                menuManager.Save.Hidden = true;
                menuManager.Rename.Hidden = true;
                menuManager.Share.Hidden = true;
                menuManager.Delete.Hidden = true;
            }
            else
            {
                var currentLyaout = IFSSession.CurrentLayout;
                //Set access to Layout menu item in reference to count of current layout shares for other users  
                if (currentLyaout.LayoutSharesCount > 0)
                {
                    //hide Save, Rename and Delete items
                    menuManager.Save.Hidden = true;
                    menuManager.Rename.Hidden = true;
                    menuManager.Delete.Hidden = true;
                }
                // If Current layout name is "Default" or user not allowed to share layouts - disable "Share" menu item
                menuManager.Share.Hidden = currentLyaout.LayoutName.Equals("Default") || !Component.IsAccessible(Component.LAYOUT_SHARE, CSession.User);
            }
            var serializer = new JavaScriptSerializer();
            hdnLayoutMenu.Value = serializer.Serialize(menuManager);
        }

        private void SetHiddenVariables(Layout layOutToUse)
        {
            hdnAttributeId.Value = ",";
            hdnAttributeIdRemove.Value = string.Empty;
            foreach (string attributeId in layOutToUse.LayoutProperties.Columns.AttributeIds)
            {
                if (!layOutToUse.LayoutProperties.AggregationKeys.Contains(attributeId))
                    hdnAttributeId.Value += attributeId + ",";
            }
        }

        [WebMethod(EnableSession = true)]
        public static string AddToLayoutAfter(string prevAttribute, string attributeID)
        {
            Layout layoutToEdit = IFSSession.CurrentLayout;

            layoutToEdit.LayoutProperties.Columns.AttributeIds.Remove(attributeID);

            if (layoutToEdit.LayoutProperties.Columns.AttributeIds.IndexOf(prevAttribute) < 0 ||
                layoutToEdit.LayoutProperties.AggregationKeys.Contains(prevAttribute))
                layoutToEdit.LayoutProperties.Columns.AddAfter(Attrib.NAME, attributeID);
            else
                layoutToEdit.LayoutProperties.Columns.AddAfter(prevAttribute, attributeID);

            var attIdsString = new StringBuilder();
            attIdsString.Append(",");
            foreach (string attID in layoutToEdit.LayoutProperties.Columns.AttributeIds)
            {
                attIdsString.Append(attID).Append(",");
            }
            return attIdsString.ToString();
        }

        [WebMethod(EnableSession = true)]
        public static string RemoveFromLayout(string hdnToRemove)
        {
            string[] attributeIdsRemoved = hdnToRemove.Split(',');
            Layout layoutToEdit = IFSSession.CurrentLayout;

            foreach (string attIDRemove in attributeIdsRemoved)
            {
                if (!string.IsNullOrEmpty(attIDRemove))
                {
                    layoutToEdit.LayoutProperties.Columns.Remove(attIDRemove);
                }
            }
            return string.Empty;
        }

        [WebMethod(EnableSession = true)]
        public static bool ChangeLayoutFilters(string ejsFilterCfg, bool doRefresh)
        {
            var clientSideFilters = Layout.BuildClientSideFilers(ejsFilterCfg);
            Layout layoutToEdit = IFSSession.CurrentLayout;
            layoutToEdit.LayoutProperties.ClientSideFilters = clientSideFilters;
            return doRefresh;
        }
        #endregion

        #region RowMenu
        protected void btnMaintain_Click(object sender, EventArgs e)
        {
            SetFundSessionVars();
            Response.Redirect(string.Format("~/pages/fund/Maintain.aspx?investableFundId={0}", int.Parse(hdnFundId.Value)), true);
        }
        protected void btnAnalysis_Click(object sender, EventArgs e)
        {
            SetFundSessionVars();
            Response.Redirect("~/pages/fund/Analysis.aspx?fromdash=true", true);
        }
        protected void btnReturns_Click(object sender, EventArgs e)
        {
            SetFundSessionVars();
            Response.Redirect("~/pages/fund/Returns.aspx", true);
        }
        protected void btnRollingIrr_Click(object sender, EventArgs e)
        {
            SetFundSessionVars();
            Response.Redirect("~/pages/fund/RollingIrr.aspx", true);
        }
        protected void SetFundSessionVars()
        {
            if (string.IsNullOrEmpty(hdnFundId.Value) || "null".Equals(hdnFundId.Value))// this is summary link
            {
                IFSSession.BaseFundId = -1;
            }
            else
            {
                int fundId = int.Parse(hdnFundId.Value);
                InvestableFund fund = InvestableFund.GetById(fundId);
                IFSSession.BaseFundId = fund.Basefund.FundID;
                if (fund is BaseFund)
                {
                    IFSSession.InvestableFundId = -1;
                }
                else
                {
                    IFSSession.InvestableFundId = fund.FundID;
                }
            }
        }
        #endregion
        #endregion

        #region Private
        private void SetPortfolio()
        {
            int baseFundAsPortdolioId;
            string strFundAsPortfolioId = Request["fapi"];
            if (strFundAsPortfolioId != null && int.TryParse(strFundAsPortfolioId, out baseFundAsPortdolioId))
            {
                BaseFund baseFund = BaseFund.Loader.GetById(baseFundAsPortdolioId);
                if (baseFund != null && baseFund.IsFundPortfolio)
                {
                    if (CSession.Portfolios.GetById(baseFund.FundToPortfolioLink.PortfolioID) == null)
                    {
                        CPopup.Alert(this, "You do not have permissions to view this portfolio. Please contact administrator.");
                    }
                    else
                    {
                        IFSSession.PortfolioId = baseFund.FundToPortfolioLink.PortfolioID;
                    }
                }
            }
        }

        private void SetSecurity(Portfolio p)
        {
            hdnHasAdminAccess.Value = Component.HasFullAccess(Component.ADMIN_USERS_GROUP, CSession.User) ? @"true" : @"false";
            if (p.FundID <= 0)  // when multiple portfolios are selected
            {
                //Variables are needed to be initialized to prevent errors in javascript
                litReadOnlyAllocations.Text = @"false";
                litIsOmsEnabled.Text = @"false";
                litReadOnlysearch.Text = @"false";
            }
            else
            {
                var user = CSession.User;
                litReadOnlyAllocations.Text = Component.IsReadOnly(Component.PORTFOLIOS_CONSTRUCT_ALLOCATIONS, user) ? @"true" : @"false";
                litReadOnlysearch.Text = Component.IsReadOnly(Component.ACCESS_QUICK_SEARCH, user) ? @"true" : @"false";
                litIsOmsEnabled.Text = p.IsTradeExecution && Role.IsClientOmsPreparer(user.UserRoleID) ? @"true" : @"false";
                litAccessDeniedMessage.Text = CPopup.NoAccessMsg;
                litSearchAccessDeniedMessage.Text = CPopup.NoAccessMsg;
            }
        }

        private void Display()
        {
            if (_menuColumnsChanged)
            {
                GenerateGrid(false);
                _menuColumnsChanged = false;
            }
            else
            {
                litIsScenario.Text = "false";

                ConstructDTO constructDto = GenerateGrid(true);
                lblTotalMarketValue.Text = constructDto.MarketValue;

                if (ViewLockdownSnapshot)
                {
                    var omittedNames = constructDto.OmmitedPortfolioNames;
                    if (omittedNames != null && omittedNames.Count > 0)
                    {
                        var sb = new StringBuilder("Following Portfolios are not locked for : ");
                        sb.Append(ValuationEndDate.ToShortDateString()).Append("<BR/>");
                        foreach (string name in omittedNames)
                        {
                            sb.Append(" - ").Append(name).Append("<BR/>");
                        }
                        lblOmittedPorts.Text = sb.ToString();
                        ShowOmittedPortsDiv = true;
                    }
                }
            }
        }


        private ConstructDTO GenerateGrid(bool forceRecalculate)
        {
            ConstructDTO constructDto = null;
            if (forceRecalculate || _menuColumnsChanged)
            {
                var parameters = GetDashboardParameters();
                SetPerfomanceData(parameters);

                constructDto = DashboardService.GetConstructDTO(parameters, CSession.GetSessionData());
                if (constructDto.Failed)
                {
                    throw constructDto.InnerException;
                }
                Session[ConstructDTO.DASHBOARD_XML_SESSION_KEY] = constructDto.Xml;
            }
            
            return constructDto;
        }

        private DashboardParameters GetDashboardParameters()
        {
            return SetDashboardParameters(new DashboardParameters());
        }

        private DashboardParameters SetDashboardParameters(DashboardParameters dashboardParameters)
        {
            dashboardParameters.FromDate = ValuationStartDate;
            dashboardParameters.ToDate = ValuationEndDate;
            dashboardParameters.LayoutProperties = IFSSession.CurrentLayout.LayoutProperties;
            dashboardParameters.OrganizationId = CSession.OrganizationID;
            dashboardParameters.SelectedPortfolios = IFSSession.SelectedPortfolioId.ToList();
            dashboardParameters.Recalculate = _recalculate;
            return dashboardParameters;
        }

        private DashboardExportParameters GetExportParameters()
        {
            var exportParameters = new DashboardExportParameters();
            SetDashboardParameters(exportParameters);
            exportParameters.ReportName = CurrentLayout.LayoutName;
            exportParameters.ExportCfg = hdnGridExportCfg.Value;
            exportParameters.ExportType = rdlExportType.SelectedValue;
            return exportParameters;
        }

        public void SetPerfomanceData(DashboardParameters parameters)
        {
            if (!PerformanceData.LogEnabled)
                return;

            PerformanceData performanceData = PerformanceData.Current;
            performanceData.AddValue(PerformanceData.Keys.DASHBOARD_LAYOUT, IFSSession.CurrentLayout.LayoutName);
            var portfolioIds = string.Join(", ", parameters.SelectedPortfolios);
            var columnNames = string.Join(", ", Attributes.Select(a => a.FullName));

            performanceData.AddValue(PerformanceData.Keys.DASHBOARD_COLUMNS, columnNames);
            performanceData.AddValue(PerformanceData.Keys.DASHBOARD_PORTFOLIOS, portfolioIds);
            performanceData.AddValue(PerformanceData.Keys.DASHBOARD_FROM_TO,
                                     (ValuationStartDate == DateTime.MinValue ? string.Empty : ValuationStartDate.ToString("d")) +
                                         " - " + ValuationEndDate.ToString("d"));
        }

        private void SyncMenuAndLayoutAttributeList()
        {
            var selectedAttributeIds = GetSelectedAttributeIdsFromColumnsMenu();
            var currentLayoutColumns = IFSSession.CurrentLayout.LayoutProperties.Columns;
            foreach (var id in selectedAttributeIds)
            {
                currentLayoutColumns.Remove(id);
                currentLayoutColumns.AttributeIds.Add(id);
            }
            // ToList() forces it to extract values. Othervise it keeps it as enumeration over currentLayoutColumns.AttributeIds
            var removedAttributeIds = currentLayoutColumns.AttributeIds.Where(attributeId => !selectedAttributeIds.Contains(attributeId) && attributeId != Attrib.NAME).ToList();
            foreach (string removedAttributeId in removedAttributeIds)
            {
                currentLayoutColumns.AttributeIds.Remove(removedAttributeId);
            }
        }

        private List<string> GetSelectedAttributeIdsFromColumnsMenu()
        {
            var selectedAttributeIds = new List<string>();
            if (hdnAttributeId.Value.Length >= 2)
            {
                string[] attributeIds = hdnAttributeId.Value.Substring(1, hdnAttributeId.Value.Length - 2).Split(',');
                selectedAttributeIds.AddRange(attributeIds);
            }
            return selectedAttributeIds;
        }

        private void SetMARandRiskFreeRate(Portfolio p)
        {
            var layOutMarRatio = IFSSession.CurrentLayout.LayoutProperties.MarRatio;
            var layOutRiskFreeRate = IFSSession.CurrentLayout.LayoutProperties.RiskFreeRate;
            var analyticsDefault = p.PortfolioProperties.AnalyticsDefaults;

            var dMar = !double.IsNaN(layOutMarRatio) ? layOutMarRatio
                              : double.IsNaN(analyticsDefault.MAR) ? Analytics.MAR_DEFAULT : analyticsDefault.MAR;

            var dRiskFreeRate = !double.IsNaN(layOutRiskFreeRate) ? layOutRiskFreeRate
                              : double.IsNaN(analyticsDefault.RiskFreeRate) ? Analytics.RISK_FREE_RATE_DEFAULT : analyticsDefault.RiskFreeRate;

            var strDMar = dMar.ToString();
            txtMAR.Text = strDMar;
            hdnMarRatio.Value = strDMar;
            lblMarRatio.Text = strDMar + @"%";

            var strDRiskFreeRate = dRiskFreeRate.ToString();
            txtRiskFreeRate.Text = strDRiskFreeRate;
            hdnRiskFreeRate.Value = strDRiskFreeRate;
            lblRiskFreeRate.Text = strDRiskFreeRate + @"%";
        }

        private void SetGlobalBenchmark(Portfolio p)
        {
            var globalBenchmarkId = IFSSession.CurrentLayout.LayoutProperties.GlobalBenchmarkId;
            if (globalBenchmarkId > 0)
            {
                ctrlBenchmark.Value = globalBenchmarkId;
            }
            else
            {
                var bm1 = p.PortfolioProperties.AnalyticsDefaults.Benchmark1;
                ctrlBenchmark.Value = bm1 <= 0
                                          ? BenchmarkStandard.GetSAndP500Benchmark().BenchmarkID
                                          : bm1;
            }
            var globalBenchmark = Benchmark.Loader.GetById(ctrlBenchmark.Value);
            if (globalBenchmark != null)
                lblBenchmark.Text = globalBenchmark.FundName;
            hdnGlobalBenchmarkId.Value = ctrlBenchmark.Value.ToString();
        }

        private void PopulateAggregationDropdowns()
        {
            ddlAggKeys.DataSource = AvailableAggKeys();
            ddlAggKeys.DataBind();
            CDropDown.BlankItem(ddlAggKeys);
        }

        private void SetHideInvLevelControls()
        {
            hdnHideInvestmentLevel.Value = HideInvestmentLevel.ToString();
            chkHideInvestments.Checked = HideInvestmentLevel;
        }

        private void SetShowTransactionsControls()
        {
            hdnShowTransactions.Value = ShowTransactions.ToString();
            chkShowTransactions.Checked = ShowTransactions;
        }

        private void SetShowHistoryControls()
        {
            hdnShowHistory.Value = ShowHistory.ToString();
            chkShowHistory.Checked = ShowHistory;
        }

        private void SetShowTradeExecutionOnlyControls()
        {
            var showTradeExecutionOnly = DashboardFilter.Filters.Exists(sf => sf.AttributeId == Attrib.ALLOCATION_IS_TRADE_EXECUTION);
            hdnShowTradeExecutionOnly.Value = showTradeExecutionOnly.ToString();
            chkShowTradeExecutionOnly.Checked = showTradeExecutionOnly;
        }

        private void SetFullyRedeemedInvestmentsControls()
        {
            chkShowFullyRedeemed.Checked = ShowFullyRedeemed;
            hdnShowFullyRedeemed.Value = ShowFullyRedeemed.ToString();
        }

        private void SetLocalCurrencyControls()
        {
            chkLocalCurrency.Checked = LocalCurrency;
            hdnLocalCurrency.Value = LocalCurrency.ToString();
        }

        private void SetShowCurrencyControls()
        {
            chkShowCurrency.Checked = ShowCurrency;
            hdnShowCurrency.Value = ShowCurrency.ToString();
        }

        private void SetLookThroughViewControls()
        {
            chkLookThroughView.Checked = LookThroughView;
            hdnLookThroughView.Value = LookThroughView.ToString();
        }

        private void SetShorterHeaderControls()
        {
            chkShorterHeaders.Checked = ShowShortNames;
            hdnShorterHeaders.Value = ShowShortNames.ToString();
        }

        private void SetUseTradeDateControls()
        {
            chkUseTradeDate.Checked = UseTradeDate;
            hdnUseTradeDate.Value = UseTradeDate.ToString();
        }

        private void SetNavCloseControls()
        {
            chkNavClose.Checked = ViewLockdownSnapshot;
            hdnNavClose.Value = ViewLockdownSnapshot.ToString();
        }

        private void SetRecalculateFilteredDashboardControls()
        {
            chkRecalculateFilteredDashboard.Checked = CalculateOnFilter;
            hdnRecalculateFilteredDashboard.Value = CalculateOnFilter.ToString();
        }

        private static List<IfsAttribute> AvailableAggKeys()
        {
            return IfsAttributeFactory.GetInstance().GetAggregationAttributes().FindAll(a => !AggregationKeys.Contains(a.Id));
        }

        private void PopulateAggKeysTable()
        {
            var aggKeys = new StringBuilder();
            var sttributesFactory = IfsAttributeFactory.GetInstance();
            foreach (string aggKey in AggregationKeys)
            {
                var row = new HtmlTableRow();
                var cell = new HtmlTableCell();
                IfsAttribute attribute = sttributesFactory.GetAttribute(aggKey);
                row.ID = attribute.Id;
                cell.InnerText = attribute.FullName;
                row.Cells.Add(cell);
                cell = new HtmlTableCell();
                var lnkRemove = new LinkButton { Text = @"x", ForeColor = Color.Red };
                lnkRemove.Font.Bold = true;
                lnkRemove.Style.Add("text-decoration", "none");
                lnkRemove.OnClientClick = "RemoveKeyFromTable(this);return false;";
                cell.Controls.Add(lnkRemove);
                row.Cells.Add(cell);
                tblAggregationKeys.Rows.Add(row);

                if (!string.IsNullOrEmpty(aggKeys.ToString()))
                    aggKeys.Append(";");
                aggKeys.Append(aggKey);
            }

            hdnAgg.Value = aggKeys.ToString();
        }

        private void PopulateReturnTypeLabel()
        {
            switch ((int)CurrentLayout.LayoutProperties.ReturnType)
            {
                case 0:
                    lblReturnType.Text = @"Derived (Historical)";
                    break;
                case 1:
                    lblReturnType.Text = @"Constant Weights";
                    break;
                case 2:
                    lblReturnType.Text = @"Net (Effective)";
                    break;
                case 3:
                    lblReturnType.Text = @"Constant Shares";
                    break;
            }
        }

        private void PopulateReturnTypeDropdown(DropDownList ddReturnType)
        {
            if (ddReturnType.Items.Count == 0)
            {
                ddReturnType.Items.Add(new ListItem("Derived (Historical)", "0"));
                ddReturnType.Items.Add(new ListItem("Constant Weights", "1"));
                ddReturnType.Items.Add(new ListItem("Net (Effective)", "2"));
                ddReturnType.Items.Add(new ListItem("Constant Shares", "3"));
            }

            var derivedHistorical = new ListItem("Derived (Historical)", "0");
            if (LookThroughView)
            {
                ddReturnType.Items.Remove(derivedHistorical);
            }
            else if (ddReturnType.Items.FindByValue(derivedHistorical.Value) == null)
            {
                ddReturnType.Items.Insert(0, derivedHistorical);
                ddReturnType.SelectedIndex = 0;
            }

            CDropDown.SetValue(ddReturnType, (int) CurrentLayout.LayoutProperties.ReturnType);
            hdnReturnType.Value = Convert.ToInt32(CurrentLayout.LayoutProperties.ReturnType).ToString();
        }

        private void PopulateDates()
        {
            PopulateFromDateControl(ddlFromDate);
            PopulateToDateControl(ddlToDate);
        }

        private static Dictionary<string, IEnumerable<string>> GetDatesForPortfolioList()
        {
            const string key = "DASHBOARD_DATES";
            var datesForPortfolioList = (Dictionary<string, IEnumerable<string>>)RequestCache.Get(key);
            if(datesForPortfolioList == null)
            {
                datesForPortfolioList = PortfolioReportDatesProvider.GetDatesForDashboard(IFSSession.SelectedPortfolioId.ToArray(),
                    IFSSession.CurrentLayout.LayoutProperties.ViewLockdownSnapshot);
                RequestCache.Insert(key, datesForPortfolioList);
            }
            return datesForPortfolioList;
        }
        
        private void PopulateFromDateControl(usercontrols_DateDropdown ucdDate)
        {
            var valuationStartDate = SessionValuationStartDate != DateTime.MinValue ? SessionValuationStartDate : DateTime.Now;

            var datesForPortfolioList = GetDatesForPortfolioList();
            var fromDates = datesForPortfolioList[PortfolioReportDatesProvider.StartDatesKeyName];
            PopulateDateControl(ucdDate, fromDates, valuationStartDate); 

            hdnFromDate.Value = valuationStartDate.ToShortDateString();
        }

        private void PopulateToDateControl(usercontrols_DateDropdown ucdDate)
        {
            var valuationEndDate = SessionValuationEndDate != DateTime.MinValue ? SessionValuationEndDate : DateTime.Now;
            var dates = GetDatesForPortfolioList();
            var toDates = dates[PortfolioReportDatesProvider.EndDatesKeyName];
            PopulateDateControl(ucdDate, toDates, valuationEndDate);
            hdnToDate.Value = valuationEndDate.ToShortDateString();
        }

        private void PopulateOptionsToDateControl(usercontrols_DateDropdown ucdDate)
        {
            var valuationEndDate = SessionValuationEndDate != DateTime.MinValue ? SessionValuationEndDate : DateTime.Now;
            var dates = GetDatesForPortfolioList();
            var toDates = dates[PortfolioReportDatesProvider.OptionsEndDatesKeyName];
            PopulateDateControl(ucdDate, toDates, valuationEndDate);
            hdnToDate.Value = valuationEndDate.ToShortDateString();
        }

        private void PopulateDateControl(usercontrols_DateDropdown ucddDate,IEnumerable<string> dates, DateTime selectedDate)
        {
            if (dates != null)
            {
                ucddDate.Clear();

                foreach (string date in dates)
                {
                    var value = date.Replace("Today-", string.Empty).Replace(" (L)", string.Empty).Replace(" (SL)", string.Empty);
                    ucddDate.Items.Add(new ListItem(date, value));
                }
                ucddDate.SelectedValue = selectedDate.ToShortDateString();
            }
        }
        #endregion

        #region ExcelExport
        public void btnExport_OnClick(object sender, EventArgs e)
        {
            var exportParameters = GetExportParameters();
            var exportResult = DashboardService.ExportExcel(exportParameters, CSession.GetSessionData());
            if (exportResult.Failed)
            {
                throw exportResult.InnerException;
            }
            OpenXmlExportHelper.WriteXlsContent(exportResult.Exported, "DashBoardExport");
        }

        public void btnExportPdf_OnClick(object sender, EventArgs e)
        {
            var exportParameters = GetExportParameters();
            var exportResult = DashboardService.ExportPdf(exportParameters, CSession.GetSessionData());
            if (exportResult.Failed)
            {
                throw exportResult.InnerException;
            }
            OpenXmlExportHelper.WritePdfContent(exportResult.Exported, "DashBoardExport");
        }
        #endregion

        public void WriteXmlResponse()
        {
            try
            {
                if (_log.IsDebugEnabled)
                    _log.Debug("Beginning xml download");

                Response.ContentType = "text/xml";
                Response.Charset = "utf-8";
                Response.AppendHeader("Cache-Control", "max-age=1, must-revalidate");

                var dataXml = (string)HttpContext.Current.Session[ConstructDTO.DASHBOARD_XML_SESSION_KEY];
                if (_log.IsDebugEnabled)
                    _log.Debug(dataXml);
                Response.Write(dataXml);

                if (_log.IsDebugEnabled)
                    _log.Debug("Finished xml download");
            }
            catch (Exception ex)
            {
                _log.Error("Error", ex);
                Response.Write("<Grid><IO Result=\"-1\" Message=\"Error in TreeGrid :&#x0a;&#x0a;" +
                    ex.Message.Replace("&", "&amp;").Replace("<", "&lt;").Replace("\"", "&quot;") + "\"/></Grid>");
            }
            Response.End();
        }

        [WebMethod]
        public static string GetPortfoliosReportDates(int[] portfolioList, bool navClose)
        {
            return new JavaScriptSerializer().Serialize(PortfolioReportDatesProvider.GetDatesForDashboard(portfolioList, navClose));
        }
    }

    public class  MenuItem
    {
        public bool Hidden;
        public string Name;
    }

    public class LayoutMenuManager
    {
        public MenuItem New { get; set; }
        public MenuItem Save { get; set; }
        public MenuItem SaveAs { get; set; }
        public MenuItem Rename { get; set; }
        public MenuItem Share { get; set; }
        public MenuItem Delete { get; set; }

        public LayoutMenuManager()
        {
            New = new MenuItem { Name = "New..." };
            Save = new MenuItem();
            SaveAs = new MenuItem { Name = "Save As..."};
            Rename = new MenuItem { Name = "Rename..."};
            Share = new MenuItem();
            Delete = new MenuItem();
        }
    }

}