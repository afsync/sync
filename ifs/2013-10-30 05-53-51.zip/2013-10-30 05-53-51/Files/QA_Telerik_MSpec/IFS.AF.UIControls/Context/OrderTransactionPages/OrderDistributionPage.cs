﻿using System;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.UIControls.Helpers;

namespace IFS.AF.UIControls.Context.OrderTransactionPages
{
    public class OrderDistributionPage : DistributionPage
    {
        public const string TITLE = "Distribution Trade Order";

        public OrderDistributionPage(Find find) : base(find)
        { }

        public OrderDistributionPage(Find find, Browser browser): base(find)
        {
            Browser = browser;
        }

        #region IDs
        const string INVEST_FUND_ID     = "InvestableFundId";
        const string ENTERED_DATE_ID    = "EnteredDate";
        const string EFFECTIVE_DATE_ID  = "EffectiveDate";
        const string TRADE_DATE_ID      = "TradeDate";
        const string CLEARER_ID         = "ClearerId";
        const string PRICE_ID           = "Price";
        const string OVERRIDE_PRICE_ID  = "OverridePrice";
        const string TRANSACTION_ID     = "TransactionId";
        const string COMMENTS_ID        = "Comments";
        const string REDEMPTION_DIV_ID  = "divRedemptionLots";
        const string BREAKUP_TYPE_ID    = "ddlBreakupType";

        const string APPROVE_BTN_ID     = "btnApprove";
        const string REJECT_BTN_ID      = "btnReject";
        const string SUBMIT_BTN_ID      = "btnAccept";
        const string CANCEL_BTN_ID      = "btnCancel";
        #endregion

        #region Controls

        protected HtmlSelect Class
        {
            get { return ElementManager.GetElementById(INVEST_FUND_ID).As<HtmlSelect>(); }
        }

         protected HtmlInputText EnteredDate
        {
            get { return ElementManager.GetElementById(ENTERED_DATE_ID).As<HtmlInputText>(); }
        }

         protected HtmlInputText EffectiveDate
        {
            get { return ElementManager.GetElementById(EFFECTIVE_DATE_ID).As<HtmlInputText>(); }
        }

         protected HtmlInputText TradeDate
        {
            get { return ElementManager.GetElementById(TRADE_DATE_ID).As<HtmlInputText>(); }
        }

        protected HtmlSelect Clearer
        {
            get { return ElementManager.GetElementById(CLEARER_ID).As<HtmlSelect>(); }
        }

        protected HtmlInputText Price
        {
            get { return ElementManager.GetElementById(PRICE_ID).As<HtmlInputText>(); }
        }

        protected HtmlInputCheckBox OverridePriceChk
        {
            get { return ElementManager.GetElementById(OVERRIDE_PRICE_ID).As<HtmlInputCheckBox>(); }
        }

        protected HtmlInputText TransactionId
        {
            get { return ElementManager.GetElementById(TRANSACTION_ID).As<HtmlInputText>(); }
        }

        protected HtmlTextArea Comments
        {
            get { return ElementManager.GetElementById(COMMENTS_ID).As<HtmlTextArea>(); }
        }

        protected HtmlTable RedemptionTable
        {
            get { return ElementManager.GetElementById(REDEMPTION_DIV_ID).As<HtmlDiv>().Find.ByAttributes<HtmlTable>("class=grid"); }
        }

        protected HtmlInputText GetTableCellInput(string header)
        {
            HtmlInputText resultCell;

            switch (header)
            {
                case TableHeaders.SHARES:
                    resultCell = RedemptionTable.AllRows[1].Cells[5].Find.ByAttributes<HtmlInputText>("type=text");
                    break;
                case TableHeaders.AMOUNT:
                    resultCell = RedemptionTable.AllRows[1].Cells[6].Find.ByAttributes<HtmlInputText>("type=text");
                    break;
                case TableHeaders.PERCENT:
                    resultCell = RedemptionTable.AllRows[1].Cells[7].Find.ByAttributes<HtmlInputText>("type=text");
                    break;
                default:
                    throw new Exception("Unhandled header name");
            }

            return resultCell;
        }

        protected HtmlSelect BreakupType
        {
            get { return ElementManager.GetElementById(BREAKUP_TYPE_ID).As<HtmlSelect>(); }
        }

        protected HtmlInputCheckBox RecallableDistributionChkbox
        {
            get { return Find.ByXPath<HtmlInputCheckBox>("//td[contains(text(),'Recallable Distribution')]/../..//input[@type='checkbox']"); }
        }

        #region Buttons
        public HtmlInputSubmit ApproveBtn
        {
            get { return ElementManager.GetElementById(APPROVE_BTN_ID).As<HtmlInputSubmit>(); }
        }

        public HtmlInputSubmit RejectBtn
        {
            get { return ElementManager.GetElementById(REJECT_BTN_ID).As<HtmlInputSubmit>(); }
        }

        public HtmlInputSubmit SubmitBtn
        {
            get { return ElementManager.GetElementById(SUBMIT_BTN_ID).As<HtmlInputSubmit>(); }
        }

        public HtmlInputButton CancelBtn
        {
            get { return ElementManager.GetElementById(CANCEL_BTN_ID).As<HtmlInputButton>(); }
        }
        #endregion

        #endregion

        #region Methods

        public DistributionFields2Pass GetOrder()
        {
            return new DistributionFields2Pass()
            {
                Fund             = GetBaseFund(),
                InvestFund       = GetInvestFund(),
                EnteredDate      = GetEnteredDate(),
                EffectiveDate    = GetEffectiveDate(),
                TradeDate        = GetTradeDate(),
                Clearer          = GetClearer(),
                Price            = GetPrice(),
                Amount           = GetAmount(),
                Shares           = GetShares(),
                Percents         = GetPercent(),
                ReedemAll        = IsRedeemAll(),
                TransactionId    = GetTransactionId()
            };
        }

        #region Get
        protected string GetValueByRowHeader(string header)
        {
            return Find.ByXPath<HtmlTableCell>("//td[contains(text(),'"+header+"')]/../td[last()]").InnerText;
        }

        public bool IsRedeemAll()
        {
            return RedemptionTable.AllRows[1].Cells[8].Find.ByAttributes<HtmlInputCheckBox>("type=checkbox").Checked;
        }

        public bool IsOverridePrice()
        {
            return OverridePriceChk.Checked;
        }

        public bool IsRecallableDistribution()
        {
            return RecallableDistributionChkbox.Checked;
        }

        public string GetBaseFund()
        {
            return GetValueByRowHeader("Base Fund Name:");
        }

        public string GetInvestFund()
        {
            string className;

            try   { className = Class.SelectedOption.Text; }
            catch { className = GetValueByRowHeader("Fund:"); }

            return className;
        }

        public string GetEnteredDate()
        {
            return EnteredDate.Text;
        }

        public string GetEffectiveDate()
        {
            return EffectiveDate.Text;
        }

        public string GetTradeDate()
        {
            return TradeDate.Text;
        }

        public string GetClearer()
        {
            return Clearer.SelectedOption.Text;
        }

        public string GetPrice()
        {
            return Price.Text;
        }

        public string GetTransactionId()
        {
            return TransactionId.Text;
        }

        public string GetComments()
        {
            return Comments.Text;
        }

        public string GetAmount()
        {
            return GetTableCellInput(TableHeaders.AMOUNT).Text;
        }

        public string GetShares()
        {
            return GetTableCellInput(TableHeaders.SHARES).Text;
        }

        public string GetPercent()
        {
            return GetTableCellInput(TableHeaders.PERCENT).Text;
        }

        public string GetReliefMethod()
        {
            return GetValueByRowHeader("Relief Method:");
        }

        public string GetCurrentState()
        {
            return GetValueByRowHeader("Current State:");
        }

        public string GetBreakupType()
        {
            return BreakupType.SelectedOption.Text;
        }

        #endregion

        #region Set
        public void SetRedeemAll(bool state = true)
        {
            RedemptionTable.AllRows[1].Cells[8].Find.ByAttributes<HtmlInputCheckBox>("type=checkbox").Check(state, true);
        }

        public void SetOverridePriceChkbox(bool state = true)
        {
            OverridePriceChk.Check(state, true);
        }

        public void SetInvestFund(string value)
        {
            try   { Class.SelectByText(value); }
            catch { }
        }

        public void SetEffectiveDate(string value)
        {
            EffectiveDate.Text = value;
        }

        public void SetTradeDate(string value)
        {
            TradeDate.Text = value;
        }

        public void GetClearer(string value)
        {
            Clearer.SelectByText(value);
        }

        public void SetPrice(string value)
        {
            Price.Text = value;
        }

        public void SetTransactionId(string value)
        {
            TransactionId.Text = value;
        }

        public void SetComments(string value)
        {
            Comments.Text = value;
        }

        public void SetAmount(string value)
        {
            GetTableCellInput(TableHeaders.AMOUNT).Text = value;
        }

        public void SetShares(string value)
        {
            GetTableCellInput(TableHeaders.SHARES).Text = value;
        }

        public void SetPercent(string value)
        {
            GetTableCellInput(TableHeaders.PERCENT).Text = value;
        }

        #endregion

        #region Actions
        public void Approve()
        {
            ApproveBtn.MouseClick();
            ClosePopup();
        }

        public void Reject()
        {
            RejectBtn.MouseClick();
            ClosePopup();
        }

        public void Cancel()
        {
            Close();
        }

        override public void Close()
        {
            CancelBtn.MouseClick();
            ClosePopup();
        }
        #endregion

        #endregion

        #region Constants
        public class TableHeaders
        {
            public const string SHARES = "Redeemed Shares";
            public const string AMOUNT = "Redeemed Proceeds";
            public const string PERCENT = "% Redeemed";  
        }
        #endregion
    }
}
