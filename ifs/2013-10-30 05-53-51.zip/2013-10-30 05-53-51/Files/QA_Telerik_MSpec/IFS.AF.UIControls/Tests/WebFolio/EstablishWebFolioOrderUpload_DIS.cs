﻿using IFS.AF.BaseContext;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Context.OrderTransactionPages;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

// ALPHA-2036 Webfolio: Distribution XML messages
// updated by: Sergii Dmytrenko

namespace IFS.AF.UIControls.Tests.WebFolio
{
    public class EstablishWebFolioOrderUpload_DIS : AfWebTest
    {
        #region Variables
        protected static DashboardPage              Dashboard;
        protected static TradeActivityPage          TradeActivity;
        protected static OrderDistributionPage      OrderDistribution;
        protected static OmsTradeTransaction        OmsTransaction;
        protected static DistributionFields2Pass    UploadedOrderValues;
        protected static DistributionFields2Pass    OrderValues;

        protected static string FileForUploading;
        protected static string FromDate = "10/02/2013";
        #endregion

        Establish _context = () =>
        {
            TestData = new TestDataSet()
            {
                Client          = "Automation WebFolio",
                Portfolio       = "Webfolio XML Import - RED",
                BaseFund        = "Fund Webfolio Import DISTR",
                InvestableFund  = "Fund Webfolio Import DISTR - A",

            };

            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
        };

        Because _of = () =>
        {
            Dashboard.GoToTradeActivity().DeleteAllTransactions(TestData.Portfolio, FromDate, FromDate);

            Dashboard.GoToWebfolioTradeUpload().UploadTrade(FileForUploading);

            TradeActivity = Dashboard.GoToTradeActivity();
            TradeActivity.SetCommonFilters(TestData.Portfolio, FromDate, FromDate);

            OrderDistribution   = TradeActivity.OpenOrderDistributionPage(OmsTransaction);
            UploadedOrderValues = OrderDistribution.GetOrder();
            OrderDistribution.Close();
        };
    }
}
