﻿using System;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Context.OrderTransactionPages;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

// ALPHA-2076 Webfolio - Add Distribution Screen
// ALPHA-2509. [BUG] Recallable Distribution checkbox in distribution trade order screen
// updated by: Sergii Dmytrenko

namespace IFS.AF.UIControls.Tests.WebFolio
{
    [Subject("Tc_AF_XML_Upload_DIS_3"), Tags("WebFolio", "Tc_AF_XML_Upload_DIS_3")]
    public class Verify_Webfolio_Order_screen_for_Private_Equity_DIS : AfWebTest
    {
        #region Variables
        protected static DashboardPage              Dashboard;
        protected static TradeActivityPage          TradeActivity;
        protected static OrderDistributionPage      OrderDistribution;
        protected static OmsTradeTransaction        PendingOrder;
        protected static OmsTradeTransaction        BookedOrder;
        protected static DistributionFields2Pass    OrderValues;

        protected static string FileForUploading;
        protected static string NewOrderStatus;
        protected static string BookedOrderStatus;
        protected static string BreakupType;
        protected static bool   RecallableDistribution;

        protected static string FromDate = "10/02/2013";
        #endregion

        Establish _context = () =>
        {
            #region Init Data
            FileForUploading = CurrentDirectoryPath + @"\WebFolio\Upload_PE_RED_2076.xml";

            OrderValues     = new DistributionFields2Pass()
            {
                Type        = TransactionType.TRADE_ORDER_DISTRIBUTION,
                Shares      = null,
                TradeDate   = FromDate,
                Amount      = "25,000.00"
            };

            TestData = new TestDataSet()
            {
                Client          = "Automation WebFolio",
                Portfolio       = "Webfolio XML Import - RED",
                BaseFund        = "Fund Webfolio Import DISTR",
                InvestableFund  = "Fund Webfolio Import DISTR - A",

            };

            PendingOrder    = new OmsTradeTransaction(OrderValues, TestData.Portfolio, TestData.InvestableFund);
            BookedOrder     = new OmsTradeTransaction(OrderValues, TestData.Portfolio, TestData.InvestableFund, OmsTradeTransaction.State.BOOKED);
            
            #endregion

            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            Dashboard.DeleteTransactionsForFund(TestData.InvestableFund, 1);
            Dashboard.GoToTradeActivity().DeleteAllTransactions(TestData.Portfolio, FromDate, FromDate);
        };

        Because _of = () =>
        {
            Dashboard.GoToWebfolioTradeUpload().UploadTrade(FileForUploading);

            TradeActivity = Dashboard.GoToTradeActivity();
            TradeActivity.SetCommonFilters(TestData.Portfolio, FromDate, FromDate);

            OrderDistribution       = TradeActivity.OpenOrderDistributionPage(PendingOrder);
            NewOrderStatus          = OrderDistribution.GetCurrentState();
            BreakupType             = OrderDistribution.GetBreakupType();
            RecallableDistribution  = OrderDistribution.IsRecallableDistribution();

            OrderDistribution.Approve();

            OrderDistribution   = TradeActivity.OpenOrderDistributionPage(BookedOrder);
            BookedOrderStatus   = OrderDistribution.GetCurrentState();
            OrderDistribution.Cancel();
        };

        private Cleanup _cleanup = () =>
        {
            try
            {
                Dashboard.GoToDashboard();
                Dashboard.DeleteTransactionsForFund(TestData.InvestableFund, 1);
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
            ;
        };

        It _01_Status_for_new_uploaded_order_should_be_Pending      = () => NewOrderStatus.ShouldEqual          (OmsTradeTransaction.State.PENDING1);
        It _02_Breakup_Type_for_order_shoulb_be_correct             = () => BreakupType.ShouldEqual             ("Temporary Return of Capital");
        It _03_RecallableDistribution_checkbox_should_be_checked    = () => RecallableDistribution.ShouldBeTrue ();
        It _04_Status_for_approved_order_should_be_Booked           = () => BookedOrderStatus.ShouldEqual       (OmsTradeTransaction.State.BOOKED);
    }
}
