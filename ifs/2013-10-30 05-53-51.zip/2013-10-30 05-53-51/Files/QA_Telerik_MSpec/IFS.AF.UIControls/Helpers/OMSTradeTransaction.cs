﻿using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.UIControls.Helpers
{
    public struct OmsTradeTransaction
    {
        // Action constants
        public struct Action
        {
            public const string NEW_ACTION = "NEW";
            public const string APPROVED_ACTION = "APPROVED";
            public const string EDITED_ACTION = "EDIT";
            //public const string DELETED = "DELETED";
        }
        // 

        // Status constants
        public struct State
        {
            public const string PENDING = "PENDING APPROVAL";
            public const string BOOKED = "TRADE BOOKED";
            public const string REJECTED = "REJECTED";
            public const string DELETED = "TRADE CANCELLED";
            public const string PENDING1 = "PENDING APPROVAL 1";
        }
            // 

        public string Security;
        public string Portfolio;
        
        public string TradeType;
        public string EffectiveDate;
        public string ReceivedTradeDate;
        public string TradePaymentDate;
        public string TradeDocumentsDueDate;

        //public string EnteredBy;
        //public string UpdatedBy;
        public string Amount;
        public string Quantity;
        public string Clearer;
        public string Comment;
        public string UserAction;
        public string Status;
        public string Percentage;
        
        public enum ActionTypes
        {
            Submit,
            Approve,
            Reject,
            Cancel
        } ;

        public OmsTradeTransaction(SubscriptionFields2Pass fields2Pass, string portfolio, string investableFund)
        {
            Security = investableFund;
            Portfolio = portfolio;
            TradeType = fields2Pass.Type;
            EffectiveDate = fields2Pass.EffectiveDate;
            ReceivedTradeDate = fields2Pass.EffectiveDate;
            TradePaymentDate = fields2Pass.PaymentDate;
            TradeDocumentsDueDate = fields2Pass.DocumentsDate;

            Amount = fields2Pass.Amount;
            Quantity = fields2Pass.Quantity;
            Clearer = fields2Pass.Clearer;
            Comment = fields2Pass.Comment;
            UserAction = Action.NEW_ACTION;
            Status = State.PENDING;
            Percentage = null;
        }
        public OmsTradeTransaction(RedemptionFields2Pass fields2Pass, string portfolio, string investableFund)
        {
            Security = investableFund;
            Portfolio = portfolio;
            TradeType = fields2Pass.Type;
            EffectiveDate = fields2Pass.EffectiveDate;
            ReceivedTradeDate = fields2Pass.EffectiveDate;
            TradePaymentDate = fields2Pass.TradeDate;
            TradeDocumentsDueDate = fields2Pass.DocumentsDate;
            Amount = fields2Pass.Proceeds != null ? StringTransform.ConvertToCurrencyNumber(fields2Pass.Proceeds) : null;
            Quantity = fields2Pass.Shares;
            Clearer = fields2Pass.Clearer;
            Comment = fields2Pass.Comment;
            UserAction = Action.NEW_ACTION;
            Status = State.PENDING;
            Percentage = fields2Pass.Procents;
        }
        public OmsTradeTransaction(TransferFields2Pass fields2Pass, string portfolio, string investableFund)
        {
            Security = investableFund;
            Portfolio = portfolio;
            TradeType = fields2Pass.Type;
            EffectiveDate = fields2Pass.EffectiveDate;
            ReceivedTradeDate = fields2Pass.EffectiveDate;
            TradePaymentDate = fields2Pass.TradeDate;
            TradeDocumentsDueDate = fields2Pass.DocumentsDate;
            Amount = "(" + StringTransform.ConvertToCurrencyNumber(fields2Pass.TransferProceeds) + ")";
            Quantity = fields2Pass.Shares;
            Clearer = fields2Pass.Clearer;
            Comment = fields2Pass.Comment;
            UserAction = Action.NEW_ACTION;
            Status = State.PENDING;
            Percentage = fields2Pass.Procents;
        }
        public OmsTradeTransaction(ExchangeFields2Pass fields2Pass, string portfolio, string investableFund)
        {
            Security = investableFund;
            Portfolio = portfolio;
            TradeType = fields2Pass.Type;
            EffectiveDate = fields2Pass.EffectiveDate;
            ReceivedTradeDate = fields2Pass.EffectiveDate;
            TradePaymentDate = fields2Pass.TradeDate;
            TradeDocumentsDueDate = fields2Pass.DocumentDueDate;
            Amount = "(" + fields2Pass.ExchangedProceeds + ")";
            Quantity = fields2Pass.ExchangesShares;
            Clearer = fields2Pass.Clearer;
            Comment = fields2Pass.Comments;
            UserAction = Action.NEW_ACTION;
            Status = State.PENDING;
            Percentage = null;
        }
        public OmsTradeTransaction(DistributionFields2Pass fields2Pass, string portfolio, string investableFund, string status = State.PENDING)
        {
            Security = investableFund;
            Portfolio = portfolio;
            TradeType = fields2Pass.Type;
            EffectiveDate = fields2Pass.EffectiveDate;
            ReceivedTradeDate = fields2Pass.EffectiveDate;
            TradePaymentDate = fields2Pass.TradeDate;
            TradeDocumentsDueDate = fields2Pass.DocumentsDate;
            //Amount = "(" + StringTransform.ConvertToCurrencyNumber(fields2Pass.Proceeds) + ")";
            Amount = fields2Pass.Amount;
            Quantity = fields2Pass.Shares;
            Clearer = fields2Pass.Clearer;
            Comment = fields2Pass.Comment;
            UserAction = Action.NEW_ACTION;
            Status = status;
            Percentage = null;
        }

        public void SetOmsTransaction(string status, string userAction)
        {
            Status = status;
            UserAction = userAction;
        }
        
        
    }
    public struct ExchangeFields2Pass
    {
        public OmsTradeTransaction.ActionTypes ActionTypes;
        public bool ReedemAll;
        public string ExchangeFromFundName, ExchangeFromClassName, ExchangeToFundName, ExchangeToClassName;
        public string DateEntered, EffectiveDate, TradeDate, DocumentDueDate;
        public string Clearer, SriClearer, Comments, TransactionId, CurrentState;
        public string AvailableShares, AvailableMarketValue, ExchangesShares, ExchangedProceeds, ProcRedeemed;
        public string Type;
    }
    public struct SubscriptionFields2Pass
    {
        public enum BookedTypes
        {
            Quantity = 1,
            Amount
        } ;

        public OmsTradeTransaction.ActionTypes ActTypes;
        public BookedTypes BkdTypes;
        public bool CashlessSubscription, CapitalCallOutsideCommitment;
        public string DateEntered,EffectiveDate, PaymentDate, DocumentsDate, Amount, Quantity, TransactionId, Clearer, Type, SubscriptionFees, BrockerFees, AttachmentPath, Comment;
        public int SubscriptionFeesProc, BrockerFeesProc;
        public string FundField;
    }
    public struct RedemptionFields2Pass
    {
        public bool ReedemAll;
        public OmsTradeTransaction.ActionTypes ActTypes;
        public string DateEntered, EffectiveDate, TradeDate, ExpectedMoneyMoveDate, Shares, Proceeds, Procents, DocumentsDate, TransactionId, Clearer, Type, AttachmentPath, Comment;
        public int  RedemptionFees, RedemptionFeesProc, BrockerFees, BrockerFeesProc;
        public string FundField;
    }
    public struct TransferFields2Pass
    {
        public bool ReedemAll;
        public OmsTradeTransaction.ActionTypes ActTypes;
        public string EffectiveDate, TradeDate, ExpectedMoneyMoveDate, Shares, TransferProceeds, Procents, DocumentsDate, ToPortfolio, TransactionId, Clearer, ToClearer, Type, AttachmentPath, Comment;
    }
    public struct DistributionFields2Pass
    {
        // TODO: review fields for distribution. This was copied from <Redemption>
        public bool ReedemAll;
        public OmsTradeTransaction.ActionTypes ActTypes;

        public string Fund,
                      InvestFund,
                      EnteredDate,
                      EffectiveDate,
                      TradeDate,
                      ExpectedMoneyMoveDate,
                      Shares,
                      Amount,
                      Price,
                      Proceeds,
                      Percents,
                      DocumentsDate,
                      TransactionId,
                      Clearer,
                      Type,
                      AttachmentPath,
                      Comment;
        public int  RedemptionFees, RedemptionFeesProc, BrockerFees, BrockerFeesProc;
    }

    public class HelpToOmsTrades
        {

        public static void PretestTradeOrderTestcases(TestDataSet TestData, bool isFullyReddemNeeded=false)
        {
            var Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            var TradeActivity = Dashboard.GoToTradeActivity();
            TradeActivity.SetCommonFilters(TestData.Portfolio, "01/01/2013");
            TradeActivity.SelectStatus(OmsTradeTransaction.State.PENDING);
            TradeActivity.DeleteAllTransactions();

            Dashboard = Dashboard.GoToDashboard();
            if (isFullyReddemNeeded) Dashboard.ShowFullyRedeemed();
            Dashboard.ExpandAll();
            Assert.IsTrue(Dashboard.IsFundVisible(TestData.InvestableFund),
                "Pretest data are incorrect, please add initial subscription");
            var activityReport = Dashboard.GoToViewActivity(TestData.BaseFund, TestData.InvestableFund);
            activityReport.DeleteAllTransExceptNum(1);
            activityReport.Close();
            Dashboard.MakeLogout();
        }

        }
}
