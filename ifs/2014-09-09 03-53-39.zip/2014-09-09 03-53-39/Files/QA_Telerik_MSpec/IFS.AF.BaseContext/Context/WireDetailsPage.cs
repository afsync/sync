﻿using System;
using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;


namespace IFS.AF.UIControls.Context
{
    public class WireDetailsPage : WebPage
    {

        #region Anchor
        private const string ANCOR = "Wire Details";
        public HtmlAnchor Anchor
        {
            get { return Find.ByContent<HtmlAnchor>(ANCOR); }
        }
        #endregion

        private const string CLASS_CURRENCY = "~_ctrlWireDetails__lblCurrency";
        private const string EFFECTIVE_DATE_BTN = "~_ctrlWireDetails__btnNewEffectiveDate";

        //Wire detials fields
        //private const string COMPANY_NAME_ = "~_ctrlWireDetails_dissalowCharactersCompanyName";

        public override string Url
        {
            get { throw new NotImplementedException(); }
        }

        public override string Title
        {
            get { throw new NotImplementedException(); }
        }

        public HtmlSelect ChooseClass
        {
            get { return Find.ById<HtmlSelect>("~_ctrlWireDetails_ddlClass"); }
        }

        public HtmlSelect EffectiveDate
        {
           get { return  Find.ById<HtmlSelect>("~_ctrlWireDetails__ddEffectiveDates"); }
        }
        public HtmlInputSubmit EffectiveNewBtn
        {
            get { return Find.ById<HtmlInputSubmit>("ctl00_ctphBody_ctrlTabset_ctrlWireDetails__btnNewEffectiveDate"); }
        }
        public HtmlInputSubmit EffectiveDeleteBtn
        {
            get { return Find.ById<HtmlInputSubmit>("ctl00_ctphBody_ctrlTabset_ctrlWireDetails__btnDeleteEffectiveDate"); }
        }
        public HtmlInputText CompanyName
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtCompanyName"); } 
        }

        public HtmlSpan CompanyNameError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_dissalowCharactersCompanyName"); }
        }

        public HtmlInputText CompanyAddress
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtCompanyAddress"); } 
        }

        public HtmlSpan CompanyAddressError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_dissalowCharactersCompanyAddress"); }
        }

        public HtmlInputText IntermediaryBank
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtIntermediaryBank"); } 
        }

        public HtmlSpan IntermediaryBankError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_dissalowCharactersIntermediaryBank"); }
        }

        public HtmlInputText BenefitaryBank
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtBenefitaryBank"); } 
        }

        public HtmlSpan BenefitaryBankError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersBenefitaryBank"); }
        }

        public HtmlInputText Aba
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtABA"); }
        }

        public HtmlSpan AbaError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersABA"); }
        }

        public HtmlInputText AccountName
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtAccountName"); }
        }

        public HtmlSpan AccountNameError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersAccountName"); }
        }

        public HtmlInputText AccountNumber
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtAccountNumber"); } 
        }

        public HtmlSpan AccountNumberError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersAccountNumber"); }
        }

        public HtmlInputText SubAccountNumber
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtSubAccountNumber"); } 
        }

        public HtmlSpan SubAccountNumberError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersSubAccountNumber"); }
        }

        public HtmlInputText SubAccount
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtSubAccount"); } 
        }

        public HtmlSpan SubAccountError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersSubAccount"); }
        }

        public HtmlInputText Reference
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtReference"); } 
        }

        public HtmlSpan ReferenceError
        {
            get { return Find.ById<HtmlSpan>("~_ctrlWireDetails_disallowCharactersReference"); }
        }

        public HtmlInputCheckBox ReviewedCheck
        {
            get { return Find.ById<HtmlInputCheckBox>("~_ctrlWireDetails_chkReviewed"); } 
        }

        public HtmlInputText FtopCompleted
        {
            get { return Find.ById<HtmlInputText>("~_ctrlWireDetails_txtFtopCompleted"); } 
        }

        public HtmlInputCheckBox ApprovedCheck
        {
            get { return Find.ById<HtmlInputCheckBox>("~_ctrlWireDetails_chkApproved"); } 
        }

        public HtmlInputSubmit Save
        {
            get { return Find.ById<HtmlInputSubmit>("~_ctrlWireDetails_btnSave"); } 
        }



        public void CreateNewEffectiveDate(string date)
        {
            EffectiveNewBtn.ButtonClick();
            var wireDetailsEffDtPopUp =  new WireDetailsPageNewEffDtPopup();
            wireDetailsEffDtPopUp.EffectiveDate.TypeText(date);
            wireDetailsEffDtPopUp.CreateNewEffectDtBtn.ButtonClick();
            Save.ButtonClick();
        }
    }
}
