﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context
{
    public class DashboardColumnsPage : BaseFindManager
    {
        private readonly Find _find;
        private const string SAVE_BTN = "~btnSubmitMenuColumns";
        private const string CANCEL_BTN = "~btnSubmitMenuColumnsCancel";
        private const string ATTRIBUTE_TO_SEARCH = "~txtAttributesToSearch";

        public DashboardColumnsPage(Find find) : base(find)
        {
            _find = find;
        }

        #region Constants

        public struct TabNames
        {
            public static string GeneralInfo = "General Info";
            public static string Accounting = "Accounting";
            public static string AnalyticsLocal = "Analytics Local";
            public static string AnalyticsBase = "Analytics Base";
            public static string ReturnsLocal = "Returns Local";
            public static string ReturnsBase = "Returns Base";
            public static string ReturnsDB = "Returns Decompositions Base";
            public static string TradeExecutionGeneral = "Trade Execution General";
            public static string TradeExecutionMM = "Trade Execution Money Movement";
            public static string BenchmarkAnalytics = "Benchmark Analytics";
            public static string PrivateEquity = "Private Equity";
            public static string AUM = "AUM";
            public static string FeesAndTerms = "Fees and Terms";

            public static List<string> GetAllNames()
            {
                var value = new TabNames();
                return typeof (TabNames).GetFields(BindingFlags.Public |
                                                   BindingFlags.Static |
                                                   BindingFlags.Instance)
                    .Select(field => field.GetValue(value) as string)
                    .ToList();
            }
        }

        #endregion

        #region Methods

        public void OpenTab(string tabName)
        {
            Find.ByXPath<HtmlAnchor>("//a[(text()='" + tabName + "') and (contains(@id, 'tab'))]").Click();
            //Find.ByXPath<HtmlAnchor>("//a[text()='" + tabName + "']").Click();
        }

        public List<string> GetTableHeaders(string tabName = null)
        {
            if (!string.IsNullOrEmpty(tabName))
                OpenTab(tabName);

            var result = new List<string>();
            var headers = ColumnsNamesTable.Find.AllByXPath<HtmlTableCell>("//tr[1]//td");

            foreach (var header in headers) result.Add(header.InnerText);

            return result;
        }

        private int GetHeaderPosition(string header, int accurence = 0)
        {
            if (accurence == 0) // default - return first accurence
                return GetTableHeaders().IndexOf(header);

            var headers = GetTableHeaders();
            var hederAccurence = 0;

            for (int i = 0; i < headers.Count; i++)
            {
                if (headers[i] == header)
                    hederAccurence++;

                if (hederAccurence == accurence)
                    return i;
            }

            return -1;
        }

        public List<string> GetColumnValues(string header, int headerAccurence = 0)
        {
            var result = new List<string>();
            var column = GetHeaderPosition(header, headerAccurence);
            var rows = ColumnsNamesTable.Find.AllByXPath<HtmlTableRow>("//tr");

            foreach (var row in rows)
            {
                var rowText = row.Cells[column].InnerText;
                if (rowText != "")
                    result.Add(rowText.Replace("  ", " "));
            }

            result.RemoveRange(0, 1); // remove header

            return result;
        }

        public bool IsColumnChecked(string columnName)
        {
            return ColumnCheckBox(columnName).Checked;
        }

        public void SetColunmChecked(string columnName, bool isChecked = true)
        {
            var chkBox = ColumnCheckBox(columnName);

            chkBox.ScrollToVisible();
            chkBox.Check(isChecked, true);
        }

        public void RemoveAllFromSelected()
        {
            while (SelectedColumnsTable.AllRows.Count > 0)
                RemoveFromSelected();
        }

        public void RemoveFromSelected(int position = 0)
        {
            var columnDeleteBtn = SelectedColumnsTable.Find.AllByXPath<HtmlAnchor>("//a")[position];
            columnDeleteBtn.ButtonClick();
        }

        public void RemoveFromSelected(string columnName)
        {
            var columnDeleteBtn = SelectedColumnsTable.Find.ByXPath<HtmlAnchor>("//td[text()='" + columnName + "']/..//a");
            columnDeleteBtn.ButtonClick();
        }

        public void Save()
        {
            SaveButton.SimpleClickAndWait();
        }
        public void Cancel()
        {
            CancelButton.Click();
        }

        public List<string> FindAndCheckColumns(params string[] columnNames)
        {
            var workList = columnNames.ToList();
            TabNames.GetAllNames().ForEach(tab =>
            {
                OpenTab(tab);

                foreach (var attribute in workList.ToList())
                {
                    try
                    {
                        if (!IsColumnChecked(attribute))
                        {
                            SetColunmChecked(attribute);
                            workList.Remove(attribute);
                        }
                    }
                    catch
                    {

                    }
                }
            });

            return workList;
        }

        #endregion

        #region Controls

        public HtmlTable ColumnsNamesTable
        {
            get
            {
                int activeTab = 0;

                var tabNames = ElementManager.GetElementById("tblTabs").As<HtmlTable>();
                foreach (HtmlTableCell cell in tabNames.Find.AllByXPath<HtmlTableCell>("//tr[1]//td"))
                {
                    if (cell.CssClass.Contains("active"))
                        break;

                    activeTab++;
                }

                return ElementManager.GetElementById("chkAttributesMenu" + activeTab.ToString()).As<HtmlTable>();
            }
        }

        public HtmlTable SelectedColumnsTable
        {
            get { return ElementManager.GetElementById("~tblSelectedAttributes").As<HtmlTable>(); }
        }

        public HtmlInputCheckBox ColumnCheckBox(string columnName)
        {
            return ColumnsNamesTable.Find.ByXPath<HtmlInputCheckBox>("//label[text() = '" + columnName + "']/..//input");
        }

        private HtmlInputButton SaveButton
        {
            get { return ElementManager.GetElementById(SAVE_BTN).As<HtmlInputButton>(); }
        }

        private HtmlInputButton CancelButton
        {
            get { return ElementManager.GetElementById(CANCEL_BTN).As<HtmlInputButton>(); }
        }

        public HtmlInputText AttributeSearch
        {
            get { return ElementManager.GetElementById(ATTRIBUTE_TO_SEARCH).As<HtmlInputText>(); }
        }

        #endregion
    }
}
