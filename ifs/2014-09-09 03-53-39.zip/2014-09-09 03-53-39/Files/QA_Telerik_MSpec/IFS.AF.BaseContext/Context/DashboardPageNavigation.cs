﻿using System;
using System.Threading;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Admin;
using IFS.AF.BaseContext.Context.Analytics;
using IFS.AF.BaseContext.Context.Analytics.Comparison;
using IFS.AF.BaseContext.Context.Analytics.Correlation;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Context.Benchmark;
using IFS.AF.BaseContext.Context.CommitmentTransaction;
using IFS.AF.BaseContext.Context.ERepository;
using IFS.AF.BaseContext.Context.FeesAndTermsPages;
using IFS.AF.BaseContext.Context.FundMaintain;
using IFS.AF.BaseContext.Context.InteractiveTradeBlotter;
using IFS.AF.BaseContext.Context.NewInterectiveTradeBlotter;
using IFS.AF.BaseContext.Context.PriceLockdown;
using IFS.AF.BaseContext.Context.PublishAttachments;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Context.Transactions;
using IFS.AF.BaseContext.Context.Webfolio;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Context.Admin;
using IFS.AF.UIControls.Context.Admin.Clients;
using IFS.AF.UIControls.Context.Admin.Roles;
using IFS.AF.UIControls.Context.Admin.Users;
using IFS.AF.UIControls.Context.ClientMaintain;
using IFS.AF.UIControls.Context.HedgeFundUpload;
using IFS.AF.UIControls.Context.Launchpad;
using IFS.AF.UIControls.Context.Layout;
using IFS.AF.UIControls.Context.PrivateEquityUpload;
using IFS.AF.UIControls.Context.Reports;
using WebAii.Framework.Context;

namespace IFS.AF.BaseContext.Context
{
    public partial class DashboardPage
    {

        private static TPage GotoPage<TPage>(string pageUrl, HtmlControl controlToClickOn, bool useMouseClick = true) where TPage : BaseFindManager
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(pageUrl))
            {
                if (useMouseClick)
                {
                    controlToClickOn.ButtonClick();
                }
                else
                {
                    controlToClickOn.SimpleClickAndWait(); 
                }

                Manager.Current.ActiveBrowser.WaitForUrl(pageUrl, true, TimeOut.MIN_01);
            }

            return (TPage) Activator.CreateInstance(typeof (TPage), new object[] {Manager.Current.ActiveBrowser.Find});
        }

        private static TPage GotoPage<TPage>(HtmlControl controlToClickOn, bool useMouseClick = true) where TPage : WebPage, new()
        {
            if (useMouseClick)
            {
                controlToClickOn.ButtonClick();
            }
            else
            {
                controlToClickOn.SimpleClickAndWait();
            }

            return new TPage();
        }

        public DashboardColumnsPage GoToDashboardColumns()
        {
            DashboardColumnsBtn.MouseHover();
            DashboardColumnsBtn.Click();
            Thread.Sleep(TimeSpan.FromSeconds(2));

            return new DashboardColumnsPage(Manager.Current.ActiveBrowser.Find);
        }

        public DashboardPage GoToDashboard()
        {
            return GotoPage<DashboardPage>(PageUrl.PORTFOLIO_CONSTRUCT, NavigationMenus.DashboardMenu);
        }

        public PriceLockdownPage GoToPriceLockdown()
        {
            return GotoPage<PriceLockdownPage>(PageUrl.PRICE_LOCKDOWN, PriceLockdownBtn, false);
        }
        
        public PriceLockdownPage GoToPriceLockdownByMenu()
        {
            return GotoPage<PriceLockdownPage>(PageUrl.PRICE_LOCKDOWN, NavigationMenus.PriceLockdownMenu);
        }

        public PullTransactionsPage GoToManageSoftLockByMenu()
        {
            NavigationMenus.ManageSoftLockMenu.ButtonClick();
            BrowserPool.WaitUntilPageLoaded();
            return new PullTransactionsPage();//Manage Soft Lock page same as Pull Transactions page
        }

        public PublishAttachmentsPage GoToPublishAttachments()
        {
            return GotoPage<PublishAttachmentsPage>(PageUrl.PUBLISH_ATTACHMENTS_PAGE, NavigationMenus.PublishAttachmentsMenu, false);
        }

        public TradeActivityPage GoToTradeActivity()
        {
            return GotoPage<TradeActivityPage>(PageUrl.TRADE_ACTIVITY_PAGE, NavigationMenus.TradeActivityMenu);
        }
        public TradeActivityPage GoToOpenTrades()
        {
            return GotoPage<TradeActivityPage>(PageUrl.TRADE_ACTIVITY_PAGE, OpenTradesLabel);
        }
        public PendingTradeActivityPage GoToPendingTradeActivity()
        {
            return GotoPage<PendingTradeActivityPage>(PageUrl.PENDING_TRADE_ACTIVITY_PAGE, NavigationMenus.PendingTradeActivityMenu);
        }

        public InteractiveTradeBlotterPage GotoInteractiveTradeBlotter(string portfolio = null)
        {
            var itb = GotoPage<InteractiveTradeBlotterPage>(PageUrl.INTERACTIVE_TRADE_BLOTTER_GRID, NavigationMenus.InteractiveTradeBlotterMenu, false);

            if (!String.IsNullOrEmpty(portfolio))
            {
                itb.PortfolioName.Select(portfolio);
            }

            itb.WaitUntilPageLoaded();

            return itb;
        }

        public NewInterectiveTradeBlotterPage GoToNewInteractiveTradeBlotter()
        {
            return GotoPage<NewInterectiveTradeBlotterPage>(PageUrl.NEW_INTERECTIVE_TRADE_BLOTTER_GRID, NavigationMenus.NewInterectiveTradeBlotterMenu);
        }

        public ERepositorySearchPage GoToERepositorSearch()
        {
            return GotoPage<ERepositorySearchPage>(PageUrl.EREPOSITORY_SEARCH, NavigationMenus.ERepositorySearchMenu);
        }

        public PortfolioMaintainPage GoToPortfolioMaintain()
        {
            return GotoPage<PortfolioMaintainPage>(PageUrl.PORTFOLIO_MAINTAIN_PAGE, NavigationMenus.PortfolioMaintainMenu);
        }


        public AdminDeleteFundPage GoToAdminDeleteFund()
        {
            return GotoPage<AdminDeleteFundPage>(PageUrl.DELETE_FUND_PAGE, NavigationMenus.FundDeleteMenu);
        }

        public EnumValuesPage GoToAdminListItems()
        {
            return GotoPage<EnumValuesPage>(PageUrl.LIST_ITEMS_PAGE, NavigationMenus.ListItemsMenu);
        }

        public ToolsFeesAndTermsPage GoToToolsFeesAndTerms()
        {
            Manager.Current.ActiveBrowser.NavigateTo(BaseContext.Properties.Settings.Default.QAAutoAFSite + PageUrl.TOOLS_FEES_TERMS);
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return new ToolsFeesAndTermsPage();
        }

        public AnalyticsHomePage GoToHomePage()
        {
            return GotoPage<AnalyticsHomePage>(PageUrl.ANALYTICS_HOME_PAGE, NavigationMenus.HomePageMenu);
        }

        public AnalyticsComparisonPage GoToAnalyticsComparison()
        {   
            NavigationMenus.ComparisonMenu.ButtonClick();

            return new AnalyticsComparisonPage();
        }

        public FundCorrelationsPage GoToCorrelations()
        {
            return GotoPage<FundCorrelationsPage>(NavigationMenus.CorrelationMenu);
        }

        public AdminFeesAndTermsPage GoToAdminFeesAndTerms()
        {
            //return GotoPage<AdminFeesAndTermsPage>(PageUrl.ADMIN_FEES_TERMS, NavigationMenus.FeesTermsMenu, false);
            Manager.Current.ActiveBrowser.NavigateTo(Properties.Settings.Default.QAAutoAFSite + PageUrl.ADMIN_FEES_TERMS);
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return new AdminFeesAndTermsPage(WebTest.ActiveBrowser.Find);
        }

        public AdminReturnsPage GoToAdminReturns()
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(AdminReturnsPage.URL)) 
            {
                Manager.Current.ActiveBrowser.NavigateTo(AfWebTest.TestSite + AdminReturnsPage.URL);
                Manager.Current.ActiveBrowser.WaitForUrl(AdminReturnsPage.URL, true, TimeOut.MIN_05);
                BrowserPool.WaitUntilPageLoaded();
            }
            return new AdminReturnsPage(Manager.Current.ActiveBrowser.Find);
        }
        public AdminClearCachePage GoToAdminClearCache()
        {
            return GotoPage<AdminClearCachePage>(PageUrl.INITIALISE_CACHE, NavigationMenus.CacheMenu);
        }

        public CafmFoldersPage GoToAdminCafmFoldersPage()
        {
            return GotoPage<CafmFoldersPage>(PageUrl.CAFM_FOLDERS, NavigationMenus.CafmFoldersMenu);
        }

        public ActivityReportPage GoToViewActivity(string baseFund, string investableFund)
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.ACTIVITY_REPORT))
            {
                GoToDashboard();
                Expand(baseFund);
                InvokeInvestmentMenu(baseFund, investableFund);
                ContextMenus.SelectByText(ContextMenus.MenuItems.ActivityReport);
            }
            
            return new ActivityReportPage();
        }
        
        public ActivityReportPage GoToViewActivity(string investableFund)
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.ACTIVITY_REPORT))
            {
                GoToDashboard();
                ExpandAll();
                InvokeInvestmentMenu(investableFund);
                ContextMenus.SelectByText(ContextMenus.MenuItems.ActivityReport);
            }

            return new ActivityReportPage();
        }

        public ActivityReportPage GoToViewActivity(BaseTransaction.Transaction transaction)
        {
            return GoToViewActivity(transaction.BaseFund, transaction.InvestableFund);
        }

        [Obsolete("This method is deprecated. Please use GoToViewActivity(transaction) instead")] //TODO: remove this method
        public void GoToViewActivityText(string baseFund, string investableFund)
        {
            if (Manager.Current.ActiveBrowser.Url.Contains(PageUrl.ACTIVITY_REPORT)) return;
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByText(ContextMenus.MenuItems.ActivityReport);
            BrowserPool.WaitUntilPageLoaded();
        }

        #region GoTo Create methods

        public SubscriptionPage GoToCreateSubscription(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.SUBSCRIPTION) as SubscriptionPage;
        }

        public SubscriptionCommitmentPage GoToCreateSubscriptionCommitment(string baseFund, string investableFund)
        {
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByText(ContextMenus.MenuItems.Subscription);

            return SubscriptionCommitmentPage.GetInstance(PopupWaiter.WaitTransactionPageAndGetInstance(TransactionType.CONTRIBUTION));
        }

        public SubscriptionPage GoToCreateSubscription(BaseTransaction.Transaction transaction)
        {
            return GoToCreateSubscription(transaction.BaseFund, transaction.InvestableFund);
        }

        public SubscriptionPage GoToCreateFirstSubscription(BaseTransaction.Transaction transaction)
        {
            return GoToQuickSearch().GoToSubscription(transaction.InvestableFund);
        }

        public TransferPage GoToCreateTransfer3RdPartyToIfs(BaseTransaction.Transaction transaction)
        {
            return GoToCreateTransfer3RdPartyToIfs(transaction.BaseFund, transaction.InvestableFund);
        }

        public TransferPage GoToCreateTransfer3RdPartyToIfs(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.TRANSFER_IN_3) as TransferPage;
        }

        public Transfer3rdPartyToIfsPage GoToCreateTransfer3RdPartyToIfsNew(string baseFund, string investableFund)
        {
            GoToCreateTransaction(baseFund, investableFund, TransactionType.TRANSFER_IN_3);
            return new Transfer3rdPartyToIfsPage();
        }
        
        public TransferPage GoToCreateTransferIfsTo3RdParty(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.TRANSFER_OUT_3) as TransferPage;
        }

        public TransferPage GoToCreateTransferIfsTo3RdParty(BaseTransaction.Transaction transaction)
        {
            return GoToCreateTransferIfsTo3RdParty(transaction.BaseFund, transaction.InvestableFund);
        }

        public TransferPage GoToCreateTransferIfsToIfs(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.TRANSFER_OUT) as TransferPage;
        }

        public TransferPage GoToCreateTransferIfsToIfs(BaseTransaction.Transaction transaction)
        {
            return GoToCreateTransferIfsToIfs(transaction.BaseFund, transaction.InvestableFund);
        }

        public TransferIfsToIfsPage GoToCreateTransferIfsToIfsNew(string baseFund, string investableFund)
        {
            GoToCreateTransactionNew(baseFund, investableFund, TransactionType.TRANSFER_OUT);
            return new TransferIfsToIfsPage();
        }

        public InvestmentControls GoToCreateTransaction(BaseTransaction.Transaction transaction)
        {
            return GoToCreateTransaction(transaction.BaseFund, transaction.InvestableFund, transaction.Type);
        }
        
        public InvestmentControls GoToCreateTransaction(string baseFund, string investableFund, string  transactionType)
        {
            GoToDashboard();
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByTransactionType(transactionType);
            return PopupWaiter.WaitTransactionPageAndGetInstance(transactionType);
        }

        public void GoToCreateTransactionNew(string baseFund, string investableFund, string transactionType)
        {
            GoToDashboard();
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByTransactionType(transactionType);
        }

        public InvestmentControls GoToCreateTradeOrder(string baseFund, string investableFund, string menuItem, string transactionType)
        {
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByTransactionType(menuItem);
            return PopupWaiter.WaitTransactionPageAndGetInstance(transactionType);
        }

        public InvestmentControls GoToCreateTradeOrder(string baseFund, string menuItem, string transactionType)
        {
            InvokeFundMenu(baseFund);
            ContextMenus.SelectByText(menuItem);
            return PopupWaiter.WaitTransactionPageAndGetInstance(transactionType);
        }

        public InvestmentControls GoToCreateBaseFundTransaction(string baseFund, string menuItem, string transactionType)
        {
            Expand(baseFund); 
            InvokeFundMenu(baseFund);
            ContextMenus.SelectByTransactionType(menuItem);
            return PopupWaiter.WaitTransactionPageAndGetInstance(transactionType);
        }

        public RedemptionPage GoToCreateRedemption(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.REDEMPTION) as RedemptionPage;
        }

        public RedemptionPage GoToCreateRedemption(BaseTransaction.Transaction transaction)
        {
            return GoToCreateRedemption(transaction.BaseFund, transaction.InvestableFund);
        }

        public ExchangePage GoToCreateExchange(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.EXCHANGE_OUT) as ExchangePage;
        }

        public ExchangePage GoToCreateExchange(BaseTransaction.Transaction transaction)
        {
            return GoToCreateExchange(transaction.BaseFund, transaction.InvestableFund);
        }

        public ExchangeCommitmentPage GoToCreateExchangeCommitment(string baseFund, string investableFund)
        {
            return ExchangeCommitmentPage.GetInstance(GoToCreateTransaction(baseFund, investableFund, TransactionType.EXCHANGE_OUT));
        }

        public EqualizationSubscriptionPage GoToCreateEqSubscription(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.EQUALIZATION_SUBSCRIPTION) as EqualizationSubscriptionPage;
        }

        public EqualizationSubscriptionPage GoToCreateEqSubscription(BaseTransaction.Transaction transaction)
        {
            return GoToCreateEqSubscription(transaction.BaseFund, transaction.InvestableFund);
        }

        public ContingentRedemptionPage GoToCreateContingentRedemption(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.CONTINGENT_REDEMPTION) as ContingentRedemptionPage;
        }

        public ContingentRedemptionPage GoToCreateContingentRedemption(BaseTransaction.Transaction transaction)
        {
            return GoToCreateContingentRedemption(transaction.BaseFund, transaction.InvestableFund);
        }
        public BuyToCoverPage GoToContingentRedemptionBuyToCover(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.BUY_TO_COVER_CONTINGENT_REDEMPTION) as BuyToCoverPage;
        }

        public ContributionPage GoToCreateContribution(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.CONTRIBUTION) as ContributionPage;
        }

        public ContributionPage GoToCreateContribution(BaseTransaction.Transaction transaction)
        {
            return GoToCreateContribution(transaction.BaseFund, transaction.InvestableFund);
        }

        public DistributionPage GoToCreateDistribution(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.DISTRIBUTION) as DistributionPage;
        }

        public DistributionPage GoToCreateDistribution(BaseTransaction.Transaction transaction)
        {
            return GoToCreateDistribution(transaction.BaseFund, transaction.InvestableFund);
        }

        public CommitmentPage GoToCreateCommitment(string baseFund, string investableFund, string type)
        {
            return GoToCreateTransaction(baseFund, investableFund, type) as CommitmentPage;
        }

        public CommitmentPage GoToCreateCommitment(BaseTransaction.Transaction transaction)
        {
            return GoToCreateCommitment(transaction.BaseFund, transaction.InvestableFund, transaction.Type);
        }

        public CashDistributionPage GoToCreateCashDistribution(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.CASH_DISTRIBUTION) as CashDistributionPage;
        }

        public CashDistributionPage GoToCreateCashDistribution(BaseTransaction.Transaction transaction)
        {
            return GoToCreateCashDistribution(transaction.BaseFund, transaction.InvestableFund);
        }

        public CorporateActionPage GoToCreateCorporateAction(string baseFund, string investableFund)
        {
            return GoToCreateTransaction(baseFund, investableFund, TransactionType.CORPORATE_ACTION) as CorporateActionPage;
        }

        public ContributionPage GoToCreateTransfer3RdPartyToIfsPvtEq(string baseFund, string investableFund)
        {
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByTransactionType(TransactionType.TRANSFER_IN_3);
            var browser = BrowserPool.IePopupOpen(PageUrl.CONTRIBUTION_PVT_EQTY, ContributionPage.TITLE);
            return new ContributionPage(Manager.Current.ActiveBrowser.Find, browser);
        }

        #endregion

        public RedemptionPage GoToEditRedemption(BaseTransaction.Transaction transaction)
        {
            return GoToViewActivity(transaction.BaseFund, transaction.InvestableFund).OpenRedemptionPage(transaction);
        }

        public QuickSearchPage GoToQuickSearch()
        {
            QuickSearchBtn.Click();
            
            return new QuickSearchPage();
        }

        public RegistrarsSetModifyPage GoToRegistrarPage()
        {
            return GotoPage<RegistrarsSetModifyPage>(PageUrl.REGISTRARS_SET_MODIFY, NavigationMenus.SetModifyRegistrar);
        }

        public TransactionsPage GoToTransactions()
        {
            return GotoPage<TransactionsPage>(PageUrl.TRANSACTIONS_PAGE, NavigationMenus.TransactionsMenu, false);
        }

        public AdminUsersPage GoToAdminUsers()
        {
            return GotoPage<AdminUsersPage>(PageUrl.USERS_PAGE, NavigationMenus.UsersMenu);
        }

        public RolePage GoToAdminRoles()
        {
            return GotoPage<RolePage>(PageUrl.ROLE_PAGE, NavigationMenus.RolesMenu);
        }
        
        public AfTransactionReport GoToTransactionReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.TRANSACTION_REPORT))
                NavigationMenus.TransactionsReportMenu.ButtonClick();

            var browserId = BrowserPool.IePopupOpen(PageUrl.TRANSACTION_REPORT, AfTransactionReport.TITLE);
            
            return new AfTransactionReport(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public HistoricalTransactionReport GoToHistoricalTransactionReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.HISTORICAL_TRANSACTION_REPORT)) 
                NavigationMenus.HistoricalTransactionsReportMenu.ButtonClick();

            var browserId = BrowserPool.IePopupOpen(PageUrl.HISTORICAL_TRANSACTION_REPORT, HistoricalTransactionReport.TITLE);

            return new HistoricalTransactionReport(Manager.Current.ActiveBrowser.Find, browserId);

        }

        public PricingReport GoToPricingReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.PRICING_REPORT))
                NavigationMenus.PricingReportMenu.ButtonClick();
            var browserId = BrowserPool.IePopupOpen(PageUrl.PRICING_REPORT, PricingReport.TITLE);
            return new PricingReport(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public LiquidityViewReportPage GoToLiquidityViewReport()
        {
            //BrowserPool.WaitUntilPageLoaded();
            //var u = WebTest.ActiveBrowser.Url;
            //WebTest.ActiveBrowser.RefreshDomTree();
            return GotoPage<LiquidityViewReportPage>(PageUrl.LIQUIDITY_VIEW_REPORT, NavigationMenus.LiquidityReportMenu);
        }

        public CustodyReportPage GoToCustodyReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.CUSTODY_REPORT)) 
            NavigationMenus.CustodyReportMenu.ButtonClick();
            var browserId = BrowserPool.IePopupOpen(PageUrl.CUSTODY_REPORT, CustodyReportPage.Title);

            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            return new CustodyReportPage(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public PerformanceReportPage GoToPerformanceReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.PERFORMANCE_REPORT))
                NavigationMenus.PerformanceReportMenu.ButtonClick();
            var browserId = BrowserPool.IePopupOpen(PageUrl.PERFORMANCE_REPORT,
                                    PerformanceReportPage.TITLE);

            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            return new PerformanceReportPage(Manager.Current.ActiveBrowser.Find, browserId);
        }
        public HistoricalReturnsReportPage GoToHistoricalReturnsReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.HISTORICAL_RETURNS_REPORT))
            NavigationMenus.HistoricalReturnsReportMenu.ButtonClick();

            var browser = BrowserPool.IePopupOpen(PageUrl.HISTORICAL_RETURNS_REPORT, HistoricalReturnsReportPage.TITLE);
            return new HistoricalReturnsReportPage(Manager.Current.ActiveBrowser.Find, browser);
        }

        public CorporateActionReport GoToCorporateActionReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (! Manager.Current.ActiveBrowser.Url.Contains(PageUrl.CORPORATE_ACTION_REPORT)) 
            NavigationMenus.CorporateActionReportMenu.ButtonClick();

            var browser = BrowserPool.IePopupOpen(PageUrl.CORPORATE_ACTION_REPORT, CorporateActionReport.TITLE);
            return new CorporateActionReport(Manager.Current.ActiveBrowser.Find, browser);
        }

        public IafofReportPage GoToIaFofReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.IA_AND_FOF_REPORT))
                NavigationMenus.IafofReportMenu.ButtonClick();

            return new IafofReportPage();
        }

        public PvtEquityControlReport GoToPvtEquityControlReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.PRIVATE_EQUITY_CONTROL_REPORT_PAGE))
                NavigationMenus.PrivateEquityControlMenu.ButtonClick();

            var browser = BrowserPool.IePopupOpen(PageUrl.PRIVATE_EQUITY_CONTROL_REPORT_PAGE, PvtEquityControlReport.TITLE);

            return new PvtEquityControlReport(Manager.Current.ActiveBrowser.Find, browser);
        }

        public CashProjectionReport GoToCashProjectionReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (! Manager.Current.ActiveBrowser.Url.Contains(PageUrl.CASH_PROJECTION_REPORT))
            NavigationMenus.CashProjectionReportMenu.ButtonClick();

            return new CashProjectionReport();
        }

        public RedemptionsPaymentReportPage GoToRedemptionPaymentReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.REDEMPTIONS_PAYMENT_REPORT))
                NavigationMenus.RedemptionsPaymentMenu.ButtonClick();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();

            return new RedemptionsPaymentReportPage(Manager.Current.ActiveBrowser.Find);
        }

        public PricingHistoryReportPage GoToPricingHistoryReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PricingHistoryReportPage.URL))
                NavigationMenus.PricingHistoryReportMenu.MouseClick();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            var browserId = BrowserPool.IePopupOpen(PricingHistoryReportPage.URL, PricingHistoryReportPage.TITLE);

            return new PricingHistoryReportPage(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public HoldingsReportPage GoToHoldingsReport()
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains("pages/reports/ReportAllPortfoliosInvestments.aspx"))
            {
                NavigationMenus.HoldingsReportMenu.Click();
            }
            var browserId = BrowserPool.IePopupOpen("pages/reports/ReportAllPortfoliosInvestments.aspx", "All Holdings Report", TimeOut.MIN_05);
            BrowserPool.WaitUntilPageLoaded();
            return new HoldingsReportPage();
        }

        public FundOfFundsReport GoToFundOfFundsReport()
        {
            NavigationMenus.FofReportMenu.Click();
            return new FundOfFundsReport();
        }

        public CreditReportPage GoToCreditReportReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(CreditReportPage.URL))
                NavigationMenus.CreditReportMenu.MouseClick();
            BrowserPool.WaitUntilPageLoaded();
            var browserId = BrowserPool.IePopupOpen(CreditReportPage.URL, CreditReportPage.TITLE);

            return new CreditReportPage(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public ReturnsPage GoToReturns(string baseFund, string investableFund)
        {
            Expand(baseFund);
            InvokeInvestmentMenu(baseFund, investableFund);
            ContextMenus.SelectByText(ContextMenus.MenuItems.Returns);
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            return new ReturnsPage(Manager.Current.ActiveBrowser.Find);
        }

        public ReturnsPage GoToReturns(bool selectBaseFund = false)
        {
            var retPage = GotoPage<ReturnsPage>(PageUrl.RETURNS_PAGE, NavigationMenus.ReturnsGeneralInfoMenu);

            if (selectBaseFund)
            {
                retPage.BaseFundRadioButton.Check(true, true);
            }

            return retPage;
        }

        public ClientMaintainPage GoToMaintainClient()
        {
            return GotoPage<ClientMaintainPage>(PageUrl.CLIENT_MAINTAIN_PAGE, NavigationMenus.ClientMaintainMenu);    
        }

        public ClientPage GoToAdminClient()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.CLIENT_PAGE))
            {
                NavigationMenus.ClientsMenu.MouseClick();
                Manager.Current.ActiveBrowser.WaitForUrl(PageUrl.CLIENT_PAGE, true, TimeOut.SEC_30);
            }

            //return (ClientPage) Activator.CreateInstance(typeof (ClientPage), new object[] {Manager.Current.ActiveBrowser.Find});
            return new ClientPage(Find);
        }

        public BenchmarkPerformanceReport GoToBenchmarkPerformanceReport()
        {
            BrowserPool.WaitUntilPageLoaded();
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.BENCHMARK_PERFORMANCE_REPORT_PAGE))
            {
                NavigationMenus.BenchmarkPerformanceReportMenu.MouseClick();
            }
            var browserId = BrowserPool.IePopupOpen(PageUrl.BENCHMARK_PERFORMANCE_REPORT_PAGE, BenchmarkPerformanceReport.TITLE);
            return new BenchmarkPerformanceReport(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public BenchmarkUploadPage GoToBenchmarkUpload()
        {
            return GotoPage<BenchmarkUploadPage>(PageUrl.BM_UPLOAD_PAGE, NavigationMenus.BenchmarksUploadMenu);
        }

        public void GoToAdminRegistrars(string portfolio, string fund)
        {
            var registrarsSetModifyPage = GoToRegistrarPage();
            registrarsSetModifyPage.SetPortfolio(portfolio);
            registrarsSetModifyPage.SetFund(fund);
        }

        public FundMaintainPage GoToFundFeesAndTerms(string baseFund, string className = null)
        {
            var fundMaintain = GoToMaintainFund();
            fundMaintain.FundSelect.Select(baseFund);
            fundMaintain.GoToFeesAndTermsTab();

            if (!string.IsNullOrEmpty(className))
                fundMaintain.FeesAndTermsTab.SeriesSideLst.Select(className);
            
            return fundMaintain;
        }

        public FundMaintainPage GoToMaintainFund()
        {
            return GotoPage<FundMaintainPage>(PageUrl.FUND_MAINTAIN_PAGE, NavigationMenus.FundMaintainMenu);
        }

        public NetAssetsSummaryPage GoToInvestmentSummary()
        {
            return GotoPage<NetAssetsSummaryPage>(PageUrl.INVESTMENT_SUMMARY, NavigationMenus.InvestmentSummaryMenu);
        }

        public PricingSummaryPage GoToOperationsSummary()
        {
            return GotoPage<PricingSummaryPage>(PageUrl.OPERATIONS_SUMMARY, NavigationMenus.OperationsSummaryMenu);
        }

        public HoldingsSummaryPage GoToHoldingsSummary()
        {
            return GotoPage<HoldingsSummaryPage>(PageUrl.HOLDINGS_SUMMARY, NavigationMenus.HoldingsSummaryMenu);
        }

        public LaunchpadDataUpload GoToLaunchpadDataUpload()
        {
            return GotoPage<LaunchpadDataUpload>(PageUrl.LAUNCHPAD_DATA_UPLOAD_PAGE, NavigationMenus.LaunchpadDataUploadMenu);
        }

        public ViewCorporateActionsPage GoToViewCorporateActions(string investableFund)
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.CORPORATE_ACTION_CHECKLIST_PAGE))
            {
                GoToDashboard();
                ExpandAll();
                InvokeInvestmentMenu(investableFund);
                ContextMenus.SelectByText(ContextMenus.MenuItems.ViewCorporateActions);
            }

            var browserId = BrowserPool.IePopupOpen(PageUrl.VIEW_CORPORATE_ACTIONS, ViewCorporateActionsPage.TITLE);
            return new ViewCorporateActionsPage(Manager.Current.ActiveBrowser.Find, browserId);
        }

        public LayoutSharePage GoToLayoutShare(string targetLayout)
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(PageUrl.LAYOUT_SHARE))
            {
                GoToDashboard();

                Layouts.Select(targetLayout);
                var layoutMenu = InvokeLayoutsMenu();
                layoutMenu.SelectByText("Share");
                Manager.Current.ActiveBrowser.WaitForUrl(PageUrl.LAYOUT_SHARE, true, TimeOut.MIN_05);
            }

            return new LayoutSharePage(Manager.Current.ActiveBrowser.Find);
        }

        public TradeUploadPage GoToTradeUpload()
        {
            return GotoPage<TradeUploadPage>(PageUrl.TRADE_UPLOAD_PAGE, NavigationMenus.TradeUploadMenu);
        }

        public PeSecurityUpload GoToPrivateEquitySecurityUpload()
        {
            return GotoPage<PeSecurityUpload>(PageUrl.PE_SECURITY_TRADE_UPLOAD, NavigationMenus.PeUploadMenu);
        }

        public ERepositoryBrowsePage GoToERepositoryBrowse()
        {
            return GotoPage<ERepositoryBrowsePage>(PageUrl.EREPOSITORY_BROWSE_PAGE, NavigationMenus.ERepositoryBrowseMenu);
        }

        public GsmSecuritiesUploadPage GoToGSMSecurityUpload()
        {
            return GotoPage<GsmSecuritiesUploadPage>(PageUrl.GSM_SECURITY_UPLOAD, NavigationMenus.GSMSecurityUploadMenu);
        }
        public HfTradeUpload GoToAdminTradeSecurity()
        {
            return GotoPage<HfTradeUpload>(PageUrl.TRADES_AND_SECURITIES_UPLOAD_PAGE, NavigationMenus.TradeSecurityMenu);
        }
        public ManagePdfAttachments GoToManagePdfAttachments()
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(ManagePdfAttachments.Url))
            {
                NavigationMenus.ManagePdfAttachments.ButtonClick();

                Manager.Current.ActiveBrowser.WaitForUrl(ManagePdfAttachments.Url, true, TimeOut.MIN_05);
            }
            return new ManagePdfAttachments();
        }
        public StalePricesPage GoToStalePrices()
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(StalePricesPage.Url))
            {
                NavigationMenus.StalePrices.ButtonClick();

                Manager.Current.ActiveBrowser.WaitForUrl(StalePricesPage.Url, true, TimeOut.MIN_05);
            }
            return new StalePricesPage();
        }

        public WebfolioTradeUploadPage GoToWebfolioTradeUpload()
        {
            //return GotoPage<WebfolioTradeUploadPage>(PageUrl.WEBFOLIO_TRADE_UPLOAD, NavigationMenus.WebfolioTradeUpload);

            //this is required to be able to upload another file (simple F5 leads to issues sometimes)
            NavigationMenus.WebfolioTradeUpload.ButtonClick();
            Manager.Current.ActiveBrowser.WaitForUrl(PageUrl.WEBFOLIO_TRADE_UPLOAD, true, TimeOut.MIN_05);
            return new WebfolioTradeUploadPage(Find);
        }

        public WebfolioPositionsDownloadPage GoToWebfolioPositionsDownload()
        {
            return GotoPage<WebfolioPositionsDownloadPage>(PageUrl.WEBFOLIO_POSITIONS_DOWNLOAD, NavigationMenus.WebfolioPositionsDownload);
        }

        public WebfolioPriceDownloadPage GoToWebfolioPriceDownload()
        {
            return GotoPage<WebfolioPriceDownloadPage>(PageUrl.WEBFOLIO_PRICE_DOWNLOAD, NavigationMenus.WebfolioPriceDownloadMenu);
        }

        public WebfolioTradeDownloadPage GoToWebfolioTradeDownload()
        {
            return GotoPage<WebfolioTradeDownloadPage>(PageUrl.WEBFOLIO_TRADE_DOWNLOAD, NavigationMenus.WebfolioTradeDownloadMenu);
        }

        public InvestmentAnalysisReport GoToInvestmentAnalysisReport()
        {
            NavigationMenus.InvestmentAnalysisReport.ButtonClick();
            return new InvestmentAnalysisReport();
        }

        public AttributeNamesPage GoToAttributeCustomName()
        {
//            return GotoPage<AttributeNamesPage>(PageUrl.ATTRIBUTE_CUSTOM_NAMES, NavigationMenus.AttributeCustomNamesMenu);
            NavigationMenus.AttributeCustomNamesMenu.ButtonClick();
            return new AttributeNamesPage();
        }

        public BenchmarkMaintainPage GoToBenchmarkMenu()
        {
            NavigationMenus.BenchmarkMenu.ButtonClick();
            return new BenchmarkMaintainPage();
        }

        public BenchmarkMaintainPage GoToBenchmark()
        {
            NavigationMenus.BenchmarkMenu.ButtonClick();
            return new BenchmarkMaintainPage();
        }

        public ReportExposurePage GoToReportExposure()
        {
            NavigationMenus.ExposureReportMenu.ButtonClick();
            return new ReportExposurePage();
        }

        public SidePocketsReport GoToSidePocketReport()
        {
            NavigationMenus.SidePocketsReportMenu.ButtonClick();
            return new SidePocketsReport();
        }

        public RollingIrrReport GoToRollingIrrReport()
        {
            NavigationMenus.RollingIrrMenu.ButtonClick();
            return  new RollingIrrReport();
        }
    }
}
