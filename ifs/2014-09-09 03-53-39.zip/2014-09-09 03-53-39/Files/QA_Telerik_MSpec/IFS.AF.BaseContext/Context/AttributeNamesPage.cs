﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context
{
    public class AttributeNamesPage : WebPage
    {
        protected const int MAX_TAGS_NUMBER = 15;

        #region Properties
        public HtmlInputText CustomTag2
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag2");
            }
        }

        public HtmlInputText CustomTag3
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag3");
            }
        }

        public HtmlInputText CustomTag4
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag4");
            }
        }

        public HtmlInputText CustomTag5
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag5");
            }
        }

        public HtmlInputText CustomTag6
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag6");
            }
        }

        public HtmlInputText CustomTag7
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag7");
            }
        }

        public HtmlInputText CustomTag8
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag8");
            }
        }

        public HtmlInputText CustomTag9
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag9");
            }
        }

        public HtmlInputText CustomTag10
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag10");
            }
        }

        public HtmlInputText CustomTag11
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag11");
            }
        }

        public HtmlInputText CustomTag12
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag12");
            }
        }

        public HtmlInputText CustomTag13
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag13");
            }
        }

        public HtmlInputText CustomTag14
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag14");
            }
        }

        public HtmlInputText CustomTag15
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtCustomTag15");
            }
        }

        

        public HtmlInputText PortfolioXREF
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtPortfolioXREF");
            }
        }

        public HtmlInputText FundXREF
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtFundDescription");
            }
        }

        public HtmlInputText FundXREF2
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtFundDescription2");
            }
        }

        public HtmlInputText ClassXREF
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtClassXref");
            }
        }

        public HtmlInputText ClassXREF2
        {
            get
            {
                return FindW.ById<HtmlInputText>("~txtClassXref2");
            }
        }

        private HtmlInputSubmit SaveBtn
        {
            get { return FindW.ById("~btnSave").As<HtmlInputSubmit>(); }
        }

        #endregion Properties

        #region methods

        public void Save()
        {
            SaveBtn.ButtonClick();
        }

        public HtmlInputText GetCustomTag(int id)
        {
            return FindW.ById<HtmlInputText>("~txtCustomTag" + id);
        }


        public void SetTagName(int id, string value)
        {
            GetCustomTag(id).Text = value;
        }

        public void ResetTags()
        {
            for (int i = 1; i <= MAX_TAGS_NUMBER; i++)
            {
                SetTagName(i, "");
            }
            PortfolioXREF.Text = "";
            FundXREF.Text = "";
            FundXREF2.Text = "";
            ClassXREF.Text = "";
            ClassXREF2.Text = "";
            Save();
        }
        #endregion

        public override string Url
        {
            get { return "pages/Tools/AttributeNames.aspx"; }
        }

        public override string Title
        {
            get { return "Alpha Frontier"; }
        }
    }
}