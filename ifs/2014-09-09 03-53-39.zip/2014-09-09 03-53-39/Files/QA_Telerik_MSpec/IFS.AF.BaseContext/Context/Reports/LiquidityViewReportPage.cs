﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ArtOfTest.Common;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.ObjectModel;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Context.Launchpad;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context.Layout;
using Machine.Specifications.Annotations;
using NUnit.Framework;
using WebAii.Framework.Context;

namespace IFS.AF.BaseContext.Context.Reports
{
    [UsedImplicitly]
    public class LiquidityViewReportPage : BaseFindManager
    {
        #region Constants

        public const string ASC = "asc";
        public const string DESC = "desc";

        private const string INDEX_ATTR = "DBAFRowId_R$";

        public struct ColumnHeaders
        {
            public const string FUND_NAME = "Fund Name";
            public const string CURRENCY = "Currency";
            public const string RED_POLICY_TYPE = "Red Policy Type";
            public const string REDEMPTION_METHOD = "Redemption Method";
            public const string ORIGINAL_COST = "Original Cost";
            public const string CURRENT_COST = "Current Cost";
            public const string INVESTMENT_DATE = "Investment Date";
            public const string MARKET_VALUE_BASE = "Market Value Base";
            public const string AMOUNT_REDEEMED_MV_ITD = "Amount redeemed MV ITD";
            public const string PERCENT_REDEEMED_ITD = "% Redeemed ITD";
            public const string MAX_REDEMPTION = "Max Redemption";
            public const string AS_OF = "as of";
            public const string LOCK_UP_EXPIRED = "Lockup Expired";
            public const string LOCKUP_TYPE = "Lockup Type";
            public const string LOCKUP_EXPIRE_DATE = "Lockup Expire date";
            public const string EXPIRATION_DATE_REDEMPTION_ALLOWED = "Expiration date redemption allowed";
            public const string SOFT_LOCK_REDEM_FEE_PERCENT = "Soft Lock Redem Fee %";
            public const string SOFT_LOCK_REDEM_FEE_CURRENCY = "Soft Lock Redem Fee $";
            public const string GENERAL_REDEM_FEE_PERCENT = "General Redem Fee %";
            public const string GENERAL_REDEM_FEE_CURRENCY = "General Redem Fee $";
            public const string ACCELERATED_REDEM_FEE_PERCENT = "Accelerated Redem Fee %";
            public const string ACCELERATED_REDEM_FEE_CURRENCY = "Accelerated Redem Fee $";
            public const string GATE = "Gate";
            public const string DAYS_TO_LOCKUP_EXP = "Days to Lockup Exp (Calendar)";
            public const string LIQUIDITY = "Liquidity";
            public const string NEXT_ELIGIBLE_REDEM_DATE = "Next Eligible Redem Date";
            public const string NOTICE_DAYS = "Notice Days";
            public const string DATE_TO_GIVE_NOTICE = "Date to Give Notice";
            public const string DAYS_TO_GIVE_NOTICE = "Days to Give Notice (Calendar)";
            public const string PAYMENT_PERCENT_REDEM_1 = "Payment % Redem 1";
            public const string PAYMENT_DATE_1 = "Payment date 1";
            public const string PAYMENT_PERCENT_REDEM_2 = "Payment % Redem 2";
            public const string PAYMENT_DATE_2 = "Payment date 2";
            public const string PAYMENT_PERCENT_REDEM_3 = "Payment % Redem 3";
            public const string PAYMENT_DATE_3 = "Payment date 3";
        }

        public static List<string> GeneralHeaders = new List<string>
                                                        {
                                                            ColumnHeaders.FUND_NAME,
                                                            ColumnHeaders.CURRENCY,
                                                            ColumnHeaders.RED_POLICY_TYPE,
                                                            ColumnHeaders.REDEMPTION_METHOD,
                                                            ColumnHeaders.ORIGINAL_COST,
                                                            ColumnHeaders.CURRENT_COST,
                                                            ColumnHeaders.INVESTMENT_DATE,
                                                            ColumnHeaders.MARKET_VALUE_BASE,
                                                            ColumnHeaders.AMOUNT_REDEEMED_MV_ITD,
                                                            ColumnHeaders.PERCENT_REDEEMED_ITD,
                                                            ColumnHeaders.MAX_REDEMPTION,
                                                            ColumnHeaders.AS_OF,
                                                            ColumnHeaders.LOCK_UP_EXPIRED,
                                                            ColumnHeaders.LOCKUP_TYPE,
                                                            ColumnHeaders.LOCKUP_EXPIRE_DATE,
                                                            ColumnHeaders.EXPIRATION_DATE_REDEMPTION_ALLOWED,
                                                            ColumnHeaders.SOFT_LOCK_REDEM_FEE_PERCENT,
                                                            ColumnHeaders.GENERAL_REDEM_FEE_PERCENT,
                                                            ColumnHeaders.ACCELERATED_REDEM_FEE_PERCENT,
                                                            ColumnHeaders.SOFT_LOCK_REDEM_FEE_CURRENCY,
                                                            ColumnHeaders.GENERAL_REDEM_FEE_CURRENCY,
                                                            ColumnHeaders.ACCELERATED_REDEM_FEE_CURRENCY,
                                                            ColumnHeaders.GATE,
                                                            ColumnHeaders.DAYS_TO_LOCKUP_EXP,
                                                            ColumnHeaders.LIQUIDITY,
                                                            ColumnHeaders.NEXT_ELIGIBLE_REDEM_DATE,
                                                            ColumnHeaders.NOTICE_DAYS,
                                                            ColumnHeaders.DATE_TO_GIVE_NOTICE,
                                                            ColumnHeaders.DAYS_TO_GIVE_NOTICE
                                                        };

        #endregion

        #region Properties

        public static string Title
        {
            get { return "Alpha Frontier >> Portfolio >> Report Liquidity"; }
        }

        public static string ReportPageUrl
        {
            get { return AfWebTest.TestSite + PageUrl.LIQUIDITY_VIEW_REPORT; }
        }

        private HtmlSpan PopupAlertTitle
        {
            get
            {
                return
                    Manager.Current.ActiveBrowser.WaitForElement(new HtmlFindExpression("id=ctl00_ctphBody_Label1"),
                                                                 3*1000, false).As<HtmlSpan>();
            }
        }

        private HtmlDiv PopupAlertMessage
        {
            get { return Find.ById<HtmlDiv>("divMessage"); }
        }

        private HtmlDiv TableScroller
        {
            get { return ElementManager.GetElementByClass("DBHScrollMid").As<HtmlDiv>(); }
        }

        private HtmlInputSubmit PopupAlertMessageCancelBtn
        {
            get { return Find.ById<HtmlInputSubmit>("ctl00_ctphBody_btnCancel"); }
        }

        public ColumnsOrderWidgetClass ColumnsOrderWidget
        {
            get { return new ColumnsOrderWidgetClass(Find); }
        }

        public HtmlSpan ErrorLabel
        {
            get { return ElementManager.GetElementById("~ErrorLabel").As<HtmlSpan>(); }
        }

        public HtmlSpan ExceptionText
        {
            get { return ElementManager.GetElementById("~ExMessage").As<HtmlSpan>(); }
        }

        public HtmlInputText AsOfDate
        {
            get { return ElementManager.GetElementById("~dtSelector_wdcValue_input").As<HtmlInputText>(); }
        }

        public HtmlSelect PortfolioSelect
        {
            get { return ElementManager.GetElementById("~ddlPortfolio").As<HtmlSelect>(); }
        }

        public HtmlSelect RedemptionPolicyTypeSelect
        {
            get { return ElementManager.GetElementById("~ddlRedemptionPolicyType_ddlEnum").As<HtmlSelect>(); }
        }

        public HtmlSelect Layouts
        {
            get { return ElementManager.GetElementById("~ddlLayouts").As<HtmlSelect>(); }
        }

        public HtmlImage LayoutsBtn
        {
            get { return ElementManager.GetElementById("~imgbtnSaveLayout").As<HtmlImage>(); }
        }

        private HtmlSpan RedemptionFeeUpToAndIncludingText
        {
            get { return ElementManager.GetElementById("~_lblRedFeeUpToAndIncluding").As<HtmlSpan>(); }
        }

        private HtmlTableCell ColumnsOrderButton
        {
            get { return ElementManager.GetElementByClass("DBCellSpaceButton DBToolColumns DBEmpty").As<HtmlTableCell>(); }
        }

        private HtmlInputSubmit OptionsButton
        {
            get { return ElementManager.GetElementById("~btnOptions").As<HtmlInputSubmit>(); }
        }

        private HtmlDiv Alert //null return needed
        {
            get { return Find.ById<HtmlDiv>("divFundList"); }
        }

        private HtmlTableCell BtnExportToExcel
        {
            //get { return Toolbar.Find.ByAttributes<HtmlTableCell>("class=~DBCellSpaceButton DBToolExport"); }
            get
            {
                return
                    ElementManager.GetElementByAttributes(Toolbar, "class=~DBCellSpaceButton DBToolExport").As
                        <HtmlTableCell>();
            }
        }

        private HtmlDiv Toolbar
        {
            get { return ElementManager.GetElementByClass("DBToolbarRow").As<HtmlDiv>(); }
        }

        public HtmlInputSubmit BtnNextEligibleLiquidityEvent
        {
            get { return ElementManager.GetElementById("~btnNext").As<HtmlInputSubmit>(); }
        }

        public HtmlTable LiquidityTable
        {
            get { return ElementManager.GetElementById("Dashboard").As<HtmlTable>(); }
        }

        public HtmlTable LiquidityGraph
        {
            get { return ElementManager.GetElementById("~Table2").As<HtmlTable>(); }
        }

        public NewHtmlChart LiquidityChart
        {
            get { return new NewHtmlChart(Find, "LiquidityGraph_container"); }
        }

        private HtmlTableCell FundExpandControl(string fundName, string investDate = null)
        {
            return LiquidityTable.Find.ByAttributes<HtmlTableCell>("class=~DBEmpty DBE",
                                                                   "class=~" + INDEX_ATTR +
                                                                   GetRowIndex(fundName, investDate) + " ");
        }

        private HtmlTableCell FundCollapseControl(string fundName, string investDate = null)
        {
            return LiquidityTable.Find.ByAttributes<HtmlTableCell>("class=~DBEmpty DBC",
                                                                   "class=~" + INDEX_ATTR +
                                                                   GetRowIndex(fundName, investDate) + " ");
        }

        private IEnumerable<HtmlTableCell> GetTableHeaderCells(bool scrollWholeTable = true)
        {
            if (scrollWholeTable) ScrollWholeTable();

            return LiquidityTable.Find.AllByAttributes<HtmlTableCell>("class=~DBWrap0 DBHeaderText DBCellHeader");
        }

        private HtmlTableCell GetTableColumnHeaderCell(string columnName, bool scrollWholeTable = false)
        {
            foreach (var cell in GetTableHeaderCells(scrollWholeTable))
                if (cell.InnerText.Equals(columnName))
                    return cell;

            return null;
        }

        private int TableColumnHeaderIndex(string columnName)
        {
            var headers = GetTableHeaderCells(false).ToList();

            for (int i = 0; i < headers.Count(); i++)
                if (headers[i].InnerText.Equals(columnName))
                    return i;

            // if not found, then scroll to the end and repeat
            headers = GetTableHeaderCells().ToList();

            for (int i = 0; i < headers.Count(); i++)
                if (headers[i].InnerText.Equals(columnName))
                    return i;

            return -1;
        }

        private HtmlControl ColumnSortArrows(string columnHeader)
        {
            var index = TableColumnHeaderIndex(columnHeader);
            var sorter =
                Find.AllByAttributes<HtmlTableCell>("class=~DBCellHeader DBNoLeft DBAlignRight DBHeaderButton").
                    ElementAt(index);

            return sorter.Find.ByXPath<HtmlControl>("//u");
        }

        private HtmlControl ColumnHeaderContextMenuItem(string text)
        {
            var menu = Find.ById<HtmlDiv>("~columnHeaderMenu");
            return menu.Find.ByContent<HtmlControl>(text);
        }

        private List<HtmlTableCell> GetLiquidityTableRow(string fundName, string subIndex = "")
        {
            ScrollWholeTable();
            subIndex = String.IsNullOrEmpty(subIndex) ? " " : "$" + subIndex;
            var result =
                LiquidityTable.Find.AllByAttributes<HtmlTableCell>(
                    "class=~" + INDEX_ATTR + GetRowIndex(fundName) + subIndex, "class=!DBEmpty").ToList();

            Assert.That(!result.Count.Equals(0), "Row not found!");

            return result;
        }

        #endregion

        #region Methods


        #region Layout Methods


        public LiquidityViewReportPage(Find find)
            : base(find)
        {
        }

        public LiquidityViewReportPage()
            : base(WebTest.ActiveBrowser.Find)
        {
        }

        public void CreateNewLayout(string name)
        {
            LayoutSaveAsPopup layout = GoToSaveAsLayout();
            layout.SaveNewLayout(name);
        }

        public string CreateNewLayoutWithErrorHandler(string name)
        {
            LayoutSaveAsPopup layout = GoToSaveAsLayout();
            return layout.SaveNewLayoutAndErorHandler(name);
        }

        public void LayoutSave()
        {
            var layoutMenu = InvokeLayoutsMenu();
            layoutMenu.SelectByText(ContextMenus.MenuItems.Save);
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();

        }

        public void LayoutDelete()
        {
            LayoutSaveAsPopup layout = GoToDeleteLayout();
            layout.DeleteApproveLayout();
        }

        public bool IsMenuItemPresent(string item)
        {
            var layoutMenu = InvokeLayoutsMenu();
            return layoutMenu.IsMenuItemPresent(ContextMenus.MenuItems.Delete);
        }


        public bool LayoutExists(string layout)
        {
            return Layouts.Options.Any(option => option.Text == layout);
        }

        public void LayoutSelect(string layout)
        {
            Layouts.Select(layout);
            BrowserPool.WaitUntilPageLoaded();
        }

        public LayoutSaveAsPopup GoToSaveAsLayout()
        {
            var layoutMenu = InvokeLayoutsMenu();
            layoutMenu.SelectByText(ContextMenus.MenuItems.SaveAs);
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            return new LayoutSaveAsPopup(Find);
        }

        public LayoutSaveAsPopup GoToDeleteLayout()
        {
            var layoutMenu = InvokeLayoutsMenu();
            layoutMenu.SelectByText(ContextMenus.MenuItems.Delete);
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            return new LayoutSaveAsPopup(Find);
        }


        #endregion

        #region ScrollTable

        private void ScrollTableRight()
        {
            TableScroller.MouseClick(MouseClickType.LeftClick, -50, 0, OffsetReference.RightCenter);
            WebTest.ActiveBrowser.RefreshDomTree();
        }

        private void ScrollTableLeft()
        {
            TableScroller.MouseClick(MouseClickType.LeftClick, 20, 5);
            WebTest.ActiveBrowser.RefreshDomTree();
        }

        public void ScrollWholeTable(bool right = true)
        {
            if (TableScroller == null) return;

            for (int i = 0; i < 15; i++)
                if (right) ScrollTableRight();
                else ScrollTableLeft();
        }

        public void ScrollToVisible(string columnHeader)
        {
            HtmlTableCell headerCell;

            while (true)
            {
                headerCell = GetTableColumnHeaderCell(columnHeader);
                var headerRect = headerCell.GetRectangle();
                var scrollRect = TableScroller.GetRectangle();

                if (scrollRect.Width == 0) break;
                if (headerRect.X > 0 && headerRect.X + headerRect.Width < scrollRect.Width) break;

                if (headerRect.X < 0)
                    ScrollTableLeft();
                if (headerRect.X + headerRect.Width > scrollRect.Width)
                    ScrollTableRight();
            }

            headerCell.ScrollToVisible();
        }

        #endregion

        #region Actions

        public void RemoveColumn(string columnName)
        {
            var cell = GetTableColumnHeaderCell(columnName);
            ScrollToVisible(columnName);
            cell.InvokeEvent(ScriptEventType.OnMouseOver);
            cell.MouseClick(MouseClickType.RightClick);
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();

            var removeMenu = ColumnHeaderContextMenuItem("Remove");
            removeMenu.ScrollToVisible();
            removeMenu.InvokeEvent(ScriptEventType.OnMouseOver);
            removeMenu.MouseClick();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
        }

        public ColumnsOrderWidgetClass OpenColumnsOrderWidget()
        {
            ColumnsOrderButton.ButtonClick();
            return new ColumnsOrderWidgetClass(Find);
        }

        public OptionsWidgetClass OpenOptionsWidget()
        {
            OptionsButton.ButtonClick();
            return new OptionsWidgetClass(Find);
        }

        public void ExpandRow(string fundName, string investDate = null)
        {
            if (!IsRowExpanded(fundName, investDate))
                FundExpandControl(fundName, investDate).MouseClick();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
        }

        public void CollapseRow(string fundName, string investDate = null)
        {
            if (IsRowExpanded(fundName, investDate))
                FundCollapseControl(fundName, investDate).MouseClick();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
        }

        public void CheckAggregateByLiquidityLot()
        {
            OpenOptionsWidget().SetAndApply(aggrigateByLot: true);
        }

        public void UncheckAggregateByLiquidityLot()
        {
            OpenOptionsWidget().SetAndApply(aggrigateByLot: false);
        }

        public void SetOptions(bool? aggrigateByLot = null, string asOfDate = null, string portfolio = null,
                               string redemPolicy = null, string redemFee = null, bool? includeGeneralFee = null)
        {
            OpenOptionsWidget().SetAndApply(aggrigateByLot, asOfDate, portfolio, redemPolicy, redemFee,
                                            includeGeneralFee);
        }

        public void SetColumns(List<string> columns)
        {
            OpenColumnsOrderWidget().Select(columns);
        }

        public void SetAndScroll(string reportDate = null, string redemptionPolicyType = null, string portfolio = null)
        {
            if (!string.IsNullOrEmpty(portfolio))
                PortfolioSelect.Select(portfolio);

            if (!string.IsNullOrEmpty(redemptionPolicyType))
                RedemptionPolicyTypeSelect.Select(redemptionPolicyType);

            if (!string.IsNullOrEmpty(reportDate))
                //AsOfDate.Select(reportDate);
                AsOfDate.TypeText(reportDate);

            ScrollWholeTable();
        }

        public void SortByColumn(string headerName, bool asc = true)
        {
            var expectedSorting = asc ? ASC : DESC;
            var tries = 5;

            ScrollToVisible(headerName);

            while (!GetColumnSorting(ColumnSortArrows(headerName)).Equals(expectedSorting))
            {
                ColumnSortArrows(headerName).MouseClick(MouseClickType.LeftClick, 2, 2);
                BrowserPool.AjaxPostBackWait();
                BrowserPool.WaitUntilPageLoaded();
                WebTest.ActiveBrowser.RefreshDomTree();

                if (--tries < 0) break;
            }
        }

        public void DragTableColumn(string headerName, int offset = 0)
        {
            ScrollToVisible(headerName);

            var headers = LiquidityTable.GetTableHeaders();
            var newPosition = headers.IndexOf(headerName) + offset;

            Assert.That((newPosition >= 0 && newPosition < headers.Count), "New position is out of range!");

            var cellToMove = GetTableColumnHeaderCell(headerName);
            var targetRect = GetTableColumnHeaderCell(headers[newPosition]).GetRectangle();
            var xPosition = (offset < 0) ? targetRect.X : targetRect.X + targetRect.Width;

            cellToMove.DragTo(new Point(xPosition, targetRect.Y));
        }

        public void Export(string exportFileName)
        {
            BtnExportToExcel.ClickAndDownload(exportFileName, true);
        }

        public void Export(string folderPath, string fileName)
        {
            BtnExportToExcel.ClickAndDownload(Path.Combine(folderPath, fileName), true);
        }

        public void SetRedemptionFeeUpToAndIncluding(string text)
        {
            OpenOptionsWidget().SetAndApply(redemFee: text);
        }

        #endregion

        #region Getters

        public string GetRedemptionFeeUpToAndIncludingText()
        {
            return RedemptionFeeUpToAndIncludingText.TextContent;
        }

        public string GetRedemptionFeeUpToAndIncluding()
        {
            var widget = OpenOptionsWidget();
            var result = widget.GetRedemptionFeeUpToAndIncluding();

            widget.Close();
            return result;
        }

        public string GetSelectedLayoutName()
        {
            return Layouts.SelectedOption.Text;
        }

        public int GetRowsCount(string fundName = null, string investDate = null)
        {
            if (string.IsNullOrEmpty(fundName))
                return LiquidityTable.Find.AllByAttributes("class=~HideCol0FundName").Count - 1;
            else
                return
                    LiquidityTable.Find.AllByAttributes(
                        "class=~" + INDEX_ATTR + GetRowIndex(fundName, investDate) + "$", "class=~HideCol0FundName").
                        Count + // sub-rows
                    LiquidityTable.Find.AllByAttributes(
                        "class=~" + INDEX_ATTR + GetRowIndex(fundName, investDate) + " ", "class=~HideCol0FundName").
                        Count; // total row
        }

        private string GetRowIndex(string fundName, string investDate = null)
        {
            var allFundCells = LiquidityTable.Find.AllByAttributes<HtmlTableCell>("class=~HideCol0FundName").ToList();
            var allDateCells =
                LiquidityTable.Find.AllByAttributes<HtmlTableCell>("class=~HideCol0Date", "class=!toGiveNotice").ToList();
            var result = string.Empty;
            HtmlTableCell fundCell = null;

            for (int i = 0; i < allFundCells.Count; i++)
                if ((allFundCells[i].InnerText.Contains(fundName)) &&
                    ((String.IsNullOrEmpty(investDate) || allDateCells[i].InnerText.Equals(investDate))))
                    fundCell = allFundCells[i];

            if (fundCell == null) return "";

            result = fundCell.GetAttributeValue("class");
            result = result.SubString(INDEX_ATTR, "DBCellClassInner").Trim();
            if (result.Contains("$")) result = result.Remove(result.IndexOf("$"));

            return result;
        }

        private string GetColumnClass(string columnName)
        {
            var count = 2;

            while (count > 0)
            {
                var headerCells =
                    LiquidityTable.Find.AllByAttributes<HtmlTableCell>("class=~DBWrap0 DBHeaderText DBCellHeader");

                foreach (var cell in headerCells)
                    if (cell.InnerText.Equals(columnName))
                        return cell.GetAttributeValue("class").SubString("HideCol0");

                ScrollWholeTable();
                count--;
            }

            return null;
        }

        public List<string> GetTableHeaders()
        {
            ScrollWholeTable();

            return LiquidityTable.GetTableHeaders();
        }

        public List<string> GetRowStyles(string fundName, string subIndex = "")
        {
            var result = new List<string>();

            foreach (var cell in GetLiquidityTableRow(fundName, subIndex))
            {
                if (cell.InnerText.Replace(SpecialSymbols.NBSP, String.Empty).Equals(string.Empty)) continue;

                var span = cell.Find.ByTagIndex<HtmlSpan>("span", 0);
                var style = (span == null)
                                ? "normal"
                                : span.GetStyleValue("fontStyle") + "&" + span.GetStyleValue("fontWeight");

                result.Add(style);
            }

            return result;
        }

        public List<string> GetRowValues(int rowIndex, string[] columns)
        {
            var result = new List<string>();

            foreach (var column in columns)
                result.Add(GetValue(column, rowIndex));

            return result;
        }

        public List<string> GetRowValues(string fundName, string subIndex = "")
        {
            var result = new List<string>();

            foreach (var cell in GetLiquidityTableRow(fundName, subIndex))
#if NEW_TELERIK
                result.Add(cell.InnerText);
#else
                result.Add(cell.InnerText.Replace(SpecialSymbols.NBSP, string.Empty));
#endif
            return result;
        }

        // Help method. Use for Liquidity tests to export current Liq. table to .csv file
        public void SaveToCsvAndFormExpectedLiquidityTable(List<string> columns, string file,
                                                           string nameOfTableStringVar = null)
        {
            var resultTable = GetTableAsListOfList(columns);

            using (StreamWriter writer = new StreamWriter(file))
            {
                resultTable.ForEach(line =>
                                        {
                                            var lineArray = line.Select(c => "\"" + c + "\" ").ToArray();
                                            writer.WriteLine(nameOfTableStringVar + ".AddRow(" +
                                                             string.Join(",", lineArray) + ");");
                                        });
            }
        }

        public List<List<string>> GetTableAsListOfList(List<string> columns = null)
        {
            var resultTable = new List<List<string>>();
            columns = !columns.Any() ? GetTableHeaders() : columns;

            for (var i = 0; i < GetRowsCount(); i++)
            {
                var row = new List<string>();
                foreach (var column in columns)
                    row.Add(GetValue(column, i));

                resultTable.Add(row);
            }
            return resultTable;
        }

        public Table<string> GetTable(List<string> columns = null)
        {
            var resultTable = new Table<string>();
            columns = columns ?? GetTableHeaders();

            resultTable.SetHeader(columns);

            for (var i = 0; i < GetRowsCount(); i++)
            {
                var row = new List<string>();
                foreach (var column in columns)
                    row.Add(GetValue(column, i));

                resultTable.AddRow(row.ToArray());
            }

            return resultTable;
        }

        public List<string> GetValues(string fundName, string column, string investmentDate = null)
        {
            var result = new List<string>();

            for (var rowNumber = 0; rowNumber < GetRowsCount(fundName, investmentDate); rowNumber++)
                result.Add(GetValue(fundName, column, investmentDate, rowNumber));

            return result;
        }

        public List<string> GetColumnValues(string column)
        {
            var result = new List<string>();

            for (var rowNumber = 0; rowNumber < GetRowsCount(); rowNumber++)
                result.Add(GetValue(column, rowNumber));

            return result;
        }

        public string GetValue(string fundName, string column, string investmentDate = null, int rowNumber = 0)
        {
            var cells =
                LiquidityTable.Find.AllByAttributes<HtmlTableCell>(
                    "class=~" + INDEX_ATTR + GetRowIndex(fundName, investmentDate), "class=~" + GetColumnClass(column));

            return rowNumber >= cells.Count
                       ? null
                       : cells[rowNumber].InnerText.Replace(SpecialSymbols.NBSP, string.Empty);
        }

        private static Collection<HtmlTableCell> FilterByClassEnding(Collection<HtmlTableCell> list, string filter)
        {
            var result = new Collection<HtmlTableCell>();

            foreach (var element in list)
                if (element.GetAttributeValue("class").EndsWith(filter))
                    result.Add(element);

            return result;
        }

        public string GetValue(string column, int rowNumber)
        {
            var className = GetColumnClass(column);
            var allColumns = LiquidityTable.Find.AllByAttributes<HtmlTableCell>("class=~HideCol0" + className,
                                                                                "class=!DBCellHeader");
            var columnCells = new List<HtmlTableCell>();

            foreach (var cell in allColumns)
                if (cell.GetAttributeValue("class").EndsWith(className))
                    columnCells.Add(cell);

#if NEW_TELERIK
            return rowNumber >= columnCells.Count ? null : columnCells[rowNumber].InnerText;
#else
            return rowNumber >= columnCells.Count
                       ? null
                       : columnCells[rowNumber].InnerText.Replace(SpecialSymbols.NBSP, string.Empty);
#endif
        }

        public string GetSilverlightGraph(string silverlightid, string paramName)
        {
            Element silverlight = ElementManager.GetElementById(silverlightid);
            return silverlight.Children.Where(e => e.GetAttribute("NAME").Value
                                                   == paramName).Select(c => c.GetAttribute("VALUE").Value).
                FirstOrDefault();
        }

        public string GetLiquiditySilverlightGraph()
        {
            return GetSilverlightGraph("silverlightControl", "InitParams");
        }

        #endregion

        public string GetReliefMethodNotificationMessageStatus()
        {
            var element = Find.ById<HtmlSpan>("~lblReliefMethodWarning");
            return element != null ? element.InnerText : null;
        }

        public bool IsRowExpanded(string fundName, string investDate = null)
        {
            return (FundExpandControl(fundName, investDate) == null);
        }

        public bool IsPopupAppear()
        {
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();

            try
            {
                Manager.Current.Wait.For(control => control.GetStyleValue("display") == "block", Alert, 3000);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool IsPopupAppearAndClose()
        {
            if (!IsPopupAppear()) return false;

            PopupAlertMessageCancelBtn.ButtonClick();
            return true;
        }

        public string GetPopupMessage()
        {
            var alertTitle = IsPopupAppear() ? PopupAlertTitle.InnerText : "";
            var alertText = PopupAlertMessage.InnerText;
            ClosePopupMessage();
            return alertTitle + "\n" + alertText;
        }

        public bool IsAggregationByLotChecked()
        {
            var widget = OpenOptionsWidget();
            var result = widget.AggregateByLiquidityLotCheckbox.Checked;

            widget.Close();
            return result;
        }

        public void ClosePopupMessage()
        {
            PopupAlertMessageCancelBtn.ButtonClick();
            AsOfDate.ScrollToVisible();
        }

        public List<string> GetPopMessagePositions(string popMessage, string splitPattern, bool isSidePocketList)
        {
            var lst = new List<string>();
            var posiArray = Regex.Split(popMessage, "Side Pocket Positions:");
            switch (posiArray.Length)
            {
                case 1:
                    {
                        //there are no side pocket positions in Popup message
                        lst = (isSidePocketList) ? lst : Regex.Split(posiArray[0], splitPattern).ToList();
                    }
                    break;
                case 2:
                    {
                        //there are some side pocket positions in Popup message
                        lst = (isSidePocketList)
                                  ? Regex.Split(posiArray[1], splitPattern).ToList()
                                  : Regex.Split(posiArray[0], splitPattern).ToList();
                    }
                    break;
            }
            if (lst.Count > 0)
                lst.Remove(lst.First());

            for (var k = 0; k < lst.Count; k++)
                lst[k] = splitPattern + lst[k];

            return lst;
        }

        private string GetColumnSorting(HtmlControl sorter)
        {
            var classValue = sorter.GetAttributeValue("class");

            switch (classValue.SubString("DBSort", "Right"))
            {
                case "1":
                case "2":
                case "3":
                    return ASC;
                case "4":
                case "5":
                case "6":
                    return DESC;
                default:
                    return string.Empty;
            }
        }

        public string GetColumnSorting(string headerName)
        {
            return GetColumnSorting(ColumnSortArrows(headerName));
        }

        #region Layouts Methods

        private ContextMenus InvokeLayoutsMenu()
        {
            LayoutsBtn.ButtonClick();
            return new ContextMenus(Find);
        }

        public void DeleteLayout(string layout)
        {
            Layouts.Select(layout);
            var layoutMenu = InvokeLayoutsMenu();
            layoutMenu.SelectByText("Delete");
        }

        #endregion

        #region Chart Methods

        public List<string> GetAllLockupsFromChart()
        {
            var lockups = new List<string>();

            foreach (var value in LiquidityChart.GetValues())
            {
                lockups.Add(value.Split("\r\n".ToCharArray())[4].Trim());
            }

            return lockups;
        }

        public List<string> GetSoftLockupsFromChart()
        {
            var allLockups = GetAllLockupsFromChart();

            return allLockups.GetRange(0, allLockups.Count/2);
        }

        public List<string> GetHardLockupsFromChart()
        {
            var allLockups = GetAllLockupsFromChart();

            return allLockups.GetRange(allLockups.Count/2, allLockups.Count/2);
        }

        public List<string> GetDatesFromChart()
        {
            var dates = new List<string>();

            foreach (var value in LiquidityChart.GetValues())
            {
                dates.Add(value.Split("\r\n".ToCharArray())[2].Trim());
            }

            return dates;
        }

        #endregion

        #endregion
    }

    public class ColumnsOrderWidgetClass
        {
            #region Controls
            protected Find Find;

            public ColumnsOrderWidgetClass(Find find)
            {
                Find = find;
            }

            public HtmlInputSubmit ApplyButton
            {
                get { return Find.ById<HtmlInputSubmit>("~btnApplySelectedColumns"); }
            }

            public HtmlInputButton CancelButton
            {
                get { return Find.ById<HtmlInputButton>("~btnSelectedColumnsCancel"); }
            }

            public MultiSelect AvailableColumns
            {
                get { return new MultiSelect(Find); }
            }

            public HtmlSelect SelectedColumns
            {
                get { return Find.ById<HtmlSelect>("~lbSelectedColumns"); }
            }

            #endregion

            #region Methods

            public void Close()
            {
                CancelButton.ButtonClick();
            }

            public void Apply()
            {
                ApplyButton.ButtonClick();
            }

            public void Select(List<string> columns)
            {
                AvailableColumns.UnCheckAll();
                AvailableColumns.Select(columns);
                Apply();
            }

            #endregion
        }

    public class OptionsWidgetClass
        {
            #region Controls

            protected Find Find;

            public OptionsWidgetClass(Find find)
            {
                Find = find;
            }

            public HtmlInputCheckBox AggregateByLiquidityLotCheckbox
            {
                get { return Find.ById<HtmlInputCheckBox>("~chkAggregate"); }
            }

            private HtmlButton RecalculateButton
            {
                get { return Find.ById<HtmlButton>("btn-recalculate"); }
            }

            private HtmlButton CloseButton
            {
                get { return Find.ById<HtmlButton>("~btn-close"); }
            }

            private HtmlInputText AsOfDate
            {
                get { return Find.ById<HtmlInputText>("~dtSelectorOptions_wdcValue_input"); }
            }

            private HtmlSelect PortfolioSelect
            {
                get { return Find.ById<HtmlSelect>("~ddlPortfolioOptions"); }
            }

            private HtmlSelect RedemptionPolicyTypeSelect
            {
                get { return Find.ById<HtmlSelect>("~ddlRedemptionPolicyTypeOptions_ddlEnum"); }
            }

            private HtmlInputText RedemptionFeeUpToAndIncluding
            {
                get { return Find.ById<HtmlInputText>("~_txtRedFeeUpToAndIncluding"); }
            }

            public HtmlInputCheckBox IncludeGeneralRedemptionFeeCheckbox
            {
                get { return Find.ById<HtmlInputCheckBox>("~chkIncludeGeneralFee"); }
            }

            #endregion

            #region Methods

            #region Set

            public void SetAndApply(bool? aggrigateByLot = null, string asOfDate = null, string portfolio = null,
                                    string redemPolicy = null, string redemFee = null, bool? includeGeneralFee = null)
            {
                if (!string.IsNullOrEmpty(asOfDate)) SetAsOfDate(asOfDate);
                if (!string.IsNullOrEmpty(portfolio)) SelectPortfolio(portfolio);
                if (!string.IsNullOrEmpty(redemFee)) SetRedemptionFeeUpToAndIncluding(redemFee);
                if (!string.IsNullOrEmpty(redemPolicy)) RedemptionPolicyTypeSelect.Select(redemPolicy);

                if (aggrigateByLot != null) AggregateByLiquidityLot(aggrigateByLot.Value);
                if (includeGeneralFee != null) IncludeGeneralRedemptionFee(includeGeneralFee.Value);

                Apply();
            }

            public void SetRedemptionFeeUpToAndIncluding(string text)
            {
                RedemptionFeeUpToAndIncluding.Clean();
                RedemptionFeeUpToAndIncluding.SendKeys(text);
                Manager.Current.Desktop.KeyBoard.KeyPress(Keys.Tab);
            }

            public void IncludeGeneralRedemptionFee(bool _checked = true)
            {
                IncludeGeneralRedemptionFeeCheckbox.Check(_checked);
            }

            public void AggregateByLiquidityLot(bool _checked = true)
            {
                AggregateByLiquidityLotCheckbox.Check(_checked);
            }

            public void SetStandardRedemptionPolicy()
            {
                RedemptionPolicyTypeSelect.Select("Standard");
            }

            public void SetAcceleratedRedemptionPolicy()
            {
                RedemptionPolicyTypeSelect.Select("Accelerated");
            }

            public void SetHybridRedemptionPolicy()
            {
                RedemptionPolicyTypeSelect.Select("Hybrid");
            }

            public void SetAsOfDate(string date)
            {
                AsOfDate.TypeText(date);
            }

            public void SelectPortfolio(string portfolio)
            {
                PortfolioSelect.Select(portfolio);
            }

            #endregion

            #region Get

            public string GetRedemptionFeeUpToAndIncluding()
            {
                return RedemptionFeeUpToAndIncluding.Text;
            }

            public List<List<string>> GetAll()
            {
                return new List<List<string>>()
                           {
                               new List<string>()
                                   {"Aggregate by Liquidity Lot:", AggregateByLiquidityLotCheckbox.Checked.ToString()},
                               new List<string>() {"Liquidity Analysis As Of:", AsOfDate.Text},
                               new List<string>() {"Portfolio:", PortfolioSelect.SelectedOption.Text},
                               new List<string>()
                                   {"Redemption Policy Type:", RedemptionPolicyTypeSelect.SelectedOption.Text},
                               new List<string>()
                                   {"Redemption Fee % Up To and Including:", RedemptionFeeUpToAndIncluding.Text},
                               new List<string>()
                                   {
                                       "Include General Redemption Fee:",
                                       IncludeGeneralRedemptionFeeCheckbox.Checked.ToString()
                                   }
                           };
            }

            #endregion

            public void Close()
            {
                CloseButton.ButtonClick();
            }

            public void Apply()
            {
                RecalculateButton.ButtonClick();
            }

            #endregion
        }

    public class LayoutSaveAsPopup : WebFrame 
        {
            #region Controls

            protected Find Find;

            public LayoutSaveAsPopup(Find find)
            {
                Find = find;
            }

            private HtmlInputText LayouttName
            {
                get { return Find.ByName<HtmlInputText>("ctl00$ctphBody$txtLayoutName"); }
            }

            private HtmlButton SaveBtn
            {
                get { return FindW.ById<HtmlButton>("btnSaveLayout"); }
            }

            private HtmlButton CloseBtn
            {
                get { return Find.ById<HtmlButton>("btnLayoutCancel"); }
            }

            private HtmlButton DeleteApproveBtn
            {
                get { return Find.ByContent<HtmlButton>("Delete Layout", FindContentType.InnerText); }
            }

            private HtmlDiv LayoutError
            {
                get { return FindW.ById<HtmlDiv>("divLayoutError"); }
            }

            #endregion

            #region Methods

            public void SaveNewLayout(string name)
            {
                LayouttName.TypeText(name);
                SaveBtn.SimpleClickAndWait();
            }

            public string SaveNewLayoutAndErorHandler(string name)
            {
                LayouttName.TypeText(name);
                SaveBtn.SimpleClickAndWait();
                var err = LayoutError.InnerText;
                CloseBtn.ButtonClick();
                return err;
            }

            public void DeleteApproveLayout()
            {
                DeleteApproveBtn.SimpleClickAndWait();
            }

            #endregion

        
        }
}