﻿using System.Linq;
using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context.Benchmark
{
    public class BlendedBenchmarkItem : WebFrame
    {
        public HtmlTableRow HeaderRow;
        public HtmlTableRow ItemRow;

        public BlendedBenchmarkItem(HtmlTableRow header, HtmlTableRow row)
        {
            this.HeaderRow = header;
            this.ItemRow = row;
        }
        
        public HtmlImage BtnExpand
        {
            get
            {
                return HeaderRow.Cells[0].Find.ByExpression<HtmlImage>("onclick=~javascript:ToggleCustomBenchmark");
            }
        }

        public HtmlImage BtnEdit
        {
            get
            {
                return HeaderRow.Cells[2].Find.ByExpression<HtmlImage>("onclick=~javascript:OW_ShowBenchmark");
            }
        }

        public HtmlInputImage BtnRemove
        {
            get
            {
                return HeaderRow.Cells[3].Find.ById<HtmlInputImage>("~delimg");
            }
        }

        public void Delete()
        {
            BtnRemove.ClickConfirmHandle();
        }

        public int EntryCount()
        {
            return ItemRow.InnerText.Split('%').Count() - 1;
        }
    }
}
