﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications.Annotations;

namespace IFS.AF.BaseContext.Context.Analytics.Correlation
{
    [UsedImplicitly]
    public class FundCorrelationsPage : WebPage
    {
        public override string Url
        {
            get { return "/pages/fund/FundCorrelations.aspx"; }
        }

        public override string Title
        {
            get { return "Fund Correlations"; }
        }

        #region Controls

        private HtmlSelect FundControl
        {
            get { return FindW.ById<HtmlSelect>("~ddlBaseFund"); }
        }

        private HtmlInputImage BtnExportToExcel
        {
            get { return FindW.ById<HtmlInputImage>("~imgbtnExportToExcel"); }
        }

        private HtmlSelect FilterControl
        {
            get { return FindW.ById<HtmlSelect>("~ddlFilter"); }
        }

        private HtmlInputText FromDateControl
        {
            get { return FindW.ById<HtmlInputText>("~dpFromDate"); }
        }

        private HtmlInputText ToDateControl
        {
            get { return FindW.ById<HtmlInputText>("~dpToDate"); }
        }

        private HtmlTable SummaryTable
        {
            get { return FindW.ById<HtmlTable>("~gvSummary"); }
        }

        private HtmlInputCheckBox NaN
        {
            get { return FindW.ById<HtmlInputCheckBox>("~chkNan"); }
        }

        private HtmlTable BenchmarkCorrelationsTable
        {
            get { return FindW.ById<HtmlTable>("~gvBenchmarkCorrelations"); }
        }

        private HtmlTable BaseFundCorrelationsTable
        {
            get { return FindW.ById<HtmlTable>("~gvBaseFundCorrelations"); }
        }

        #endregion

        public string Fund
        {
            get { return FundControl.SelectedOption.Text; }
            set { FundControl.Select(value); }
        }

        public string Filter
        {
            get { return FilterControl.SelectedOption.Text; }
            set { FilterControl.SelectByText(value); }
        }

        public string FromDate
        {
            get { return FromDateControl.Text; }
            set { FromDateControl.TypeText(value); }
        }

        public string ToDate
        {
            get { return ToDateControl.Text; }
            set { ToDateControl.TypeText(value); }
        }

        public bool HideNaNCorrelations
        {
            get { return NaN.Checked; }
            set { NaN.Check(value); }
        }

        public GridTable Summary
        {
            get { return new GridTable(SummaryTable); }
        }

        public GridTable BenchmarkCorrelations
        {
            get { return new GridTable(BenchmarkCorrelationsTable); }
        }

        public GridTable BaseFundCorrelations
        {
            get { return new GridTable(BaseFundCorrelationsTable); }
        }

        public void ExportToExcel(string fullTargetFileName)
        {
            BtnExportToExcel.ClickAndDownload(fullTargetFileName);
        }

        public struct RowValues
        {
            public string FirstColumn;
            public string N;
            public string R;
            public string Rsquared;
            public string Alpha;
            public string Beta;
            public string TrackingError;
        }

        public static RowValues Headers(bool isBenchmark = false)
        {
            return new RowValues
            {
                FirstColumn = isBenchmark ? "Benchmark Name" : "Fund Name",
                N = "N",
                R = "r",
                Rsquared = "r-squared",
                Alpha = "Alpha",
                Beta = "Beta",
                TrackingError = "Tracking Error"
            };
        }
    }
}
