﻿using System;
using System.Collections.Generic;
using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context.Analytics.Comparison.ComparisonGrid;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context.Analytics.Comparison
{
    public class AnalyticsComparisonPage : WebPage
    {
        public override string Url
        {
            get { return "/pages/comparison/comparison.aspx"; }
        }

        public override string Title
        {
            get { return "Alpha Frontier >> Analytics >> Comparisons"; }
        }

        #region Controls
        private HtmlSelect ComparisonSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddlComparison"); }
        }

        private HtmlInputButton SaveAsBtn
        {
            get { return FindW.ById<HtmlInputButton>("~btnSaveAs"); }
        }

        private HtmlInputButton DeleteBtn
        {
            get { return FindW.ById<HtmlInputButton>("~btnDelete"); }
        }

        private HtmlInputButton ModifyBtn
        {
            get { return Find.ById<HtmlInputButton>("~btnModify"); }
        }

        private HtmlSelect BenchmarkSelect
        {
            get { return FindW.ById<HtmlSelect>("~dblBenchmark"); }
        }

        private HtmlInputText RiskFreeRateInput
        {
            get { return FindW.ById<HtmlInputText>("~txtRiskFreeRate"); }
        }

        private HtmlInputText MARInput
        {
            get { return FindW.ById<HtmlInputText>("~txtMAR"); }
        }

        private HtmlImage SearchImage
        {
            get { return FindW.ById<HtmlImage>("~imgComparisonSearch"); }
        }

        private HtmlSelect FilterSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddlFilter"); }
        }

        private HtmlInputText FromDatePicker
        {
            get { return FindW.ById<HtmlInputText>("~fromDate_wdcValue_input"); }
        }

        private HtmlInputText ToDatePicker
        {
            get { return FindW.ById<HtmlInputText>("~toDate_wdcValue_input"); }
        }

        private HtmlInputImage ExportExcelImage
        {
            get { return FindW.ById<HtmlInputImage>("~ImageButton1"); }
        }

        private HtmlSelect ReturnTypeSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddlReturnType"); }
        }

        private HtmlSelect LayoutsSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddlLayouts"); }
        }

        private HtmlImage ManageLayoutsImage
        {
            get { return FindW.ById<HtmlImage>("~imgbtnSaveLayout"); }
        }

        private HtmlTable ComparisonTable
        {
            get { return FindW.ById<HtmlTable>("Dashboard"); }
        }
        #endregion

        #region Methods
        public string Comparison
        {
            get { return ComparisonSelect.InnerText; }
            set { ComparisonSelect.Select(value); }
        }

        public string Benchmark
        {
            get { return BenchmarkSelect.InnerText; }
            set { BenchmarkSelect.Select(value); }
        }

        public string RiskFreeRate
        {
            get { return RiskFreeRateInput.Text; }
        }

        public string MAR
        {
            get { return MARInput.Text; }
        }

        public string Filter
        {
            get { return FilterSelect.InnerText; }
            set { FilterSelect.Select(value); }
        }

        public string FromDate
        {
            get { return FromDatePicker.Text; }
            set
            {
                if (FromDatePicker.IsDisabled())
                    throw new Exception("FromDatePicker is diabled");
                FromDatePicker.TypeText(value);
            }
        }

        public string ToDate
        {
            get { return ToDatePicker.Text; }
            set
            {
                if (ToDatePicker.IsDisabled())
                    throw new Exception("ToDatePicker is diabled");
                ToDatePicker.TypeText(value);
            }
        }

        public string ReturnType
        {
            get { return ReturnTypeSelect.InnerText; }
            set { ReturnTypeSelect.Select(value); }
        }

        public string Layout
        {
            get { return LayoutsSelect.InnerText; }
            set { LayoutsSelect.Select(value); }
        }
        
        public void ExportToExcell(string fullPath)
        {
            ExportExcelImage.ClickAndDownload(fullPath);
        }

        public ComparisonModifyPopUp GoToQuickSearch()
        {
            SearchImage.SimpleClickAndWait();
            return new ComparisonModifyPopUp();
        }

        public ComparisonSaveAsPopUp OpenSaveAsPopup()
        {
            SaveAsBtn.ButtonClick();
            return new ComparisonSaveAsPopUp();
        }

        public void Delete()
        {
            DeleteBtn.ClickConfirmHandle();
        }

        public ComparisonModifyPopUp OpenModifyPopup()
        {
            ModifyBtn.Click();
            return new ComparisonModifyPopUp();
        }

        public ComparisonSearchPopup OpenSearchPopup()
        {
            SearchImage.Click();
            return new ComparisonSearchPopup();
        }

        public AnalysisComparisonGrid ComparisonGrid
        {
            get { return new AnalysisComparisonGrid(ComparisonTable); }
        }

        public void SelectComparison(string comparisonName)
        {
            ComparisonSelect.SelectPartial(comparisonName);
        }
        #endregion
    }
}
