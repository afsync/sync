﻿using System.Collections.Generic;
using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications.Annotations;

namespace IFS.AF.BaseContext.Context.Analytics.Analysis
{

    public class MonthlyPerfomanceNetGridRow : AfTypedHtmlTableRow
    {
        public string Year
        {
            get { return Cells[0].InnerText; }
        }

        public string Jan
        {
            get { return Cells[1].InnerText; }
        }

        public string Feb
        {
            get { return Cells[2].InnerText; }
        }

        public string Mar
        {
            get { return Cells[3].InnerText; }
        }

        public string Apr
        {
            get { return Cells[4].InnerText; }
        }

        public string May
        {
            get { return Cells[5].InnerText; }
        }

        public string Jun
        {
            get { return Cells[6].InnerText; }
        }

        public string Jul
        {
            get { return Cells[7].InnerText; }
        }

        public string Aug
        {
            get { return Cells[8].InnerText; }
        }

        public string Sep
        {
            get { return Cells[9].InnerText; }
        }

        public string Oct
        {
            get { return Cells[10].InnerText; }
        }

        public string Nov
        {
            get { return Cells[11].InnerText; }
        }

        public string Dec
        {
            get { return Cells[12].InnerText; }
        }

        public string Ytd
        {
            get { return Cells[13].InnerText; }
        }

        public string Bm1
        {
            get { return Cells[14].InnerText; }
        }

        public string Bm2
        {
            get { return Cells[15].InnerText; }
        }
    }

    public class MonthlyPerfomanceNetComparer : IEqualityComparer<MonthlyPerfomanceNetGridRow>
    {
        public bool Equals(MonthlyPerfomanceNetGridRow x, MonthlyPerfomanceNetGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;
            return x.Year == y.Year &&
                   x.Jan == y.Jan &&
                   x.Feb == y.Feb &&
                   x.Mar == y.Mar &&
                   x.Apr == y.Apr &&
                   x.May == y.May &&
                   x.Jun == y.Jun &&
                   x.Jul == y.Jul &&
                   x.Aug == y.Aug &&
                   x.Sep == y.Sep &&
                   x.Oct == y.Oct &&
                   x.Nov == y.Nov &&
                   x.Dec == y.Dec &&
                   x.Ytd == y.Ytd &&
                   x.Bm1 == y.Bm1 &&
                   x.Bm2 == y.Bm2;
        }

        public int GetHashCode(MonthlyPerfomanceNetGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class DrawndownAnalysisHistoricalGridRow : AfTypedHtmlTableRow
    {
        public string Peak
        {
            get { return Cells[0].InnerText; }
        }

        public string Valley
        {
            get { return Cells[1].InnerText; }
        }

        public string Loss
        {
            get { return Cells[2].InnerText; }
        }

        public string Recovery
        {
            get { return Cells[3].InnerText; }
        }

        public string Bm1
        {
            get { return Cells[4].InnerText; }
        }

        public string Bm2
        {
            get { return Cells[5].InnerText; }
        }
    }

    public class DrawndownAnalysisHistoricalComparer : IEqualityComparer<DrawndownAnalysisHistoricalGridRow>
    {

        public bool Equals(DrawndownAnalysisHistoricalGridRow x, DrawndownAnalysisHistoricalGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;
            return x.Peak == y.Peak &&
                   x.Valley == y.Valley &&
                   x.Loss == y.Loss &&
                   x.Recovery == y.Recovery &&
                   x.Bm1 == y.Bm1 &&
                   x.Bm2 == y.Bm2;
        }

        public int GetHashCode(DrawndownAnalysisHistoricalGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class DrawndownAnalysisCalendarGridRow : AfTypedHtmlTableRow
    {
        public string Index
        {
            get { return Cells[0].InnerText; }
        }

        public string CurrentFund
        {
            get { return Cells[1].InnerText; }
        }

        public string Bm1
        {
            get { return Cells[2].InnerText; }
        }

        public string Bm2
        {
            get { return Cells[3].InnerText; }
        }

    }

    public class DrawndownAnalysisCalendarComparer : IEqualityComparer<DrawndownAnalysisCalendarGridRow>
    {
        public bool Equals(DrawndownAnalysisCalendarGridRow x, DrawndownAnalysisCalendarGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;
            return x.Index == y.Index &&
                   x.CurrentFund == y.CurrentFund &&
                   x.Bm1 == y.Bm1 &&
                   x.Bm2 == y.Bm2;
        }

        public int GetHashCode(DrawndownAnalysisCalendarGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class RollingGridRow : AfTypedHtmlTableRow
    {
        public string Index
        {
            get { return Cells[0].InnerText; }
        }

        public string CurrentFund
        {
            get { return Cells[1].InnerText; }
        }

        public string Bm1
        {
            get { return Cells[2].InnerText; }
        }

        public string Bm2
        {
            get { return Cells[3].InnerText; }
        }

    }

    public class RollingGridRowComparer : IEqualityComparer<RollingGridRow>
    {

        public bool Equals(RollingGridRow x, RollingGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;
            return x.Index == y.Index &&
                   x.CurrentFund == y.CurrentFund &&
                   x.Bm1 == y.Bm1 &&
                   x.Bm2 == y.Bm2;
        }

        public int GetHashCode(RollingGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class CorrelationsGridRow : AfTypedHtmlTableRow
    {
        public string Coefficient
        {
            get { return Cells[0].InnerText; }
        }

        public string Bm1
        {
            get { return Cells[1].InnerText; }
        }

        public string Bm2
        {
            get { return Cells[2].InnerText; }
        }

    }

    public class CorrelationComparer : IEqualityComparer<CorrelationsGridRow>
    {
        public bool Equals(CorrelationsGridRow x, CorrelationsGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;

            return x.Coefficient == y.Coefficient &&
                   x.Bm1 == y.Bm1 &&
                   x.Bm2 == y.Bm2;
        }

        public int GetHashCode(CorrelationsGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class RiskMeasuresGridRow : AfTypedHtmlTableRow
    {
        public string Percentage
        {
            get { return Cells[0].InnerText; }
        }

        public string P1
        {
            get { return Cells[1].InnerText; }
        }

        public string P2
        {
            get { return Cells[2].InnerText; }
        }

        public string P3
        {
            get { return Cells[3].InnerText; }
        }

        public string P4
        {
            get { return Cells[4].InnerText; }
        }
    }

    public class RiskMeasuresComparer : IEqualityComparer<RiskMeasuresGridRow>
    {
        public bool Equals(RiskMeasuresGridRow x, RiskMeasuresGridRow y)
        {
            if (x.Count != y.Count) return false;
            if (ReferenceEquals(x, y)) return true;
            return x.Percentage == y.Percentage &&
                   x.P1 == y.P1 &&
                   x.P2 == y.P2 &&
                   x.P3 == y.P3 &&
                   x.P4 == y.P4;
        }

        public int GetHashCode(RiskMeasuresGridRow obj)
        {
            return obj.GetHashCode();
        }
    }

    public class RiskReturnsGrid
    {
        private readonly HtmlTable _tableLeft;
        private readonly HtmlTable _tableRight;

        public RiskReturnsGrid(HtmlTable tableLeft, HtmlTable tableRight)
        {
            _tableLeft = tableLeft;
            _tableRight = tableRight;
        }

        //Left table
        public string ClassicalMean
        {
            get { return _tableLeft.GetCell(0, 1).InnerText; }
        }

        public string BestMonthDate
        {
            get { return _tableLeft.GetCell(1, 1).InnerText; }
        }

        public string BestMonth
        {
            get { return _tableLeft.GetCell(2, 1).InnerText; }
        }

        public string TotalWinningMonths
        {
            get { return _tableLeft.GetCell(3, 1).InnerText; }
        }

        public string PercentWinningMonths
        {
            get { return _tableLeft.GetCell(4, 1).InnerText; }
        }

        public string TotalLosingMonths
        {
            get { return _tableLeft.GetCell(5, 1).InnerText; }
        }

        //Right table
        public string AveMonthlyWinning
        {
            get { return _tableRight.GetCell(0, 1).InnerText; }
        }

        public string AveMonthlyLosing
        {
            get { return _tableRight.GetCell(1, 1).InnerText; }
        }

        public string WorstMonthDate
        {
            get { return _tableRight.GetCell(2, 1).InnerText; }
        }

        public string WorstMonth
        {
            get { return _tableRight.GetCell(3, 1).InnerText; }
        }

        public string SortinoRatio
        {
            get { return _tableRight.GetCell(4, 1).InnerText; }
        }

        public string SharpeRatio
        {
            get { return _tableRight.GetCell(5, 1).InnerText; }
        }

        public override bool Equals(object obj)
        {
            var compObj = obj as RiskReturnsGrid;
            if (compObj == null) return false;

            return ClassicalMean == compObj.ClassicalMean &&
                   BestMonthDate == compObj.BestMonthDate &&
                   BestMonth == compObj.BestMonth &&
                   TotalWinningMonths == compObj.TotalWinningMonths &&
                   PercentWinningMonths == compObj.PercentWinningMonths &&
                   TotalLosingMonths == compObj.TotalLosingMonths &&
                   AveMonthlyWinning == compObj.AveMonthlyWinning &&
                   AveMonthlyLosing == compObj.AveMonthlyLosing &&
                   WorstMonthDate == compObj.WorstMonthDate &&
                   SortinoRatio == compObj.SortinoRatio &&
                   SharpeRatio == compObj.SharpeRatio;
        }
        public override int GetHashCode()
        {
            int hash = 12;
            hash = (hash*8) + ClassicalMean.GetHashCode();
            hash = (hash * 8) + BestMonthDate.GetHashCode();
            hash = (hash * 8) + BestMonth.GetHashCode();
            hash = (hash * 8) + TotalWinningMonths.GetHashCode();
            hash = (hash * 8) + PercentWinningMonths.GetHashCode();
            hash = (hash * 8) + TotalLosingMonths.GetHashCode();
            hash = (hash * 8) + AveMonthlyWinning.GetHashCode();
            hash = (hash * 8) + AveMonthlyLosing.GetHashCode();
            hash = (hash * 8) + WorstMonthDate.GetHashCode();
            hash = (hash * 8) + WorstMonth.GetHashCode();
            hash = (hash * 8) + SortinoRatio.GetHashCode();
            hash = (hash * 8) + SharpeRatio.GetHashCode();
            return hash;
        }
    }

    public class VolitilityAndCharacteristicsGrid
    {
        private readonly HtmlTable _tableLeft;
        private readonly HtmlTable _tableRight;

        public VolitilityAndCharacteristicsGrid(HtmlTable tableLeft, HtmlTable tableRight)
        {
            _tableLeft = tableLeft;
            _tableRight = tableRight;
        }

        //Left table
        public string ClassicalStandardDeviation
        {
            get { return _tableLeft.GetCell(0, 1).InnerText; }
        }

        public string ClassicalStandardDeviationAnn
        {
            get { return _tableLeft.GetCell(1, 1).InnerText; }
        }

        public string ClassicalSkewness
        {
            get { return _tableLeft.GetCell(2, 1).InnerText; }
        }

        //Right table
        public string ClassicalKurtosis
        {
            get { return _tableRight.GetCell(0, 1).InnerText; }
        }

        public string VolatilityUpside
        {
            get { return _tableRight.GetCell(1, 1).InnerText; }
        }

        public string VolatilityDownsideSemiDeviation
        {
            get { return _tableRight.GetCell(2, 1).InnerText; }
        }

        public override bool Equals(object obj)
        {
            var compObj = obj as VolitilityAndCharacteristicsGrid;
            if (compObj == null) return false;
            if (ReferenceEquals(this, compObj)) return true;
            return ClassicalStandardDeviation == compObj.ClassicalStandardDeviation &&
                   ClassicalStandardDeviationAnn == compObj.ClassicalStandardDeviationAnn &&
                   ClassicalSkewness == compObj.ClassicalSkewness &&
                   ClassicalKurtosis == compObj.ClassicalKurtosis &&
                   VolatilityUpside == compObj.VolatilityUpside &&
                   VolatilityDownsideSemiDeviation == compObj.VolatilityDownsideSemiDeviation;
        }

        public override int GetHashCode()
        {
            int hash = 12;
            hash = (hash*8) + ClassicalStandardDeviation.GetHashCode();
            hash = (hash*8) + ClassicalStandardDeviationAnn.GetHashCode();
            hash = (hash*8) + ClassicalSkewness.GetHashCode();
            hash = (hash*8) + ClassicalKurtosis.GetHashCode();
            hash = (hash*8) + VolatilityUpside.GetHashCode();
            hash = (hash*8) + VolatilityDownsideSemiDeviation.GetHashCode();
            return hash;
        }
    }

    [UsedImplicitly]
    public class AnalyticsAnalysisPage : WebPage
    {
        public override string Url
        {
            get { return "AlphaFrontierAuto/pages/fund/Analysis.aspx"; }
        }

        public override string Title
        {
            get { return "Alpha Frontier >> Analytics >> Analysis"; }
        }

        public HtmlImage PrintButton
        {
            get
            {
                return FindW.ById<HtmlImage>("~btnPrint");
            }
        }

        #region Export to Excel

        public HtmlInputImage ExportToExcel
        {
            get { return FindW.ById<HtmlInputImage>("~btnExport"); }
        }

        #endregion

        #region Radio button group (type)

        public HtmlInputRadioButton FundTypeBasefund
        {
            get { return FindW.ById<HtmlInputRadioButton>("~rblFundType_0"); }
        }

        public HtmlInputRadioButton FundTypePortfolio
        {
            get { return FindW.ById<HtmlInputRadioButton>("~rblFundType_1"); }
        }

        public HtmlInputRadioButton FundTypeBenchmarks
        {
            get { return FindW.ById<HtmlInputRadioButton>("~rblFundType_2"); }
        }

        #endregion

        #region Base fund or Portfolio select (name)

        public HtmlSelect BaseFundSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddBaseFund"); }
        }

        public HtmlSelect PortfolioSelect
        {
            get { return FindW.ById<HtmlSelect>("~_ddPortfolios"); }
        }

        public HtmlSelect BenchmarksSelect
        {
            get { return FindW.ById<HtmlSelect>("~ddBenchmarks"); }
        }

        #endregion

        #region Aggregation

        public HtmlSelect Aggregation
        {
            get { return FindW.ById<HtmlSelect>("~ddlAggregation"); }
        }

        #endregion

        #region Value

        public HtmlSelect SubAggregation
        {
            get { return FindW.ById<HtmlSelect>("~ddlSubAggregation"); }
        }

        #endregion

        #region Report Period

        public HtmlInputText ReportPeriodFrom
        {
            get { return FindW.ById<HtmlInputText>("~ctrlFromDate_wdcValue_input"); }
        }

        public HtmlInputText ReportPeriodTo
        {
            get { return FindW.ById<HtmlInputText>("~ctrlToDate_wdcValue_input"); }
        }

        #endregion

        #region Risk free rate (%):

        public HtmlInputText RiskFreeRate
        {
            get { return FindW.ById<HtmlInputText>("~txtRiskFreeRate"); }
        }

        #endregion

        #region MAR (%)

        public HtmlInputText MAR
        {
            get { return FindW.ById<HtmlInputText>("~txtMar"); }
        }

        #endregion

        #region Return type

        public HtmlSelect ReturnType
        {
            get { return FindW.ById<HtmlSelect>("~dblReturnType"); }
        }

        #endregion

        #region Benchmarks

        public HtmlSelect Bm1
        {
            get { return FindW.ById<HtmlSelect>("~dblBenchmark1"); }
        }

        public HtmlSelect Bm2
        {
            get { return FindW.ById<HtmlSelect>("~dblBenchmark2"); }
        }

        #endregion

        // ReSharper restore InconsistentNaming

        #region Tables

        public HtmlTable MonthlyPerfomanceNetTable
        {
            get { return FindW.ById<HtmlTable>("~tblHistoryScreenData"); }
        }

        public HtmlTable DrawndownAnalysisHistoricalTable
        {
            get { return FindW.ById<HtmlTable>("~UCDrawdownsHistorical1_tbl"); }
        }

        public HtmlTable DrawndownAnalysisCalendarTable
        {
            get { return FindW.ById<HtmlTable>("~UCDrawdownsCalendar1__tblAnalytics"); }
        }

        public HtmlTable RollingTable
        {
            get { return FindW.ById<HtmlTable>("~UCRolling1__tblAnalytics"); }
        }

        public HtmlTable CorrelationsTable
        {
            get { return FindW.ById<HtmlTable>("~UCCorrelation1_tbl"); }
        }

        public HtmlTable RiskMeasuresTable
        {
            get { return FindW.ById<HtmlTable>("~tblRiskMeasures"); }
        }

        public HtmlTable RiskReturnsTableLeft
        {
            get { return FindW.ById<HtmlTable>("~UCAnalytics1_tbl"); }
        }

        public HtmlTable RiskReturnsTableRigth
        {
            get { return FindW.ById<HtmlTable>("~UCAnalytics1_tbl1"); }
        }

        public HtmlTable VolitilityAndCharacteristicsTableLeft
        {
            get { return FindW.ById<HtmlTable>("~UCAnalytics1_tbl2"); }
        }

        public HtmlTable VolitilityAndCharacteristicsTableRigth
        {
            get { return FindW.ById<HtmlTable>("~UCAnalytics1_tbl3"); }
        }

        #endregion

        #region Indicators

        public HtmlDiv ErrorIndicator
        {
            get { return FindW.ById<HtmlDiv>("~upnlDataErrors"); }
        }

        /// <summary>
        /// If page contains no error - this element is present
        /// </summary>
        public HtmlDiv GreenCheckMark
        {
            get
            {
                try
                {
                    return FindW.ById<HtmlDiv>("~divDataNoErrors");
                }
                catch
                {
                    return null;
                }

            }
        }

        /// <summary>
        /// If page contains ERROR - this element is present
        /// </summary>
        public HtmlDiv RedXMark
        {
            get
            {
                try
                {
                    return FindW.ById<HtmlDiv>("~divDataErrors");
                }
                catch
                {
                    return null;
                }
            }
        }

        public bool IsErrorPresent
        {
            get
            {
                var errorIndicator = RedXMark;
                return null != errorIndicator;
            }
        }

        #endregion

        #region Grids

        public AfTypedHtmlGrid<MonthlyPerfomanceNetGridRow> MonthlyPerfomanceNetGrid
        {
            get { return new AfTypedHtmlGrid<MonthlyPerfomanceNetGridRow>(MonthlyPerfomanceNetTable); }
        }

        public AfTypedHtmlGrid<DrawndownAnalysisHistoricalGridRow> DrawndownAnalysisHistoricalGrid
        {
            get { return new AfTypedHtmlGrid<DrawndownAnalysisHistoricalGridRow>(DrawndownAnalysisHistoricalTable); }
        }

        public AfTypedHtmlGrid<DrawndownAnalysisCalendarGridRow> DrawndownAnalysisCalendarGrid
        {
            get { return new AfTypedHtmlGrid<DrawndownAnalysisCalendarGridRow>(DrawndownAnalysisCalendarTable); }
        }

        public AfTypedHtmlGrid<RollingGridRow> RollingGrid
        {
            get { return new AfTypedHtmlGrid<RollingGridRow>(RollingTable); }
        }

        public AfTypedHtmlGrid<CorrelationsGridRow> CorrelationsGrid
        {
            get { return new AfTypedHtmlGrid<CorrelationsGridRow>(CorrelationsTable); }
        }

        public AfTypedHtmlGrid<RiskMeasuresGridRow> RiskMeasuresGrid
        {
            get { return new AfTypedHtmlGrid<RiskMeasuresGridRow>(RiskMeasuresTable); }
        }

        public RiskReturnsGrid RiskReturnsGrid
        {
            get { return new RiskReturnsGrid(RiskReturnsTableLeft, RiskReturnsTableRigth); }
        }

        public VolitilityAndCharacteristicsGrid VolitilityAndCharacteristicsGrid
        {
            get
            {
                return new VolitilityAndCharacteristicsGrid(VolitilityAndCharacteristicsTableLeft,
                    VolitilityAndCharacteristicsTableRigth);
            }
        }

        #endregion

        public AnalysisPrintPopup GoToPrintPage()
        {
            PrintButton.SimpleClickAndWait();
            return new AnalysisPrintPopup();
        }
    }
}
