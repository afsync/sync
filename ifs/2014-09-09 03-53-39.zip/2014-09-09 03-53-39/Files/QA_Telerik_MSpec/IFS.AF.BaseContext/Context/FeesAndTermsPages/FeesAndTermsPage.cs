﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Context.FeesAndTermsPages.Popups;
using IFS.AF.BaseContext.Context.FeesAndTermsPages.Widgets;
using IFS.AF.BaseContext.Context.General;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.BaseContext.Helpers.Common;
using IFS.AF.BaseContext.Helpers.GSM;

namespace IFS.AF.BaseContext.Context.FeesAndTermsPages
{
    public class FeesAndTermsPage : WebPage
    {
        private AddClassPopup _addClassPopup;
        private CreateSideLetterPopup _createSideletter;
        
        #region F&T Widgets
        public readonly BasicInfoWidget BasicInfoWidget = new BasicInfoWidget();
        public readonly FeesWidget FeesWidget = new FeesWidget();
        public readonly FeeRebateWidget FeeRebateWidget = new FeeRebateWidget();
        public readonly SubscriptionPolicyWidget SubscriptionPolicyWidget = new SubscriptionPolicyWidget();
        public readonly RedemptionPaymentScheduleWidget RedemptionPaymentScheduleWidget = new RedemptionPaymentScheduleWidget();
        public readonly RedemptionEventsWidget RedemptionEventsWidget = new RedemptionEventsWidget();
        public readonly RedemptionPolicyWidget RedemptionPolicyWidget = new RedemptionPolicyWidget();
        #endregion
        
        #region Properties

        public override string Url
        {
            get { throw new System.NotImplementedException(); }
        }

        public override string Title
        {
            get { throw new System.NotImplementedException(); }
        }

        public HtmlSelect SeriesSideLst
        {
            get { return FindW.ById<HtmlSelect>("~ddlClassSeriesSide"); }
        }

        private HtmlInputSubmit NewBtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~ctrlTabset_ctrlFeesAndTerms_btnNew"); }
        }

        private HtmlInputSubmit DeleteBtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~ctrlFeesAndTerms_btnDelete"); }
        }

        private HtmlInputSubmit SaveBtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~dynamicFeeTermsUserControl_btnSave"); }
        }

        private HtmlInputSubmit DuplicateBtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~ctrlTabset_ctrlFeesAndTerms_btnDuplicate"); }
        }

        private HtmlInputSubmit SideBtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~ctrlFeesAndTerms_btnSide"); }
        }

        protected HtmlTable MainTbl
        {
            get { return FindW.ById<HtmlTable>("~dynamicFeeTermsUserControl_gvSummaryInvested"); }
        }


        public HtmlAnchor Anchor
        {
            get { return FindW.ByExpression<HtmlAnchor>("InnerText=Fees And Terms", "id=~_ctrlTabset_lnkTab"); }
        }

        public HtmlInputCheckBox SidePocket
        {
            get { return FindW.ById<HtmlInputCheckBox>("~UCFeesAndTermsBasicInfo1_chkSidePocket"); }
        }

        public HtmlInputText ManagementFee
        {
            get { return FindW.ById<HtmlInputText>("~txtMgmtFee"); }
        }

        public HtmlInputText CarriedInterest
        {
            get { return FindW.ById<HtmlInputText>("~txtCarriedInt"); }
        }

        public HtmlInputText HurdlRate
        {
            get { return FindW.ById<HtmlInputText>("~txtHurdleRate"); }
        }

        public HtmlInputText TransactionFeeSplit
        {
            get { return FindW.ById<HtmlInputText>("~txtTransFee"); }
        }

        public HtmlInputText OrganizationFee
        {
            get { return FindW.ById<HtmlInputText>("~txtOrgFee"); }
        }

        public HtmlInputCheckBox Term
        {
            get { return FindW.ById<HtmlInputCheckBox>("~chkKeyMan"); }
        }

        public HtmlInputText InvestmentPeriod
        {
            get { return FindW.ById<HtmlInputText>("~txtInvPeriod"); }
        }

        public HtmlSpan AdjustedCapitalLabel
        {
            get { return FindW.ById<HtmlSpan>("~_ucFeesAndTermsBasicInfo_lblAdjustedCapital"); }
        }

        #endregion

        #region Actions

        public void ClickNew()
        {
            NewBtn.Click();
        }

        public void ClickSave()
        {
            SaveBtn.SimpleClickAndWait();
        }

        public string ClickSaveWithAlert()
        {
            return SaveBtn.ClickAlertHandle();
        }

        public void ClickSide()
        {
            SideBtn.Click();
        }

        public void ClickDuplicate()
        {
            DuplicateBtn.Click();
        }

        public void ClickDelete()
        {
            DeleteBtn.Click();
        }

        public void ClickDeleteAndConfirm()
        {
            DeleteBtn.ClickConfirmHandle();
        }

        public void WaitUntilPageLoaded()
        {
            Manager.Current.Wait.For(control => control.IsVisible(), SeriesSideLst, 5000); //wait while any (SeriesSideLst in this case) element appears on the screen
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
        }

        #endregion

        #region Getters

        private static bool IsDisabled(string control)
        {
            return control.Contains(" disabled ");
        }

        public bool IsDeleteBtnDisabled()
        {
            return IsDisabled(DeleteBtn.ToString());
        }

        public bool IsNewBtnDisabled()
        {
            return NewBtn.ToString().Contains(" disabled ");
        }

        public bool IsSideBtnDisabled()
        {
            return SideBtn.ToString().Contains(" disabled ");
        }

        public bool IsClassPresent(string className)
        {
            return SeriesSideLst.Options.Any(item => item.Text == className);
        }

        public bool IsClassSelected(string className)
        {
            return (SeriesSideLst.SelectedOption.Text == className);
        }

        #endregion

        #region MainMethods

        public void CreateGsmClass(GsmClassInfo classInfo)
        {
            if (IsClassPresent(classInfo.ClassName)) return;
            _addClassPopup = GoToCreateClass();
            _addClassPopup.SetGsmClassValues(classInfo);
            _addClassPopup.Save();
        }

        public string CreateGsmClassWithError(GsmClassInfo classInfo)
        {
            _addClassPopup = GoToCreateClass();
           _addClassPopup.SetGsmClassValues(classInfo);
            var result = _addClassPopup.SaveAndAlertHandle();
            _addClassPopup.Cancel();
            return result;
        }

        public string DuplicateClass(DuplicateClassInfo duplClassInfo)
        {
            ClickDuplicate();
            _addClassPopup = new AddClassPopup();
            var browserId = IePopupHelper.GetHtmlPopup("Add Class", "/pages/popups/AddFundOrPortfolioClass.aspx");

            _addClassPopup.DuplicateClass(duplClassInfo);

            _addClassPopup.ClickSave();
            IePopupHelper.CloseHtmlPopup(browserId.ClientId);

            WaitHelper.AjaxPostBackWait();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return DialogHelper.AlertDialogInfo.Message;
        }

        public string DuplicateClassWithError(DuplicateClassInfo duplClassInfo)
        {
            _addClassPopup = new AddClassPopup();
            ClickDuplicate();

            var browserId = IePopupHelper.GetHtmlPopup("Add Class", "/pages/popups/AddFundOrPortfolioClass.aspx");

            _addClassPopup.DuplicateClass(duplClassInfo);

            DialogHelper.StartAlertMonitor();
                _addClassPopup.ClickSave(false);
                WaitHelper.AjaxPostBackWait();
                Thread.Sleep(Constants.TIMEOUT_MEDIUM);
                DialogHelper.StopAlertMonitor();
                _addClassPopup.ClickCancel();
                DialogHelper.ResetDialogMonitor();
            IePopupHelper.CloseHtmlPopup(browserId.ClientId);

            WaitHelper.AjaxPostBackWait();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return DialogHelper.AlertDialogInfo.Message;
        }

        public GsmClassInfoToGet GetGsmClassData(string className, string operation = ClassOperations.EDIT, string effDate = null)
        {
            var getClassInfo = new GsmClassInfoToGet();
            switch (operation)
            {
                case ClassOperations.EDIT:
                    SelectClass(className);
                    getClassInfo = BasicInfoWidget.GetGsmClassData(effDate);
                    break;
                case ClassOperations.CREATE:
                    ClickNew();
                    _addClassPopup = GoToCreateClass();
                    getClassInfo = _addClassPopup.GetGsmClassData();
                    _addClassPopup.Cancel();
                    break;
                case ClassOperations.DUPLICATE:
                    SelectClass(className);
                    ClickDuplicate();
                    _addClassPopup = new AddClassPopup();
                    getClassInfo = _addClassPopup.GetGsmClassData();
                    _addClassPopup.Cancel();
                    break;
            }
            WaitHelper.AjaxPostBackWait();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return getClassInfo;
        }

        public ClientClassInfoToGet GetClientClassData(string clientClassName = null, string operation = ClassOperations.EDIT, 
            string effDate = null, string gsmClassName = null)
        {
            _addClassPopup = new AddClassPopup();
            var getClassInfo = new ClientClassInfoToGet();
            switch (operation)
            {
                case ClassOperations.EDIT:
                    SelectClass(clientClassName);
                    getClassInfo = BasicInfoWidget.GetClientClassData(effDate);
                    break;
                case ClassOperations.CREATE:
                    _addClassPopup = GoToCreateClass();
                    if (gsmClassName != null)
                    {
                        _addClassPopup.SelectGsmClass(gsmClassName);
                    }
                    getClassInfo = _addClassPopup.GetClientClassData();
                    _addClassPopup.Cancel();
                    break;
            }

            WaitHelper.AjaxPostBackWait();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return getClassInfo;
        }
        
        public string CreateClientClass(ClientClassInfo classInfo, bool withError = false)
        {
            _addClassPopup = GoToCreateClass();
            _addClassPopup.SetClientClassValues(classInfo);
            var result = string.Empty;
            if (withError)
            {
                result = _addClassPopup.SaveAndAlertHandle();
                _addClassPopup.Cancel();
            }
            else
                _addClassPopup.Save();

            return result;
        }

        public bool IsGsmClassPresent(string gsmClassName)
        {
            _addClassPopup = GoToCreateClass();
            var isPresent = _addClassPopup.IsGsmClassPresent(gsmClassName);
            _addClassPopup.Cancel();
            
            return isPresent;
        }

        public void EditGsmClass(string className, GsmClassInfo classInfo)
        {
            SelectClass(className);
            BasicInfoWidget.SetGsmClassValues(classInfo);
            ClickSave();
        }

        public string EditGsmClassWithError(GsmClassInfo classInfo, bool withError = false, string className = null)
        {
            if (className != null) SelectClass(className);
            BasicInfoWidget.SetGsmClassValues(classInfo);

            if (withError)
            {
                DialogHelper.StartAlertMonitor();
                ClickSave();
                WaitHelper.AjaxPostBackWait();
                // Thread.Sleep(Constants.TIMEOUT_MEDIUM);
                DialogHelper.StopAlertMonitor();
            }
            else
                ClickSave();

            return DialogHelper.AlertDialogInfo.Message;
        }

        public void EditClientClass(string className, ClientClassInfo classInfo, bool isSave=true)
        {
            SelectClass(className);
            BasicInfoWidget.SetClientClassValues(classInfo);

            if (isSave) ClickSave();
        }

        public void EditClassName(string newClassName, string newEffectiveDate = null, string effectiveDate = "initial")
        {
            BasicInfoWidget.EffectiveDate.SetEffectiveDateMain(newEffectiveDate ?? effectiveDate);
            BasicInfoWidget.SetGsmClassValues(new GsmClassInfo { ClassName = newClassName });
            
            ClickSave();
        }

        public void CreateNewSideLetter(string sideLetter)
        {            
            ClickSide();
            var browserId = IePopupHelper.GetHtmlPopup(CreateSideLetterPopup.TITLE, CreateSideLetterPopup.GSMURL);
            WaitHelper.AjaxPostBackWait();
            _createSideletter = new CreateSideLetterPopup();
            _createSideletter.UploadSideLetter(sideLetter);
            _createSideletter.ClickAccept();
            LogReport.MakeScreenshot();
            IePopupHelper.CloseHtmlPopup(browserId.ClientId,100000);
            WaitHelper.AjaxPostBackWait();
        }

        public string RemoveClass(string className)
        {
            SelectClass(className);

            DialogHelper.StartConfirmMonitor();
            ClickDelete();
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);
            DialogHelper.StopConfirmMonitor();

            WaitHelper.AjaxPostBackWait();
            Manager.Current.ActiveBrowser.RefreshDomTree();

            return DialogHelper.AlertDialogInfo.Message;
        }

        public void RemoveClassIfExists(string className)
        {
            if (IsClassPresent(className)) RemoveClass(className);
        }
        #endregion

        #region SummaryPageMethods

        public void SelectClass(string className)
        {
            SeriesSideLst.Select(className);
        }

        public string SelectClassWithAlert(string className)
        {
            return SeriesSideLst.SelectAlertHandle(className);
        }

        public List<string> GetClassNames()
        {
            var list = SeriesSideLst.Options.Select(option => option.Text).ToList();
            list.RemoveAt(0);
            return list;
        }

        public int GetClassesAmountInGrid()
        {
            return MainTbl.AllRows.Select(row => row.ChildNodes[0].As<HtmlTableCell>()).Count() - 1;
        }

        public List<string> GetClassNamesFromGrid()
        {
            var classesList = new List<string>();
            foreach (var row in MainTbl.AllRows)
            {
                classesList.Add(row.ChildNodes[0].As<HtmlTableCell>().InnerText);
            }
            return classesList;
        }

        public bool IsClassPresentInGrid(string className)
        {
            return MainTbl.AllRows.Select(tableCell => tableCell.ChildNodes[0].As<HtmlTableCell>())
                .Any(tdCell => tdCell.InnerText == className);
        }

        public int GetFirstFundClassId()
        {
            return int.Parse(GetClassesIDsInGrid().First());
        }

        public List<string> GetClassesIDsInGrid()
        {
            List<string> idList = MainTbl.BodyRows.Select(row => row.Cells[1].InnerText).ToList();
            idList.RemoveRange(0, 1);
            return idList;
        }

        public List<string> GetTableHeader()
        {
            var headerRow = FindW.ByAttributes<HtmlTableRow>("class=grid_heading");
            return headerRow.Cells.Select(cell => cell.InnerText).ToList();
        }

        public HtmlAnchor GetLink(string className)
        {
            var a = Find.AllByContent(className);
            return a[1].As<HtmlAnchor>();
        }

        public HtmlTableRow GetClassNameRow(string className)
        {
            return GetLink(className).Parent<HtmlTableRow>();
        }
        
        public string GetValue(string header, string className)
        {
            var headerList = GetTableHeader();
            var classNameRow = GetClassNameRow(className);
            int counter = 0;
            var bFound = false;
            string result = null;
            while((counter<=headerList.Count()))
            {
                if (headerList[counter] == header)
                {
                    bFound = true;
                    break;
                }
                counter++;
            }
            if (bFound)
            {
                result = classNameRow.Cells[counter].InnerText.Replace("&nbsp;", "");
            }
            return result;
        }
        
        public string GetIDFromLink(string name)
        {
            var value = GetLink(name).BaseElement.GetAttribute("Href").Value;
            var str = StringTransform.GetField(value, "(", 2).Replace("&nbsp;", "");
            return str.Replace(")", "");
        }

        public bool AreClassesSortedInDropdown()
        {
            var itemsList = new List<string>();
            itemsList.AddRange(SeriesSideLst.Options.Select(item => item.Text));
            if (itemsList.Count == 0) return false;

            for (int i = 2; i < itemsList.Count; i++)
            {
                if (itemsList[i].CompareTo(itemsList[i - 1]) < 0)
                    return false;
            }
            return true;
        }

        public bool AreClassesSortedInGrid()
        {
            var itemsList = new List<string>();
            var tableRow = MainTbl.Find.AllByAttributes<HtmlTableRow>();
            itemsList.AddRange(tableRow.Select(tableCell => 
                tableCell.ChildNodes[0].As<HtmlTableCell>()).Select(tdCell => tdCell.InnerText));
            if (itemsList.Count == 1) return false; 

            for (int i = 2; i < itemsList.Count; i++)
            {
                if (itemsList[i].CompareTo(itemsList[i - 1]) < 0)
                    return false;
            }

            return true;
        }

        public bool GetSidePocketForClass(string clasName)
        {
            SelectClass(clasName, false);
            Thread.Sleep(5000);
            return SidePocket.Checked;
        }
        
        public void SetSidePocketForClass(string clasName, bool state)
        {           
            SelectClass(clasName, false);
            SidePocket.Check(state, true);
            SaveBtn.SimpleClickAndWait();
        }
        
        public void SelectClass(string className, bool distinctName = true)
        {
            if (distinctName)
                SeriesSideLst.Select(className);
            else
                SeriesSideLst.SelectPartial(className);
        }

        public AddClassPopup GoToCreateClass()
        {
            NewBtn.SimpleClickAndWait();
            return new AddClassPopup();
        }
        #endregion

        #region Specific methods

        public RedemptionPolicyWidget GetRedemPolicyInstance()
        {
            return new RedemptionPolicyWidget();
        }

        public void SetAllWidgetsEffDate(string effDate)
        {
            FeesWidget.EffectiveDate.SetEffectiveDateMain(effDate);
            FeeRebateWidget.EffectiveDate.SetEffectiveDateMain(effDate);
            SubscriptionPolicyWidget.EffectiveDate.SetEffectiveDateMain(effDate);
            RedemptionPaymentScheduleWidget.EffectiveDate.SetEffectiveDateMain(effDate);
            RedemptionEventsWidget.EffectiveDate.SetEffectiveDateMain(effDate);
            RedemptionPolicyWidget.EffectiveDate.SetEffectiveDateMain(effDate);
        }

        public void DeleteAllWidgetsEffDate(string issueDate)
        {
            FeesWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
            FeeRebateWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
            SubscriptionPolicyWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
            RedemptionPaymentScheduleWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
            RedemptionEventsWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
            RedemptionPolicyWidget.EffectiveDate.RemoveEffectiveDate(issueDate);
        }

        public FtWidgets AreEffDatePresentInAllWidgets()
        {
            return new FtWidgets
                       {
                           Fees = FeesWidget.EffectiveDate.IsMainBlockPresent(),
                           FeeRebate = FeeRebateWidget.EffectiveDate.IsMainBlockPresent(),
                           SubscriptionPolicy = SubscriptionPolicyWidget.EffectiveDate.IsMainBlockPresent(),
                           RedempPaymentSchedule = RedemptionPaymentScheduleWidget.EffectiveDate.IsMainBlockPresent(),
                           RedemptionEvents = RedemptionEventsWidget.EffectiveDate.IsMainBlockPresent(),
                           RedemptionPolicy = RedemptionPolicyWidget.EffectiveDate.IsMainBlockPresent(),
                           BasicInfo = BasicInfoWidget.EffectiveDate.IsMainBlockPresent()
                       };
        }

        public void SetAllWidgetsInfo(FtWidgetsInfo widgetsData, FtWidgets widgetsToSet, bool isGsm = true)
        {
            if (isGsm)
            {
                if (widgetsToSet.BasicInfo) BasicInfoWidget.SetGsmClassValues(widgetsData.BasicInfoToSet);
            }
            else if (widgetsToSet.BasicInfo) BasicInfoWidget.SetClientClassValues(widgetsData.ClientBasicInfoToSet);
            if (widgetsToSet.Fees) FeesWidget.SetValues(widgetsData.Fees);
            if (widgetsToSet.FeeRebate) FeeRebateWidget.SetValues(widgetsData.FeeRebate);
            if (widgetsToSet.SubscriptionPolicy) SubscriptionPolicyWidget.SetValues(widgetsData.SubscriptionPolicy);
            if (widgetsToSet.RedempPaymentSchedule) RedemptionPaymentScheduleWidget.SetValues(widgetsData.RedempPaymentSchedule);
            if (widgetsToSet.RedemptionEvents) RedemptionEventsWidget.SetValues(widgetsData.RedempEvents);
            if (widgetsToSet.RedemptionPolicy) RedemptionPolicyWidget.SetValues(widgetsData.RedempPolicy);
        }

        public FtWidgetsInfo GetAllWidgetsInfo(FtWidgets widgetsToGet, bool  isGsm = true, bool isGsmFlow = true)
        {
            var result = new FtWidgetsInfo();

            if (isGsm)
            {
                if (widgetsToGet.BasicInfo)
                    result.BasicInfoGet = BasicInfoWidget.GetGsmClassData();
            }
            else
            {
                if (widgetsToGet.BasicInfo)
                    result.ClientBasicInfoGet = BasicInfoWidget.GetClientClassData();
            }
            if (widgetsToGet.Fees) result.Fees = FeesWidget.GetValues(!isGsm, isGsmFlow);
            if (widgetsToGet.FeeRebate) result.FeeRebate = FeeRebateWidget.GetValues(!isGsm, isGsmFlow);
            if (widgetsToGet.SubscriptionPolicy) result.SubscriptionPolicy = SubscriptionPolicyWidget.GetValues(!isGsm, isGsmFlow);
            if (widgetsToGet.RedempPaymentSchedule) result.RedempPaymentSchedule = RedemptionPaymentScheduleWidget.GetValues(!isGsm, isGsmFlow);
            if (widgetsToGet.RedemptionEvents) result.RedempEvents = RedemptionEventsWidget.GetValues(!isGsm, isGsmFlow);
            if (widgetsToGet.RedemptionPolicy) result.RedempPolicy = RedemptionPolicyWidget.GetValues(!isGsm, isGsmFlow);
            return result;
        }

        public FtWidgets AreAllWidgetsDisabled()
        {
            return  new FtWidgets
                        {
                            Fees = ClassDataHelper.AreControlsDisabled(FeesWidget.GetWidgetControls()),
                            FeeRebate = ClassDataHelper.AreControlsDisabled(FeeRebateWidget.GetWidgetControls()),
                            SubscriptionPolicy = ClassDataHelper.AreControlsDisabled(SubscriptionPolicyWidget.GetWidgetControls()),
                            RedempPaymentSchedule = ClassDataHelper.AreControlsDisabled(RedemptionPaymentScheduleWidget.GetWidgetControls()),
                            RedemptionEvents = ClassDataHelper.AreControlsDisabled(RedemptionEventsWidget.GetWidgetControls()),
                            RedemptionPolicy = ClassDataHelper.AreControlsDisabled( RedemptionPolicyWidget.GetWidgetControls())
                        };
        }
        
        public void ApproveBasicInfoWidget(string effDate = null)
        {
            BasicInfoWidget.EffectiveDate.Approve(effDate);
            BasicInfoWidget.ApproveGeneralFields();
        }

        public void ApproveOtherWidgets(string effDate = null)
        {
            FeesWidget.EffectiveDate.Approve(effDate);
            FeeRebateWidget.EffectiveDate.Approve(effDate);
            SubscriptionPolicyWidget.EffectiveDate.Approve(effDate);
            RedemptionPolicyWidget.EffectiveDate.Approve(effDate);
            RedemptionPaymentScheduleWidget.EffectiveDate.Approve(effDate);
            RedemptionEventsWidget.EffectiveDate.Approve(effDate);
        }

        public WidgetsApproveInfo GetApproveInfo(string effDate = null)
        {
            var approveInfo = new WidgetsApproveInfo();
            FeesWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsFeesApproved = FeesWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsFeesApproveEnabled = FeesWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;

            FeeRebateWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsFeeRebateApproved = FeeRebateWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsFeeRebateApproveEnabled = FeeRebateWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;
            
            SubscriptionPolicyWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsSubscriptionPolicyApproved = SubscriptionPolicyWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsSubscriptionPolicyApproveEnabled = SubscriptionPolicyWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;
            
            RedemptionPolicyWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsRedemptionPolicyApproved = RedemptionPolicyWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsRedemptionPolicyApproveEnabled = RedemptionPolicyWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;
            
            RedemptionPaymentScheduleWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsRedempPaymentScheduleApproved = RedemptionPaymentScheduleWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsRedempPaymentScheduleApproveEnabled = RedemptionPaymentScheduleWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;
            
            RedemptionEventsWidget.EffectiveDate.SetEffectiveDate(effDate);
            approveInfo.IsRedemptionEventsApproved = RedemptionEventsWidget.EffectiveDate.GetEffectiveDateInfo().IsApproved;
            approveInfo.IsRedemptionEventsApproveEnabled = RedemptionEventsWidget.EffectiveDate.GetEffectiveDateInfo().IsApprovedEnabled;

            return approveInfo;
        }
        
        public void ApproveFtWidgets(WidgetsApproveTask approveTask, string effDate = null)
        {
            var feesAndTermsPage = new FeesAndTermsPage();
            
            if (approveTask.AllWidgetsApprove)
            {
                ApproveBasicInfoWidget();
                ApproveOtherWidgets();
            }
            else
            {
                if (approveTask.BasicInfoApprove)
                {
                    BasicInfoWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.BasicInfoGeneralFieldsApprove)
                {
                    BasicInfoWidget.ApproveGeneralFields();
                }
                if (approveTask.FeesApprove)
                {
                    FeesWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.FeeRebateApprove)
                {
                    FeeRebateWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.SubscriptionPolicyApprove)
                {
                    SubscriptionPolicyWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.RedemptionPolicyApprove)
                {
                    RedemptionPolicyWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.RedempPaymentScheduleApprove)
                {
                    RedemptionPaymentScheduleWidget.EffectiveDate.Approve(effDate);
                }
                if (approveTask.RedemptionEventsApprove)
                {
                    RedemptionEventsWidget.EffectiveDate.Approve(effDate);
                }
            }
            feesAndTermsPage.ClickSave();

            }

        public void ApproveFtWidgetsAnotherUser(string userLogin, string gsmFund, string gsmClass, WidgetsApproveTask approveTask, string effDate = null)
        {
            var gsmHeader = new GsmHeaderPage();
            var feesAndTermsPage = new FeesAndTermsPage();
            var login = new LoginPage();

            login.ReLogin(userLogin, Clients.GsmManager, GsmPage.Gsm);
            gsmHeader.SelectFund(gsmFund);
            gsmHeader.GoToFeesAndTerms();
            feesAndTermsPage.SelectClass(gsmClass);
            ApproveFtWidgets(approveTask,effDate);
        }

        public void ApproveWidgets(string effDate = null,  bool allWidgets = true,  bool basicInfo = false, bool generalInfo = false, bool fees = false,
                                   bool feeRebate = false, bool subPolicy  = false, bool redPolicy = false, bool redPayments = false, bool redEvents = false)
        {
            if (allWidgets)
            {
                ApproveBasicInfoWidget();
                ApproveOtherWidgets();
                ClickSave();
                return;
            }

            if (basicInfo)   BasicInfoWidget.EffectiveDate.Approve(effDate);
            if (generalInfo) BasicInfoWidget.ApproveGeneralFields();
            if (fees)        FeesWidget.EffectiveDate.Approve(effDate);
            if (feeRebate)   FeeRebateWidget.EffectiveDate.Approve(effDate);
            if (subPolicy)   SubscriptionPolicyWidget.EffectiveDate.Approve(effDate);
            if (redPolicy)   RedemptionPolicyWidget.EffectiveDate.Approve(effDate);
            if (redPayments) RedemptionPaymentScheduleWidget.EffectiveDate.Approve(effDate);
            if (redEvents)   RedemptionEventsWidget.EffectiveDate.Approve(effDate);

            ClickSave();
        }

        #endregion
    }
}
