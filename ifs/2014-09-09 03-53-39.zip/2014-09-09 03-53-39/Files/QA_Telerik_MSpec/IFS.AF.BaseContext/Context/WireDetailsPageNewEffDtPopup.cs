﻿using System;
using ArtOfTest.WebAii.Controls.HtmlControls;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Base;

namespace IFS.AF.UIControls.Context
{
    public class WireDetailsPageNewEffDtPopup : WebPage
    {
        private const string EFFECTIVE_DATE_TXTBOX = "~_txtEffectiveDate_wdcValue_input";
        private const string EFFECTIVE_CREATENEW_BTN = "~_btnCreateNewEffectiveDate";
        private const string EFFECTIVE_CANCEL_BTN = "~_btnCreateNewEffectiveDateCancel";

        public HtmlInputText EffectiveDate
        {
            get { return Find.ById<HtmlInputText>(EFFECTIVE_DATE_TXTBOX); }
        }
        public HtmlInputSubmit CreateNewEffectDtBtn
        {
            get { return Find.ById<HtmlInputSubmit>(EFFECTIVE_CREATENEW_BTN); }
        }
        public HtmlButton CancelBtn
        {
            get { return Find.ById<HtmlButton>(EFFECTIVE_CANCEL_BTN); }
        }

        public override string Url
        {
            get { throw new NotImplementedException(); }
        }

        public override string Title
        {
            get { throw new NotImplementedException(); }
        }
    }
}
