﻿using System.Collections.Generic;
using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications.Annotations;
using WebAii.Framework.Context;

namespace IFS.AF.BaseContext.Context
{
    [UsedImplicitly]
    public class ContextMenus : BaseFindManager
    {
        public ContextMenus(Find find)
            : base(find)
        {}

        const string MENU_ITEM_CLASS = "~popup_menu_item";
        const int MENU_WAIT_TIMEOUT_MILISECONDS = 60 * 1000;

        public struct MenuItems
        {
            public static string Subscription = "Subscription";
            public static string Redemption = "Redemption";
            public static string Exchange = "Exchange";
            public static string Transfer = "Transfer";
            public static string TransferToIFS = "IFS To IFS";
            public static string Transfer3rdToIFS = "3rd Party To IFS";
            public static string TransferIFSTo3rd = "IFS To 3rd Party";
            public static string Equalization = "Equalization";
            public static string ContingentRedemption = "Contingent Redemption";
            public static string ActivityReport = "View Activity";
            public static string CashDistribution = "Cash Distribution";
            public static string Distribution = "Distribution";
            public static string Returns = "Returns";
            public static string ViewCorporateActions = "View Corporate Actions";
            public static string CorporateAction = "Corporate Action";
            public static string Delete = "Delete";
            public static string SaveAs = "Save As";
            public static string Save = "Save";
            public static string BuyToCover = "Buy To Cover";
            public static string Contribution = "Contribution";
            public static string Commitments = "Commitments";
            public static string SubscriptionTradeOrder = "New Subscription Trade"; //available for Basefund menu under Admin
        }

        public bool IsMenuItemPresent(string itemText)
        {
            var findExpression = new HtmlFindExpression("class=~context-menu-list", "class=~context-menu-root", "style=~z-index", "style=!display: none");

            var menuContainer = WebTest.ActiveBrowser.WaitForElement(findExpression, MENU_WAIT_TIMEOUT_MILISECONDS, false).As<HtmlUnorderedList>();
            var menuItem = menuContainer.Find.ByExpression<HtmlListItem>("class=~context-menu-item", "InnerText=~" + itemText);
            
            return menuItem != null;
        }

        private static HtmlContainerControl GetMenuItemByText(string itemText)
        {
            var findExpression = new HtmlFindExpression("class=~context-menu-list", "class=~context-menu-root", "style=~z-index", "style=!display: none");

            var menuContainer = WebTest.ActiveBrowser.WaitForElement(findExpression, MENU_WAIT_TIMEOUT_MILISECONDS, false).As<HtmlUnorderedList>();
            var menuItem = menuContainer.Find.ByExpression<HtmlListItem>("class=~context-menu-item", "InnerText=~" + itemText);

            Assert.IsNotNull(menuItem, string.Format("Cannot find menu item with text '{0}'", itemText));

            return menuItem;
        }

        public void SelectByText(string itemText)
        {
            GetMenuItemByText(itemText).InvokeEvent(ScriptEventType.OnMouseOver);
            GetMenuItemByText(itemText).MouseClick();
        }

        public void SelectSubmenuItemByText(string itemText)
        {
            var findExpression = new HtmlFindExpression("class=~context-menu-item", "class=~context-menu-submenu", "class=~hover");

            var subMenuContainer = WebTest.ActiveBrowser.WaitForElement(findExpression, MENU_WAIT_TIMEOUT_MILISECONDS, false).As<HtmlListItem>();
            var subMenuItem = subMenuContainer.Find.ByExpression<HtmlListItem>("class=~context-menu-item", "InnerText=" + itemText);

            Assert.IsNotNull(subMenuItem, string.Format("Cannot find menu item with text '{0}'", itemText));

            subMenuItem.MouseClick();
        }
        
        public void SelectByTextAndConfirm(string itemText)
        {
            GetMenuItemByText(itemText).ClickConfirmHandle();
        }

        public void SelectTransferByText(string menuText)
        {
            SelectByText(MenuItems.Transfer);
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            SelectSubmenuItemByText(menuText);
        }

        public void SelectByTransactionType(string transactionType)
        {
            var transferItem = MenuItems.Transfer;
            var itemText = GetMenuItemText(transactionType);
            if (transactionType.Contains(transferItem.ToUpper()))
            {
                SelectTransferByText(itemText);
            }
            else
            {
                SelectByText(itemText);
            }
        }

        private static string GetMenuItemText(string transactionType)
        {
            var dict = new Dictionary<string, string>
            {
                {TransactionType.SUBSCRIPTION, MenuItems.Subscription},
                {TransactionType.ADDITIONAL_SUBSCRIPTION, MenuItems.Subscription},
                {TransactionType.EXCHANGE_OUT, MenuItems.Exchange},
                {TransactionType.REDEMPTION, MenuItems.Redemption},
                {TransactionType.TRANSFER_OUT_3, MenuItems.TransferIFSTo3rd},
                {TransactionType.TRANSFER_OUT, MenuItems.TransferToIFS},
                {TransactionType.TRANSFER_IN_3, MenuItems.Transfer3rdToIFS},
                {TransactionType.EQUALIZATION_SUBSCRIPTION, MenuItems.Equalization},
                {TransactionType.CONTINGENT_REDEMPTION, MenuItems.ContingentRedemption},
                {TransactionType.CONTRIBUTION, MenuItems.Contribution},
                {TransactionType.CORPORATE_ACTION, MenuItems.CorporateAction},
                {TransactionType.BUY_TO_COVER_CONTINGENT_REDEMPTION, MenuItems.BuyToCover},
                {TransactionType.DISTRIBUTION, MenuItems.Distribution},
                {TransactionType.ADDITIONAL_COMMITMENT, MenuItems.Commitments},
                {TransactionType.REDUCE_COMMITMENT, MenuItems.Commitments},
                {TransactionType.CASH_DISTRIBUTION, MenuItems.CashDistribution},
                {TransactionType.TRADE_ORDER_SUBSCRIPTION, MenuItems.SubscriptionTradeOrder}
            };
            return dict[transactionType];
        }
    }
}
