﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Context.CP;
using IFS.AF.BaseContext.Context.ERepository;
using IFS.AF.BaseContext.Context.General;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.BaseContext.Helpers.CP;
using IFS.AF.BaseContext.Helpers.Common;

namespace IFS.AF.BaseContext.Context
{
    public class GsmNavigationPage : WebPage
    {
        public override string Url
        {
            get { return "/pages/GSM/"; }
        }

        public override string Title
        {
            get { return "Alpha Frontier"; }
        }

        #region Controls
        GsmNavigatonMenuMapping Menu
        {
            get { return new GsmNavigatonMenuMapping(Find); }
        }

        HtmlAnchor LogoutBtn
        {
            get { return Find.ById<HtmlAnchor>("~imgLogout"); }
        }
        #endregion

        #region Methods

        public GsmHeaderPage GoToGsm()
        {
            if (!Manager.Current.ActiveBrowser.Url.Contains(GsmPage.Gsm.Url))
                Menu.GSM.ButtonClick();
            BrowserPool.WaitUntilPageLoaded();

            return new GsmHeaderPage();
        }

        public ERepositoryBrowsePage GoToERepository()
        {
            Menu.eRepositoryBrowse.ButtonClick();
            return new ERepositoryBrowsePage(Find);
        }

        public FundGlobalContactsUpdateReport.FundGlobalContactsUpdateReport GoToFundGlobalContactsUpdateReport()
        {
            Menu.FundGlobalContactsUpdateReport.ButtonClick();
            return new FundGlobalContactsUpdateReport.FundGlobalContactsUpdateReport();
        }

        public CentralPricingPage GoToCentralPricing()
        {
            Menu.PricingApproval.ButtonClick();

            WaitHelper.AjaxPostBackWait();
            GridHelperBase.WaitForGridLoaded();

            return new CentralPricingPage();
        }


        public void MakeLogout()
        {
            LogoutBtn.ButtonClick();
        }

        #endregion
    }
}