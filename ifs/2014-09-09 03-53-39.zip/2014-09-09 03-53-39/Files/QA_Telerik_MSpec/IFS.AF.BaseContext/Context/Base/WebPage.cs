﻿using ArtOfTest.WebAii.Core;

namespace IFS.AF.BaseContext.Context.Base
{
    public abstract class WebPage : WebFrame
    {
        public abstract string Url { get; }
        public abstract string Title { get; }

        public virtual void WaitUntilPageLoaded()
        {
            Manager.Current.ActiveBrowser.WaitForUrl(Url, true, TimeOut.MIN_01);
        }
    }
}
