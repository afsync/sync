﻿using ArtOfTest.Common.Win32;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context
{
    public abstract class PopupPage : WebPage
    {
        protected Browser Browser;// { get; private set; }
        
        protected override Find Find
        {
            get
            {
                WaitPopup();
                return Browser.Find;
            }
        }

        protected override FindWrapper FindW
        {
            get
            {
                WaitPopup();
                return base.FindW;
            }
        }

        protected virtual HtmlInputControl SaveBtn
        {
            get { return FindW.ById<HtmlInputButton>("~btnSave"); }
        }

        private void WaitPopup()
        {
            if (Browser == null)
            {
                Browser = BrowserPool.IePopupOpen(Url, Title);
            }
        }

        public virtual void SetTopMostPosition()
        {
            Browser.Window.SetPosition(WindowPosition.TopMost);
        }

        protected virtual void MaximizeWindow()
        {
            WaitPopup();
            Manager.Current.ActiveBrowser.Window.Maximize();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
        }

        protected virtual void ClosePopup()
        {
            BrowserPool.IePopupClose(Browser.ClientId);
            Browser = null;
        }

        public virtual void Close()
        {
            Browser.Window.Close();
            ClosePopup();
        }

        public virtual void SaveAndClose()
        {
            SaveBtn.Click(true);
            ClosePopup();
        }
    }
}
