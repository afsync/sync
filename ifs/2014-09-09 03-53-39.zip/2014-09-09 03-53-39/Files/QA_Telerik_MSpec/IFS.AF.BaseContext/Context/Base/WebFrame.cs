﻿using ArtOfTest.WebAii.Core;

namespace IFS.AF.BaseContext.Context.Base
{
    public abstract class WebFrame
    {
        private FindWrapper _findWrapperEx;

        protected virtual Find Find
        {
            get { return Manager.Current.ActiveBrowser.Find; }
        }

        protected virtual FindWrapper FindW
        {
            get { return _findWrapperEx ?? (_findWrapperEx = new FindWrapper()); }
        }
    }
}
