﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;

namespace IFS.AF.BaseContext.Context.Checklists
{
    public class FileHistoryClueWidget : WebFrame
    {
        private readonly Find _find;
        public FileHistoryClueWidget()
        {
            var hDiv = Find.ById<HtmlDiv>("cluetip-inner");
            hDiv.Refresh();
            _find = hDiv.Find;
        }

        protected HtmlAnchor FileVersionAnchor
        {
            get { return _find.ByExpression<HtmlAnchor>("class=fileVersionAnchor"); }
        }

        public void ExportFile(string fullTargetFileName)
        {
            FileVersionAnchor.ClickAndDownload(fullTargetFileName);
        }

        sealed protected override Find Find
        {
            get { return base.Find; }
        }
    }
}
