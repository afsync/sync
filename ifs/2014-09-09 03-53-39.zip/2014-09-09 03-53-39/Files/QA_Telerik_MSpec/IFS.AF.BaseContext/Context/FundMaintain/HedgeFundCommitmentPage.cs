﻿using System.Collections.Generic;
using System.Linq;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using WebAii.Framework.Context;

namespace IFS.AF.BaseContext.Context.FundMaintain
{
    public class HedgeFundCommitmentPage : WebFrame
    {
        private HedgeFundCommitmentGrid _hedgeFundCommitmentGrid;

        public HtmlAnchor Anchor
        {
            get { return FindW.ByContent<HtmlAnchor>("Hedge Fund Commitment"); }
        }

        private HtmlInputSubmit Newbtn
        {
            get { return FindW.ById<HtmlInputSubmit>("~ctrlHedgeFundCommitment_btnNew"); }
        }

        private HtmlSelect ClassSelectFld
        {
            get { return FindW.ById<HtmlSelect>("~ctrlHedgeFundCommitment_ddlClass"); }
        }

        #region PageProperies

        public string ClassName
        {
            get { return ClassSelectFld.SelectedOption.Text; }
            set { ClassSelectFld.Select(value); }
        }

        public HedgeFundCommitmentGrid HedgeFundCommitmentGrid
        {
            get
            {
                return _hedgeFundCommitmentGrid ??
                       (_hedgeFundCommitmentGrid =
                           new HedgeFundCommitmentGrid("~ctrlHedgeFundCommitment_gvSummaryInvested"));
            }
        }

        #endregion

        #region Navigation

        public AddEditHedgeFundCommitmentPopup GoToCreateHedgeFundCommitment()
        {
            Newbtn.SimpleClickAndWait();
            return new AddEditHedgeFundCommitmentPopup();
        }

        public AdjustedCommitmentHistoryPopup GoToAdjustedCommitment(string className, string portfolio)
        {
            return HedgeFundCommitmentGrid.GetRow(className, portfolio).GoToAdjustedCommitment();
        }

        public CommitmentExpirationDateHistoryPopup GoToExpirationDate(string className, string portfolio)
        {
            return HedgeFundCommitmentGrid.GetRow(className, portfolio).GoToExpirationDate();
        }

        #endregion


    }

    public class HedgeFundCommitmentRow
    {
        private readonly HtmlTableRow _row;

        public HedgeFundCommitmentRow(HtmlTableRow row)
        {
            _row = row;
        }

        #region Row cells

        public string ClassName
        {
            get { return _row.Cells[0].ChildNodes[0].InnerText; }
        }

        public string Portfolio
        {
            get { return _row.Cells[1].InnerText; }
        }

        public string OriginalCommitment
        {
            get { return _row.Cells[2].InnerText; }
        }

        public string AdjustedCommitment
        {
            get { return _row.Cells[3].ChildNodes[0].InnerText; }
        }

        public string ExpirationDate
        {
            get { return _row.Cells[4].ChildNodes[0].InnerText; }
        }

        #endregion

        #region Anchors

        private HtmlAnchor ClassNameAnchor
        {
            get { return _row.Cells[0].ChildNodes[0].As<HtmlAnchor>(); }
        }

        private HtmlAnchor AdjustedCommitmentAnchor
        {
            get { return _row.Cells[3].ChildNodes[0].As<HtmlAnchor>(); }
        }

        private HtmlAnchor ExpirationDateAnchor
        {
            get { return _row.Cells[4].ChildNodes[0].As<HtmlAnchor>(); }
        }

        #endregion

        #region Navigation

        public AddEditHedgeFundCommitmentPopup GoToAddEditCommitment()
        {
            ClassNameAnchor.SimpleClickAndWait();
            return new AddEditHedgeFundCommitmentPopup();
        }

        public AdjustedCommitmentHistoryPopup GoToAdjustedCommitment()
        {
            AdjustedCommitmentAnchor.Click();
            return new AdjustedCommitmentHistoryPopup();
        }

        public CommitmentExpirationDateHistoryPopup GoToExpirationDate()
        {
            ExpirationDateAnchor.Click();
            return new CommitmentExpirationDateHistoryPopup();
        }

        #endregion

    }

    public class HedgeFundCommitmentGrid
    {
        private readonly List<HedgeFundCommitmentRow> _rows = new List<HedgeFundCommitmentRow>();
        public string ElementId { get; private set; }

        public HtmlTable Source
        {
            get
            {
                {
                    HtmlTable result;
                    try
                    {
                        result = _findWrapper.ById<HtmlTable>(ElementId);
                    }
                    catch
                    {
                        return null;
                    }
                    return result;
                }
            }
        }

        private readonly FindWrapper _findWrapper = new FindWrapper();

        public List<HedgeFundCommitmentRow> Rows
        {
            get
            {
                Clear();
                Update();
                return _rows;
            }
        }

        public HedgeFundCommitmentGrid(string elementId)
        {
            ElementId = elementId;
        }

        public void Update()
        {
            if (Source == null) return;
            for (var i = 1; i < Source.Rows.Count; i++)
            {
                var newRow = new HedgeFundCommitmentRow(Source.Rows[i]);
                _rows.Add(newRow);
            }
        }

        public void Clear()
        {
            if (_rows.Count != 0) _rows.Clear();
        }

        public HedgeFundCommitmentRow GetRow(string className, string portfolio)
        {
            return Rows.FirstOrDefault(node => node.ClassName == className && node.Portfolio == portfolio);
        }
    }
}