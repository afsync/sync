﻿using System;
using System.Collections.Generic;
using System.Linq;

using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.Base;
using IFS.AF.BaseContext.Helpers;
using NUnit.Framework;
using WebAii.Framework.Context;

namespace IFS.AF.BaseContext.Context.FundMaintain
{
    public class CustomTagsPages : WebPage
    {
        
        private CustomTagsGrid _customTagsGrid;
        protected static int CurrentTagNum;
        #region Anchor
        //private const string ANCOR = "Custom Tags";
        public HtmlAnchor Anchor
        {
            get { return FindW.ByContent<HtmlAnchor>("Custom Tags"); }
        }
        #endregion

        private const string ADD_CUSTOM_TAG_BTN = "~btnAddRows";
        private const string CUSTOM_TAG_TABLE = "~ctrlFundCustomTags_tblCustomTags";
        private const string SAVE_BTN = "~btnSave";

        #region PageProperies
        public HtmlInputSubmit AddCustomTagBtn
        {
            get { return FindW.ById(ADD_CUSTOM_TAG_BTN).As<HtmlInputSubmit>(); }
        }

        public HtmlInputSubmit SaveBtn
        {
            get { return FindW.ById(SAVE_BTN).As<HtmlInputSubmit>(); }
        }

        public HtmlTable CustomTable
        {
            get { return FindW.ById(CUSTOM_TAG_TABLE).As<HtmlTable>(); }
        }

        public CustomTagsGrid CustomTagsGrid
        {
            get { return _customTagsGrid ?? (_customTagsGrid = new CustomTagsGrid(CustomTable)); }
        }

        public void RefreshCustomTagGrid()
        {
            _customTagsGrid.Init(CustomTable);
        }
        #endregion

        #region Methods
        private CustomTagsRows FindRowByNum(int num)
        {
            return CustomTagsGrid.Rows.First(node => node.CustomTagLable == "Custom Tag " + num);
        }

        
        public CustomTagsRows FindRowByName(string name)
        {
            return CustomTagsGrid.Rows.First(node => node.CustomTagLable == name);
        }
        
        
        public string GetSelectedValueByTagNum(int num)
        {
            return FindRowByNum(num).CustomTagSelect.SelectedOption.Text;
        }

        public string GetSelectedValueByTagName(string name)
        {
            return FindRowByName(name).CustomTagSelect.SelectedOption.Text;
        }

        public void SetCustomTagValue(string name, string value)
        {
            Console.WriteLine("================");
            Console.WriteLine("name: " + name );
            Console.WriteLine("value: " + value);
            Console.WriteLine("================");

            FindRowByName(name).CustomTagSelect.Select(value);
        }

        public void SetCustomTagValueByIndex(string name, int index)
        {

            FindRowByName(name).CustomTagSelect.SelectByIndex(index);
        }

        public void SetCustomTagValue(int num, string value)
        {

            FindRowByNum(num).CustomTagSelect.Select(value);
        }

        public bool IsCustomTagOnPage(string name)
        {
            return !String.IsNullOrEmpty(FindRowByName(name).CustomTagLable);
        }

        public void AddCustomTag(int currentTag)
        {
            AddCustomTagBtn.Click();

            Console.WriteLine(currentTag);
//            RefreshCustomTagGrid();
            WebTest.ActiveBrowser.RefreshDomTree();
            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            Manager.Current.Wait.For(control => control.GetOptionsList().Contains(""), GetSelectById(currentTag), 20000);
            


        }


        public HtmlSelect GetSelectById(int id)
        {
            return FindW.ById<HtmlSelect>("ddlCustomTagValues" + id);
        }

        public void Save()
        {
            SaveBtn.ButtonClick();
            WebTest.ActiveBrowser.RefreshDomTree();
        }
        #endregion

        public override string Url
        {
            get { throw new NotImplementedException(); }
        }

        public override string Title
        {
            get { throw new NotImplementedException(); }
        }
    }

    public class CustomTagsRows
    {
        private HtmlTableRow _row;
        public CustomTagsRows(HtmlTableRow row)
        {
            _row = row;
        }

        public string CustomTagLable
        {
            get { return _row.Cells[0].InnerText; }
        }

        public HtmlSelect CustomTagSelect
        {
            get { return _row.Cells[2].ChildNodes[0].As<HtmlSelect>(); }
        }
    }

    public class CustomTagsGrid
    {
        private List<CustomTagsRows> _rows;

        public List<CustomTagsRows> Rows
        {
            get { return _rows ?? (_rows = new List<CustomTagsRows>());}
        }
        
        public CustomTagsGrid(HtmlTable table)
        {
            Init(table);
        }

        public void Init(HtmlTable table)
        {
            if (table == null)
                return;

            foreach (var row in table.Rows)
            {
                var newRow = new CustomTagsRows(row);
                Rows.Add(newRow);
            }
        }
    }
}