﻿using System;
using System.Collections.Generic;
using System.Text;
using ArtOfTest.Common.UnitTesting;

namespace IFS.AF.BaseContext.Helpers
{
    public static class CompareLists
    {
        public static void ShouldEqualExtended(this List<string> actual, List<string> expected)
        {
            var error = new StringBuilder();

            if (expected.Count != actual.Count)
                error.AppendLine(string.Format("Lists have different count: '{0}', Actual: '{1}'", expected.Count, actual.Count));

            for (var i = 0; i < Math.Max(expected.Count, actual.Count); i++)
            {
                var expectedValue = (i < expected.Count) ? expected[i] : "<null>";
                var actualValue   = (i < actual.Count)   ? actual[i]   : "<null>";

                if (expectedValue != actualValue)
                    error.AppendLine(string.Format("'{0}' Elements are different. Expected: '{1}', Actual: '{2}'", i + 1, expectedValue, actualValue));
            }

            Assert.IsTrue(string.IsNullOrEmpty(error.ToString()), "Lists are different!\n" + error);
        }
        
        public static void ShouldEqualExtended(this List<List<string>> actual, List<List<string>> expected)
        {
            var error = new StringBuilder();

            if (expected.Count != actual.Count)
                error.AppendLine(string.Format("Lists have different rows count: '{0}', Actual: '{1}'", expected.Count, actual.Count));
            if (expected[0].Count != actual[0].Count)
                error.AppendLine(string.Format("Lists have different columns count: '{0}', Actual: '{1}'", expected[0].Count, actual[0].Count));

            for (var i = 0; i < Math.Max(expected.Count, actual.Count); i++)
                for (var j = 0; j < Math.Max(expected[0].Count, actual[0].Count); j++)
                {
                    var expectedValue = (i < expected.Count && j < expected[0].Count) ? expected[i][j] : "<null>";
                    var actualValue   = (i < actual.Count   && j < actual[0].Count)   ? actual[i][j]   : "<null>";

                    if (expectedValue != actualValue)
                        error.AppendLine(string.Format("'{0};{1}' Elements are different. Expected: '{2}', Actual: '{3}'", i + 1, j+1, expectedValue, actualValue));
                }

            Assert.IsTrue(string.IsNullOrEmpty(error.ToString()), "Tables are different:\n" + error);
        }
        
        public static void ListShouldBeSorted(List<string> list)
        {
            var sortedList = new List<string>(list);
            sortedList.Sort();

            list.ShouldEqualExtended(sortedList);
        }

        public static void ShouldEqualExtended(this List<KeyValuePair<string, string>> actual, List<KeyValuePair<string, string>> expected)
        {
            var error = new StringBuilder();

            if (expected.Count != actual.Count)
                error.AppendLine(string.Format("Lists have different count: '{0}', Actual: '{1}'", expected.Count, actual.Count));

            Assert.IsTrue(string.IsNullOrEmpty(error.ToString()), error.ToString());

            for (var i = 0; i < Math.Max(expected.Count, actual.Count); i++)
            {
                var expectedValue = (i < expected.Count) ? expected[i].Value : "<null>";
                var actualValue = (i < actual.Count) ? actual[i].Value : "<null>";

                if (!expectedValue.Equals(actualValue))
                    error.AppendLine(string.Format("'{0}' Elements are different. Expected: '{1} : {2}', Actual: '{3} : {4}'",
                            i + 1, expected[i].Key, expectedValue, actual[i].Key, actualValue));
            }

            Assert.IsTrue(string.IsNullOrEmpty(error.ToString()), error.ToString());
        }

        public static List<string> RemoveDuplicates(this List<string> list)
        {
            var result = new List<string>();

            foreach (var item in list)
                if (!result.Contains(item))
                     result.Add(item);

            return result;
        }

        public static List<string> RemoveEmpty(this List<string> list)
        {
            var result = new List<string>();

            foreach (var item in list)
                if (!string.IsNullOrEmpty(item) && !item.Equals(SpecialSymbols.NBSP) && !item.Equals(SpecialSymbols.SPACE))
                    result.Add(item);

            return result;
        }
    }
}