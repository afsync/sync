﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using ArtOfTest.Common.Win32;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context.CP;
using IFS.AF.BaseContext.Context.PriceLockdown;
using IFS.AF.BaseContext.Helpers.Common;

namespace IFS.AF.BaseContext.Helpers.Client
{
    /// <summary> Methods should be called on HtmlTable object of one of Price Lockdown tables </summary>
    public static class PriceLockdownGridExtMethods
    {
        //---- Tables structure
        // Rows[0] - header; 
        // Rows[1] - empty row! ; 
        // Rows[2...]  - data rows;
        // Rows[rows-1] - new price row.
        //----
        private const int START_IDX = 1;
        private static AttachFilePopup _attachFile;

        #region Grid IDs

        private const string TF_ESTIMATE_NAV = "~txtEstimateNav_field";
        private const string TF_ESTIMATE_RETURN = "~txtEstimateReturn_field";
        private const string TF_ESTIMATE_SOURCE = "~ctrlPriceSource_ddlEnum";
        private const string CHK_IS_FINAL = "~chkIsFinal";
        private const string CHK_IS_GROSS = "~chkIsGross";
        private const string CHK_CP_GROSS = "~chbGross";
        private const string LBL_PUBLISHED_BY = "~lblPublishedBy";
        private const string CHK_DELETE_ESTIMATE = "~chkDeleteThisEstimate";
        private const string DIV_PRICING_DOC = "~pnlUploadDocument";
        private const string DIV_PRICING_DOC_CP = "~divAttachmentsImg";
        private const string BTN_APPROVE_PRICE = "~SelectRow";

        #endregion

        private const string BTN_SAVE = "ctl00_ctphBody_btnSave";
        private static HtmlInputSubmit SaveBtn
        {
            get { return Manager.Current.ActiveBrowser.Find.ById<HtmlInputSubmit>(BTN_SAVE); }
        }

        
        /// <summary>
        /// Extension method for PriceLockdown grid. 
        /// Deletes price.
        /// </summary>
        public static void DeleteEstimate(this HtmlTable targetTable, 
                                          bool shouldClickSave=true, 
                                          bool shouldDeleteAll=true,
                                          int attempts = 10)
        {
            try
            {
                var rows = targetTable.Rows.Count;
                if (targetTable.GetEstimateRowsCount() == 0) return;

                var lastEstimateIdx = rows - 2;
                var finalIdx = rows - 1;
                const int deleteCellIdx = (int)PriceLockdownPage.EstimateTableColumns.Delete;

                if (targetTable.Rows.Count <= lastEstimateIdx ||
                    targetTable.Rows[lastEstimateIdx].Cells.Count <= deleteCellIdx)
                    return;

                var deleteCell = targetTable.Rows[lastEstimateIdx].Cells[deleteCellIdx];

                // Add a confirm dialog support for deleting price
                DialogHelper.StartConfirmMonitor();
                try    // try to delete last estimate
                {
                    var checkbox = deleteCell.Find.ById<HtmlInputCheckBox>(CHK_DELETE_ESTIMATE);
                    if (Helper.IsDisabledGen(checkbox)) return;
                    checkbox.Click();
                    Thread.Sleep(Constants.TIMEOUT_MEDIUM);
                }
                catch  // if no checkbox found - delete final price
                {
                    deleteCell = targetTable.Rows[finalIdx].Cells[(int)PriceLockdownPage.EstimateTableColumns.Delete];
                    var checkboxFinal = deleteCell.Find.ById<HtmlInputCheckBox>(CHK_DELETE_ESTIMATE);
                    if (Helper.IsDisabledGen(checkboxFinal)) return;
                    checkboxFinal.Click();
                    Thread.Sleep(Constants.TIMEOUT_MEDIUM);
                }
                DialogHelper.StopConfirmMonitor();
                DialogHelper.ResetDialogMonitor();

                if (!shouldClickSave) return;
                SaveBtn.Click();

                if (!shouldDeleteAll) return;
                targetTable.Refresh();
                targetTable.DeleteEstimate(attempts: attempts-1);
            }
            catch (Exception ex)
            {
                Manager.Current.Log.WriteLine("Exception thrown while trying to delete estimate: " + ex.Message);          
            }
        }


        /// <summary>
        /// Extension method for PriceLockdown grid.
        /// Clicks on IsFinal checkbox
        /// </summary>
        public static void ClickIsFinal(this HtmlTable targetTable)
        {
            int lastRow = targetTable.Rows.Count - 1;
            var isFinalChk = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.EstimateType].Find.ById<HtmlInputCheckBox>(CHK_IS_FINAL);
            isFinalChk.Refresh();

            if (isFinalChk != null &&
                !isFinalChk.ToString().Contains("disabled"))
            {
                isFinalChk.Click();
            }
        }

        /// <summary>
        /// Extension method for PriceLockdown grid
        /// Creates new price on Nav.
        /// </summary>
        public static void CreateNewPriceByNav(this HtmlTable targetTable, string navValue, 
                                               bool isFinal = false, 
                                               bool shouldClickSave = true)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();
            var lastRow = targetTable.Rows.Count - 1;
            var newEstimateNavCell = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.Nav];
            newEstimateNavCell.Find.AllByTagName("span")[0].As<HtmlSpan>().InvokeEvent(ScriptEventType.OnClick);
            newEstimateNavCell.Refresh();
            var input = newEstimateNavCell.Find.ById(TF_ESTIMATE_NAV).As<HtmlInputText>();
            input.Value = navValue;

            // Add an alert dialog support if more than ±5%
            DialogHelper.StartAlertMonitor();
            input.InvokeEvent(ScriptEventType.OnChange);
            input.InvokeEvent(ScriptEventType.OnBlur);
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);
            DialogHelper.StopAlertMonitor();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();

            var newEstimateSourceCell = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.Source];
            newEstimateSourceCell.Find.AllByTagName("span")[0].As<HtmlSpan>().InvokeEvent(ScriptEventType.OnClick);
            newEstimateSourceCell.Refresh();
            var source = newEstimateSourceCell.Find.ById(TF_ESTIMATE_SOURCE).As<HtmlSelect>();
            source.SelectByText("Whisper", true);

            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();



            if (isFinal)
                ClickIsFinal(targetTable);
            AttachFileToPriceByDefault(targetTable);

            if (shouldClickSave) SaveBtn.Click();
        }

        /// <summary> Creates new price on Returns. </summary>
        public static void CreateNewPriceByReturns(this HtmlTable targetTable, string returnValue, 
                                                   string dateReceived=null, 
                                                   bool isFinal = false,
                                                   bool shouldClickSave = true,
                                                   string fileToAttach=null)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();
            var lastRow = targetTable.Rows.Count - 1;
            var newEstimateReturnCell = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.Return];
            newEstimateReturnCell.Find.AllByTagName("span")[0].As<HtmlSpan>().InvokeEvent(ScriptEventType.OnClick);
            newEstimateReturnCell.Refresh();
            var input = newEstimateReturnCell.Find.ById(TF_ESTIMATE_RETURN).As<HtmlInputText>();
            input.Value = returnValue;

            // Add an alert dialog support if more than ±5%
            DialogHelper.StartAlertMonitor();
            input.InvokeEvent(ScriptEventType.OnChange);
            input.InvokeEvent(ScriptEventType.OnBlur);
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);
            DialogHelper.StopAlertMonitor();

            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();

            var newEstimateSourceCell = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.Source];
            newEstimateSourceCell.Find.AllByTagName("span")[0].As<HtmlSpan>().InvokeEvent(ScriptEventType.OnClick);
            newEstimateSourceCell.Refresh();
            var source = newEstimateSourceCell.Find.ById(TF_ESTIMATE_SOURCE).As<HtmlSelect>();
            source.SelectByText("Whisper", true);

            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();

            if (isFinal)
                ClickIsFinal(targetTable);

            if (dateReceived != null)
            {
                HtmlTableCell dateReceivedCell = targetTable.Rows[lastRow].Cells[(int)PriceLockdownPage.EstimateTableColumns.DateRecieved];
                
                input = dateReceivedCell.Find.AllByTagName("input")[1].As<HtmlInputText>();
                input.Value = dateReceived;
                input.InvokeEvent(ScriptEventType.OnKeyDown);
                input.InvokeEvent(ScriptEventType.OnKeyPress);
                input.InvokeEvent(ScriptEventType.OnChange);
                input.InvokeEvent(ScriptEventType.OnBlur);
            }

            targetTable.Refresh();
            if (string.IsNullOrEmpty(fileToAttach)) AttachFileToPriceByDefault(targetTable);
            else
            {
                AttachFileToPrice(targetTable,fileToAttach,"Is Final");
            }

            if (shouldClickSave) SaveBtn.Click();
            WaitHelper.AjaxPostBackWait();
        }
        
        
        #region Get Methods

        public static bool IsDeletePossible(this HtmlTable targetTable, string estimateType)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();
            var rowIndex = -1;

            for (var i = 0; i < targetTable.Rows.Count; i++)
            {
                if (!targetTable.Rows[i].Cells[(int)PriceLockdownPage.EstimateTableColumns.EstimateType]
                    .InnerText.Contains(estimateType)) continue;
                rowIndex = i;
                break;
            }

            var checkBox = targetTable.Rows[rowIndex].Find.ById<HtmlInputCheckBox>(CHK_DELETE_ESTIMATE);

            return checkBox != null && checkBox.IsVisible() && !checkBox.ToString().Contains(" disabled "); 
        }

        public static int GetEstimateRowsCount(this HtmlTable targetTable)
        {
            if (targetTable.GetStyleValue("display") == "none")
                return 0;

            int count = targetTable.Rows.
                            SelectMany(row => row.Attributes).
                            Count(attr => attr.Name == "class" && attr.Value.Contains("grid_"));
            // - (header + new Estimate row)
            return count - 2;
        }

        public static int GetPriceRowsCount(this HtmlTable targetTable)
        {
            return Convert.ToInt32((targetTable.Rows.Count - 1)/2);
        }

        /// <summary> Returns list of names from "Estimate Type" column </summary>
        public static List<string> GetEstimateTypeList(this HtmlTable targetTable)
        {
            int rows = targetTable.Rows.Count;
            var types = new List<string>();

            for (int i = START_IDX; i < rows - 1; i++)
                types.Add(targetTable.Rows[i].Cells[(int)PriceLockdownPage.EstimateTableColumns.EstimateType].InnerText);

            return types;
        }

        public static string GetLastNavPrice(this HtmlTable targetTable)
        {
            int rows = targetTable.Rows.Count;
            string navPrice = "";

            if (rows == 2) return navPrice;

            Manager.Current.ActiveBrowser.RefreshDomTree();
            int newPriceRow = targetTable.Rows.Count - 1;
            HtmlTableCell estimateNavCell =
                    targetTable.Rows[newPriceRow - 1].Cells[(int)PriceLockdownPage.EstimateTableColumns.Nav];

            navPrice = estimateNavCell.Find.AllByTagName<HtmlSpan>("span")[0].InnerText;


            return navPrice;
        }

        public static bool GetPriceRadioStatusByIdx(this HtmlTable priceTable, int index)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();
            var radioButtonCell = priceTable.Rows[index * 2 + 1].Cells[0].Find.ByName(BTN_APPROVE_PRICE).As<HtmlInputRadioButton>();
            return radioButtonCell.Checked;
        }

        public static bool GetApproveNoneRadioStatus(this HtmlTable priceTable)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();
            var approveNonDiv = priceTable.Parent<HtmlDiv>().Parent<HtmlDiv>().ChildNodes[1].As<HtmlDiv>();
            var approveNonRadio = approveNonDiv.Find.ByName("~SelectRow").As<HtmlInputRadioButton>();
            return approveNonRadio.Checked;
        }

        #endregion


        #region Attachments Methods

        public static void OpenAttachmentPopup(this HtmlTable targetTable, AttachFilePopup.AttachmentSide side, string estimateName = null)
        {
            _attachFile = new AttachFilePopup();
            switch (side)
            {
                case AttachFilePopup.AttachmentSide.FromCp:
                    targetTable.ClickUploadDocumentLinkCp(estimateName);
                    _attachFile.OpenAttachmentPopup(AttachFilePopup.AttachmentSide.FromCp);
                    break;
                case AttachFilePopup.AttachmentSide.Client:
                    targetTable.ClickUploadDocumentLink(estimateName);
                    _attachFile.OpenAttachmentPopup(AttachFilePopup.AttachmentSide.Client);
                    break;
                case AttachFilePopup.AttachmentSide.Update:
                    targetTable.ClickUploadDocumentLink(estimateName);
                    _attachFile.OpenAttachmentPopup(AttachFilePopup.AttachmentSide.Update);
                    break;
            }
        }

        public static void CloseAttachmentPopup(this HtmlTable targetTable, bool clickAccept)
        {
            if (clickAccept)
                    _attachFile.ClickAccept(true);
            else
                    _attachFile.ClickCancel(true);
        }

        public static void ClickUploadDocumentLink(this HtmlTable targetTable, string estimateName = null)
        {
            ClickAttachmentIcon(targetTable, estimateName, false);
        }
        public static void ClickUploadDocumentLinkCp(this HtmlTable targetTable, string estimateName = null)
        {
            ClickAttachmentIcon(targetTable, estimateName, true);
        }
        private static void ClickAttachmentIcon(HtmlTable targetTable, string estimateName, bool isCp)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            Manager.Current.ActiveBrowser.WaitUntilReady();
            
            var rowIdx = -1;
            if (estimateName == null)
            {
                // click on the last client estimate
                var newPriceRow = targetTable.Rows.Count - 1;
                rowIdx = newPriceRow -(isCp ? 0 : 1);
            }
            else
            {
                // find estimate by name
                var estimateType1 = isCp
                                       ? (int) PriceLockdownPage.PriceTableColumns.EstimateType
                                       : (int) PriceLockdownPage.EstimateTableColumns.EstimateType;
                for (var i = 0; i < targetTable.Rows.Count; i++)
                {
                    if (targetTable.Rows[i].Cells[estimateType1].InnerText != estimateName)
                        continue;
                    rowIdx = i;
                    break;
                }
            }

            if (isCp)
            {
                targetTable.Rows[rowIdx].Cells[(int)PriceLockdownPage.PriceTableColumns.PricingDocument].
                    Find.ById<HtmlDiv>(DIV_PRICING_DOC_CP).Click();
            }
            else
            {
                targetTable.Rows[rowIdx].Cells[(int)PriceLockdownPage.EstimateTableColumns.PricingDocument].
                    Find.ById<HtmlDiv>(DIV_PRICING_DOC).ChildNodes[0].As<HtmlControl>().Click();
            }
            
        }

        public static void AttachFileToPrice(this HtmlTable currTable, string filePath=@"C:\Temp\file.pdf", string estimateType=null)
        {
            currTable.ClickUploadDocumentLink(estimateType);

            var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);

            _attachFile = new AttachFilePopup();
            _attachFile.UploadFile(filePath);

            DialogHelper.StartAlertMonitor();

            // Close Upload file dialog
            _attachFile.ClickAccept();
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);

            IePopupHelper.CloseHtmlPopup(browserId.ClientId);
            DialogHelper.StopAlertMonitor();

            Manager.Current.ActiveBrowser.WaitUntilReady();
        }

        public static void AttachFileToPriceByDefault(this HtmlTable currTable, string fileName = "file.pdf", string type = "Is Final")
        {
            var tempDir = Path.GetTempPath();
            FileHelper.WriteStringToFile(tempDir, fileName, "default");

            var rowIndex = -1;

            for (var i = 0; i < currTable.Rows.Count; i++)
            {
                if (!currTable.Rows[i].Cells[(int)PriceLockdownPage.EstimateTableColumns.EstimateType]
                    .InnerText.Contains(type)) continue;
                rowIndex = i;
                break;
            }

            if (rowIndex <= -1) return;

            var target = currTable.Rows[rowIndex].Cells[(int)PriceLockdownPage.EstimateTableColumns.PricingDocument];
          
            
            var doc = target.Find.ById<HtmlDiv>(DIV_PRICING_DOC);
            //var image = doc.ChildNodes[0].As<HtmlInputImage>();
            //image.ButtonClick();
            doc.ChildNodes[0].As<HtmlInputImage>().ButtonClick();
            //var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);

            _attachFile = new AttachFilePopup();
            _attachFile.OpenAttachmentPopup(AttachFilePopup.AttachmentSide.Client);
            _attachFile.UploadFile(Path.Combine(tempDir, fileName));

            DialogHelper.StartAlertMonitor();

            // Close Upload file dialog
            _attachFile.ClickAccept();
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);
            DialogHelper.StopAlertMonitor();
            _attachFile.Close();
            //IePopupHelper.CloseHtmlPopup(browserId.ClientId);
        }

        public static string AttachIncorrectFileToPrice(this HtmlTable currTable, string filePath = @"C:\Temp\file.png")
        {
            currTable.ClickUploadDocumentLink();

            var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);

            _attachFile = new AttachFilePopup();
            _attachFile.UploadFile(filePath);

            DialogHelper.StartAlertMonitor();
            // Close Upload file dialog
            _attachFile.ClickAccept();
            Thread.Sleep(Constants.TIMEOUT_MEDIUM);
            _attachFile.ClickCancel();
            DialogHelper.StopAlertMonitor();
            IePopupHelper.CloseHtmlPopup(browserId.ClientId);
            return DialogHelper.AlertDialogInfo.Message;
        }

        public static bool IsReadyToAttach(this HtmlTable targetTable)
        {
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree(); 
            var newPriceRowIdx = targetTable.Rows.Count - 1;
            const int pricingDocument = (int) PriceLockdownPage.EstimateTableColumns.PricingDocument;
            return targetTable.Rows[newPriceRowIdx - 1].Cells[pricingDocument].ChildNodes[0]
                .ChildNodes[0].As<HtmlInputImage>().Src.Contains("/NoAttachement.png");
        }

        public static bool IsFileAttached(this HtmlTable targetTable)
        {
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            var newPriceRowIdx = targetTable.Rows.Count - 1;
            return targetTable.Rows[newPriceRowIdx - 1].Cells[(int)PriceLockdownPage.EstimateTableColumns.PricingDocument].ChildNodes[0]
                       .ChildNodes[0].As<HtmlInputImage>().Src.Contains("/Attachement.png");
        }
        
        public static List<string> GetUploadedFilesUrl(this HtmlTable targetTable)
        {
            targetTable.ClickUploadDocumentLink();
            var attachFilePopup = new AttachFilePopup();
            //var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);
            var urlsList = attachFilePopup.GetUploadedDocumentUrls();
            attachFilePopup.ClickCancel();
            //IePopupHelper.CloseHtmlPopup(browserId.ClientId);

            return urlsList;
        }

        public static List<string> GetUploadedFilesNames(this HtmlTable targetTable, bool isClientUpdate = false)
        {
            targetTable.ClickUploadDocumentLink();
            WaitHelper.AjaxPostBackWait();
            var attachFilePopup = new AttachFilePopup();

            attachFilePopup.OpenAttachmentPopup(isClientUpdate ? AttachFilePopup.AttachmentSide.Update : AttachFilePopup.AttachmentSide.Client);

            var urlsList = attachFilePopup.GetUploadedDocumentsNames();
            attachFilePopup.ClickCancel(true);
            
            return urlsList;
        }

        public static List<string> GetAttachmentListByType(this HtmlTable table, string priceType = null)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            table.Refresh();
            ClickUploadDocumentLink(table, priceType);
            WaitHelper.AjaxPostBackWait();
            var attachFilePopup = new AttachFilePopup();

            attachFilePopup.OpenAttachmentPopup(AttachFilePopup.AttachmentSide.Client);

            var urlsList = attachFilePopup.GetUploadedDocumentsNames();
            attachFilePopup.ClickCancel(true);

            return urlsList;
        }

        public static void DownloadPriceFile(this HtmlTable targetTable, string sourceFileName, string targetFolder, string targetFileName)
        {
            var fullFilePath = Path.Combine(targetFolder, targetFileName);

            targetTable.ClickUploadDocumentLink();
            var attachFilePopup = new AttachFilePopup();

            var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);
            browserId.Window.SetPosition(WindowPosition.TopMost);

            attachFilePopup.DownloadFile(sourceFileName, fullFilePath);
            
            attachFilePopup.ClickCancel();
            
            IePopupHelper.CloseHtmlPopup(browserId.ClientId);
        }
        
        public static bool IsMultiselectControlPresent(this HtmlTable targetTable, string estimateName = null)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            targetTable.Refresh();

            targetTable.ClickUploadDocumentLink();
            
            WaitHelper.AjaxPostBackWait();
            var browserId = IePopupHelper.GetHtmlPopup(AttachFilePopup.CLIENT_TITLE, AttachFilePopup.CLIENT_URL);
            var attachFilePopup = new AttachFilePopup();
            var multi = attachFilePopup.IsMultiselectControlPresent();
            attachFilePopup.ClickCancel();
            IePopupHelper.CloseHtmlPopup(browserId.ClientId);
            return multi;
        }

        public static void AcceptAttachmentUpdates(this HtmlTable table, List<string> files, string estimate = null, bool clickAccept = true)
        {
            OpenAttachmentPopup(table,AttachFilePopup.AttachmentSide.Update);
            var popup = new AttachmentPopupDataClient(AttachFilePopup.AttachmentSide.Update);
            popup.AcceptAttachments(files);
            CloseAttachmentPopup(table, clickAccept);
        }

        public static bool IsUpdateAttchmentLinkPresent(this HtmlTable table, bool isFinalUpdate = false)
        {
            var rowIdx = isFinalUpdate
                             ? table.Rows.Count - 1
                             : table.Rows.Count - 2;
            var updateLinkDiv = table.Rows[rowIdx].Cells[(int)PriceLockdownPage.EstimateTableColumns.PricingDocument].
                    Find.ById<HtmlDiv>(DIV_PRICING_DOC);
            return updateLinkDiv.Find.AllByTagName("a").Count > 0;
        }

        public static void AcceptAttachmentUpdatesByType(this HtmlTable table, string updateType, string estimate = null, bool clickAccept = true)
        {
            OpenAttachmentPopup(table, AttachFilePopup.AttachmentSide.Update);
            var popup = new AttachmentPopupDataClient(AttachFilePopup.AttachmentSide.Update);
            popup.AcceptAttachmentsByType(updateType);
            CloseAttachmentPopup(table, true);
        }

        public static Dictionary<string, AttachmentInfoClientUpdate> GetAttachmentInfoClientUpdateDict(this HtmlTable table, bool byName = true)
        {
            OpenAttachmentPopup(table, AttachFilePopup.AttachmentSide.Update);
            var popup = new AttachmentPopupDataClient(AttachFilePopup.AttachmentSide.Update);
            var result = popup.GetAttachmentInfoClientUpdateDict();
            CloseAttachmentPopup(table, false);
            return result;
        }

        public static List<AttachmentInfoClientUpdate> GetAttachmentInfoClientUpdateList(this HtmlTable table, bool byName = true)
        {
            OpenAttachmentPopup(table, AttachFilePopup.AttachmentSide.Update);
            var popup = new AttachmentPopupDataClient(AttachFilePopup.AttachmentSide.Update);
            var result = popup.GetAttachmentInfoClientUpdateList();
            CloseAttachmentPopup(table, false);
            return result;
        }


        public static bool IsAttachmentTablePresent(this HtmlTable table)
        {
            OpenAttachmentPopup(table, AttachFilePopup.AttachmentSide.Client);
            var popup = new AttachmentPopupDataClient();
            var result = popup.IsAttachmentsTablePresent();
            CloseAttachmentPopup(table, false);
            return result;
        }

        #endregion

        
        public static void SelectPriceToApproveByEstimateType(this HtmlTable priceTable, string estimateType)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();

            var index = priceTable.EstimateRowIndex(estimateType, true);
            var radioButtonCell = priceTable.Rows[index].Cells[0];
            radioButtonCell.ClickSelectPriceToApproveRadiobutton();
        }

        public static void SelectPriceToApproveByIdx(this HtmlTable priceTable, int index)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();
            var radioButtonCell = priceTable.Rows[index*2 + 1].Cells[0];
            radioButtonCell.ClickSelectPriceToApproveRadiobutton();
        }

        public static void SelectLastPriceToApprove(this HtmlTable priceTable)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();
            var radioButtonCell = priceTable.Rows[priceTable.Rows.Count - 2].Cells[0];
            radioButtonCell.ClickSelectPriceToApproveRadiobutton();
        }

        public static void SelectRowToApprove(this HtmlTableRow priceRow)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceRow.Refresh();
            var radioButtonCell = priceRow.Cells[0];
            radioButtonCell.ClickSelectPriceToApproveRadiobutton();
        }

        public static void SelectApproveNone(this HtmlTable priceTable)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            priceTable.Refresh();
            var approveNonDiv = priceTable.Parent<HtmlDiv>().Parent<HtmlDiv>().ChildNodes[1].As<HtmlDiv>();
            var approveNonRadio = approveNonDiv.Find.ByName("~SelectRow").As<HtmlInputRadioButton>();
            approveNonRadio.Click();
            approveNonRadio.InvokeEvent(ScriptEventType.OnClick);
        }

        private static void ClickSelectPriceToApproveRadiobutton(this HtmlTableCell radioButtonCell)
        {
            var inputs = radioButtonCell.Find.AllByTagName("input");
            foreach (var input in inputs)
            {
                if (input.Content.Contains("onclick"))
                {
                    input.As<HtmlInputRadioButton>().Click();
                    input.As<HtmlInputRadioButton>().InvokeEvent(ScriptEventType.OnClick);
                    break;
                }
            }
        }

        // todo
        public static bool IsEstimateEditable(this HtmlTable estimateTable, int index)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            estimateTable.Refresh();
            var row = estimateTable.Rows[index*2 + 1];
            var list = row.Find.AllByAttributes("onclick=ConvertLabelsToTextBox(this, false)","enabled=true");
            return !list.Count.Equals(0);
        }

        public static bool IsEstimateDataPresentInTable(this List<PriceLockdownEstimate> estimatesList, PriceLockdownEstimate estimateToCheck)
        {
            var result = false;
            foreach (var est in estimatesList)
            {
                result = est.Nav == estimateToCheck.Nav && est.Return == estimateToCheck.Return &&
                         est.LocalMv == estimateToCheck.LocalMv && est.AvailShares == estimateToCheck.AvailShares &&
                         est.DateReceived == estimateToCheck.DateReceived && est.IsFlat == estimateToCheck.IsFlat &&
                         est.Source == estimateToCheck.Source;
                if (result) break;
            }

            return result;
        }

        /// <summary>
        /// Extension method for PriceLockdown grid.
        /// Checks if Gross is enabled
        /// </summary>
        public static bool IsGrossCheckboxEnabled(this HtmlTable table, string estimateName, bool isCpPriceTable = false)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            table.Refresh();

            var row = table.Rows[table.EstimateRowIndex(estimateName, isCpPriceTable)];

            var grossIdx = (int) PriceLockdownPage.EstimateTableColumns.Gross + (!isCpPriceTable ? 0 : 2);
            var gross = !isCpPriceTable ? CHK_IS_GROSS : CHK_CP_GROSS;
            return !Helper.IsDisabledGen(row.Cells[grossIdx].Find.ById<HtmlInputCheckBox>(gross));
        }

        /// <summary>
        /// Extension method for PriceLockdown grid.
        /// Checks if Gross is checked
        /// </summary>
        public static bool IsGrossCheckboxChecked(this HtmlTable table, string estimateName, bool isCpPriceTable = false)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            table.Refresh();

            var row = table.Rows[table.EstimateRowIndex(estimateName, isCpPriceTable)];

            var grossIdx = (int)PriceLockdownPage.EstimateTableColumns.Gross + (!isCpPriceTable ? 0 : 2);
            var gross = !isCpPriceTable ? CHK_IS_GROSS : CHK_CP_GROSS;
            return row.Cells[grossIdx].Find.ById<HtmlInputCheckBox>(gross).Checked;
        }

        public static bool IsPublishedByPresent(this HtmlTable targetTable)
        {
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            var newPriceRowIdx = targetTable.Rows.Count - 1;
            //return targetTable.Rows[newPriceRowIdx - 1].Cells[(int)PriceLockdownPage.EstimateTableColumns.PublishedBy].Find.ById<HtmlSpan>(TF_PUBLISHED_BY).
            if (targetTable.Rows[newPriceRowIdx - 1].Cells.Count - 1 < (int)PriceLockdownPage.EstimateTableColumns.PublishedBy)
                return false;
            if (!targetTable.Rows[newPriceRowIdx - 1].Cells[(int)PriceLockdownPage.EstimateTableColumns.PublishedBy].ChildNodes[0].IdAttributeValue.Contains(LBL_PUBLISHED_BY))
                return false;
            return true;
            //return targetTable.Rows[newPriceRowIdx - 1].Cells[(int)PriceLockdownPage.EstimateTableColumns.PublishedBy].ChildNodes[0]
            //           .As<HtmlSpan>().ID.Contains(LBL_PUBLISHED_BY);
        }

        public static string GetPublishedBy(this HtmlTable targetTable)
        {
            Manager.Current.ActiveBrowser.WaitUntilReady();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            var newPriceRowIdx = targetTable.Rows.Count - 1;
            var a = targetTable.Rows[newPriceRowIdx - 1].Cells[(int) PriceLockdownPage.EstimateTableColumns.PublishedBy]
                .Find.ById<HtmlSpan>(LBL_PUBLISHED_BY);
            return targetTable.Rows[newPriceRowIdx - 1].Cells[(int) PriceLockdownPage.EstimateTableColumns.PublishedBy].
                Find.ById<HtmlSpan>(LBL_PUBLISHED_BY).TextContent;
        }

        private static int EstimateRowIndex(this HtmlTable table, string estimateName, bool isCpPriceTable)
        {
            var idx = (int) PriceLockdownPage.EstimateTableColumns.EstimateType + (isCpPriceTable ? 1 : 0);

            for (var rowIndex = 1; rowIndex < table.Rows.Count; rowIndex++)
                if (table.Rows[rowIndex].Cells[idx].InnerText.Contains(estimateName))
                    return rowIndex;

            throw new ArgumentException(string.Format("Estimate: \"{0}\", was not found", estimateName));
        }
    }
}
