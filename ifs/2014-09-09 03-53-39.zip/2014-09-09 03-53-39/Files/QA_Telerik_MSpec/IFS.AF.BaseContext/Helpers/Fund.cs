﻿using System;
using IFS.AF.BaseContext.Context;

namespace IFS.AF.BaseContext.Helpers
{
    public class Fund : AfWebTest
    {
        public static Boolean IsFundWithSeries(string baseFund)
        {
            var dashboard = AsPage<DashboardPage>();
            
            var fundMaintainPage = dashboard.GoToMaintainFund();
            fundMaintainPage.FundSelect.Select(baseFund);
            fundMaintainPage.GoToSeriesMaintenanceTab();
            ActiveBrowser.WaitUntilReady();
            ActiveBrowser.RefreshDomTree();
            return (!fundMaintainPage.SeriesMaintenanceTab.NewBtn.IsDisabled());
        }

        public static string ModifyOfferPrice(string baseFund, string investableFund, string newPrice)//for class and series
        {
            return IsFundWithSeries(baseFund) ? UpdateOfferPriceForSeries(baseFund, investableFund, newPrice) : UpdateOfferPriceForClass(baseFund, investableFund, newPrice);
        }

        public static string UpdateOfferPriceForClass(string baseFund, string investableFund, string newPrice)
        {
            var dashboard = AsPage<DashboardPage>();
            var fundMaintain = AsPage<FundMaintainPage>();

            dashboard.NavigationMenus.FundMaintainMenu.ButtonClick();
            fundMaintain.FundSelect.Select(baseFund);
            fundMaintain.FeesAndTermsTabAnchor.ButtonClick();
            ActiveBrowser.WaitUntilReady();
            ActiveBrowser.RefreshDomTree();
            var tab = fundMaintain.FeesAndTermsTab;
            tab.SeriesSideLst.Select(StringTransform.GetTailInvestableFund(investableFund, baseFund));

            var basicInfo = fundMaintain.FeesAndTermsTab.BasicInfoWidget;
            basicInfo.SetOfferPrice(newPrice);
            string newPriceOut = basicInfo.GetOfferPrice();
            fundMaintain.FeesAndTermsTab.ClickSave();
            ActiveBrowser.WaitUntilReady();
            ActiveBrowser.RefreshDomTree();
            return newPriceOut;
        }
        public static string UpdateOfferPriceForSeries(string baseFund, string investableFund, string newPrice)
        {
            var dashboard = AsPage<DashboardPage>();
            var fundMaintain = dashboard.GoToMaintainFund();

            fundMaintain.FundSelect.Select(baseFund);
            fundMaintain.GoToSeriesMaintenanceTab();
            
            var seriesGridFirstRow = fundMaintain.SeriesMaintenanceTab.SeriesGrid.GridRows[0]; //todo change select to seria
            seriesGridFirstRow.IssueDate.MouseClick();
            
            var browserId = BrowserPool.IePopupOpen(PageUrl.SERIES_ADD_EDIT_POPUP_PAGE, SeriesAddEditPage.TITLE);
            var seriesAddEditPopupEdit = AsPage<SeriesAddEditPage>();
            var oldPrice = seriesAddEditPopupEdit.TxtOfferPrice.Value;
            seriesAddEditPopupEdit.TxtOfferPrice.TypeText(newPrice);
            string newPriceOut = seriesAddEditPopupEdit.TxtOfferPrice.Value;
            seriesAddEditPopupEdit.BtnSave.Click(true);

            if (! browserId.Window.WaitForVisibility(false, 3000, true))
                seriesAddEditPopupEdit.BtnSave.Click(true);
            
            BrowserPool.IePopupClose(browserId.ClientId);
            
            BrowserPool.WaitUntilPageLoaded();
            return newPriceOut;
        }
    }
}
