﻿using System;
using System.Collections.Generic;
using System.Text;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Helpers.CP;

namespace IFS.AF.BaseContext.Helpers
{
    public class Login : AfWebTest
    {
        [Obsolete("This method is deprecated.")]
        public static void AutoLogin(string username, string password, string clientName, string targetPageUrl = PageUrl.PORTFOLIO_CONSTRUCT)
        {
            password = "Moonwalk1";
            var fullUrl = new StringBuilder();
            fullUrl.Append(TestSite + PageUrl.AUTO_LOGIN_PAGE);
            fullUrl.Append("?UserName=" + username);
            fullUrl.Append("&Password=" + password);
            fullUrl.Append("&Client=" + AfClients.GetClientId(clientName));
            fullUrl.Append("&ReturnURL=/" + targetPageUrl);

            ActiveBrowser.NavigateTo(fullUrl.ToString());
            ActiveBrowser.WaitForUrl(targetPageUrl, true, TimeOut.MIN_05);

            BrowserPool.WaitUntilPageLoaded();
        }

        public static void UiLogin(WebLogin user, string baseClient)
        {
            var loginControl = AsPage<LoginControl>();
            var selectClientsPage = AsPage<SelectClientPage>();
            
            BrowserPool.WaitUntilPageLoaded();

            loginControl.Login(user.Login, user.Password);
            ActiveBrowser.WaitForUrl(PageUrl.CHOOSE_CLIENT, true, TimeOut.MIN_01);

            selectClientsPage.SelectClient(baseClient, user.Name);
            ActiveBrowser.WaitForUrl(PageUrl.PORTFOLIO_CONSTRUCT, true, TimeOut.MIN_03);
            
            BrowserPool.WaitUntilPageLoaded();
        }

        public static DashboardPage FullLogin(string userName, string password, string baseClient)
        {
            return FullLogin(new WebLogin(userName, password), baseClient);
        }

        public static DashboardPage FullLogin(WebLogin user, string baseClient)
        {
            
            try
            {
                UiLogin(user, baseClient);    
            }catch
            {
                LogReport.MakeScreenshot();
                throw;
            }
            
            return new DashboardPage(Manager.Current.ActiveBrowser.Find);
        }
    }

    public class UserAction : AfWebTest
    {
        static DashboardPage LoginAndSelectPortfolio(WebLogin credentials, string client, params string[] portfolio)
        {
            var dashboard = Login.FullLogin(credentials, client);

            if (portfolio.Length > 0)
                dashboard.PortfolioName.Select(portfolio);
            
            return new DashboardPage(Manager.Current.ActiveBrowser.Find);
        }
        
        public static GsmNavigationPage LoginAsGsmManager(WebLogin user = null)
        {
            Login.UiLogin(user ?? GsmMainLogin, Clients.GsmManager.Name);

            BrowserPool.AjaxPostBackWait();
            BrowserPool.WaitUntilPageLoaded();
            BrowserPool.WaitUntilPageLoaded();

            return new GsmNavigationPage();
        }

        public static DashboardPage LoginAsAccountant(string client, string portfolio)
        {
            return LoginAndSelectPortfolio(AccountantWebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsAccountantLocking(string client, string portfolio)
        {
            return LoginAndSelectPortfolio(AccountantLockingWebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsSupervisor(string client, string portfolio)
        {
            return LoginAndSelectPortfolio(SupervisorWebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsAdmin(string client, List<string> portfolios)
        {
            return LoginAsAdmin(client, portfolios.ToArray());
        }

        public static DashboardPage LoginAsAdmin(string client, params string[] portfolio)
        {
            return LoginAndSelectPortfolio(WebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsClient(string client, string portfolio)
        {
            return LoginAndSelectPortfolio(ClientWebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsClient2(string client, params string[] portfolio)
        {
            return LoginAndSelectPortfolio(Client2WebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsOmsPreparer(string client, params string[] portfolio)
        {
            return LoginAndSelectPortfolio(OmsPreparerWebCredentials, client, portfolio);
        }

        public static DashboardPage LoginAsOmsApprover(string client, params string[] portfolio)
        {
            return LoginAndSelectPortfolio(OmsApproverWebCredentials, client, portfolio);
        }

    }
}
