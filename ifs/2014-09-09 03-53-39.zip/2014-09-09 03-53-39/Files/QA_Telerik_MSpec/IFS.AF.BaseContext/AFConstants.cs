﻿using System;
using System.Collections.Specialized;

namespace IFS.AF.BaseContext
{
    #region TestData
    public static class AfConstants
    {
        public const string DISABLED_STATE = "disabled";
        public const string READONLY_STATE = "readOnly";
        public const string LOCKED_STATE = "Locked";
        public const string LOCKED_STATE_SNAPSHOT = "(L)";
        public const string DIV_WIRECALLS_ID = "dvWireCalls";
    }

    public static class TimeOut
    {
        private const int MILLIS = 1000;

        public const int SEC_01 =  5 * MILLIS;
        public const int SEC_15 = 15 * MILLIS;
        public const int SEC_30 = 30 * MILLIS;
        public const int SEC_45 = 45 * MILLIS;
        public const int MIN_01 = 1 * 60 * MILLIS;
        public const int MIN_03 = 3 * 60 * MILLIS;
        public const int MIN_05 = 5 * 60 * MILLIS;
    }

    public static class PageUrl 
    {
        
        public const string PRICING_REPORT = "pages/reports/ReportQuotes.aspx";
        public const string CHOOSE_CLIENT = "login/ChooseClient.aspx";
        public const string PORTFOLIO_CONSTRUCT = "pages/portfolio/Construct.aspx";
        public const string MERGED_CLIENTS_CONSTRUCT = "pages/MergedClientConstruct/MergedClientConstruct.aspx";
        public const string WELCOME_MESSAGE = "pages/WelcomeMessage.html";
        public const string QUICK_SEARCH = "pages/popups/NewQuickSearchPopup.aspx";//"pages/popups/QuickSearchPopup.aspx";
        public const string PRICE_LOCKDOWN = "pages/portfolio/PriceLockdown.aspx";
        public const string ADD_SERIA = "pages/popups/SeriesAddEdit.aspx";
        public const string ALLOCATION_SUBSCRIPTION = "pages/popups/AllocationSubscription.aspx";
        public const string ALLOCATION_REDEMPTION = "pages/popups/AllocationRedemption.aspx";
        public const string ALLOCATION_EXCHANGE = "pages/popups/AllocationExchange.aspx";
        public const string ALLOCATION_TRANSFER = "pages/popups/AllocationTransfer.aspx";
        public const string ALLOCATION_CASH_DISTRIBUTION_PVT_EQTY = "pages/popups/AllocationCashDistributionPvtEqty.aspx";
        public const string ALLOCATION_SUBSCRIPTION_PVT_EQTY = "pages/popups/AllocationSubscriptionPvtEqty.aspx";
        public const string ALLOCATION_DISTRIBUTION_PVT_EQTY = "pages/popups/AllocationRedemptionPvtEqty.aspx";
        public const string ACTIVITY_REPORT = "/pages/popups/ActivityReport.aspx";
        public const string MERGED_CLIENT_ACTIVITY_REPORT = "pages/popups/MergedClientViewActivity.aspx";
        public const string EREPOSITORY_SEARCH = "pages/erepository/eRepositorySearch.aspx";
        public const string USER_INFO = "/pages/admin/popups/UserPopup.aspx";
        public const string TRADE_HISTORY_REPORT = "/pages/popups/TradeOrderHistoryPopup.aspx";
        public const string EQUALIZATION_SUBSCRIPTION = "pages/popups/EqualizationSubscription.aspx";
        public const string ALLOCATION_CONTINGENT_REDEMPTION = "pages/popups/AllocationContingentRedemption.aspx";
        public const string COMMITMENT_PVT_EQTY = "pages/popups/AllocationCommitmentPvtEqty.aspx";
        public const string FX_RATES = "pages/admin/FxRates.aspx";
        public const string CONTRIBUTION_PVT_EQTY = "pages/popups/AllocationSubscriptionPvtEqty.aspx";
        public const string BY_TO_COVER = "pages/popups/ShortSaleBuyToCover.aspx";
        public const string TRANSACTIONS_PAGE = "pages/admin/Transactions.aspx";
        public const string SONIC_MESSAGE_PAGE = "pages/admin/show_transaction.aspx";
        public const string ANALYTICS_HOME_PAGE = "pages/PMR/Homepage.aspx";
        public const string ANALYTICS_COMPARISON_PAGE = "/pages/comparison/comparison.aspx";
        public const string ANALYTICS_ANALYSIS_PAGE = "pages/fund/Analysis.aspx";
        public const string PORTFOLIO_COPY_PAGE = "pages/popups/PortfolioCopyPopup.aspx";
        public const string DELETE_FUND_PAGE = "pages/admin/DeleteFund.aspx";
        public const string ADMIN_FEES_TERMS = "pages/admin/FeesAndTerms.aspx";
        public const string TOOLS_FEES_TERMS = "pages/Tools/FeesAndTerms";
        public const string LIST_ITEMS_PAGE = "pages/admin/EnumValues.aspx";
        public const string FUND_MAINTAIN_PAGE = "pages/fund/Maintain.aspx";
        public const string PORTFOLIO_MAINTAIN_PAGE = "pages/portfolio/Maintain.aspx";
        public const string CLIENT_MAINTAIN_PAGE = "pages/client/ClientCreditTerms.aspx";
        public const string ADD_EDIT_KEY_PERSONS_POPUP_PAGE = "pages/popups/KeyPersonPopup.aspx";
        public const string COMPANY_DETAILS_POPUP_PAGE = "pages/popups/CompanyDetailPopup.aspx";
        public const string CONTACT_DETAILS_POPUP_PAGE = "pages/popups/ContactDetailPopup.aspx";
        public const string TRADE_SUBSCRIPTION_PAGE = "pages/popups/TradeOrderPopup.aspx";
        public const string TRADE_ORDER_TRANSFER_PAGE = "pages/popups/TradeOrderTransfer.aspx";
        public const string ADD_CLASS_POPUP_PAGE = "pages/popups/AddFundOrPortfolioClass.aspx";
        public const string PORTFOLIO_POPUP_PAGE = "pages/popups/PortfolioPopup.aspx";
        public const string FUND_POPUP_PAGE = "pages/popups/FundPopup.aspx";
        public const string SERIES_ADD_EDIT_POPUP_PAGE = "pages/popups/SeriesAddEdit.aspx";
        public const string PE_SECURITY_TRADE_UPLOAD = "pages/admin/PvtEquityUpload.aspx";
        public const string TRADES_AND_SECURITIES_UPLOAD_PAGE = "pages/admin/InitializePortfolio.aspx";
        public const string TRADE_ACTIVITY_PAGE = "pages/portfolio/TradeActivity.aspx";
        public const string PENDING_TRADE_ACTIVITY_PAGE = "pages/Tools/PendingTradeActivity";
        public const string ENUM_VALUES_PAGE = "pages/admin/EnumValues.aspx";
        public const string RETURNS_PAGE = "pages/fund/Returns.aspx";
        public const string REDEMPTION_CHECKLIST_PAGE = "pages/popups/TradeProcessingChecklist.aspx";
        public const string SUBSCRIPTION_CHECKLIST_PAGE = "pages/popups/TradeProcessingChecklistSub.aspx";
        public const string EXCHANGE_CHECKLIST_PAGE = "pages/popups/TradeProcessingChecklistExchanges.aspx";
        public const string TRANSFER_CHECKLIST_PAGE = "pages/popups/TransferChecklist.aspx";
        public const string TRADE_CANCELLATION_CHECKLIST_PAGE = "pages/popups/TradeCancellationChecklist.aspx";
        public const string CORPORATE_ACTION_CHECKLIST_PAGE = "pages/popups/CorporateActionsChecklist.aspx";
        public const string ENTRY_CORPORATE_ACTIONS = "/pages/popups/CorporateActionEntry.aspx";
        public const string VIEW_CORPORATE_ACTIONS = "/pages/popups/ViewCorporateActions.aspx";
        public const string NON_HF_ACTIVITY_PAGE = "/pages/portfolio/NonHfActivity.aspx";
        public const string CASH_ACTIVITY_PAGE = "/pages/reports/ReportCashActivity.aspx";
        public const string CASH_ACTIVITY_ADDEDIT_PAGE = "/pages/popups/AddEditCashBalance.aspx";
        public const string TRANSACTION_REPORT = "pages/reports/ReportTransactions.aspx";
        public const string HISTORICAL_TRANSACTION_REPORT = "pages/reports/HistoricalTransactionsReport.aspx";
        public const string PRICING_HISTORY_REPORT = "pages/reports/HistoricalTransactionsReport.aspx";
        public const string GSM_SECURITY_UPLOAD = "/pages/admin/UploadGsmFunds.aspx";

        public const string CUSTODY_REPORT = "pages/reports/ReportCustody.aspx";
        public const string IA_AND_FOF_REPORT = "pages/reports/ReportIaAndFof.aspx";
        public const string PERFORMANCE_REPORT = "pages/reports/CannedPerformanceReport";
        public const string LIQUIDITY_VIEW_REPORT = "pages/Reports/ReportLiquidityProfile.aspx";
        public const string HISTORICAL_RETURNS_REPORT = "pages/reports/ReportHistoricalReturns.aspx";
        public const string BENCHMARK_PERFORMANCE_REPORT_PAGE = "pages/reports/ReportBenchmarkPerformance.aspx";
        public const string TRADE_ORDER = "pages/popups/TradeOrder";
        public const string TRADE_ORDER_REDEMPTION = "pages/popups/TradeOrderRedemption.aspx";
        public const string TRADE_ORDER_CONTRIBUTION = "pages/popups/TradeOrderContribution";
        public const string TRADE_ORDER_DISTRIBUTION = "pages/popups/TradeOrderDistribution";
        public const string TRADE_ORDER_EXCHANGE = "pages/popups/TradeOrderExchange.aspx";
        public const string INTERACTIVE_TRADE_BLOTTER_GRID = "pages/tradeblotter/TradeBlotterMain.aspx";
        public const string NEW_INTERECTIVE_TRADE_BLOTTER_GRID = "pages/Tools/InteractiveTradeBlotter";
        public const string INITIALISE_CACHE = "pages/admin/InitialiseCache.aspx";
        public const string CAFM_FOLDERS = "pages/admin/CafmFolders";
        public const string USERS_PAGE = "pages/admin/Users.aspx";
        public const string CASH_PROJECTION_REPORT = "pages/admin/CafmFolders";
        public const string CLIENT_PAGE = "pages/admin/Organizations.aspx";
        public const string ROLE_PAGE = "pages/admin/Roles.aspx";
        public const string BM_UPLOAD_PAGE = "pages/admin/BulkUploadBenchmarks.aspx";
        public const string UPLOAD_FILE_DIALOG = "pages/popups/InteractiveTradeBlotter/UploadFilesInteractiveTradeBlotter.aspx";
        public const string REDEMPTIONS_PAYMENT_REPORT = "pages/portfolio/HoldbackSchedule.aspx";
        public const string LAUNCHPAD_DATA_UPLOAD_PAGE = "pages/launchpad/LaunchpadDataBulkUpload.aspx";
        public const string CORPORATE_ACTION_REPORT = "pages/reports/ReportCorpActionBlotter.aspx";
        public const string TRADE_UPLOAD_PAGE = "pages/portfolio/BulkTradesUpload.aspx";
        public const string PRIVATE_EQUITY_CONTROL_REPORT_PAGE = "pages/reports/PvtEqtyControlReport.aspx";

        public const string INVESTMENT_SUMMARY = "pages/launchpad/InvestmentSummary.aspx";
        public const string OPERATIONS_SUMMARY = "pages/launchpad/OperationsSummary.aspx";
        public const string HOLDINGS_SUMMARY = "launchpad/HoldingsSummary.aspx";
        public const string LAYOUT_SHARE = "pages/portfolio/LayoutShare.aspx";
        public const string LAYOUT_SAVE_AS = "pages/popups/EnterNamePopup.aspx";

        public const string REGISTRARS_SET_MODIFY = "pages/admin/RegistrarsSetModify.aspx";
        public const string EREPOSITORY_BROWSE_PAGE = "pages/erepository/eRepositoryBrowse.aspx";
        public const string PUBLISH_ATTACHMENTS_PAGE = "pages/tools/PublishAttachments.aspx";
        public const string VIEW_ATTACHMENTS_PAGE = "pages/popups/PublishPortfolioAttachments.aspx";
        public const string WEBFOLIO_POSITIONS_DOWNLOAD = "pages/admin/WebfolioPositionsDownload";
        public const string WEBFOLIO_TRADE_UPLOAD = "pages/tools/WebfolioUpload.aspx";
        public const string WEBFOLIO_PRICE_DOWNLOAD = "pages/admin/WebfolioPriceDownload.aspx";
        public const string WEBFOLIO_TRADE_DOWNLOAD = "pages/admin/WfTradeDownloads";
        public const string ATTRIBUTE_CUSTOM_NAMES = "pages/Tools/AttributeNames.aspx";

        public const string AUTO_LOGIN_PAGE = "QAAutoLogin.aspx";
    }

    public static class Files
    {
        public const string DASHBOARD_EXPORT = "DB_Export.xlsx";
        public const string HF_DASHBOARD_EXPORT = "HF_DB_Export.xlsx";

        public const string AUTOMATION_SUBSCRIPTION_PARTNERSHIP = "Automation Subscription - Partnership.xml";
        public const string AUTOMATION_SUBSCRIPTION_SOS = "Automation Subscription - SOS.xml";
        public const string AUTOMATION_SUBSCRIPTION_LLC = "Automation Subscription - LLC.xml";
        public const string AUTOMATION_SUBSCRIPTION_FUND1 = "Sub1_3 Automation Fund 1.xml";
        public const string AUTOMATION_SUBSCRIPTION_FUND4 = "Sub1_3 Automation Fund 4.xml";
        public const string AUTOMATION_SUBSCRIPTION_PTRANCHE = "Automation Subscription - PTranche.xml";
        public const string AUTOMATION_REDEMPTION_FUND1 = "Automation Redemption - Fund1.xml";
        public const string AUTOMATION_REDEMPTION_FUND2 = "Automation Redemption - Fund2.xml";
        public const string AUTOMATION_REDEMPTION_FUND3 = "Automation Redemption - Fund3.xml";
        public const string AUTOMATION_SPECIFIC_ID_FULL_REDEMPTION = "Automation Specific ID Full Redemption.xml";
        public const string AUTOMATION_TRANSFER_FUND1 = "Automation Transfer - Fund1.xml";
        public const string AUTOMATION_EQUALIZATION_FUND = "Automation Equalization - Fund.xml";
        public const string AUTOMATION_COMMONPRICE_FUND5 = "Automation CommonPrice Fund5.xml";
        public const string AUTOMATION_COMMONPRICE_FUND3 = "Automation CommonPrice Fund3.xml";
        public const string AUTOMATION_CASHDISTRIBUTION_FUND5 = "Automation Cash Distribution - Fund1.xml";
        public const string AUTOMATION_COMMONPRICE_FUND7 = "Automation CommonPrice Fund7.xml";
        public const string AUTOMATION_PRIVATEEQUITY_FUND = "Automation Private Equity - Fund.xml";
        public const string AUTOMATION_NAVPRICE_FUND3 = "Automation NAVPrice - Fund3.xml";
        public const string AUTOMATION_NAVCLOSE_LIVE_REPORTING = "Automation NAV Close vs Live Reporting.xml";
        public const string AUTOMATION_EXCHANGE_PARTNERSHIP = "Automation Exchange - Partnership.xml";
        public const string AUTOMATION_EXCHANGE_SOS = "Automation Exchange - SOS.xml";
        public const string AUTOMATION_EXCHANGE_LLC = "Automation Exchange - LLC.xml";
        public const string AUTOMATION_LOCKDOWN_1 = "Automation Lockdown 1.xml";
        public const string AUTOMATION_TRADE_SUBSCRIPTION = "Automation Trade Subscription.xml";
        public const string AUTOMATION_TRADE_REDEMPTION = "Automation Trade Redemption.xml";
        public const string AUTOMATION_TRADE_TRANSFER = "Automation Trade Transfer.xml";
        //public const string AUTOMATION_LOCKDOWN_SOS = "Automation Lockdown - SOS.xml"; 
        public const string AUTOMATION_LOCKDOWN_2 = "Automation Lockdown 2.xml";
        public const string DASHBOARD_FUND1 = "Dashboard Fund1.xml";
        public const string DASHBOARD_FUND2 = "Dashboard Fund2.xml";
        public const string DASHBOARD_STATS = "Dashboard Stats.xml";
        public const string AUTOMATION_BACKDATED_FUND1 = "Automation Backdated - Fund1.xml";
        public const string AUTOMATION_BACKDATED_FUND4 = "Automation Backdated - Fund4.xml";
        public const string AUTOMATION_EFFECTIVEDATE_FUND1 = "Automation EffectiveDate - Fund1.xml";
        public const string AUTOMATION_EFFECTIVEDATE_FUND2 = "Automation EffectiveDate - Fund2.xml";
        public const string AUTOMATION_GLS_PARTNERSHIP = "Automation GLS - Partnership.xml";
        public const string AUTOMATION_GLS_SINGLENAV = "Automation GLS - Single NAV.xml";
        public const string AUTOMATION_DEMO_PRD = "Automation Demo - PRD.xml";
        public const string AUTOMATION_DEMO_LLC = "Automation Demo - LLC.xml";
        public const string AUTOMATION_DEMO_PE = "Automation Demo - PE.xml";
        public const string AUTOMATION_EDIT_SUB = "Automation EditingTrades Sub.xml";
        public const string AUTOMATION_EDIT_RED = "Automation EditingTrades Red.xml";
        public const string AUTOMATION_UOP_PORTFOLIO = "Automation UOP Portfolio.xml";
        public const string AUTOMATION_UOP_PORTFOLIO_I = "Automation UOP Portfolio1.xml";
        public const string AUTOMATION_UOP_PORTFOLIO_II = "Automation UOP Portfolio2.xml";
        public const string AUTOMATION_OMS_VALIDATION = "Automation OMS Validation.xml";
        public const string AUTOMATION_KN_AC3_1 = "Automation KN Return Partnership.xml";
        public const string AUTOMATION_KN_AC3_2 = "Automation KN Return Equalization.xml";
        public const string AUTOMATION_KN_AC3_3 = "Automation KN Return Single NAV.xml";
        public const string AUTOMATION_KN_AC3_4 = "Automation KN Return Partnership Tranch.xml";
        public const string AUTOMATION_KN_AC3_5 = "Automation KN Return LLC.xml";
        public const string AUTOMATION_KN_AC3_6 = "Automation KN Return SOS.xml";

        public const string AUTOMATION_KN_AC8_1 = "Automation KN Partnership Lot Rebook 1.xml";

        public const string AUTOMATION_TRADE_UPLOAD_PARTNERSHIP = "Automation Trade Upload Partnership.xml";
        public const string AUTOMATION_TRADE_UPLOAD_LLC = "Automation Trade Upload LLC.xml";
        public const string AUTOMATION_TRADE_UPLOAD_SOS = "Automation Trade Upload SOS.xml";
        public const string AUTOMATION_TRADE_UPLOAD_EQUALIZATION = "Automation Trade Upload Equalization.xml";
        public const string AUTOMATION_TRADE_UPLOAD_PTRANCH = "Automation Trade Upload PTranch.xml";
        public const string AUTOMATION_TRADE_UPLOAD_SINGLE_NAV = "Automation Trade Upload Single NAV.xml";

        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_PARTNERSHIP = "Automation NAV Close Modify Amount Partnership.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_LLC = "Automation NAV Close Modify Amount LLC.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_SOS = "Automation NAV Close Modify Amount SOS.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_EQUALIZATION = "Automation NAV Close Modify Amount Equalization.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_PTRANCH = "Automation NAV Close Modify Amount PTranch.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_AMOUNT_SINGLE_NAV = "Automation NAV Close Modify Amount Single NAV.xml";

        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_PARTNERSHIP = "Automation NAV Close Modify NAV Partnership.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_LLC = "Automation NAV Close Modify NAV LLC.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_SOS = "Automation NAV Close Modify NAV SOS.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_EQUALIZATION = "Automation NAV Close Modify NAV Equalization.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_PTRANCH = "Automation NAV Close Modify NAV PTranch.xml";
        public const string AUTOMATION_NAVCLOSE_MODIFY_NAV_SINGLE_NAV = "Automation NAV Close Modify NAV Single NAV.xml";

        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_PARTNERSHIP = "Automation NAV Close Delete Allocation Partnership.xml";
        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_LLC = "Automation NAV Close Delete Allocation LLC.xml";
        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_SOS = "Automation NAV Close Delete Allocation SOS.xml";
        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_EQUALIZATION = "Automation NAV Close Delete Allocation Equalization.xml";
        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_PTRANCH = "Automation NAV Close Delete Allocation PTranch.xml";
        public const string AUTOMATION_NAVCLOSE_DELETE_ALLOCATION_SINGLE_NAV = "Automation NAV Close Delete Allocation Single NAV.xml";
        
    }

    public static class old_TestData
    {
        public static readonly string Client = AfWebTest.TestData.Client; //Settings.Default.Client;
        public static readonly string Portfolio = AfWebTest.TestData.Portfolio;
        public static readonly string Fund = AfWebTest.TestData.BaseFund;
        public static readonly string InceptionDate = AfWebTest.TestData.FundIssueDate;
    }

    public static class SpecialSymbols
    {
        public const string WAVE_DASH = "~";
        public const string FUND_SEPARATOR = " - ";
        public const string SPACE = " ";
        public const string BREAK = "<BR>";
        public const string UNDERLINE = "_";

        #if NEW_TELERIK
        public const string LESS = "<";
        public const string GREATER = ">";
        public const string NBSP = " ";
        public const string AMPERSAND = "&";
        #else        
        public const string LESS = "&lt;";
        public const string GREATER = "&gt;";
        public const string NBSP = "&nbsp;";
        public const string AMPERSAND = "&amp;";
        #endif
        //public const string UNICODE_SPACE = "_u0020_";
        //public const string UNICODE_SLASH = "_u002f_";
        //public const string SLASH = "/";
        //public const string REVERSE_SLASH = @"\";
        //public const string NUMBER_SIGN = "#";
        //public const string DATE_MASK = "__/__/____";
        //public const string CR = "\n\r";
    }

    public static class XPathMessages
    {
        public const string MESSAGE_ACTION_NAME_XPATH = "//messages/@action_name";
        public const string MESSAGE_SEQNO_XPATH = "//messages/@seqno";
        public const string MESSAGE_INSTRUMENT_XPATH = "//messages/@instrument";

        public const string SECURITY_IVESTMENT_TYPE = "//messages/SECURITY/key[@name='investment_type']";
        public const string SECURITY_DESCRIPTION = "//messages/SECURITY/key[@name='description']";
        public const string SECURITY_INSTRUMENT_XPATH = "//messages/SECURITY/key[@name='instrument']";
        public const string SECURITY_MSG_ID_XPATH = "//messages/SECURITY/key[@name='af_msg_id']";

        public const string TRADE_SEQNO_XPATH = "//messages/TRADE/key[@name='seqno']";
        public const string TRADE_CLIENT_XPATH = "//messages/TRADE/key[@name='client']";
        public const string TRADE_FUND_XPATH = "//messages/TRADE/key[@name='fund']";
        public const string TRADE_INSTRUMENT_XPATH = "//messages/TRADE/key[@name='instrument']";
        public const string TRADE_MSG_ID_XPATH = "//messages/TRADE/key[@name='af_msg_id']";
        public const string TRADE_TXN_CODE_XPATH = "//messages/TRADE/key[@name='txn_code']";
        public const string TRADE_CLIENT_TXN_XPATH = "//messages/TRADE/key[@name='client_txn_id']";
        public const string TRADE_CLEARER_XPATH = "//messages/TRADE/key[@name='clearer_account']";
        public const string TRADE_TRADE_DATE_XPATH = "//messages/TRADE/key[@name='trade_date']";
        public const string TRADE_TRADE_RATE_XPATH = "//messages/TRADE/key[@name='trade_rate']";
        public const string TRADE_TAX_DATE_XPATH = "//messages/TRADE/key[@name='tax_date']";
        public const string TRADE_MM_DATE_XPATH = "//messages/TRADE/key[@name='mm_date']";
        public const string TRADE_SET_DATE_XPATH = "//messages/TRADE/key[@name='set_date']";
        public const string TRADE_QUANTITY_XPATH = "//messages/TRADE/key[@name='quantity']";
        public const string TRADE_USER_XPATH = "//messages/TRADE/key[@name='user']";
        public const string TRADE_CURRENCY_XPATH = "//messages/TRADE/key[@name='currency']";
        public const string TRADE_TRADER_XPATH = "//messages/TRADE/key[@name='trader']";
        public const string TRADE_SECTOR_XPATH = "//messages/TRADE/key[@name='sector']";
        public const string TRADE_STRATEGY_XPATH = "//messages/TRADE/key[@name='strategy']";
        public const string TRADE_OFFSET_LOT_1_XPATH = "//messages/TRADE/key[@name='offset_lot'][@keyno='1']";
        public const string TRADE_OFFSET_LOT_2_XPATH = "//messages/TRADE/key[@name='offset_lot'][@keyno='2']";
        public const string TRADE_OFFSET_LOT_3_XPATH = "//messages/TRADE/key[@name='offset_lot'][@keyno='3']";
        public const string TRADE_TRADE_PRICE_XPATH = "//messages/TRADE/key[@name='trade_price']";

        public const string PRICE_DATE_XPATH = "//messages/PRICE/key[@name='price_date']";
        public const string PRICE_XPATH = "//messages/PRICE/key[@name='price']";

        public const string CASH_TRADE_ACTION_XPATH = "//messages/AF_CASH/key[@name='trade_action']";
        public const string CASH_TXN_CODE_XPATH = "//messages/AF_CASH/key[@name='txn_code']";
        public const string CASH_DATE_XPATH = "//messages/AF_CASH/key[@name='trade_date']";
        public const string CASH_QUANTITY_XPATH = "//messages/AF_CASH/key[@name='quantity']";
    }

    #endregion


    public static class HtmlTags
    {
        public const string TAG_ANCHOR = "a";
        public const string TAG_DIV = "div";
        public const string TAG_IMG = "img";
        public const string TAG_INPUT = "input";
        public const string TAG_INS = "ins";
        public const string TAG_LI = "li";
        public const string TAG_SPAN = "span";
        public const string TAG_TABLE = "table";
        public const string TAG_UL = "ul";
        public const string TAG_TR = "tr";
    }

    public static class AssertMessage
    {
        public const string ELEMENT_NOT_FOUND = "Custom error: Element not found";
        public const string ELEMENT_NOT_CREATED = "Custom error: Element not created";
        public const string ELEMENT_HAS_INCORRECT_REFERENCE = "Element has not expected reference. expected '{0}', actual - '{1}'";
        public const string ELEMENT_HAS_INCORRECT_CSS = "Element has not expected CSS class. Expected - '{0}', actual - '{1}'";

        public const string ROW_FOR_ID_NOT_FOUND = "Row for id '{0}' not found";
        public const string ROW_FOR_FILE_NOT_FOUND = "Row for file '{0}' not found";
        public const string ROW_FOR_INDEX_NOT_FOUND = "Row # '{0}' not found";

        public const string EMPTY_TREE = "Tree is empty";

        public const string TABLE_NOT_FOUND = "Table with attribute '{0}' not found";
        public const string TABLE_IS_EMPTY = "Table '{0}' is empty";

        public const string METADATA_NOT_FOUND = "Metadata for row '{0}' not found";

        public const string FOLDER_NOT_FOUND = "Folder '{0}' not found";
        public const string FOLDER_HAS_NOT_PARENT = "Folder '{0}' has not parent";
        public const string FOLDER_EXISTS = "Folder '{0}' is exists";
        public const string NO_SUBFOLDERS = "Folder '{0}' contains no subfolders";
        public const string SUBFOLDERS_EXISTS = "Folder '{0}' has any subfolders";

        public const string FILE_NOT_FOUND = "File '{0}' not found";

        public const string LISTITEM_NOT_EXISTS = "Custom error: List item  id not exists";

        public const string NODE_NOT_FOUND = "Node '{0}' in tree not found";

        public const string WEBSERVICE_ERROR = "WebService Error: '{0}'";

        public const string ELEMENTS_NOT_EQUAL = "Elements '{0}' and '{1}' are not equal";

        public const string IMAGE_DISABLED = "Image '{0}' disabled but should be enabled";

        public const string XML_NOT_MATCH = "XML values didn't match. Please see '{0}'.";
    }

    public class ExpectedError
    {
        public const string SHOULD_BE_NOT_EMPTY = "Should be not empty";
        public const string ALREADY_EXISTS = "already exists";
        public const string NOT_FOUND = "' not found.";
        public const string CANNOT_CONTAIN_ANY_OF_THE_NEXT_SYMBOLS = "Cannot contain any of the next symbols";
        public const string LENGTH_SHOULD_BE_LESS_OR_EQUAL = "Length should be less or equal to 128 symbols";
        public const string NOT_BE_STARTED_AND_ENDED_WITH_PERIOD = "Should not be started and ended with period";
        public const string APOSTROPHES_SYMBOLS = "Cannot consist only from apostrophes symbols";
        public const string NO_RESULT = "Nothing matches with info you provided";
        public const string NO_LOCATION = "Please provide search location";
        public const string NO_SEARCH_DATA = "Please provide information to search for";
        public const string INCORRECT_DATE_RANGE = "Date from cannot be greater than date till";
        public const string INCORRECT_DATE = "String was not recognized as a valid DateTime";
        public const string IVALID_CREATED_DATE = "Invalid created date";
        public const string IVALID_MODIFIED_DATE = "Invalid modified date";
        public const string INCORRECT_DATE_LONG = "The string was not recognized as a valid DateTime. There is a unknown word starting at index";
        public const string NO_UPLOAD_FILE = "Please select file to upload";
    }

    public static class Status
    {
        public const string PleaseWait = "Please wait...";
        public const string Accept = "Accept";
        public const string Update = "Update";
    } 

    public static class Strategy
    {
        public const string CONVERTIBLE_ARBITRAGE = "Convertible Arbitrage";
        public const string DISTRESSED = "Distressed";
        public const string FIXED_INCOME_ARBITRAGE = "Fixed Income Arbitrage";
        public const string LONG_SHORT_EQUITY = "Long/Short Equity";
        public const string MERGER_ARBITRAGE = "Merger Arbitrage";
    }

    public static class AfClients
    {
        private static readonly StringDictionary _clientsDictionary = new StringDictionary()
        {
             {"Auto ERepository", "AutoERepository"},
             {"Auto Exchange", "AutoEx"}, 
             {"Auto NV AC5", "AutoNVAC5"},
             {"Automation Average", "AutoAvg"},
             {"Automation Backdated", "ABACK"},
             {"Automation Cash Distribution", "AutoCash"},
             {"Automation Client", "Automation"},
             {"Automation Common Price", "ACP"},
             {"Automation Dashboard", "AutomationDashboard"},
             {"Automation Dashboard 1", "AutoDash"},
             {"Automation Edit Trades", "Auto Edit SubRed"},
             {"Automation Effective", "AEFF"},
             {"Automation Equalization", "EQL"},
             {"Automation Exchange", "AutoExc"},
             {"Automation FixedFifo", "AutoFixed"},
             {"Automation GLS", "AGLS"},
             {"Automation JPM", "AutoJPM"},
             {"Automation KN Lockdown", "AutoKNLockdown"},
             {"Automation KN Lot Rebook", "AutoKNLotRebook"},
             {"Automation KN Modify", "A_KN_Modify"},
             {"Automation KN OP", "AutoKNOP"},
             {"Automation KN RebookFutures", "AutoKNRF"},
             {"Automation KN Return", "AutoKNR"},
             {"Automation KN Trade Upload", "AutoKNTU"},
             {"Automation Launchpad Data Upload", "AutoLDataUpl"},
             {"Automation LIFO", "AUTOLIFO"},
             {"Automation Lockdown", "AutoLock"},
             {"Automation Merge 1", "Automation Merge 1"},
             {"Automation Merge 2", "Automation Merge 2"},
             {"Automation NAV", "ANAV"},
             {"Automation NAVClose Delete Allocation", "AutoNavCloseDelAll"},
             {"Automation NAVClose Modify Allocation", "AutoNAVClose1"},
             {"Automation NAVClose Modify NAV", "AutoModifyNAV"},
             {"Automation NavClose OP", "AutomationNavCloseOP"},
             {"Automation OMS", "AutoOMS"},
             {"Automation OMS Validation", "AutoOMSV"},
             {"Automation Private Equity", "AutoPE"},
             {"Automation Redemption", "AutoRed"},
             {"Automation Specific", "AutoSpec"},
             {"Automation Subscription", "AutoSub"},
             {"Automation TradeEx", "Auto TradeEx"},
             {"Automation Transfers", "AutoTran"},
             {"Automation Update Offer", "AUO_X"},
             {"Cash Distribution", "CashDistribution"},
             {"JP Morgan", "NCWW"},
             {"QA Test Client", "QA Test Client"},
             {"Dashboard", "Dashboard"}
        };

        public static string GetClientId(string clientName)
        {
            if (!_clientsDictionary.ContainsKey(clientName)) 
                throw new ArgumentException("Cannot find client with name " + clientName);
                
            return _clientsDictionary[clientName];
        }
    }

    public class SonicMessage
    {
        public struct XmlKeys
        {
            public const string FAS157 = "FAS157";
            public const string QUANTITY = "quantity";
            public const string MM_DATE = "mm_date";
            public const string INSTRUMENT = "instrument";
            public const string DESCRIPTION = "description";
        }
    }

    public static class AfCurrency
    {
        public const string AUD = "AUD";
        public const string BRL = "BRL";
        public const string CAD = "CAD";
        public const string CHF = "CHF";

        public const string CNY = "CNY";
        public const string EUR = "EUR";
        public const string GBP = "GBP";
        public const string HKD = "HKD";

        public const string JPY = "JPY";
        public const string SEK = "SEK";
        public const string TWD = "TWD";
        public const string USD = "USD";
    }
}