﻿using System.Collections.Generic;
using IFS.AF.BaseContext.Context;
using Machine.Specifications;

//[ALPHA]   2542: Add yearly return for 2013 to the notepad
//[Author]  Sergii Dmytrenko
//[Created] 12/13/2013

namespace IFS.AF.UIControls.Tests.DashboardColumns
{
    [Subject("TC_DC_Private_Equity"), Tags("DashboardColumns", "TC_DC_Private_Equity")]
    public class TC_DC_Private_Equity : EstablishDashboard
    {
        Establish _context = () =>
        {
            TabName = DashboardColumnsPage.TabNames.PrivateEquity;

            #region Headers
            ExpectedTableHeaders = new List<string>()
            {
                "General",
                "Performance",
                "Contributions",
                "Distributions"
            };
            #endregion

            #region General
            ExpectedColumn1 = new List<string>()
            {
                "Vintage Year",
                "Cash Funded",
                "Investment Type",
                "Investment Form",
                "Breakup Type",
                "Breakup Amount (Base)",
                "Breakup Amount (Local)",
                "Capital Account Balance - Opening (Base)",
                "Capital Account Balance - Opening (Local)",
                "Capital Account Balance - Activity (Base)",
                "Capital Account Balance - Activity (Local)",
                "Capital Account Balance - Closing (Base)",
                "Capital Account Balance - Closing (Local)",
                "Stock Distribution",
                "Commitment - Opening (Base)",
                "Commitment - Opening (Local)",
                "Additional Commitment (Base)",
                "Additional Commitment (Local)",
                "Commitment - Closing (Base)",
                "Commitment - Closing (Local)",
                "Funded Commitment - Opening (Base)",
                "Funded Commitment - Opening (Local)",
                "Funded Commitment - Activity (Base)",
                "Funded Commitment - Activity (Local)",
                "Funded Commitment - Closing (Base)",
                "Funded Commitment - Closing (Local)",
                "UnFunded Commitment - Opening (Base)",
                "UnFunded Commitment - Opening (Local)",
                "UnFunded Commitment - Activity (Base)",
                "UnFunded Commitment - Activity (Local)",
                "UnFunded Commitment - Closing (Base)",
                "UnFunded Commitment - Closing (Local)",
                "Profit and Loss (Base)",
                "Profit and Loss (Local)",
                "Effective Date of Breakup"
            };
            #endregion

            #region Performance
            ExpectedColumn2 = new List<string>()
            {
                "Inception IRR",
                "Quarter IRR",
                "YTD IRR",
                "One Year IRR",
                "Three Years IRR",
                "Five Years IRR",
                "Seven Years IRR",
                "Ten Years IRR",
                "Investment Multiple (TVPI)",
                "Distribution Multiple (DVPI)",
                "RVPI"
            };
            #endregion

            #region Contributions
            ExpectedColumn3 = new List<string>()    
            {
                "Contributions Cumulative (Local)",
                "Contributions Cumulative",
                "Contributions (Local)",
                "Contributions",
                "Percentage Contributed",
                "CapitalCall",
                "Interest or Fee Paid to Other LPs- Inside Commitment",
                "Interest or Fee Paid to Other LPs- Outside Commitment",
                "Management Fees-Inside Commitment",
                "Management Fees-Outside Commitment",
                "Expenses and Organization Costs-Inside Commitment",
                "Expenses and Organization Costs-Outside Commitment",
                "Miscellaneous-Inside Commitment",
                "Miscellaneous-Outside Commitment",
                "Contribution - Inside Commitment (Base)",
                "Contribution - Inside Commitment (Local)",
                "Contribution - Outside Commitment (Base)",
                "Contribution - Outside Commitment (Local)"
            };
            #endregion

            #region Distributions
            ExpectedColumn4 = new List<string>()    
            {
                "Distributions Cumulative",
                "Distributions Cumulative (Local)",
                "Distributions (Local)",
                "Distributions",
                "Temporary Return of Capital",
                "Return of Capital-Distributions Recallable",
                "Return of Capital-Distributions NonRecallable",
                "Interest Income-Distributions Recallable",
                "Interest Income-Distributions Non Recallable",
                "Dividend Income-Distributions Recallable",
                "Dividend Income-Distributions Non Recallable",
                "Other Income-Distributions Recallable",
                "Other Income-Distributions Non Recallable",
                "Return of Management Fees-Distributions Recallable",
                "Return of Management Fees-Distributions Non Recallable",
                "Return of Expenses-Distributions Recallable",
                "Return of Expenses-Distributions Non Recallable",
                "Taxes Withheld-Distributions Recallable",
                "Taxes Withheld-Distributions Non Recallable",
                "Miscellaneous-Distributions Recallable",
                "Miscellaneous-Distributions Non Recallable",
                "Distributions Recallable (Base)",
                "Distributions Recallable (Local)",
                "Distributions NonRecallable (Base)",
                "Distributions NonRecallable (Local)"
            };
            #endregion
        };

        It _0_Table_headers_should_be_correct               = () => TableHeaders.ShouldEqual(ExpectedTableHeaders);
        It _1_Columns_list_should_be_correct_General        = () => ColumnNames[0].ShouldContainOnly(ExpectedColumn1);
        It _2_Columns_list_should_be_correct_Performance    = () => ColumnNames[1].ShouldContainOnly(ExpectedColumn2);
        It _3_Columns_list_should_be_correct_Contributions  = () => ColumnNames[2].ShouldContainOnly(ExpectedColumn3);
        It _4_Columns_list_should_be_correct_Distributions  = () => ColumnNames[3].ShouldContainOnly(ExpectedColumn4);
    }
}