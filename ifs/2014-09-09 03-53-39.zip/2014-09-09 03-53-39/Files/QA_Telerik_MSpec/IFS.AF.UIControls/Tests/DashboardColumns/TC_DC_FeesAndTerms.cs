﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using Machine.Specifications;

//[ALPHA-3140] Add "Expected Holdback Payment Date" to Note Pad on Dashboard
//[Created By] Sergii Dmytrenko @ 02/14/2014

namespace IFS.AF.UIControls.Tests.DashboardColumns
{
    [Subject("TC_DC_FeesAndTerms"), Tags("DashboardColumns", "TC_DC_FeesAndTerms")]
    public class TC_DC_FeesAndTerms : EstablishDashboard
    {
        Establish _context = () =>
        {
            TabName = DashboardColumnsPage.TabNames.FeesAndTerms;
            
            ExpectedTableHeaders = new List<string>()
            {
                "Fees " + SpecialSymbols.AMPERSAND + " Terms", 
                "Redemption Payment Schedule"
            };

            ExpectedColumn1 = new List<string>()
            {
                "Hurdle",
                "Incentive Fee",
                "Liquidity",
                "Lockup",
                "Management Fee",
                "Redemption Notice (Days)"
            };

            ExpectedColumn2 = new List<string>()
            {
                "Expected Holdback Payment Date"
            };
        };

        It _0_Table_headers_should_be_correct   = () => TableHeaders.ShouldEqual(ExpectedTableHeaders);
        It _1_Columns_list_should_be_correct    = () => ColumnNames[0].ShouldContainOnly(ExpectedColumn1);
        It _2_Columns_list_should_be_correct    = () => ColumnNames[1].ShouldContainOnly(ExpectedColumn2);
    }
}