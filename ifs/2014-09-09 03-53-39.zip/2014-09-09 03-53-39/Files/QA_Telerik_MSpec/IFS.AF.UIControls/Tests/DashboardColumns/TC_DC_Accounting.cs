﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using Machine.Specifications;

//ALPHA-2542: Add yearly return for 2013 to the notepad
//[Author]  Sergii Dmytrenko
//[Created] 12/13/2013

namespace IFS.AF.UIControls.Tests.DashboardColumns
{
    [Subject("TC_DC_Accounting"), Tags("DashboardColumns", "TC_DC_Accounting")]
    public class TC_DC_Accounting : EstablishDashboard
    {
        Establish _context = () =>
        {
            TabName = DashboardColumnsPage.TabNames.Accounting;

            #region Headers
            ExpectedTableHeaders = new List<string>()
            {
               "Accounting",
               "Allocation", 
               "IAFOF",
               "IAFOF (contd)"
            };
            #endregion

            #region Accounting
            ExpectedColumn1 = new List<string>()
            {
                "Allocations Cumulative",
                "Allocations Cumulative (Local)",
                "Current Nav",
                "Final Nav",
                "Final Nav Date",
                "Final Market Value",
                "Current Shares",
                "Instrument ID",
                "Market Value",
                "Market Value (Local)",
                "Market Value Weighting",
                "Ownership %",
                "Price Status",
                "Profit " + SpecialSymbols.AMPERSAND + " Loss",
                "Profit " + SpecialSymbols.AMPERSAND + " Loss (Local)",
                "Profit " + SpecialSymbols.AMPERSAND + " Loss Cumulative",
                "Profit " + SpecialSymbols.AMPERSAND + " Loss Cumulative (Local)",
                "Redemptions",
                "Redemptions (Local)",
                "Redemptions Cumulative",
                "Redemptions Cumulative (Local)",
                "Subscriptions",
                "Subscriptions (Local)",
                "Subscriptions Cumulative",
                "Subscriptions Cumulative (Local)",
                "Prior Month Market Value",
                "Prior Month Market Value (Local)",
                "Current Nav Base",
                "Fx Rate",
                "Dividend Income",
                "Interest Income",
                "Cash Distribution (Local)",
                "Cash Distribution (Base)"
            };
            #endregion

            #region Allocation
            ExpectedColumn2 = new List<string>()
            {
                "Effective Date",
                "Trade Date",
                "Cancellation Trade Ticket Date",
                "Money Move Date",
                "Transaction Type",
                "Clearer",
                "Comments",
                "Entered By",
                "Reason For Change",
                "Transaction ID",
                "Source",
                "Cancellation Source",
                "Registrar",
                "Reason For Cancellation"
            };
            #endregion

            #region IAFOF
            ExpectedColumn3 = new List<string>()
            {
                "Date Of Return",
                "Shares @[Prior Month]",
                "NAV Close NAV @[Prior Month]",
                "Estimate / Final @[Prior Month]",
                "NAV Close MV Final Price Coverage @[Prior Month]",
                "NAV Close MV @[Prior Month]",
                "Backdated Trades",
                "Shares on Backdated Trades",
                "Backdate Trade Adjustment",
                "Final True-Up",
                "Adjusted NAV Close MV @[Prior Month]",
                "Updated NAV @[Prior Month]",
                "Updated MV @[Prior Month]",
                "Cost @[Prior Month]",
                "Capital Activity @[Current Month]",
                "Share Activity @[Current Month]"
            };
            #endregion

            #region IAFOF (contd)
            ExpectedColumn4 = new List<string>()
            {
                "Opening Shares @[Current Month]",
                "Opening MV @[Current Month]",
                "Current Month Updated Income",
                "Current Month NAV Close Income",
                "Current Month Total Income",
                "Ending MV @[Current Month]",
                "Current Cost @[Current Month]",
                "Estimate / Final @[Current Month]",
                "Price Source",
                "Price Posted Date",
                "Final Price Coverage @[Current Month]",
                "MTD Weights %",
                "MTD Weights Portfolio %",
                "Price Entered MTD Weights %",
                "NAV Close %Return",
                "MTD %Return",
                "MTD %Return (Local)",
                "Price Status @[Prior Month]",
                "RMTD Vs. NAV Close % Variance @[Current Month]",
                "Price Status @[Current Month]"
            };
            #endregion
        };

        It _0_Table_headers_should_be_correct               = () => TableHeaders.ShouldEqual(ExpectedTableHeaders);
        It _1_Columns_list_should_be_correct_Accounting     = () => ColumnNames[0].ShouldContainOnly(ExpectedColumn1);
        It _2_Columns_list_should_be_correct_Allocation     = () => ColumnNames[1].ShouldContainOnly(ExpectedColumn2);
        It _3_Columns_list_should_be_correct_IAFOF          = () => ColumnNames[2].ShouldContainOnly(ExpectedColumn3);
        It _4_Columns_list_should_be_correct_IAFOF_contd    = () => ColumnNames[3].ShouldContainOnly(ExpectedColumn4);
    }
}