﻿using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.ModifyTradesAfterLockdown;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.ModifyTradesAfterLockdown
{
    public class EstablishDeleteTradesAfterLockdown : EstablishModifyTradesAfterLockdown
    {
        private Because _of = () =>
        {
            UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            GetAvailSharesFromPriceLockdownPage(ref SharesInBlueLineBeforeModifyActual, ref SharesUnderBlueLineBeforeModifyActual);
            Dashboard.GoToDashboard();
            Dashboard.DeleteTransactionsForFund(TestData.InvestableFund, 1);

            Dashboard.Expand(TestData.BaseFund);
            GetAvailSharesFromPriceLockdownPage(ref SharesInBlueLineAfterModifyActual, ref SharesUnderBlueLineAfterModifyActual);
        };

        Cleanup _clean = () =>
        {
            try
            {
                Dashboard.GoToDashboard();
                Dashboard.GoToPriceLockdown();

                try   { PriceLockdown.UnlockPortfolio(TestData.Portfolio, LockDownDate); }
                catch {};

                Dashboard.GoToDashboard();
                Dashboard.DeleteTransactionsForFund(TestData.InvestableFund, 1);

                TransactionAction.CreateTransaction(ModifiedTransaction);
                Dashboard.GoToPriceLockdown();
                PriceLockdown.LockdownDate.SelectPartial(LockDownDate);
                PriceLockdown.SaveAndLockdownDate("5/18/2012");

            }catch
            {
            }
        };
    }
    
}
