﻿/*
 * Automated test for TradeEx
 * 
 * 001 - 016        Subs
 * 017 - 031        Reds
 * 032 - 046        Exchange
 * 047 - 061        IFS to IFS
 * 062 - 076        IFS to 3rd
 * 077 - 090        3rd to IFS
 * 091 - 098        Corporate Action
 * 099              Custody Report
 * 100              Subscription Checklist Report
 * 101              Redemption Checklist Report
 * 102              TT Tests
 */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Win32.Dialogs;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Context.CreditProvider;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.TradeEx
{
    public class TradeExInit : AfWebTest
    {
        private static LoginControl _loginControl;
        // private static DisclaimerPage _disclaimerPage;

        protected static Browser BrowserId, BrowserId1;
        protected static DashboardPage Dashboard;
        protected static RedemptionPage Redemption;
        protected static ExchangePage Exchange;
        protected static TransferPage Transfer;
        protected static SubscriptionPage Subscription;
        protected static ActivityReportPage ActivityReport;
        protected static PriceLockdownPage PriceLockdown;
        protected static ContextMenus ContextMenu;
        protected static QuickSearchPage QuickSearch;
        protected static PortfolioMaintainPage PortfolioMaintainPage;
        protected static PortfolioPopupPage PortfolioPopupPage;
        protected static CreditProviderPage CreditProviderTab;
        protected static SubscriptionChecklistPage SubscriptionChecklist;
        protected static RedemptionChecklistPage RedemptionChecklist;
        protected static CustodyReportPage CustodyReportPage;
        protected static CorporateActionPage CorporateAction;
        protected static ViewCorporateActionsPage ViewCorporateActions;
        protected static EqualizationSubscriptionPage EqualizationSubscription;
        protected static SelectClientPage _selectClientsPage;
        protected static ExportFromLayoutPage ExportFromLayoutPage;

        protected static BaseTransaction.Transaction InitialTransaction;
        protected static BaseTransaction.Transaction Subscription1;
        protected static BaseTransaction.Transaction Exchange1;
        protected static BaseTransaction.Transaction Transfer1;

        protected static FileUploadDialog FileUpload;
        protected static ConfirmDialog BaseDialog;
        protected static DialogMonitor dialogMonitor;

        protected static List<ReportSettings> ReportSettings;

        protected static string ExpectedReportRootDirectory;
        protected static string ExportRootDirectory;

        protected static string DefaultLayout, DefaultToDate, ActualMessage, Client;

        Establish _context = () =>
        {
            Dashboard = AsPage<DashboardPage>();
            
            DefaultLayout = "Default";
            DefaultToDate = "Today-" + DateTransform.GetToday();

            ExpectedReportRootDirectory = CurrentDirectoryPath + @"\TradeEx\Import Files\TradeExFiles\";
            ExportRootDirectory = Path.Combine(CurrentDirectoryPath, "TradeEx", "ActualFiles");
            Client = "Automation TradeEx";
        };

        Cleanup _clean = () =>
        {
            try
            {
                ClearDialogListener();

            }catch(Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
        };

        protected static string GetRandomTicketNumber()
        {
            return RandomNumber(900, 9999).ToString(CultureInfo.InvariantCulture);
        }

        protected static void ConfirmAndAlertDialogsInit()
        {
            ClearDialogListener();
            ConfirmDialog confirmDialog = ConfirmDialog.CreateConfirmDialog(Manager.Current.ActiveBrowser, DialogButton.OK);
            AlertDialog alertDialog = AlertDialog.CreateAlertDialog(Manager.Current.ActiveBrowser, DialogButton.OK);
            alertDialog.HandlerDelegate = AlertDialogHandler;
            dialogMonitor = new DialogMonitor();
            dialogMonitor.AddDialog(confirmDialog);
            dialogMonitor.AddDialog(alertDialog);
        }
        
        protected static void AlertDialogHandler(IDialog dialog)
        {
            dialog.Window.WaitForVisibility(true, TimeOut.SEC_45);
            ActualMessage = dialog.Window.AllChildren[2].Caption;
            Manager.Current.Log.WriteLine("From dialog: " + ActualMessage);
            // Simply close the dialog
            dialog.Window.Close();
            dialog.Window.WaitForVisibility(false, TimeOut.SEC_45);
        }

        protected static void ClearDialogListener()
        {
            if (dialogMonitor != null)
            {
                if (dialogMonitor.IsMonitoring)
                    dialogMonitor.Stop();

                // delete all listeners
                int dialogs = dialogMonitor.Dialogs.Count;
                for (int i = 0; i < dialogs; i++)
                {
                    dialogMonitor.RemoveDialog(dialogMonitor.Dialogs[0]);
                }
            }
        }

        protected static void BaseFund4Pretest()
        {
            Dashboard.LayoutSelect("Default");
            if (Dashboard.GetMarketValue("Test Base Fund4") != "18,000,000.00")
            {
                Dashboard.DeleteTransactionsForFund("Test Base Fund4 - Partnership Class 8", 2);    
            }
        }

        protected static void SubControlAgreement(string comments, string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.ControlAgreement.CommentsCheckBox.Check();
            SubscriptionChecklist.ControlAgreement.CommentsTextArea.Text = comments;
            SubscriptionChecklist.ControlAgreement.ConfirmedCheckBox.Check();
            SubscriptionChecklist.ControlAgreement.ConfirmedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubControlAgreementReviewed(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.ControlAgreement.ReviewedCheckBox.Check();
            BrowserPool.WaitUntilPageLoaded();
            SubscriptionChecklist.ControlAgreement.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeDocumentation1(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsDeadlineCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsDeadlineDateBox.Text = date;
            SubscriptionChecklist.TradeDocumentation.EarliestNotificationDeadlineCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.EarliestNotificationDeadlineDateBox.Text = date;
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsPreparedCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsPreparedDateBox.Text = date;
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeDocumentationReviewed1(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsReviewedCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.TradeDocumentsReviewedDateBox.Text = date;
            SubscriptionChecklist.TradeDocumentation.ReconcileToTradesReceivedCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.ReconcileToTradesReceivedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeDocumentation2(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeDocumentation.ObtainSignatoryCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.ObtainSignatoryDateBox.Text = date;
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeDocumentation2Fax(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeDocumentation.ObtainSignatoryCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.ObtainSignatoryDateBox.Text = date;
            SubscriptionChecklist.TradeDocumentation.FaxCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.FaxDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeDocumentationReviewed2(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeDocumentation.ReviewedCheckBox.ScrollToVisible();
            SubscriptionChecklist.TradeDocumentation.ReviewedCheckBox.Check();
            SubscriptionChecklist.TradeDocumentation.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubMoneyMovement(string date, string comments, string additionalAmount)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.MoneyMovement.ReasonPaymentSentConfirmedInputBox.ScrollToVisible();
            SubscriptionChecklist.MoneyMovement.ActualMoneyMoveDateCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.ActualMoneyMoveDateBox.TypeText(date);
            SubscriptionChecklist.MoneyMovement.ReasonActualMoneyMoveCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.ReasonActualMoneyMoveTextArea.Text = comments;
            SubscriptionChecklist.MoneyMovement.AdditionalMoneyMoveDateCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.AdditionalMoneyMoveDateBox.TypeText(date);
            SubscriptionChecklist.MoneyMovement.AdditionalAmountCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.AdditionalAmountInputBox.TypeText(additionalAmount);
            SubscriptionChecklist.MoneyMovement.CommentsCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.CommentsTextArea.Text = comments;
            SubscriptionChecklist.MoneyMovement.PaymentSentConfirmedCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.PaymentSentConfirmedDateBox.TypeText(date);
            SubscriptionChecklist.MoneyMovement.ReasonPaymentSentConfirmedCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.ReasonPaymentSentConfirmedInputBox.Text = comments;
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubMoneyMovementReviewed(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.MoneyMovement.ReviewedDateBox.ScrollToVisible();
            SubscriptionChecklist.MoneyMovement.ReviewedCheckBox.Check();
            SubscriptionChecklist.MoneyMovement.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeConfirmation(string verbalAcknowledgement, string followUp, string writtenConfirmation)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeConfirmation.WrittenConfirmationCheckBox.ScrollToVisible();
            SubscriptionChecklist.TradeConfirmation.VerbalAcknowledgmentCheckBox.Check();
            SubscriptionChecklist.TradeConfirmation.VerbalAcknowledgmentBox.TypeText(verbalAcknowledgement);
            SubscriptionChecklist.TradeConfirmation.FollowUpCheckBox.Check();
            SubscriptionChecklist.TradeConfirmation.FollowUpBox.TypeText(followUp);
            SubscriptionChecklist.TradeConfirmation.WrittenConfirmationCheckBox.Check();
            SubscriptionChecklist.TradeConfirmation.WrittenConfirmationBox.TypeText(writtenConfirmation);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeConfirmationReviewed(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeConfirmation.ReviewedCheckBox.ScrollToVisible();
            SubscriptionChecklist.TradeConfirmation.ReviewedCheckBox.Check();
            SubscriptionChecklist.TradeConfirmation.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeTracking(string date, string courierRefNumber, string courierSentBy)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeTracking.CourierSentByDateBox.ScrollToVisible();
            SubscriptionChecklist.TradeTracking.OriginalDocumentsSentCheckBox.Check();
            SubscriptionChecklist.TradeTracking.OriginalDocumentsSentDateBox.TypeText(date);
            SubscriptionChecklist.TradeTracking.CourierReferenceNumberCheckBox.Check();
            SubscriptionChecklist.TradeTracking.CourierReferenceNumberDateBox.TypeText(courierRefNumber);
            SubscriptionChecklist.TradeTracking.CourierSentByCheckBox.Check();
            SubscriptionChecklist.TradeTracking.CourierSentByDateBox.TypeText(courierSentBy);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubTradeTrackingReviewed(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.TradeTracking.ReviewedCheckBox.ScrollToVisible();
            SubscriptionChecklist.TradeTracking.ReviewedCheckBox.Check();
            SubscriptionChecklist.TradeTracking.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubFinalContractStatus(string date, string reason, string comment)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.FinalContractStatus.CommentBox.ScrollToVisible();
            SubscriptionChecklist.FinalContractStatus.StatusCheckBox.Check();
            SubscriptionChecklist.FinalContractStatus.StatusDateBox.TypeText(date);
            SubscriptionChecklist.FinalContractStatus.StatusReasonDropDown.Select(reason);
            SubscriptionChecklist.FinalContractStatus.CommentBox.TypeText(comment);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void SubFinalContractStatusReviewed(string date)
        {
            SubscriptionChecklist = AsPage<SubscriptionChecklistPage>();
            SubscriptionChecklist.FinalContractStatus.ReviewedCheckBox.ScrollToVisible();
            SubscriptionChecklist.FinalContractStatus.ReviewedCheckBox.Check();
            SubscriptionChecklist.FinalContractStatus.ReviewedDateBox.TypeText(date);
            SubscriptionChecklist.FinalContractStatus.CompletedCheckBox.Check();
            SubscriptionChecklist.FinalContractStatus.CompletedDateBox.TypeText(date);
            SubscriptionChecklist.AcceptBtn.ScrollToVisible();
            SubscriptionChecklist.AcceptBtn.Click(true);
        }

        protected static void RedControlAgreement(string comments, string date)
        {
            RedemptionChecklist.ControlAgreement.CommentsCheckBox.Check();
            RedemptionChecklist.ControlAgreement.CommentsTextArea.Text = comments;
            RedemptionChecklist.ControlAgreement.ConfirmedCheckBox.Check();
            RedemptionChecklist.ControlAgreement.ConfirmedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedControlAgreementReviewed(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.ControlAgreement.ReviewedCheckBox.Check();
            RedemptionChecklist.ControlAgreement.ReviewedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeDocumentation1(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeDocumentation.TradeDocumentsDeadlineCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.TradeDocumentsDeadlineDateBox.Text = date;
            RedemptionChecklist.TradeDocumentation.EarliestNotificationDeadlineCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.EarliestNotificationDeadlineDateBox.Text = date;
            RedemptionChecklist.TradeDocumentation.TradeDocumentsPreparedCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.TradeDocumentsPreparedDateBox.Text = date;
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeDocumentationReviewed1(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeDocumentation.TradeDocumentsReviewedCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.TradeDocumentsReviewedDateBox.TypeText(date);
            RedemptionChecklist.TradeDocumentation.ReconcileToTradesReceivedCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.ReconcileToTradesReceivedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeDocumentation2(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeDocumentation.ObtainSignatoryCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.ObtainSignatoryDateBox.Text = date;
            RedemptionChecklist.TradeDocumentation.FaxCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.FaxDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeDocumentationReviewed2(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeDocumentation.ReviewedCheckBox.Check();
            RedemptionChecklist.TradeDocumentation.ReviewedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeConfirmation(string verbalAcknowledgement, string followUp, string writtenConfirmation)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeConfirmation.VerbalAcknowledgmentCheckBox.ScrollToVisible();
            RedemptionChecklist.TradeConfirmation.VerbalAcknowledgmentCheckBox.Check();
            RedemptionChecklist.TradeConfirmation.VerbalAcknowledgmentBox.TypeText(verbalAcknowledgement);
            RedemptionChecklist.TradeConfirmation.FollowUpCheckBox.Check();
            RedemptionChecklist.TradeConfirmation.FollowUpBox.TypeText(followUp);
            RedemptionChecklist.TradeConfirmation.WrittenConfirmationCheckBox.Check();
            RedemptionChecklist.TradeConfirmation.WrittenConfirmationBox.TypeText(writtenConfirmation);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeConfirmationReviewed(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeConfirmation.ReviewedCheckBox.ScrollToVisible();
            RedemptionChecklist.TradeConfirmation.ReviewedCheckBox.Check();
            RedemptionChecklist.TradeConfirmation.ReviewedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeTracking(string date, string courierRefNumber, string courierSentBy)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeTracking.OriginalDocumentsSentCheckBox.ScrollToVisible();
            RedemptionChecklist.TradeTracking.OriginalDocumentsSentCheckBox.Check();
            RedemptionChecklist.TradeTracking.OriginalDocumentsSentDateBox.TypeText(date);
            RedemptionChecklist.TradeTracking.CourierReferenceNumberCheckBox.Check();
            RedemptionChecklist.TradeTracking.CourierReferenceNumberDateBox.TypeText(courierRefNumber);
            RedemptionChecklist.TradeTracking.CourierSentByCheckBox.Check();
            RedemptionChecklist.TradeTracking.CourierSentByDateBox.TypeText(courierSentBy);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedTradeTrackingReviewed(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.TradeTracking.ReviewedCheckBox.ScrollToVisible();
            RedemptionChecklist.TradeTracking.ReviewedCheckBox.Check();
            RedemptionChecklist.TradeTracking.ReviewedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedFinalContractStatus(string statusReason, string comments, string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.FinalContractStatus.StatusCheckBox.ScrollToVisible();
            RedemptionChecklist.FinalContractStatus.StatusCheckBox.Check();
            RedemptionChecklist.FinalContractStatus.StatusReasonDropDown.Select(statusReason);
            RedemptionChecklist.FinalContractStatus.CommentBox.TypeText(comments);
            RedemptionChecklist.FinalContractStatus.StatusDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static void RedFinalContractStatusReviewed(string date)
        {
            RedemptionChecklist = AsPage<RedemptionChecklistPage>();
            RedemptionChecklist.FinalContractStatus.ReviewedCheckBox.ScrollToVisible();
            RedemptionChecklist.FinalContractStatus.ReviewedCheckBox.Check();
            RedemptionChecklist.FinalContractStatus.ReviewedDateBox.TypeText(date);
            RedemptionChecklist.FinalContractStatus.CompletedCheckBox.Check();
            RedemptionChecklist.FinalContractStatus.CompletedDateBox.TypeText(date);
            RedemptionChecklist.SaveAndClose();
        }

        protected static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }

    public class ReportSettings
    {
        public string FileName;
        public string Date = null;
        public string ToDate = null;
        public string NumberOfEstimates = null;
        public bool? NavClose = null;
    }

    #region Behaviors

    [Behaviors]
    public class verify_popup_message
    {
        protected static string _expectedErrorMessage;

        It actual_message_should_equal_expected_message = () =>
                DialogMonitoring.ActualMessage.ShouldEqual(_expectedErrorMessage);
    }

    [Behaviors]
    public class verify_popup_message_2
    {
        protected static string _expectedErrorMessage, ActualMessage;

        It actual_message_should_equal_expected_message = () =>
            ActualMessage.ShouldEqual(_expectedErrorMessage);
    }

    [Behaviors]
    public class check_tradeex_fields_are_not_visible
    {
        protected static bool _tradeExControls;

        It tradeex_controls_should_not_exist = () =>
            _tradeExControls.ShouldBeFalse();
    }

    [Behaviors]
    public class check_expected_money_move_date
    {
        protected static RedemptionChecklistPage RedemptionChecklist;
        protected static string _expectedMoneyMoveDate;

        It expected_money_move_date_should_match = () =>
            _expectedMoneyMoveDate.ShouldEqual("07/03/2006");
    }

    #endregion
}
