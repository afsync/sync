﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications;

// [ALPHA-3533] Allow user changing the position of the columns in Liquidity view report directly on report page
// [Created by] Sergii Dmytrenko @ 04/09/2014

namespace IFS.AF.UIControls.Tests.LiquidityViewReport
{
    [Subject("AF_LVR_3533"), Tags("LiquidityViewReport", "AF_LVR_3533")]
    public class Verify_Ability_To_DragAndDrop_Columns : AfWebTest
    {
        protected static List<string> TestColumns, ColumnsBeforeMoving, ColumnsAfterMoving, ExpectedColumnsBeforeMoving, ExpectedColumnsAfterMoving;

        Establish _establish = () =>
        {
            #region Init Data
            TestColumns = new List<string>()
            {
                LiquidityViewReportPage.ColumnHeaders.FUND_NAME,
                LiquidityViewReportPage.ColumnHeaders.CURRENCY,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_2,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_2
            };

            ExpectedColumnsBeforeMoving = new List<string>(TestColumns);

            ExpectedColumnsAfterMoving = new List<string>()
            {
                TestColumns[0],
                TestColumns[5],
                TestColumns[2],
                TestColumns[3],
                TestColumns[4],//1
                TestColumns[1] //4
            };
            #endregion
        };
        
        Because _of = () =>
        {
            var liquidityViewReport = UserAction.LoginAsAdmin("Automation Liquidity", "Liquidity Refactor Portfolio 1")
                .GoToLiquidityViewReport();
            
            liquidityViewReport.OpenColumnsOrderWidget();
            liquidityViewReport.ColumnsOrderWidget.AvailableColumns.UnCheckAll();
            liquidityViewReport.ColumnsOrderWidget.AvailableColumns.Select(TestColumns);
            liquidityViewReport.ColumnsOrderWidget.Apply();

            ColumnsBeforeMoving = liquidityViewReport.GetTableHeaders();

            liquidityViewReport.DragTableColumn(TestColumns[1], offset: 4);
            liquidityViewReport.DragTableColumn(TestColumns[4], offset: 1);//2
            liquidityViewReport.DragTableColumn(TestColumns[5], offset:-2);
            
            ColumnsAfterMoving = liquidityViewReport.GetTableHeaders();
        };

         It The_Default_order_of_columns_should_be_correct = () => ColumnsBeforeMoving.ShouldEqualExtended(ExpectedColumnsBeforeMoving);
         It The_columns_should_be_moved_correctly          = () => ColumnsAfterMoving.ShouldEqualExtended (ExpectedColumnsAfterMoving);
    }
}