﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.LiquidityViewReport
{
    /* Alpha-3527 Allow user changing the list of columns to be displayed in Liquidity view report
    * 
    * UAC 12
    * This test is not changing any data
    * 
    * Created by: Svetlana Isaienko
    * 04/09/2014
    */
    [Subject("AF_LVR_3527_06"), Tags("LiquidityViewReport", "AF_LVR_3527_06")]
    public class Verify_that_default_list_of_columns_to_be_displayed_remains : AfWebTest
    {
        #region Variables

        protected static DashboardPage Dashboard;
        protected static LiquidityViewReportPage LiquidityViewReport;
        protected static ColumnsOrderWidgetClass ColumnsWindow;
        protected static List<string> DefaultColumnsList, NewColumnsList, ActualColumnsListAfterSelect, ActualColumnsListAfterSwitchClient;

        private static string _anotherClient, _adminLogin;

        #endregion

        Establish _context = () =>
        {
            TestData = new TestDataSet
            {
                Client = "Automation Liquidity",
                Portfolio = "Liquidity Refactor Portfolio 1"
            };

            NewColumnsList = new List<string>
            {
                LiquidityViewReportPage.ColumnHeaders.FUND_NAME,
                LiquidityViewReportPage.ColumnHeaders.INVESTMENT_DATE,
                LiquidityViewReportPage.ColumnHeaders.CURRENT_COST,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_2,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_2
            };

            _anotherClient = "Automation Client";
            _adminLogin = WebCredentials.Name;

        };

        Because _of = () =>
        {
            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            
            LiquidityViewReport = Dashboard.GoToLiquidityViewReport();
            DefaultColumnsList = LiquidityViewReport.GetTableHeaders();

            ColumnsWindow = LiquidityViewReport.OpenColumnsOrderWidget();
            ColumnsWindow = new LiquidityViewReportPage(Find).ColumnsOrderWidget;
            ColumnsWindow.AvailableColumns.Select(NewColumnsList);
            ColumnsWindow.Apply();
            ActualColumnsListAfterSelect = LiquidityViewReport.GetTableHeaders();
            Dashboard = Dashboard.GoToDashboard();
            

            Dashboard.SwitchClient(_anotherClient, _adminLogin);
            Dashboard.SwitchClient(TestData.Client, _adminLogin);

            LiquidityViewReport = Dashboard.GoToLiquidityViewReport();
            ActualColumnsListAfterSwitchClient = LiquidityViewReport.GetTableHeaders();
            
        };

        It _1_List_of_displayed_columns_should_change_after_new_columns_were_selected = () => ActualColumnsListAfterSelect.ShouldEqualExtended(NewColumnsList);

        It _2_List_of_displayed_columns_should_get_back_to_default_after_client_was_temporarily_changed = () => ActualColumnsListAfterSwitchClient.ShouldEqualExtended(DefaultColumnsList);
    }
}