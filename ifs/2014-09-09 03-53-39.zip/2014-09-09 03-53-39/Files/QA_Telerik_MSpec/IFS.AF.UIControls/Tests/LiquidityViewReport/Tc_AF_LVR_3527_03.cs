﻿using System.Collections.Generic;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Helpers;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.LiquidityViewReport
{
    /* Alpha-3527 Allow user changing the list of columns to be displayed in Liquidity view report
    * 
    * UAC 6, UAC 4 (Save part), UAC 9
    * This test is not changing any data
    * 
    * Created by: Svetlana Isaienko
    * 04/03/2014
    */
    [Subject("AF_LVR_3527_03"), Tags("LiquidityViewReport", "AF_LVR_3527_03")]
    public class Verify_that_columns_in_the_report_are_displayed_in_the_order_of_the_users_selection_on_Columns_order_page : AfWebTest
    {
        #region Variables

        protected static DashboardPage Dashboard;
        protected static LiquidityViewReportPage LiquidityViewReport;
        protected static ColumnsOrderWidgetClass ColumnsWindow;
        protected static List<string> ExpectedColumnsList, ActualColumnsList, ActualColumnsListAfterRefresh;

        private static string _date;

        #endregion

        Establish _context = () =>
        {
            TestData = new TestDataSet
            {
                Client = "Automation Liquidity",
                Portfolio = "Liquidity Refactor Portfolio 1"
            };

            ExpectedColumnsList = new List<string>
            {
                LiquidityViewReportPage.ColumnHeaders.FUND_NAME,
                LiquidityViewReportPage.ColumnHeaders.INVESTMENT_DATE,
                LiquidityViewReportPage.ColumnHeaders.CURRENT_COST,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_2,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_2
            };

            _date = "4/30/2014";

        };

        Because _of = () =>
        {
            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            
            LiquidityViewReport = Dashboard.GoToLiquidityViewReport();

            ColumnsWindow = LiquidityViewReport.OpenColumnsOrderWidget();

            ColumnsWindow.AvailableColumns.Select(ExpectedColumnsList);
            ColumnsWindow.Apply();

            ActualColumnsList = LiquidityViewReport.GetTableHeaders();

            LiquidityViewReport.AsOfDate.TypeText(_date); //just to have the report get refreshed 
            ActualColumnsListAfterRefresh = LiquidityViewReport.GetTableHeaders();
        };

        It _1_List_of_displayed_columns_should_equal_to_the_list_of_selected_columns = () => ActualColumnsList.ShouldEqualExtended(ExpectedColumnsList);

        It _2_List_of_displayed_columns_should_not_be_changed_after_report_was_refreshed = () => ActualColumnsListAfterRefresh.ShouldEqualExtended(ExpectedColumnsList); //UAC 9
    }
}