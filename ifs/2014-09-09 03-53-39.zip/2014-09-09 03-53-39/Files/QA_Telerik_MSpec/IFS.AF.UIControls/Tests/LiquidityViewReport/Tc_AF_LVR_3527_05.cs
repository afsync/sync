﻿using System.Collections.Generic;
using System.IO;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Context;
using IFS.AF.BaseContext.Context.Reports;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.CompareExcel;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.LiquidityViewReport
{
    /* Alpha-3527 Allow user changing the list of columns to be displayed in Liquidity view report
    * 
    * UAC 11
    * This test is not changing any data
    * 
    * Created by: Svetlana Isaienko
    * 04/08/2014
    */
    [Subject("AF_LVR_3527_05"), Tags("LiquidityViewReport", "AF_LVR_3527_05")]
    public class Verify_that_if_report_is_exported_to_Excel_then_the_columns_in_Excel_file_are_the_same_that_the_displayed_columns_in_the_report : AfWebTest
    {
        #region Variables

        protected static DashboardPage Dashboard;
        protected static LiquidityViewReportPage LiquidityViewReport;
        protected static ColumnsOrderWidgetClass ColumnsWindow;
        protected static List<string> ExpectedColumnsList, ReportColumnsList, ExcelColumnsList;
        protected static string ReportExportFile;

        #endregion

        Establish _context = () =>
        {
            TestData = new TestDataSet
            {
                Client = "Automation Liquidity",
                Portfolio = "Liquidity Refactor Portfolio 1"
            };

            ExpectedColumnsList = new List<string>
            {
                LiquidityViewReportPage.ColumnHeaders.FUND_NAME,
                LiquidityViewReportPage.ColumnHeaders.INVESTMENT_DATE,
                LiquidityViewReportPage.ColumnHeaders.CURRENT_COST,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_1,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_PERCENT_REDEM_2,
                LiquidityViewReportPage.ColumnHeaders.PAYMENT_DATE_2
            };

            ReportExportFile = Path.Combine(Path.GetTempPath(), "Liquidity_View_Report_ALPHA_3527_05.xlsx");
            
        };

        Because _of = () =>
        {
            File.Delete(ReportExportFile);
            
            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            LiquidityViewReport = Dashboard.GoToLiquidityViewReport();

            ColumnsWindow = LiquidityViewReport.OpenColumnsOrderWidget();

            ColumnsWindow.AvailableColumns.Select(ExpectedColumnsList);
            ColumnsWindow.Apply();

            ReportColumnsList = LiquidityViewReport.GetTableHeaders();

            LiquidityViewReport.Export(ReportExportFile);
            ExcelColumnsList = Workbook.GetRow(ReportExportFile, rowNumber: 3);
        };

        It _1_List_of_columns_in_the_Excel_export_file_should_equal_to_the_list_of_columns_displayed_in_the_report = () => ExcelColumnsList.ShouldEqualExtended(ReportColumnsList);

        It _2_List_of_columns_in_the_Excel_export_file_should_be_correct = () => ExcelColumnsList.ShouldEqualExtended(ExpectedColumnsList);
    }
}