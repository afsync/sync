﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Loader;
using IFS.BusinessLayer.GSM.Immutable.Repository;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.LoaderTest
{
    [TestFixture]
    public class ImmutableGsmContactPersonLoaderTests
    {
        private const string KEY = ImmutableGsmContactPersonLoader.CACHE_KEY;

        [TearDown]
        public void ClearCache()
        {
            GlobalRuntimeCache.Remove(KEY);
        }
        [Test]
        public void TestGetCacheKey()
        {
            var loader = new ImmutableGsmContactPersonLoader(null);
            Assert.AreEqual(KEY, loader.GetCacheKey(null));
        }
        [Test]
        public void TestGetByName()
        {
            var loader = new ImmutableGsmContactPersonLoader(null);
            Assert.Throws<NotImplementedException>(() => loader.GetByName("", -1));
        }
        [Test]
        public void TestSelectAll_GettingFromCache()
        {
            var contactPersons = new List<ImmutableGsmContactPerson> { GetTestContact(1) };
            var existingCachebleList = new CacheableList<ImmutableGsmContactPerson>(contactPersons) { CacheKey = KEY };
            GlobalRuntimeCache.Insert(existingCachebleList);

            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null,null,null);
            repositoryMock.Setup(r => r.GetAllGsmContactPersons()).Verifiable();
            var loader = new ImmutableGsmContactPersonLoader(repositoryMock.Object);

            repositoryMock.Verify(r => r.GetAllGsmContactPersons(), Times.Never());
            Assert.AreSame(existingCachebleList, loader.SelectAll());
        }

        [Test]
        public void TestSelectAll_PuttingInCache()
        {
            var immutableContacts = new List<ImmutableGsmContactPerson> { GetTestContact(1) };
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null, null, null);
            repositoryMock.Setup(r => r.GetAllGsmContactPersons()).Returns(immutableContacts.AsReadOnly);
            var loader = new ImmutableGsmContactPersonLoader(repositoryMock.Object);

            Assert.IsNull(GlobalRuntimeCache.Get(KEY));
            var result = loader.SelectAll();
            Assert.IsNotNull(GlobalRuntimeCache.Get(KEY));
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<CacheableList<ImmutableGsmContactPerson>>(result);
            Assert.AreEqual(immutableContacts, result);
        }
        
        [Test]
        public void TestGetById()
        {
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null, null, null);
            repositoryMock.Setup(r => r.GetAllGsmContactPersons()).Returns(new List<ImmutableGsmContactPerson>
            {
                GetTestContact(1),
                GetTestContact(2),
            }.AsReadOnly);

            var loader = new ImmutableGsmContactPersonLoader(repositoryMock.Object);
            Assert.IsNull(loader.GetById(100));
            Assert.AreEqual(2, loader.GetById(2).Id);
        }

        [Test]
        public void TestGetById_NegativeId()
        {
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null, null, null);
            repositoryMock.Setup(r => r.GetAllGsmContactPersons()).Returns(new List<ImmutableGsmContactPerson>
            {
                GetTestContact(1),
                GetTestContact(2),
            }.AsReadOnly);
            var loader = new ImmutableGsmContactPersonLoader(repositoryMock.Object);
            var result = loader.GetById(-1);

            Assert.IsNull(result);
        }

        private ImmutableGsmContactPerson GetTestContact(int id)
        {
            return new ImmutableGsmContactPerson(id, null, null, null, null, null, null, null, null, null);
        }
    }
}
