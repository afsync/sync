﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.BusinessLayer.GSM.Immutable.Repository;
using IFS.BusinessLayer.GSM.Immutable.Store;
using IFS.BusinessLayer.Repository;
using IFS.DataAccess.Entity;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement.ImmutableGsmContactPersons
{
    [TestFixture]
    public class ImmutableGsmContactPersonStoreTests
    {
        private ImmutableGsmContactPersonStore GetStore(
            ImmutableGsmContactPersonRepository contactPersonRepository = null,
            ILoadable<ImmutableGsmContactPerson> gsmContactPersonLoader = null,
            GsmFundOfficeContactBlRepository gsmFundOfficeContactRepository = null,
            ImmutableGsmContactPersonRelatedDataProcessor gsmContactPersonRelatedDataProcessor = null,
            ContactPersonHistoryDataProvider contactPersonHistoryDataProvider = null)
        {
            return new ImmutableGsmContactPersonStore(contactPersonRepository, gsmContactPersonLoader, gsmContactPersonRelatedDataProcessor, 
                                                      contactPersonHistoryDataProvider);
        }

        [TearDown]
        public void TearDown()
        {
            CSession.OrganizationID = 1;
        }

        [Test]
        public void TestValidateContactEmailMustBeUnique_Unique()
        {
            var contact = new ImmutableGsmContactPerson(1, null, null, null, null, null, "email@ya.ru", null, null, null);
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        contact,
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, "other_email@ya.ru", null, null, null)
                    });
            var store = GetStore(gsmContactPersonLoader: loaderMock.Object);

            Assert.DoesNotThrow(() => new ImmutableGsmContactPersonHelper().ValidateContactEmailMustBeUnique(contact, store));
        }
        [Test]
        public void TestValidateContactEmailMustBeUnique_SameEmailExists()
        {
            var contact = new ImmutableGsmContactPerson(1, null, null, null, null, null, "email@ya.ru", null, null, null);
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        contact,
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, "email@ya.ru", null, null, null)
                    });
            var store = GetStore(gsmContactPersonLoader: loaderMock.Object);

            var exception = Assert.Throws<ValidationException>(() => new ImmutableGsmContactPersonHelper().ValidateContactEmailMustBeUnique(contact, store));
            Assert.AreEqual(ImmutableGsmContactPersonStore.PERSON_WITH_EMAIL_ALREADY_EXISTS, exception.Message);
        }
        [Test]
        public void TestValidateContactEmailMustBeUnique_SameEmailExistsCaseSensitive()
        {
            var contact = new ImmutableGsmContactPerson(1, null, null, null, null, null, "email@ya.ru", null, null, null);
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        contact,
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, "EMAIL@ya.ru", null, null, null)
                    });
            var store = GetStore(gsmContactPersonLoader: loaderMock.Object);

            var exception = Assert.Throws<ValidationException>(() => new ImmutableGsmContactPersonHelper().ValidateContactEmailMustBeUnique(contact, store));
            Assert.AreEqual(ImmutableGsmContactPersonStore.PERSON_WITH_EMAIL_ALREADY_EXISTS, exception.Message);
        }

        [Test]
        public void TestSelectAllForOrganization_GsmOrgId()
        {
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, CSession.GSMOrgId, new List<int>().AsReadOnly() ),
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, 12345, new List<int>().AsReadOnly())
                    });
            var companyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            companyLoaderMock.Setup(l => l.GetById(1)).Returns(new ImmutableGsmCompany(1,"Name","","","","",1,null,new List<int>().AsReadOnly()));
            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
                   companyLoaderMock.Object);

            var store = GetStore(gsmContactPersonLoader: loaderMock.Object, gsmContactPersonRelatedDataProcessor:mockGsmRelatedData.Object);
            var result = store.SelectAllForOrganization(CSession.GSMOrgId, -1);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(1, result[0].Id);
        }
        [Test]
        public void TestSelectAllForOrganization_NoContactsForOrganization()
        {
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, CSession.GSMOrgId, new List<int>().AsReadOnly() ),
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, 12345, new List<int>().AsReadOnly())
                    });
            var companyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            companyLoaderMock.Setup(l => l.GetById(1)).Returns(new ImmutableGsmCompany(1,"Name","","","","",1,null,new List<int>().AsReadOnly()));

            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
                companyLoaderMock.Object);

            var store = GetStore(gsmContactPersonLoader: loaderMock.Object, gsmContactPersonRelatedDataProcessor: mockGsmRelatedData.Object);
            var result = store.SelectAllForOrganization(1, -1);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(1, result[0].Id);
        }
        [Test]
        public void TestSelectAllForOrganization_NotGsmOrgId()
        {
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                 new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, CSession.GSMOrgId, new List<int>().AsReadOnly() ),
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, 12345, new List<int>().AsReadOnly())
                    });
            var companyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            companyLoaderMock.Setup(l => l.GetById(1)).Returns(new ImmutableGsmCompany(1, "Name", "", "", "", "", 1, null, new List<int>().AsReadOnly()));
            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
                companyLoaderMock.Object);

            var store = GetStore(gsmContactPersonLoader: loaderMock.Object, gsmContactPersonRelatedDataProcessor: mockGsmRelatedData.Object);
            var result = store.SelectAllForOrganization(12345, -1);

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }
        [Test]
        public void TestSelectAllForOrganization_NotGsmOrgId_CompanyIdSet()
        {
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(1, null, "Lastname1", null, null, null, null, 1, CSession.GSMOrgId, new List<int>().AsReadOnly()),
                        new ImmutableGsmContactPerson(2, null, "Lastname2", null, null, null, null, 2, 12345, new List<int>().AsReadOnly())
                    });
            var companyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            companyLoaderMock.Setup(l => l.GetById(1)).Returns(new ImmutableGsmCompany(1, "Name", "", "", "", "", 1, null, new List<int>().AsReadOnly()));
            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
               companyLoaderMock.Object);

            var store = GetStore(gsmContactPersonLoader: loaderMock.Object, gsmContactPersonRelatedDataProcessor: mockGsmRelatedData.Object);
            var result = store.SelectAllForOrganization(12345, 1);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(1, result[0].Id);
        }

        [Test]
        public void TestGetContactsForFundOffice()
        {
            var loaderMock = new Mock<ILoadable<ImmutableGsmContactPerson>>();
            loaderMock.Setup(l => l.SelectAll()).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, CSession.GSMOrgId, null),
                        new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, 12345, null)
                    });

            var gsmFundOfficeContact = new GsmFundOfficeContact
                                           {
                                               Id = 3,
                                               ContactPersonId = 1,
                                               OrganizationId = 2,
                                               IsReadyForDelete = true,
                                               ModifiedByUserId = 4,
                                               ApprovedByUserId = 5,
                                               ModifiedDate = new DateTime(2014, 2, 3)
                                           };
            var mockRelatedProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            mockRelatedProcessor.Setup(rp => rp.GetFundOfficeContactPersons(It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { gsmFundOfficeContact });

            var store = GetStore(null, loaderMock.Object, null, mockRelatedProcessor.Object);

            var result = store.GetContactPersonModelForFundOffice(1, new GsmFundOffice{ Id=1});
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(gsmFundOfficeContact.Id, result[0].Id);
            Assert.AreEqual(gsmFundOfficeContact.OrganizationId, result[0].OrganizationId);
            Assert.AreEqual(gsmFundOfficeContact.IsReadyForDelete, result[0].IsReadyForDelete);
            Assert.AreEqual(gsmFundOfficeContact.ModifiedByUserId, result[0].ModifiedByUserId);
            Assert.AreEqual(gsmFundOfficeContact.ModifiedDate, result[0].ModifiedDate);
            Assert.AreEqual(gsmFundOfficeContact.ApprovedByUserId, result[0].ApprovedByUserId);
            Assert.AreEqual(false, result[0].CanBeRemoved);
        }

        [Test]
        public void TestGetContactsAvailableForFund()
        {
            const int contactId1 = 1;
            const int contactId2 = 2;
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null,null,null);
            repositoryMock.Setup(l => l.GetContactsForOffice(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(
                new List<ImmutableGsmContactPerson>
                    {
                        new ImmutableGsmContactPerson(contactId1, null, null, null, null, null, null, null, CSession.GSMOrgId, null),
                        new ImmutableGsmContactPerson(contactId2, null, null, null, null, null, null, null, 12345, null)
                    }.AsReadOnly);
            var gsmFundOfficeContact = new GsmFundOfficeContact { ContactPersonId = contactId1 };
            var mockRelatedProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null,null);
            mockRelatedProcessor.Setup(rp => rp.GetFundOfficeContactPersons(It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> {gsmFundOfficeContact});

            var store = GetStore(repositoryMock.Object, null, null,mockRelatedProcessor.Object);

            var result = store.GetContactsAvailableForFund(1, 1, 1);
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(contactId2, result[0].Id);
        }

        
        [Test]
        public void TestGetAvailableContactsForOffice_CompanyOrgIdCorresponds()
        {
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null, null, null);
            repositoryMock.Setup(r => r.GetAvailableContactsForOffice(It.IsAny<int>(), It.IsAny<int>(), true, It.IsAny<int>()))
                          .Returns(new List<ImmutableGsmContactPerson> { new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null) }.AsReadOnly);
            repositoryMock.Setup(r => r.GetAvailableContactsForOffice(It.IsAny<int>(), It.IsAny<int>(), false, It.IsAny<int>()))
                          .Returns(new List<ImmutableGsmContactPerson> { new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, null, null) }.AsReadOnly);
            
            var gsmCompanyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
                    gsmCompanyLoaderMock.Object);
            mockGsmRelatedData.Setup(rd => rd.IsOwnCompany(1, 333)).Returns(true);
            var store = GetStore(repositoryMock.Object, gsmContactPersonRelatedDataProcessor:mockGsmRelatedData.Object);

            var result = store.GetAvailableContactsForOffice(1, 1, 333);
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(1, result[0].Id);
        }
        [Test]
        public void TestGetAvailableContactsForOffice_CompanyOrgIdDiffers()
        {
            var repositoryMock = new Mock<ImmutableGsmContactPersonRepository>(null, null, null);
            repositoryMock.Setup(r => r.GetAvailableContactsForOffice(It.IsAny<int>(), It.IsAny<int>(), true, It.IsAny<int>()))
                          .Returns(new List<ImmutableGsmContactPerson> { new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null) }.AsReadOnly);
            repositoryMock.Setup(r => r.GetAvailableContactsForOffice(It.IsAny<int>(), It.IsAny<int>(), false, It.IsAny<int>()))
                          .Returns(new List<ImmutableGsmContactPerson> { new ImmutableGsmContactPerson(2, null, null, null, null, null, null, null, null, null) }.AsReadOnly);
            var gsmCompanyLoaderMock = new Mock<ILoadable<ImmutableGsmCompany>>();
            var mockGsmRelatedData = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(Mock.Of<GsmFundOfficeContactBlRepository>(),
                    gsmCompanyLoaderMock.Object);
            mockGsmRelatedData.Setup(rd => rd.IsOwnCompany(1, 111)).Returns(false);
            var store = GetStore(repositoryMock.Object, gsmContactPersonRelatedDataProcessor: mockGsmRelatedData.Object);

            var result = store.GetAvailableContactsForOffice(1, 1, 111);
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(2, result[0].Id);
        }

       
        [Test]
        public void TestSave_NewContactWithoutContactOfficeIds_VerifyMainFlow()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            var sequenceProvider = new Mock<ISequenceProvider>();
            sequenceProvider.Setup(m => m.GetNextSequenceNumber()).Returns(sequenceId);
            var repository = new ImmutableGsmContactPersonRepository(new ImmutableGsmContactPersonMapper(),new AuditLogger<ImmutableGsmContactPerson>(),sequenceProvider.Object);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var objectsToSaveBsd = new List<GsmContactPersonData>();
            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.InsertOnSubmit(It.IsAny<GsmContactPersonData>())).Callback<GsmContactPersonData>(objectsToSaveBsd.Add);

            var id = store.Save(contactPerson, bsdMock.Object);

            Assert.AreEqual(sequenceId, id);
            Assert.AreEqual(1, objectsToSaveBsd.Count);
            Assert.AreEqual(contactPerson.FirstName, objectsToSaveBsd[0].ContactFirstName);
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        public void TestSave_NewContactWithoutContactOfficeIds_VerifyRelatedDataFlow()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            var sequenceProvider = new Mock<ISequenceProvider>();
            sequenceProvider.Setup(m => m.GetNextSequenceNumber()).Returns(sequenceId);
            var repository = new ImmutableGsmContactPersonRepository(new ImmutableGsmContactPersonMapper(), new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider.Object);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            store.Save(contactPerson, bsdMock.Object);

            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            linksProcessor.Verify(m => m.ProcessSave(It.IsAny<ImmutableGsmContactPerson>(), It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
        }
        
        [Test]
        public void TestSave_NewContactWithContactOfficeIds_VerifyMainFlow()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());
            
            var sequenceProvider = new Mock<ISequenceProvider>();
            sequenceProvider.Setup(m => m.GetNextSequenceNumber()).Returns(sequenceId);
            var repository = new ImmutableGsmContactPersonRepository(new ImmutableGsmContactPersonMapper(), new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider.Object);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null,null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var objectsToSaveBsd = new List<GsmContactPersonData>();
            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.InsertOnSubmit(It.IsAny<GsmContactPersonData>())).Callback<GsmContactPersonData>(objectsToSaveBsd.Add);

            var id = store.Save(contactPerson, bsdMock.Object);

            Assert.AreEqual(sequenceId, id);
            Assert.AreEqual(1, objectsToSaveBsd.Count);
            Assert.AreEqual(contactPerson.FirstName, objectsToSaveBsd[0].ContactFirstName);
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        public void TestSave_NewContactWithContactOfficeIds_VerifyRelatedDataFlow()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());

            var sequenceProvider = new Mock<ISequenceProvider>();
            sequenceProvider.Setup(m => m.GetNextSequenceNumber()).Returns(sequenceId);
            var repository = new ImmutableGsmContactPersonRepository(new ImmutableGsmContactPersonMapper(), new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider.Object);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null,null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            store.Save(contactPerson, bsdMock.Object);

            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            linksProcessor.Verify(m => m.ProcessSave(It.IsAny<ImmutableGsmContactPerson>(), It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
        }
        
        [Test]
        public void TestSave_UpdateContactWithoutContactOfficeIds_VerifyMainFlow()
        {
            var dbContactPerson = new GsmContactPersonData { Id = 2, ContactEmail = "mail@i.com" };
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(It.IsAny<int>())).Returns(dbContactPerson);

            var id = store.Save(contactPerson, bsdMock.Object);

            Assert.AreEqual(contactPerson.Id, id);
            Assert.AreEqual(contactPerson.FirstName, dbContactPerson.ContactFirstName); // check dbContact is updated
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        public void TestSave_UpdateContactWithoutContactOfficeIds_VerifyRelatedDataFlow()
        {
            var dbContactPerson = new GsmContactPersonData { Id = 2, ContactEmail = "mail@i.com" };
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(It.IsAny<int>())).Returns(dbContactPerson);

            store.Save(contactPerson, bsdMock.Object);

            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            linksProcessor.Verify(m => m.ProcessSave(It.IsAny<ImmutableGsmContactPerson>(), It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
        }
        
        [Test]
        public void TestSave_UpdateContactWithContactOfficeIds_VerifyMainFlow()
        {
            var dbContactPerson = new GsmContactPersonData { Id = 2, ContactEmail = "mail@i.com" };
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());

            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(It.IsAny<int>())).Returns(dbContactPerson);

            var id = store.Save(contactPerson, bsdMock.Object);

            Assert.AreEqual(contactPerson.Id, id);
            Assert.AreEqual(contactPerson.FirstName, dbContactPerson.ContactFirstName); // check dbContact is updated
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        public void TestSave_UpdateContactWithContactOfficeIds_VerifyRelativeDataFlow()
        {
            var dbContactPerson = new GsmContactPersonData { Id = 2, ContactEmail = "mail@i.com" };
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());

            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null, null);
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(It.IsAny<int>())).Returns(dbContactPerson);

            store.Save(contactPerson, bsdMock.Object);

            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            linksProcessor.Verify(m => m.ProcessSave(It.IsAny<ImmutableGsmContactPerson>(), It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
        }

        [Test]
        [Ignore]
        public void TestDelete_ContactWithoutLinks_VerifyMainFlow()
        {
            const int contactPersonId = 1;
            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null);
            var historyDataProvider = new Mock<ContactPersonHistoryDataProvider>();
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object,
                                 contactPersonHistoryDataProvider: historyDataProvider.Object);

            var objectsToDeleteBsd = new List<GsmContactPersonData>();
            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(contactPersonId)).Returns(new GsmContactPersonData { Id = contactPersonId, ContactFirstName = "AA" });
            bsdMock.Setup(m => m.DeleteOnSubmit(It.IsAny<GsmContactPersonData>())).Callback<GsmContactPersonData>(objectsToDeleteBsd.Add);

            store.Delete(contactPersonId, bsdMock.Object);

            Assert.AreEqual(1, objectsToDeleteBsd.Count);
            Assert.AreEqual(contactPersonId, objectsToDeleteBsd[0].Id);
            Assert.AreEqual("AA", objectsToDeleteBsd[0].ContactFirstName);
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        [Ignore]
        public void TestDelete_ContactWithoutLinks_VerifyRelatedDataFlow()
        {
            const int contactPersonId = 1;
            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null);
            var historyDataProvider = new Mock<ContactPersonHistoryDataProvider>();
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object,
                                 contactPersonHistoryDataProvider: historyDataProvider.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(contactPersonId)).Returns(new GsmContactPersonData { Id = contactPersonId, ContactFirstName = "AA" });
            
            store.Delete(contactPersonId, bsdMock.Object);
            
            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Never());
            linksProcessor.Verify(m => m.ProcessDelete(It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
            historyDataProvider.Verify(m => m.DeleteHistory(contactPersonId), Times.Once());
        }

        [Test]
        [Ignore]
        public void TestDelete_ContactWithLinks_VerifyMainFlow()
        {
            const int contactPersonId = 1;
            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null);
            var historyDataProvider = new Mock<ContactPersonHistoryDataProvider>();
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object,
                                 contactPersonHistoryDataProvider: historyDataProvider.Object);

            var objectsToDeleteBsd = new List<GsmContactPersonData>();
            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(contactPersonId)).Returns(new GsmContactPersonData { Id = contactPersonId, ContactFirstName = "AA" });
            bsdMock.Setup(m => m.DeleteOnSubmit(It.IsAny<GsmContactPersonData>())).Callback<GsmContactPersonData>(objectsToDeleteBsd.Add);

            store.Delete(contactPersonId, bsdMock.Object);

            Assert.AreEqual(1, objectsToDeleteBsd.Count);
            Assert.AreEqual(contactPersonId, objectsToDeleteBsd[0].Id);
            Assert.AreEqual("AA", objectsToDeleteBsd[0].ContactFirstName);
            bsdMock.Verify(m => m.AddObjectToFlush(loaderMock, null), Times.Once());
        }
        [Test]
        [Ignore]
        public void TestDelete_ContactWithLinks_VerifyRelatedDataFlow()
        {
            const int contactPersonId = 1;
            var sequenceProvider = Mock.Of<ISequenceProvider>();
            var mapper = new ImmutableGsmContactPersonMapper();
            var repository = new ImmutableGsmContactPersonRepository(mapper, new AuditLogger<ImmutableGsmContactPerson>(), sequenceProvider);
            var loaderMock = Mock.Of<ILoadable<ImmutableGsmContactPerson>>();
            var linksProcessor = new Mock<ImmutableGsmContactPersonRelatedDataProcessor>(null);
            var historyDataProvider = new Mock<ContactPersonHistoryDataProvider>();
            var store = GetStore(repository, loaderMock, gsmContactPersonRelatedDataProcessor: linksProcessor.Object,
                                 contactPersonHistoryDataProvider: historyDataProvider.Object);

            var bsdMock = new Mock<IBulkSaveData>();
            bsdMock.Setup(m => m.SelectRecord<GsmContactPersonData>(contactPersonId)).Returns(new GsmContactPersonData { Id = contactPersonId, ContactFirstName = "AA" });
            
            store.Delete(contactPersonId, bsdMock.Object);

            bsdMock.Verify(m => m.AddDeleteObjToContext(It.IsAny<ObjectContainer>()), Times.Once());
            bsdMock.Verify(m => m.AddSaveObjToContext(It.IsAny<ObjectContainer>()), Times.Never());
            linksProcessor.Verify(m => m.ProcessDelete(It.IsAny<int>(), It.IsAny<ObjectContainer>()), Times.Once());
            historyDataProvider.Verify(m => m.DeleteHistory(contactPersonId), Times.Once());
        }
    }
}
