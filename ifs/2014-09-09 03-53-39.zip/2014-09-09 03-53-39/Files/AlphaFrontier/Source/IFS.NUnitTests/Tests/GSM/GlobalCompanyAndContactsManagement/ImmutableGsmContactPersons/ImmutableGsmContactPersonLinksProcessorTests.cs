﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Repository;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Entity;
using IFS.NUnitTests.MockResults;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement.ImmutableGsmContactPersons
{
    [TestFixture]
    public class ImmutableGsmContactPersonLinksProcessorTests
    {
        private ImmutableGsmContactPersonRelatedDataProcessor GetLinksProcessor(GsmFundOfficeContactBlRepository gsmFundOfficeContactBLRepository)
        {
            return new ImmutableGsmContactPersonRelatedDataProcessor(gsmFundOfficeContactBLRepository, ImmutableLoaderFactory.GetImmutableGsmCompanyLoader());
        }

        [Test]
        public void TestIsOwnCompanyReturnsForGsmOrgId()
        {
            var linksProcessor = GetLinksProcessor(null);
            Assert.That(linksProcessor.IsOwnCompany(1, CSession.GSMOrgId),Is.True);
        }


        [Test]
        public void TestProcessSave_NewContactWithoutContactOfficeIds()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            var linksProcessor = GetLinksProcessor(null);
            var oc = new ObjectContainer();
            linksProcessor.ProcessSave(contactPerson, sequenceId, oc);

            Assert.AreEqual(0, oc.ObjectsToSave.Count);
            Assert.AreEqual(0, oc.ObjectsToDelete.Count);
        }
        [Test]
        public void TestProcessSave_NewContactWithContactOfficeIds()
        {
            const int sequenceId = 10;
            var contactPerson = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());

            var linksProcessor = GetLinksProcessor(null);
            var oc = new ObjectContainer();
            linksProcessor.ProcessSave(contactPerson, sequenceId, oc);

            var objectsToSaveOc = oc.ObjectsToSave.Cast<ContactPersonOffice>().ToList();
            Assert.AreEqual(2, objectsToSaveOc.Count);
            Assert.AreEqual(sequenceId, objectsToSaveOc[0].ContactPersonId);
            Assert.AreEqual(20, objectsToSaveOc[0].CompanyOfficeId);
            Assert.AreEqual(sequenceId, objectsToSaveOc[1].ContactPersonId);
            Assert.AreEqual(30, objectsToSaveOc[1].CompanyOfficeId);

            Assert.AreEqual(0, oc.ObjectsToDelete.Count);
        }
        [Test]
        public void TestProcessSave_UpdateContactWithoutContactOfficeIds()
        {
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int>().AsReadOnly());

            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetOfficesForContact", new List<IContactPersonOfficeData>());

            var linksProcessor = GetLinksProcessor(null);
            var oc = new ObjectContainer();
            linksProcessor.ProcessSave(contactPerson, contactPerson.Id, oc);

            Assert.AreEqual(0, oc.ObjectsToSave.Count);
            Assert.AreEqual(0, oc.ObjectsToDelete.Count);
        }
        [Test]
        public void TestProcessSave_UpdateContactWithContactOfficeIds()
        {
            var contactPerson = new ImmutableGsmContactPerson(2, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 20, 30 }.AsReadOnly());

            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetOfficesForContact",
                new List<IContactPersonOfficeData>
                    {
                        new ContactPersonOfficeData {CompanyOfficeId = 20, ContactPersonId = 2, Id = 321}, 
                        new ContactPersonOfficeData {CompanyOfficeId = 40, ContactPersonId = 2, Id = 432}
                    });

            var gsmFundOfficeContactRepository = new Mock<GsmFundOfficeContactBlRepository>();
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(2, 20, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 123 } });
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(2, 40, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 234 } });

            var linksProcessor = GetLinksProcessor(gsmFundOfficeContactRepository.Object);
            var oc = new ObjectContainer();
            linksProcessor.ProcessSave(contactPerson, contactPerson.Id, oc);

            Assert.AreEqual(2, oc.ObjectsToDelete.Count);
            Assert.AreEqual(234, oc.ObjectsToDelete.Where(o => o is GsmFundOfficeContact).Cast<GsmFundOfficeContact>().First().Id);
            Assert.AreEqual(432, oc.ObjectsToDelete.Where(o => o is ContactPersonOffice).Cast<ContactPersonOffice>().First().Id);

            Assert.AreEqual(1, oc.ObjectsToSave.Count);
            Assert.AreEqual(30, oc.ObjectsToSave.Where(o => o is ContactPersonOffice).Cast<ContactPersonOffice>().First().CompanyOfficeId);
        }

        [Test]
        public void TestProcessDelete_ContactWithoutLinks()
        {
            const int idToDelete = 1;

            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetOfficesForContact", new List<IContactPersonOfficeData>());
            var gsmFundOfficeContactRepository = new Mock<GsmFundOfficeContactBlRepository>();
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonId(It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact>());
            var linksProcessor = GetLinksProcessor(gsmFundOfficeContactRepository.Object);
            var oc = new ObjectContainer();
            linksProcessor.ProcessDelete(idToDelete, oc);

            Assert.AreEqual(0, oc.ObjectsToSave.Count);
            Assert.AreEqual(0, oc.ObjectsToDelete.Count);
        }

        [Test]
        public void TestProcessDelete_ContactWithLinks()
        {
            const int contactPersonId = 1;
            const int officeId1 = 20;
            const int officeId2 = 40;

            var gsmFundOfficeContactRepository = new Mock<GsmFundOfficeContactBlRepository>();
            // GetByContactPersonId
            gsmFundOfficeContactRepository.Setup(r => r.GetByContactPersonId(contactPersonId))
                .Returns(new List<GsmFundOfficeContact>
                             {
                                 new GsmFundOfficeContact {Id = 1, ContactPersonId = contactPersonId},
                                 new GsmFundOfficeContact {Id = 2, ContactPersonId = contactPersonId},
                                 new GsmFundOfficeContact {Id = 3, ContactPersonId = contactPersonId}
                             });
            // GetByContactPersonAndOffice
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(contactPersonId, officeId1, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 2, ContactPersonId = contactPersonId } });
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(contactPersonId, officeId2, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 3, ContactPersonId = contactPersonId } });

            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetOfficesForContact",
                new List<IContactPersonOfficeData>
                    {
                        new ContactPersonOfficeData {CompanyOfficeId = officeId1, ContactPersonId = contactPersonId, Id = 321}, 
                        new ContactPersonOfficeData {CompanyOfficeId = officeId2, ContactPersonId = contactPersonId, Id = 432}
                    });

            var linksProcessor = GetLinksProcessor(gsmFundOfficeContactRepository.Object);
            var oc = new ObjectContainer();
            linksProcessor.ProcessDelete(contactPersonId, oc);

            Assert.AreEqual(0, oc.ObjectsToSave.Count);
            Assert.AreEqual(5, oc.ObjectsToDelete.Count);
            Assert.AreEqual(2, oc.ObjectsToDelete.Count(o => o is ContactPersonOffice));
            Assert.AreEqual(3, oc.ObjectsToDelete.Count(o => o is GsmFundOfficeContact));
        }

        [Test]
        public void TestRemoveFromOffice()
        {
            const int contactPersonId = 1;
            const int officeId1 = 20;
            const int officeId2 = 40;

            var gsmFundOfficeContactRepository = new Mock<GsmFundOfficeContactBlRepository>();
           gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(contactPersonId, officeId1, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 2, ContactPersonId = contactPersonId } });
            gsmFundOfficeContactRepository.Setup(m => m.GetByContactPersonAndOffice(contactPersonId, officeId2, It.IsAny<int>()))
                .Returns(new List<GsmFundOfficeContact> { new GsmFundOfficeContact { Id = 3, ContactPersonId = contactPersonId } });

            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetOfficesForContact",
                new List<IContactPersonOfficeData>
                    {
                        new ContactPersonOfficeData {CompanyOfficeId = officeId1, ContactPersonId = contactPersonId, Id = 321}, 
                        new ContactPersonOfficeData {CompanyOfficeId = officeId2, ContactPersonId = contactPersonId, Id = 432}
                    });

            var linksProcessor = GetLinksProcessor(gsmFundOfficeContactRepository.Object);
            var oc = new ObjectContainer();
            linksProcessor.RemoveFromOffice(contactPersonId,officeId1, oc);

            Assert.AreEqual(0, oc.ObjectsToSave.Count);
            Assert.AreEqual(2, oc.ObjectsToDelete.Count);
            Assert.AreEqual(1, oc.ObjectsToDelete.Count(o => o is ContactPersonOffice));
            Assert.AreEqual(1, oc.ObjectsToDelete.Count(o => o is GsmFundOfficeContact));
        }
    }
}
