﻿using System.Collections.Generic;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.BusinessLayer.GSM.Immutable.Repository;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Entity;
using IFS.NUnitTests.MockResults;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement.ImmutableGsmContactPersons
{
    [TestFixture]
    public class ImmutableGsmContactPersonRepositoryTests
    {
        [Test]
        public void TestGetAllGsmContactPersons()
        {
            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetAllOffices", new List<IContactPersonOfficeData>());
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.SelectAll", GetContactPersonTestData());
            var repository = GetRepository();
            var result = repository.GetAllGsmContactPersons();

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }

        [Test]
        public void TestGetContactsForOffice_ByOfficeIdAndOrganizationId()
        {
            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetAllOffices", new List<IContactPersonOfficeData>());
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.GetContactsForOfficeByOrganization", GetContactPersonTestData());
            var repository = GetRepository();
            var result = repository.GetContactsForOffice(1,1,1);

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }

        [Test]
        public void TestGetContactsForOffice_ByOfficeId()
        {
            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetAllOffices", new List<IContactPersonOfficeData>());
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.GetContactsForOffice", GetContactPersonTestData());
            var repository = GetRepository();
            var result = repository.GetContactsForOffice(1);

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }

        [Test]
        public void TestGetAvailableContactsForOffice()
        {
            MockResultSingleton.SetResult("ContactPersonOfficeDbRepository.GetAllOffices", new List<IContactPersonOfficeData>());
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.GetAvailableContactsForOffice", GetContactPersonTestData());
            var repository = GetRepository();
            var result = repository.GetAvailableContactsForOffice(1, 1, false, 1);

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }

        [Test]
        public void TestHasRelatedFunds()
        {
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.HasRelatedFunds",true);
            var repository = GetRepository();
            var result = repository.HasRelatedFunds(1);

            Assert.AreEqual(true, result);
        }

        [Test]
        public void TestCanBeRemovedFromOffice()
        {
            MockResultSingleton.SetResult("GsmContactPersonDbRepository.CanBeRemovedFromOffice", true);
            var repository = GetRepository();
            var result = repository.CanBeRemovedFromOffice(1, 1);

            Assert.AreEqual(true, result);
        }

        private ImmutableGsmContactPersonRepository GetRepository()
        {
            return new ImmutableGsmContactPersonRepository(new ImmutableGsmContactPersonMapper(), null, null);
        }

        private List<IGsmContactPersonData> GetContactPersonTestData()
        {
            return new List<IGsmContactPersonData>
                {
                    new GsmContactPersonData {Id = 1},
                    new GsmContactPersonData {Id = 2}
                };
        }
    }
}
