﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.NUnitTests.BusinessLayer.shared;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement
{
    [TestFixture]
    public class GsmContactPersonHistoryManagerTest
    {
        [Test]
        public void AddToHistoryShouldIgnoreNotSetCompanyIfHistoryIsEmpty()
        {
            var contactPerson = new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null);
            var historyManager = new GsmContactPersonHistoryManager(
                    contactPerson, 
                    new MockContactPersonHistoryDataProvider(new List<GsmContactPersonHistory>())
                    );
            historyManager.Add(new GsmContactPersonHistory
                                   {
                                       ChangeDate = DateTime.Now,
                                       ContactPersonId = 1,
                                       Comments = ""
                                   });
            Assert.AreEqual(0, historyManager.History.Count);
        }
        [Test]
        public void AddToHistoryShouldIgnoreCompanyIfLastRecordContainsSameCompany()
        {
            var contactPerson = new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null);
            var history = new List<GsmContactPersonHistory>
                           {
                               new GsmContactPersonHistory
                                   {
                                       ChangeDate = DateTime.Now.AddDays(-1),
                                       ContactPersonId = 1,
                                       GsmCompanyId = 1
                                   }
                           };
            var historyManager = new GsmContactPersonHistoryManager(
                    contactPerson,
                    new MockContactPersonHistoryDataProvider(history)
                    );
            historyManager.Add(new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = 1,
                GsmCompanyId = 1
            });
            Assert.AreEqual(1, historyManager.History.Count);
        }
        [Test]
        public void AddToHistoryShouldAddRecordToHistoryIfPreviosRecordContainsDifferentCompany()
        {
            var contactPerson = new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null);
            var history = new List<GsmContactPersonHistory>
                           {
                               new GsmContactPersonHistory
                                   {
                                       ChangeDate = DateTime.Now.AddDays(-1),
                                       ContactPersonId = 1,
                                       GsmCompanyId = 1
                                   }
                           };
            var historyManager = new GsmContactPersonHistoryManager(
                    contactPerson,
                    new MockContactPersonHistoryDataProvider(history)
                    );
            historyManager.Add(new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = 1,
                GsmCompanyId = 2,
                Comments = ""
            });
            Assert.AreEqual(2, historyManager.History.Count);
        }
        [Test]
        public void AddToHistoryShouldAddNotSelectedCompanyRecordToHistoryIfPreviosRecordHasCompany()
        {
            var contactPerson = new ImmutableGsmContactPerson(1, null, null, null, null, null, null, null, null, null);
            var history = new List<GsmContactPersonHistory>
                           {
                               new GsmContactPersonHistory
                                   {
                                       ChangeDate = DateTime.Now.AddDays(-1),
                                       ContactPersonId = 1,
                                       GsmCompanyId = 1
                                   }
                           };
            var historyManager = new GsmContactPersonHistoryManager(
                    contactPerson,
                    new MockContactPersonHistoryDataProvider(history)
                    );
            historyManager.Add(new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = 1
            });
            Assert.AreEqual(2, historyManager.History.Count);
            Assert.AreEqual(GsmContactPersonHistoryManager.NOT_SELECTED_COMPANY, historyManager.History[0].CompanyName);
        }
        [Test]
        public void LastAddedToHistoryCompanyShouldBeFirst()
        {
            var contactPerson = new ImmutableGsmContactPerson(1,null,null,null,null,null,null,null,null,null);
            var history = new List<GsmContactPersonHistory>
                           {
                               new GsmContactPersonHistory
                                   {
                                       ChangeDate = DateTime.Now.AddDays(-1),
                                       ContactPersonId = 1,
                                       GsmCompanyId = 1
                                   }
                           };
            var historyManager = new GsmContactPersonHistoryManager(
                    contactPerson,
                    new MockContactPersonHistoryDataProvider(history)
                    );
            historyManager.Add(new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = 1,
                GsmCompanyId = 2
            });
            Assert.AreEqual(2, historyManager.History.Count);
            Assert.AreEqual(2, historyManager.History[0].GsmCompanyId);

        }
    }
}
