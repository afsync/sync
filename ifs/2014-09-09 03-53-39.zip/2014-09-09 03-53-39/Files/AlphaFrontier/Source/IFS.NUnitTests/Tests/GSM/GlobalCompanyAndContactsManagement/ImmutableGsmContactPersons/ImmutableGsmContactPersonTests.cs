﻿using IFS.BusinessLayer.GSM.Immutable;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement.ImmutableGsmContactPersons
{
    [TestFixture]
    public class ImmutableGsmContactPersonTests
    {
        [Test]
        public void TestGetFullName()
        {
            var contact = new ImmutableGsmContactPerson(0, "First name", "Last name", null, null, null, null, null, null, null);
            Assert.AreEqual("First name Last name", contact.GetFullName());
        }

        [TestCase(0, 1, 1, true, TestName = "New contact.")]
        [TestCase(2, 1, 1, true, TestName = "Existing contact, organization id equals.")]
        [TestCase(2, 1, 2, false, TestName = "Existing contact, organization id differs.")]
        public void TestIsEditableByOrganization(int id, int? contactOrganizationId, int orgId, bool expected)
        {
            var contact = new ImmutableGsmContactPerson(id, null, null, null, null, null, null, null, contactOrganizationId, null);
            Assert.AreEqual(expected, contact.IsEditableByOrganization(orgId));
        }

        [Test]
        public void TestGetAuditXml()
        {
            const string expectedXml =
                "<Audit>" +
                "<Id>1</Id>" +
                "<FirstName>First name</FirstName>" +
                "<LastName>Last name</LastName>" +
                "<Role>Role1</Role>" +
                "<Phone>2223</Phone>" +
                "<Fax>44445</Fax>" +
                "<Email>mail@mail.com</Email>" +
                "<CompanyId>32</CompanyId>" +
                "<OrganizationId>90</OrganizationId>" +
                "</Audit>";
            var contact = new ImmutableGsmContactPerson(1, "First name", "Last name", "Role1", "2223", "44445", "mail@mail.com", 32, 90, null);
            var resultXml = contact.GetAuditXml();
            Assert.AreEqual(expectedXml, resultXml);
        }
    }
}
