﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.DataAccess.Entity;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.GSM.GlobalCompanyAndContactsManagement.ImmutableGsmContactPersons
{
    [TestFixture]
    public class ImmutableGsmContactPersonMapperTests
    {
        [SetUp]
        public void Setup()
        {
            CSession.OrganizationID = 1;
        }

        [Test]
        public void TestGetImmutableFromEntity()
        {
            var data = new GsmContactPersonData
                           {
                               Id = 3,
                               ContactFirstName = "FirstName1",
                               ContactLastName = "LastName1",
                               ContactEmail = "mail@mail.ru",
                               ContactPhone = "32132",
                               ContactFax = "542345",
                               ContactRole = "Role 1",
                               OrganizationId = 33,
                               ContactCompanyId = 5
                           };
            var immutable = new ImmutableGsmContactPersonMapper().GetImmutableFromEntity(data);
            Assert.AreEqual(data.Id, immutable.Id);
            Assert.AreEqual(data.ContactFirstName, immutable.FirstName);
            Assert.AreEqual(data.ContactLastName, immutable.LastName);
            Assert.AreEqual(data.ContactEmail, immutable.Email);
            Assert.AreEqual(data.ContactPhone, immutable.Phone);
            Assert.AreEqual(data.ContactFax, immutable.Fax);
            Assert.AreEqual(data.ContactRole, immutable.Role);
            Assert.AreEqual(data.OrganizationId, immutable.OrganizationId);
            Assert.AreEqual(data.ContactCompanyId, immutable.CompanyId);
            Assert.AreEqual(data.OrganizationId, immutable.OrganizationId);
            Assert.AreEqual(null, immutable.ContactOfficeIds);
        }
        [Test]
        public void TestGetImmutableFromEntityWithOfficeIds()
        {
            var data = new GsmContactPersonData
            {
                Id = 3,
                ContactFirstName = "FirstName1",
                ContactLastName = "LastName1",
                ContactEmail = "mail@mail.ru",
                ContactPhone = "32132",
                ContactFax = "542345",
                ContactRole = "Role 1",
                OrganizationId = 33,
                ContactCompanyId = 5
            };
            var officeIds = new List<int> {3, 2}.AsReadOnly();
            var immutable = new ImmutableGsmContactPersonMapper().GetImmutableFromEntity(data, officeIds);
            Assert.AreEqual(data.Id, immutable.Id);
            Assert.AreEqual(data.ContactFirstName, immutable.FirstName);
            Assert.AreEqual(data.ContactLastName, immutable.LastName);
            Assert.AreEqual(data.ContactEmail, immutable.Email);
            Assert.AreEqual(data.ContactPhone, immutable.Phone);
            Assert.AreEqual(data.ContactFax, immutable.Fax);
            Assert.AreEqual(data.ContactRole, immutable.Role);
            Assert.AreEqual(data.OrganizationId, immutable.OrganizationId);
            Assert.AreEqual(data.ContactCompanyId, immutable.CompanyId);
            Assert.AreEqual(data.OrganizationId, immutable.OrganizationId);
            Assert.AreEqual(officeIds, immutable.ContactOfficeIds);
        }

        [Test]
        public void TestGetEntityData()
        {
            var immutable = new ImmutableGsmContactPerson(2,"FirstName1", "LastName2","Role3","4523", "112", "mail@i.com", 4,5,null);
            var data = new ImmutableGsmContactPersonMapper().GetEntityData(immutable);
            Assert.AreEqual(immutable.Id, data.Id);
            Assert.AreEqual(immutable.FirstName, data.ContactFirstName);
            Assert.AreEqual(immutable.LastName, data.ContactLastName);
            Assert.AreEqual(immutable.Email, data.ContactEmail);
            Assert.AreEqual(immutable.Phone, data.ContactPhone);
            Assert.AreEqual(immutable.Fax, data.ContactFax);
            Assert.AreEqual(immutable.Role, data.ContactRole);
            Assert.AreEqual(immutable.OrganizationId, data.OrganizationId);
            Assert.AreEqual(immutable.CompanyId, data.ContactCompanyId);
            Assert.AreEqual(immutable.OrganizationId, data.OrganizationId);
        }
        [Test]
        public void TestCreateNewWithId()
        {
            var immutable = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 3, 2 }.AsReadOnly());
            var immutableNew = new ImmutableGsmContactPersonMapper().CreateNewWithId(immutable, 123);
            Assert.AreEqual(123, immutableNew.Id);
            Assert.AreEqual(immutable.FirstName, immutableNew.FirstName);
            Assert.AreEqual(immutable.LastName, immutableNew.LastName);
            Assert.AreEqual(immutable.Email, immutableNew.Email);
            Assert.AreEqual(immutable.Phone, immutableNew.Phone);
            Assert.AreEqual(immutable.Fax, immutableNew.Fax);
            Assert.AreEqual(immutable.Role, immutableNew.Role);
            Assert.AreEqual(immutable.OrganizationId, immutableNew.OrganizationId);
            Assert.AreEqual(immutable.CompanyId, immutableNew.CompanyId);
            Assert.AreEqual(immutable.OrganizationId, immutableNew.OrganizationId);
            Assert.AreEqual(immutable.ContactOfficeIds, immutableNew.ContactOfficeIds);
        }

        [Test]
        public void TestUpdateEntityData()
        {
            var immutable = new ImmutableGsmContactPerson(0, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 5, new List<int> { 3, 2 }.AsReadOnly());
            var data = new GsmContactPersonData {Id = 44};
            new ImmutableGsmContactPersonMapper().UpdateEntityData(data, immutable);

            Assert.AreEqual(44, data.Id);
            Assert.AreEqual(immutable.FirstName, data.ContactFirstName);
            Assert.AreEqual(immutable.LastName, data.ContactLastName);
            Assert.AreEqual(immutable.Email, data.ContactEmail);
            Assert.AreEqual(immutable.Phone, data.ContactPhone);
            Assert.AreEqual(immutable.Fax, data.ContactFax);
            Assert.AreEqual(immutable.Role, data.ContactRole);
            Assert.AreEqual(immutable.OrganizationId, data.OrganizationId);
            Assert.AreEqual(immutable.CompanyId, data.ContactCompanyId);
            Assert.AreEqual(immutable.OrganizationId, data.OrganizationId);
        }
        
        [Test]
        public void TestGetView()
        {
            var immutable = new ImmutableGsmContactPerson(33, "FirstName1", "LastName2", "Role3", "4523", "112", "mail@i.com", 4, 1, new List<int> { 3, 2 }.AsReadOnly());

            var view = new ImmutableGsmContactPersonMapper().GetView(immutable, true, "Company", new List<string> { "office1", "office1" });
            Assert.AreEqual(immutable.Id, view.Id);
            Assert.AreEqual("FirstName1 LastName2", view.FullName);
            Assert.AreEqual(immutable.Role, view.Role);
            Assert.AreEqual(immutable.Phone, view.Phone);
            Assert.AreEqual(immutable.Fax, view.Fax);
            Assert.AreEqual(true, view.IsEditable);
            Assert.AreEqual(true, view.CanBeRemovedFromOffice);
            Assert.AreEqual("Company", view.CompanyName);
            Assert.AreEqual(2, view.OfficeNames.Split(new [] { ',' }, StringSplitOptions.RemoveEmptyEntries).Length);
        }

    }
}
