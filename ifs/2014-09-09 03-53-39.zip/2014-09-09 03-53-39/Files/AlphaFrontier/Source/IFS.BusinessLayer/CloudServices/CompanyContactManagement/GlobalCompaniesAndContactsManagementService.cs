﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.Interfaces.CloudContracts.CompanyContactManagement;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Common;
using IFS.Interfaces.CloudContracts.DataContracts.CompanyContactManagement;

namespace IFS.BusinessLayer.CloudServices.CompanyContactManagement
{
    public class GlobalCompaniesAndContactsManagementService : CloudServiceBase, IGlobalCompaniesAndContactsManagementService
    {
        public CollectionRequestResult<GsmCompanyView> GetCompanyList(CompanyListFetchParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () => GetGsmCompanyList(parameters));
        }

        public OfficeListRequestResult GetOfficeDataForSelectedCompany(int selectedCompanyId, SessionData sessionData)
        {
            return Execute(sessionData, () => GetCompanyAndItsOfficeList(selectedCompanyId));
        }

        public ContactListRequestResult GetContactDataForSelectedOffice(int selectedOfficeId, SessionData sessionData)
        {
            return Execute(sessionData, () => GetOfficeAndItsContactList(selectedOfficeId));
        }

        public CollectionRequestResult<DropDownListElement> GetCompanyFilterDropdownList(bool isCompanyTypeNeed, SessionData sessionData)
        {
            return Execute(sessionData, () => new CollectionRequestResult<DropDownListElement>(new PageDataProvider(CSession.CurrentOrganization).GetCompanyFilter(isCompanyTypeNeed)));
        }

        private ContactListRequestResult GetOfficeAndItsContactList(int selectedOfficeId)
        {
            var gsmContactPersonMapper = new ImmutableGsmContactPersonMapper();
            var gsmContactPersonStore = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();
            var currentOrgId = CSession.CurrentOrganization.Id;
            return new ContactListRequestResult
            {
                Office = new ImmutableGsmOfficeMapper().GetView(ImmutableLoaderFactory.GetImmutableGsmOfficeLoader().GetById(selectedOfficeId)),
                Contacts = gsmContactPersonStore.GetContactsForOffice(selectedOfficeId, currentOrgId)
                    .Select(c =>gsmContactPersonMapper.GetView(c,gsmContactPersonStore.CanBeRemovedFromOffice(c.Id, selectedOfficeId),string.Empty,new List<string>()))
                    .ToList()
//                            GsmContactPerson.GetContactsForOffice(selectedOfficeId, CSession.CurrentOrganization).Select(c => c.GetView(selectedOfficeId)).ToList()
            };
        }

        private CollectionRequestResult<GsmCompanyView> GetGsmCompanyList(CompanyListFetchParameters parameters)
        {
            return new CollectionRequestResult<GsmCompanyView>(new PageDataProvider(CSession.CurrentOrganization).GetGsmCompanyList(parameters.SelectedTypeId, parameters.NameToSearch));
        }

        private OfficeListRequestResult GetCompanyAndItsOfficeList(int selectedCompanyId)
        {
            var company = ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().GetById(selectedCompanyId);
            var officeMapper = new ImmutableGsmOfficeMapper();
            return new OfficeListRequestResult
            {
                Company = company.GetView(),
                Offices = company.CompanyOfficesIds.Select(ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetById)
                                                   .OrderBy(o => o.GetDisplayName()).Select(officeMapper.GetView).ToList()
            };
        }
    }
}
