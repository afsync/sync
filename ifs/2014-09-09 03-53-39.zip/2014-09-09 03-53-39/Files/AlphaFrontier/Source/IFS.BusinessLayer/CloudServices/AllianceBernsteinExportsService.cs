﻿using System;
using System.Collections.Generic;
using Common.Logging;
using IFS.BusinessLayer.AttributesFramework;
using IFS.BusinessLayer.Export;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.PositionsExport;
using IFS.Interfaces.CloudContracts.Reports;

namespace IFS.BusinessLayer.CloudServices
{
    class AllianceBernsteinExportsService : CloudServiceBase, IAllianceBernsteinPositionsExportService
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(AllianceBernsteinExportsService));
        public PostionsExportCsvData GenerateExport(int organizationId)
        {
            _log.Info("Begin GenerateExport");
            CSession.OrganizationID = organizationId;
            var organization = CSession.CurrentOrganization;
            var snapshot = Portfolio.ClientLevelPortfoliosSnapshot(GetDfdParameters(organizationId));
            var export = new AllianceBernsteinPositionsExport(snapshot, GetAttributesList(organization));
            return export.GetExportDataAsCsv();
        }

        private AttributesList GetAttributesList(Organization organization)
        {
            var attributeMapping = organization.AttributesMapping;
            return attributeMapping == null ? new AttributesList() : attributeMapping.AttributesList;
        }

        private DfdParameters GetDfdParameters(int organizationId)
        {
            return new DfdParameters
            {
                OrganizationId = organizationId,
                AggregationKeys = new List<string> { "portfolio" },
                ValuationEndDate = DateTime.Now.Date,
                RiskFreeRate = 4.0,
                MarRatio = 0.0,
                GlobalBenchmark = BenchmarkStandard.GetSAndP500Benchmark(),
                IncludeFullyRedeemedInvestments = true,
                ReturnType = EReturnType.DERIVED,
                Filter = new CSearch(),
                IsCalculateIrr = false,
                ViewLockDownSnapshot = CSession.ViewLockdownSnapshot,
            };
        }
    }
}
