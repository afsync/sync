﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Logging;
using IFS.BusinessLayer.AttributesFramework;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.PositionsExport;

namespace IFS.BusinessLayer.Export
{
    public class AllianceBernsteinPositionsExport
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(AllianceBernsteinPositionsExport));
        private const string NUM_OF_RECORDS = "No. of Records:";
        private readonly DerivedFundData _derivedFundData;
        private readonly AttributesList _attributesList;
        private readonly string _reportDateString;

        public AllianceBernsteinPositionsExport(DerivedFundData derivedFundData, AttributesList attributesList)
        {
            _derivedFundData = derivedFundData;
            _attributesList = attributesList;
            _reportDateString = DateTime.Today.ToShortDateString();
        }

        public PostionsExportCsvData GetExportDataAsCsv()
        {
            _log.Info("Begin GetExportDataAsCsv");
            var portfolioNodeList = GetPortfolioNodeList();
            return GenerateExportData(portfolioNodeList);
        }

        private List<DerivedFundData> GetPortfolioNodeList()
        {
            return (from portfolioNode in _derivedFundData.ChildNodes
                    let portfolio = portfolioNode.Source as Portfolio
                    where portfolio != null && portfolio.PortfolioProperties.IncludeInExports
                    select portfolioNode).ToList();
        }

        private PostionsExportCsvData GenerateExportData(List<DerivedFundData> portfolioNodeList)
        {
            _log.Info("Begin GenerateExportData");
            var childLevelCsv = new StringBuilder(1024*512);
            var portfolioLevelCsv = new StringBuilder(1024*512);

            var portfolioNodeCount = portfolioNodeList.Count;
            var childNodeCount = portfolioNodeList.Sum(p => p.ChildNodes.Count);

            CreatePortfolioLevelReportCaption(portfolioLevelCsv);
            CreateChildLevelReportCaption(childLevelCsv);
            CreateReportsRows(portfolioNodeList, portfolioLevelCsv, childLevelCsv);
            CreatePortfolioLevelReportTotalsLine(portfolioLevelCsv, portfolioNodeCount);
            CreateChilLevelReportTotalsLine(childLevelCsv, childNodeCount);

            return new PostionsExportCsvData(childLevelCsv.ToString(), childNodeCount, 
                                                portfolioLevelCsv.ToString(), portfolioNodeCount);
        }

        private void CreateReportsRows(IEnumerable<DerivedFundData> portfolioNodeList, StringBuilder portfolioLevelCsv, StringBuilder childLevelCsv)
        {
            _log.Info("Begin CreateReportsRows");            
            foreach (var portfolioNode in portfolioNodeList)
            {
                CreatePortfolioLevelCsvRow(portfolioNode, portfolioLevelCsv);
                CreateChildReportRows(portfolioNode, childLevelCsv);
            }
        }

        private void CreateChildReportRows(DerivedFundData portfolioNode, StringBuilder childLevelCsv)
        {
            foreach (var fundLevelNode in portfolioNode.ChildNodes)
            {
                CreateChildLevelCsvRow(portfolioNode, fundLevelNode, childLevelCsv);
            }
        }

        private static void CreatePortfolioLevelReportCaption(StringBuilder portfolioLevelCsv)
        {
            portfolioLevelCsv.AppendLine(@"Nav Date,Fund Of Fund Name, Fund#, Market Value, Currency");
        }

        private void CreateChildLevelReportCaption(StringBuilder childLevelCsv)
        {
            childLevelCsv.Append(
                "Nav Date,Fund Of Fund Name, Security Identifier, Fund#, Underlying Fund Name, IFS Security ID," +
                "Asset Type, Fund Type, Underlying Fund Cusip,Strategy, Shares,Price, Market Value, Currency,Country,");
            childLevelCsv.Append(GetAttributeColumnName(Attrib.CUSTOM_TAG14, "Custom tag 14")).Append(",");
            childLevelCsv.AppendLine(GetAttributeColumnName(Attrib.CUSTOM_TAG15, "Custom tag 15"));
        }

        private string GetAttributeColumnName(string attributeId, string defaultValue)
        {
            var attribute = _attributesList.Items.Find(attrib => attrib.Id == attributeId);
            return attribute != null ? attribute.Name : defaultValue;
        }

        private static void CreatePortfolioLevelReportTotalsLine(StringBuilder portfolioLevelCsv, int portfolioLevelDataRowCount)
        {
            portfolioLevelCsv.Append(NUM_OF_RECORDS).Append(",").AppendLine(portfolioLevelDataRowCount.ToString());
        }

        private static void CreateChilLevelReportTotalsLine(StringBuilder childLevelCsv, int childLevelDataRowCount)
        {
            childLevelCsv.Append(NUM_OF_RECORDS).Append(",").AppendLine(childLevelDataRowCount.ToString());
        }

        private void CreatePortfolioLevelCsvRow(DerivedFundData portfolioNode, StringBuilder portfolioLevelCsv)
        {
            portfolioLevelCsv.Append(_reportDateString).Append(",");
            portfolioLevelCsv.Append(CsvUtil.FormatStringForCsv(portfolioNode.PortfolioName)).Append(",");
            portfolioLevelCsv.Append(portfolioNode.GlsId).Append(",");
            portfolioLevelCsv.Append(portfolioNode.FundAccountingData.MarketValueBase).Append(",");
            portfolioLevelCsv.AppendLine(portfolioNode.FundAccountingData.CurrencyID);
        }

        private void CreateChildLevelCsvRow(DerivedFundData portfolioNode, DerivedFundData fundLevelNode,
                                            StringBuilder childLevelCsv)
        {
            childLevelCsv.Append(_reportDateString).Append(",");
            childLevelCsv.Append(CsvUtil.FormatStringForCsv(portfolioNode.PortfolioName)).Append(",");
            childLevelCsv.Append(fundLevelNode.GlsId).Append(",");
            childLevelCsv.Append(portfolioNode.GlsId).Append(",");
            childLevelCsv.Append(CsvUtil.FormatStringForCsv(fundLevelNode.Name)).Append(",");
            childLevelCsv.Append(fundLevelNode.InstrumentId).Append(",");
            childLevelCsv.Append(fundLevelNode.AssetClass).Append(",");
            childLevelCsv.Append(fundLevelNode.FundType).Append(",");
            childLevelCsv.Append("NA,");
            childLevelCsv.Append(CsvUtil.FormatStringForCsv(fundLevelNode.Strategy)).Append(",");
            childLevelCsv.Append(fundLevelNode.FundAccountingData.Shares).Append(",");
            childLevelCsv.Append(fundLevelNode.FundAccountingData.Nav).Append(",");
            childLevelCsv.Append(fundLevelNode.FundAccountingData.MarketValueBase).Append(",");
            childLevelCsv.Append(fundLevelNode.FundAccountingData.CurrencyID).Append(",");
            childLevelCsv.Append(fundLevelNode.Country).Append(",");
            childLevelCsv.Append(fundLevelNode.CustomTag14).Append(",");
            childLevelCsv.AppendLine(fundLevelNode.CustomTag15);
        }
    }
}
