﻿using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableContact;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable.Store;
using IFS.BusinessLayer.Utilities;

namespace IFS.BusinessLayer
{
    public class ImmutableRepositoryFactory
    {
        private static ImmutableContactRepository _contactRepository;
        public static ImmutableContactRepository ImmutableContactRepository()
        {
            return _contactRepository ??
                (_contactRepository = SpringUtil.GetObject<ImmutableContactRepository>("ImmutableContactRepository"));
        }
        
        private static ImmutableGsmCompanyStore _gsmCompanyStore;
        public static ImmutableGsmCompanyStore ImmutableGsmCompanyStore()
        {
            return _gsmCompanyStore ??
                (_gsmCompanyStore = SpringUtil.GetObject<ImmutableGsmCompanyStore>("ImmutableGsmCompanyStore"));
        }

        private static ImmutableGsmOfficeStore _gsmOfficeStore;
        public static ImmutableGsmOfficeStore ImmutableGsmOfficeStore()
        {
            return _gsmOfficeStore ??
                (_gsmOfficeStore = SpringUtil.GetObject<ImmutableGsmOfficeStore>("ImmutableGsmOfficeStore"));
        }
        private static ImmutableGsmContactPersonStore _gsmContactPersonStore;
        public static ImmutableGsmContactPersonStore ImmutableGsmContactPersonStore()
        {
            return _gsmContactPersonStore ??
                (_gsmContactPersonStore = SpringUtil.GetObject<ImmutableGsmContactPersonStore>("ImmutableGsmContactPersonStore"));
        }
    }
}
