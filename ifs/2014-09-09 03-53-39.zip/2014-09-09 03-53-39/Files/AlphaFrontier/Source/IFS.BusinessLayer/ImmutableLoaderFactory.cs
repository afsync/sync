﻿using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Utilities;

namespace IFS.BusinessLayer
{
    public class ImmutableLoaderFactory
    {
        private static ILoadable<ImmutableGsmCompany> _gsmCompanyLoader;
        public static ILoadable<ImmutableGsmCompany> GetImmutableGsmCompanyLoader()
        {
            return _gsmCompanyLoader ?? 
                (_gsmCompanyLoader = (ILoadable<ImmutableGsmCompany>)SpringUtil.GetObject("immutableGsmCompanyLoader"));
        }

        private static ILoadable<ImmutableGsmOffice> _gsmOfficeLoader;
        public static ILoadable<ImmutableGsmOffice> GetImmutableGsmOfficeLoader()
        {
            return _gsmOfficeLoader ?? 
                (_gsmOfficeLoader = (ILoadable<ImmutableGsmOffice>)SpringUtil.GetObject("immutableGsmOfficeLoader"));
        }
        private static ILoadable<ImmutableGsmContactPerson> _gsmContactLoader;
        public static ILoadable<ImmutableGsmContactPerson> GetImmutableGsmContactPersonLoader()
        {
            return _gsmContactLoader ??
                (_gsmContactLoader = (ILoadable<ImmutableGsmContactPerson>)SpringUtil.GetObject("immutableGsmContactPersonLoader"));
        }
    }
}
