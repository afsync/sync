﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable.Store;
using IFS.BusinessLayer.Repository;

namespace IFS.BusinessLayer.Reports.CPReports.Reconciliation
{
    public class ProviderInfoBilder
    {
        private readonly ILoadable<ImmutableGsmCompany> _gsmCompanyLoader;
        private readonly ImmutableGsmContactPersonStore _gsmContactPersonStore;
        private readonly ImmutableGsmOfficeStore _gsmOfficeStore;
        private readonly GsmFundOfficeContactBlRepository _gsmFundOfficeContactBlRepository;

        public ProviderInfoBilder(ILoadable<ImmutableGsmCompany> gsmCompanyLoader,
            GsmFundOfficeContactBlRepository gsmFundOfficeContactBlRepository,
            ImmutableGsmContactPersonStore gsmContactPersonStore, ImmutableGsmOfficeStore gsmOfficeLoader)
        {
            _gsmCompanyLoader = gsmCompanyLoader;
            _gsmFundOfficeContactBlRepository = gsmFundOfficeContactBlRepository;
            _gsmContactPersonStore = gsmContactPersonStore;
            _gsmOfficeStore = gsmOfficeLoader;
        }

        public ProviderInfo GetProviderInformation(IList<GsmFundOffice> gsmOffices, int providerId, bool isFinal)
        {
            if (providerId > 0)
            {
                var gsmOfficeGroupId = providerId == EnumValue.PRICE_RELEASE_PROVIDED_BY_MANAGER
                    ? AttributeGroup.INVESTMENT_MANAGERS
                    : AttributeGroup.ADMINISTRATORS;
                return isFinal
                    ? GetProviderInfoForFinal(gsmOffices, gsmOfficeGroupId)
                    : GetProviderInfoFromFirstOffice(gsmOffices, gsmOfficeGroupId);
            }
            return new ProviderInfo();
        }

        private ProviderInfo GetProviderInfoForFinal(IList<GsmFundOffice> gsmOffices, int gsmOfficeGroupId)
        {
            return GetLastAddedProviderInfoForFinal(gsmOffices, gsmOfficeGroupId) ??
                   GetProviderInfoFromFirstOffice(gsmOffices, gsmOfficeGroupId);
        }

        private ProviderInfo GetLastAddedProviderInfoForFinal(IEnumerable<GsmFundOffice> gsmOffices, int currentProviderGroup)
        {
            var gsmFundOffices = gsmOffices.Where(o => o.CompanyGroupId == currentProviderGroup).OrderByDescending(o => o.ModifiedDate);
            foreach (var gsmFundOffice in gsmFundOffices)
            {
                var office = _gsmOfficeStore.GetById(gsmFundOffice.OfficeId);
                if (office != null)
                {
                    var providerInfo = GetProviderInformationForOffice(gsmFundOffice.Id, office);
                    if (providerInfo != null)
                        return providerInfo;
                }
            }
            return null;
        }

        private ProviderInfo GetProviderInformationForOffice(int gsmFundOfficeId, ImmutableGsmOffice office)
        {
            var gsmCompany = _gsmCompanyLoader.GetById(office.CompanyId);
            var email = GetEmailOfProvider(gsmFundOfficeId, office, gsmCompany);
            if (string.IsNullOrEmpty(email))
                return null;
            var providerInfo = GetProviderNameAndCountry(office, gsmCompany);
            providerInfo.Email = email;
            return providerInfo;
        }

        private ProviderInfo GetProviderNameAndCountry(ImmutableGsmOffice office, ImmutableGsmCompany gsmCompany)
        {
            return new ProviderInfo
            {
                Name = gsmCompany.CompanyName,
                Country = office.OfficeCountry
            };
        }

        public string GetEmailOfProvider(int fundOfficeId, ImmutableGsmOffice office, ImmutableGsmCompany gsmCompany)
        {
            var email = GetEmailFromLastAddedContacts(fundOfficeId);
            if (string.IsNullOrEmpty(email))
                email = GetOfficeMail(office);
            if (string.IsNullOrEmpty(email))
                email = GetCompanyMail(gsmCompany);
            return email;
        }

        private string GetEmailFromLastAddedContacts(int fundOfficeId)
        {
            var contacts = GetGsmFundOfficeContacts(fundOfficeId);
            return SelectEmail(contacts) ?? string.Empty;
        }

        private string SelectEmail(IEnumerable<GsmFundOfficeContact> contacts)
        {
            return contacts.Select(c => _gsmContactPersonStore.GetById(c.ContactPersonId).Email).FirstOrDefault(e => !string.IsNullOrEmpty(e));
        }

        private IEnumerable<GsmFundOfficeContact> GetGsmFundOfficeContacts(int fundOfficeId)
        {
            return GetAllFundOfficeContacts()
                    .Where(c => c.FundOfficeId == fundOfficeId && c.ApprovedByUserId.HasValue)
                    .OrderByDescending(c => c.ModifiedDate);
        }

        private string GetOfficeMail(ImmutableGsmOffice office)
        {
            return office.OfficeEmail;
        }

        private string GetCompanyMail(ImmutableGsmCompany gsmCompany)
        {
            return gsmCompany.CompanyEmail;
        }

        private IEnumerable<GsmFundOfficeContact> _allFundContacts;
        private IEnumerable<GsmFundOfficeContact> GetAllFundOfficeContacts()
        {
            return _allFundContacts ?? (_allFundContacts = _gsmFundOfficeContactBlRepository.SelectAll());
        }

        private ProviderInfo GetProviderInfoFromFirstOffice(IEnumerable<GsmFundOffice> gsmOffices, int gsmOfficeGroupId)
        {
            ProviderInfo providerInfo = null;
            var gsmOffice = gsmOffices.FirstOrDefault(o => o.CompanyGroupId == gsmOfficeGroupId);
            if (gsmOffice != null)
            {
                var office = _gsmOfficeStore.GetById(gsmOffice.OfficeId);
                if (office != null)
                    providerInfo = GetProviderNameAndCountry(office, _gsmCompanyLoader.GetById(office.CompanyId));
            }
            return providerInfo ?? new ProviderInfo();
        }
    }
}
