﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using IFS.DataAccess.Entity;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.GSM.Immutable.Mapper
{
    public class ImmutableGsmContactPersonMapper : IGsmContactPersonOfficesMapper<ImmutableGsmContactPerson, GsmContactPersonData>
    {

        public ImmutableGsmContactPerson GetImmutableFromEntity(GsmContactPersonData data)
        {
            return GetImmutableFromEntity(data, null);
        }

        public virtual ImmutableGsmContactPerson GetImmutableFromEntity(GsmContactPersonData data, ReadOnlyCollection<int> contactOfficeIds)
        {
            return new ImmutableGsmContactPerson(data.Id,
                                                 data.ContactFirstName,
                                                 data.ContactLastName,
                                                 data.ContactRole,
                                                 data.ContactPhone,
                                                 data.ContactFax,
                                                 data.ContactEmail,
                                                 data.ContactCompanyId,
                                                 data.OrganizationId,
                                                 contactOfficeIds);
        }

        

        public GsmContactPersonData GetEntityData(ImmutableGsmContactPerson immutable)
        {
            return new GsmContactPersonData
            {
                Id = immutable.Id,
                ContactFirstName = immutable.FirstName,
                ContactLastName = immutable.LastName,
                ContactRole = immutable.Role,
                ContactPhone = immutable.Phone,
                ContactFax = immutable.Fax,
                ContactEmail = immutable.Email,
                ContactCompanyId = immutable.CompanyId,
                OrganizationId = immutable.OrganizationId
            };
        }

        public void UpdateEntityData(GsmContactPersonData data, ImmutableGsmContactPerson immutable)
        {
            data.ContactFirstName = immutable.FirstName;
            data.ContactLastName = immutable.LastName;
            data.ContactRole = immutable.Role;
            data.ContactPhone = immutable.Phone;
            data.ContactFax = immutable.Fax;
            data.ContactEmail = immutable.Email;
            data.ContactCompanyId = immutable.CompanyId;
            data.OrganizationId = immutable.OrganizationId;
        }

        public ImmutableGsmContactPerson CreateNewWithId(ImmutableGsmContactPerson immutable, int id)
        {
            return new ImmutableGsmContactPerson(id,
                                                 immutable.FirstName,
                                                 immutable.LastName,
                                                 immutable.Role,
                                                 immutable.Phone,
                                                 immutable.Fax,
                                                 immutable.Email,
                                                 immutable.CompanyId,
                                                 immutable.OrganizationId,
                                                 immutable.ContactOfficeIds);
        }
        
        public GsmContactPersonView GetView(ImmutableGsmContactPerson immutable, bool canBeRemovedFromOffice,
            string companyName, List<string> officeNames)
        {
            return new GsmContactPersonView
            {
                Id = immutable.Id,
                FullName = immutable.GetFullName(),
                Role = immutable.Role,
                Phone = immutable.Phone,
                Fax = immutable.Fax,
                Email = immutable.Email,
                IsEditable = immutable.IsEditableByOrganization(CSession.OrganizationID),
                CanBeRemovedFromOffice = canBeRemovedFromOffice,
                CompanyName = companyName,
                FirstName = immutable.FirstName,
                LastName = immutable.LastName,
                OfficeNames = string.Join(", ", officeNames)
            };
        }

    }
}
