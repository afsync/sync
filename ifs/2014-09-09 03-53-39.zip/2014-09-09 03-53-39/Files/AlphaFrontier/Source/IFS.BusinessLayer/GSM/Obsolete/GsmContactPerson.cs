﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Repository;
using IFS.BusinessLayer.Utilities;
using IFS.DataAccess.Entity;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.Entity;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.GSM.Obsolete
{
    /// <summary>
    /// Global Contact
    /// </summary>
    [Serializable]
    public class GsmContactPerson : BaseAuditedEntity<GsmContactPersonData>
    {
        private static readonly ImmutableGsmOfficeStore _gsmOfficeRepository =
            ImmutableRepositoryFactory.ImmutableGsmOfficeStore();

        public int ContactPersonId
        {
            get { return Id; }
            set { Id = value; }
        }
        public string ContactFirstName { get; set; }
        public string ContactLastName { get; set; }
        public string ContactRole { get; set; }
        public string ContactPhone { get; set; }
        public string ContactFax { get; set; }
        public string ContactEmail { get; set; }
        private int? _contactCompanyId;
        public int? ContactCompanyId
        {
            get { return _contactCompanyId; }
            set
            {
                if (_contactCompanyId != value)
                {
                    _company = null;
                    _contactCompanyId = value;
                    _contactOfficeIds = null;
                    _contactOfficeNames = null;
                }
            }
        }

        public int? OrganizationId { get; set; }
        private List<string> _contactOfficeNames;
        private IEnumerable<string> ContactOfficeNames
        {
            get { return _contactOfficeNames ?? (_contactOfficeNames = GetOfficeNames()); }
        }
        private List<int> _contactOfficeIds;
        public List<int> ContactOfficeIds
        {
            get
            {
                return _contactOfficeIds ??
                       (_contactOfficeIds = ContactPersonId <= 0 ? new List<int>() : 
                       ContactPersonOffice.GetOfficesForContact(ContactPersonId).Select(x => x.CompanyOfficeId).ToList());
            }
            set
            {
                _contactOfficeIds = value;
                _contactOfficeNames = null;
            }
        }
        public string OfficeNames
        {
            get { return String.Join(", ", ContactOfficeNames); }
        }
        public string FullName
        {
            get { return ContactFirstName + " " + ContactLastName; }
        }
        public string CompanyName
        {
            get { return Company == null || string.IsNullOrEmpty(Company.CompanyName) ? "--" : Company.CompanyName; }
        }
        private ImmutableGsmCompany _company;
        public ImmutableGsmCompany Company
        {
            get
            {
                return _company ?? (_company = ContactCompanyId != null ? ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().GetById((int)ContactCompanyId):null);
            }
            set
            {
                _company = value;
                _contactCompanyId = _company != null ? (int?)_company.Id : null;
                _contactOfficeIds = null;
                _contactOfficeNames = null;
            }
        }

        private static ILoadable<GsmContactPerson> _loader;
        public static ILoadable<GsmContactPerson> Loader
        {
            get { return _loader ?? (_loader = (ILoadable<GsmContactPerson>)SpringUtil.GetObject("gsmContactPersonLoader")); }
        }
        
        #region <<< Methods >>>
        
        public override void Save()
        {
            var oc = new ObjectContainer();
            BulkSave(oc);
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        public override void Delete()
        {
            DeleteRelations();
            base.Delete();
            Loader.Remove(null);
        }
        public override void BulkSave(ObjectContainer oc)
        {
            if (_insertPending && Id <= 0)
                SetId();
            base.BulkSave(oc);

            if (!ContactCompanyId.HasValue || Company.Id != ContactCompanyId)
            {
                _company = null;
            }
            SaveOffices(oc);

            if (!IsBatchMode())
                Loader.Remove(null);
        }
        private void SetId()
        {
            if (Id <= 0)
            {
                var provider = (ISequenceProvider)SpringUtil.GetObject("GsmContactPersonSequenceProvider");
                Id = provider.GetNextSequenceNumber();
            }
        }


        public static void GetLastModificationInfo(IEnumerable<GsmContactPersonModel> data, out int? lastModifiedUserId, out DateTime? lastModifiedDate)
        {
            lastModifiedUserId = null;
            lastModifiedDate = null;

            if (!CSession.IsGSM) 
                return;

            var canApprove = (from d in data
                              where d.ApprovedByUserId == null || d.IsReadyForDelete
                              orderby d.ModifiedDate descending
                              select d).FirstOrDefault();
            if (canApprove != null)
            {
                lastModifiedUserId = canApprove.ModifiedByUserId;
                lastModifiedDate = canApprove.ModifiedDate;
            }
        }

        public static GsmContactPerson GetById(int id)
        {
            return Loader.GetById(id);
        }
        
        /// <summary>
        /// Returns all contact persons
        /// </summary>
        /// <returns></returns>
        public static IList<GsmContactPerson> SelectAll()
        {
            return Loader.SelectAll();
        }
        /// <summary>
        /// All person contacts for company
        /// </summary>
        /// <param name="companyId">company id</param>
        /// <returns></returns>
        public static IList<GsmContactPerson> GetContactsForCompany(int companyId)
        {
            return SelectAll().Where(x => x.ContactCompanyId == companyId).ToList();
        }

        /// <summary>
        ///  Get offices selected for person
        /// </summary>
        /// <returns></returns>
        public List<SelectedOffice> GetSelected()
        {
            return Company == null
                       ? new List<SelectedOffice>()
                       : Company.CompanyOfficesIds.Select(_gsmOfficeRepository.GetById).Select(
                           x =>
                           new SelectedOffice
                           {
                               OfficeId = x.Id,
                               Name = x.GetDisplayName(),
                               IsSelected = ContactOfficeIds.Contains(x.Id)
                           }).ToList();
        }

        /// <summary>
        /// List of contact persons which can be added to office(already added for this office are excluded)
        /// </summary>
        /// <param name="companyId">company id</param>
        /// <param name="officeId">office id</param>
        /// <param name="organization"></param>
        /// <returns></returns>
        public static IList<GsmContactPerson> GetAvailableContactsForOffice(int companyId, int officeId, Organization organization)
        {
            IList<IGsmContactPersonData> gsmContactPersonList;
            var isOwnCompany = IsOwnCompany(companyId, organization);

            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                gsmContactPersonList = dbRepository.GetAvailableContactsForOffice(companyId, officeId, isOwnCompany, organization.OrganizationID);
            }

            return gsmContactPersonList.Select(EntityUtil.NewFromEntityObject<GsmContactPerson>).ToList();
        }

        // Checks if persons added to organization's company
        // Client which support GSM can create office for GSM company and add persons to such office 
        private static bool IsOwnCompany(int companyId, Organization organization)
        {
            return organization.OrganizationID == CSession.GSMOrgId || ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().GetById(companyId).OrganizationId == organization.OrganizationID;
        }
        
        /// <summary>
        /// List of contact persons for office
        /// </summary>
        /// <param name="officeId">office id</param>
        /// <param name="organization"></param>
        /// <returns></returns>
        public static List<GsmContactPerson> GetContactsForOffice(int officeId, Organization organization)
        {
            IList<IGsmContactPersonData> gsmContactPersonList;

            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                gsmContactPersonList = dbRepository.GetContactsForOfficeByOrganization(officeId, organization.OrganizationID, CSession.GSMOrgId);
            }

            return gsmContactPersonList.Select(EntityUtil.NewFromEntityObject<GsmContactPerson>).ToList();
        }

        public static List<GsmContactPerson> GetContactsForOffice(int officeId)
        {
            IList<IGsmContactPersonData> gsmContactPersonList;

            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                gsmContactPersonList = dbRepository.GetContactsForOffice(officeId);
            }

            return gsmContactPersonList.Select(EntityUtil.NewFromEntityObject<GsmContactPerson>).ToList();
        }

        /// <summary>
        /// List of contact which can be added to office of fund ( for specific company type)
        /// </summary>
        /// <param name="officeId">office id</param>
        /// <param name="fundOfficeId">fudn - office relation id</param>
        /// <param name="organization"></param>
        /// <returns></returns>
        public static IList<GsmContactPerson> GetContactsAvailableForFund(int officeId, int fundOfficeId, Organization organization)
        {
            var officeContacts = GetContactsForOffice(officeId, organization);  // all persons for this office
            var gsmFundOfficeContactBLRepository = new GsmFundOfficeContactBlRepository();
            var alreadyAdded = gsmFundOfficeContactBLRepository.GetByFundOffice(fundOfficeId);
            var result = from contact in officeContacts
                         join added in alreadyAdded
                             on contact.Id equals added.ContactPersonId into tmp
                         from x in tmp.DefaultIfEmpty()
                         where x == null
                         orderby contact.ContactFirstName
                         select contact;
            return result.ToList();
        }

       
        public static void RemoveFromOffice(int contactPersonId, int officeId)
        {
            var contactOffice = ContactPersonOffice.GetOfficesForContact(contactPersonId)
                                .SingleOrDefault(x => x.CompanyOfficeId == officeId);
            if (contactOffice != null)
            {
                contactOffice.Delete();
                var contact = GetById(contactOffice.ContactPersonId);
                if (contact != null)
                {
                    contact.RemoveOffice(contactOffice.CompanyOfficeId);
                }
            }
            var gsmFundOfficeContactBLRepository = new GsmFundOfficeContactBlRepository();
            var links = gsmFundOfficeContactBLRepository.GetByContactPersonAndOffice(contactPersonId, officeId, CSession.OrganizationID);
            if (links.Count > 0)
            {
                var oc = new ObjectContainer();
                foreach (var link in links)
                    link.BulkDelete(oc);
                
                using (var bsd = new BulkSaveData())
                {
                    bsd.SubmitChanges(oc);
                }
            }
        }

        private void DeleteRelations()
        {
            DeleteFromFundOffices();
            DeleteFromOffices();
            DeleteHistory();
        }
        
        private void DeleteHistory()
        {
            var person = new ImmutableGsmContactPerson(Id, ContactFirstName, ContactLastName, ContactRole, ContactPhone,
                ContactFax, ContactEmail, _contactCompanyId, OrganizationId, ContactOfficeIds.AsReadOnly());
            ;
            new GsmContactPersonHistoryManager(person,new ContactPersonHistoryDataProvider()).ClearHistory();
        }

        /// <summary>
        /// Remove from FundOffice contacts
        /// </summary>
        private void DeleteFromFundOffices()
        {
            var gsmFundOfficeContactBLRepository = new GsmFundOfficeContactBlRepository();
            var links = gsmFundOfficeContactBLRepository.GetByContactPersonId(ContactPersonId);
            var oc = new ObjectContainer();
            foreach (var link in links)
                link.BulkDelete(oc);
            
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        /// <summary>
        /// Remove from global office
        /// </summary>
        private void DeleteFromOffices()
        {
            if (ContactOfficeIds.Count > 0 && ContactPersonId > 0)
            {
                var officiesInDb = ContactPersonOffice.GetOfficesForContact(ContactPersonId);
                var oc = new ObjectContainer();
                RemoveFromDb(oc, officiesInDb);
            }
        }
        private void RemoveFromDb(ObjectContainer oc, IEnumerable<ContactPersonOffice> officiesToDelete)
        {
            foreach (var c in officiesToDelete)
            {
                (new ContactPersonOffice { Id = c.Id, ContactPersonId = ContactPersonId, CompanyOfficeId = c.CompanyOfficeId }).BulkDelete(oc);
                RemoveFromOffice(ContactPersonId, c.CompanyOfficeId);
            }
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        public void ValidateContactEmailMustBeUnique()
        {
            var result = SelectAll().Any(x => x.ContactPersonId != ContactPersonId &&
                        string.Equals(x.ContactEmail, ContactEmail, StringComparison.OrdinalIgnoreCase));
            if (result)
            {
                throw new ValidationException("Person with such email already exists");
            }
        }

        private void SaveOffices(ObjectContainer oc)
        {
            var officiesInDb = !InsertPending ? ContactPersonOffice.GetOfficesForContact(ContactPersonId) : new List<ContactPersonOffice>();
            var officiesToDelete = new List<ContactPersonOffice>();
            var alreadyExists = new List<int>();
            foreach (var item in officiesInDb)
            {
                if (!ContactOfficeIds.Contains(item.CompanyOfficeId))
                {
                    officiesToDelete.Add(item);                        // user uncheck office -> must be deleted
                }
                else
                {
                    alreadyExists.Add(item.CompanyOfficeId);          // no need to add(already in db) 
                }
            }
            bool isBulkSave = (oc != null);
            oc = oc ?? new ObjectContainer();
            if (officiesToDelete.Count > 0)
            {
                RemoveFromDb(oc, officiesToDelete);
            }
            var officiesToAdd = ContactOfficeIds.Except(alreadyExists).ToList();
            if (officiesToAdd.Count > 0)
            {
                foreach (var id in officiesToAdd)
                {
                    var c = new ContactPersonOffice { CompanyOfficeId = id, ContactPersonId = ContactPersonId };
                    c.BulkSave(oc);
                }
                if (!isBulkSave)
                {
                    using (var bsd = new BulkSaveData())
                    {
                        bsd.SubmitChanges(oc);
                    }
                }
            }
        }

        private List<string> GetOfficeNames()
        {
            return (from id in ContactOfficeIds 
                    select _gsmOfficeRepository.GetById(id) into office 
                    where office != null 
                    select office.GetDisplayName()).ToList();
        }

        public static PersonsNames SeparatePersonName(string personName)
        {
            if (string.IsNullOrWhiteSpace(personName))
                return new PersonsNames();

            // One word case
            var words = personName.Trim().ToLower().Split(' ');
            if (words.Length == 1)
                return new PersonsNames { LastName = personName };

            // Title
            string[] titles = { "dr", "Dr", "ms", "Ms", "mrs", "Mrs", "sir", "Sir", "phd", "Phd" };

            //var lowerdPersonName = personName.ToLower();
            var title = titles.FirstOrDefault(personName.Contains);
            if (title != null)
                personName = personName.Replace(title, string.Empty).Replace(",", string.Empty).Trim();

            // prefixes
            string[] prefixes = { "mc", "de", "von" };
            var containPrefix = words.Intersect(prefixes).FirstOrDefault();

            var index = containPrefix != null ? personName.ToLower().IndexOf(containPrefix) : personName.LastIndexOf(' ');

            var firstName = index > 0 ? personName.Substring(0, index).Trim() : personName;
            var lastName = index > 0 ? personName.Substring(index).Trim() : null;
            return new PersonsNames(firstName, lastName, title); 
        }

        public static bool CanBeApproved(List<GsmContactPersonModel> data)
        {
            if (!CSession.IsGSM) return false;

            var canApprove = (from d in data
                              where d.ApprovedByUserId == null || d.IsReadyForDelete
                              orderby d.ModifiedDate descending
                              select d).FirstOrDefault();

            return canApprove != null && canApprove.ModifiedByUserId != CSession.UserID;
        }

        /// <summary>
        /// All persons for organization + GSM contacts(for clients)
        /// </summary>
        /// <param name="organization"></param>
        /// <returns></returns>
        public static IList<GsmContactPerson> SelectAllForOrganization(Organization organization)
        {
            var result = SelectAllForOrganizationInternal(organization.OrganizationID);
            if (organization.OrganizationID != CSession.GSMOrgId)
            {
                result.AddRange(SelectAllForOrganizationInternal(CSession.GSMOrgId));
            }
            return result;
        }
        
        private static List<GsmContactPerson> SelectAllForOrganizationInternal(int organizationId)
        {
            return SelectAll().Where(x => x.OrganizationId == organizationId).ToList();
        }
        
        public bool IsEditableByOrganization(int organizationId)
        {
            return ContactPersonId <= 0 || OrganizationId == organizationId;
        }

        public bool HasRelatedFunds()
        {
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.HasRelatedFunds(ContactPersonId);
            }
        }
        
        public bool CanBeRemovedFromOffice(int officeId)
        {
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.CanBeRemovedFromOffice(officeId, ContactPersonId);
            }
        }

        public void AddOffice(int officeId)
        {
            if (!ContactOfficeIds.Contains(officeId))
            {
                ContactOfficeIds.Add(officeId);
                _contactOfficeNames = null;
            }
        }
        
        private void RemoveOffice(int officeId)
        {
            if (ContactOfficeIds.Contains(officeId))
            {
                ContactOfficeIds.Remove(officeId);
                _contactOfficeNames = null;
            }
        }

        public GsmContactPersonView GetView(int officeId)
        {
            return new GsmContactPersonView
                       {
                           Id = ContactPersonId,
                           FullName = FullName,
                           Role = ContactRole,
                           Phone = ContactPhone,
                           Fax = ContactFax,
                           Email = ContactEmail,
                           IsEditable = IsEditableByOrganization(CSession.OrganizationID),
                           CanBeRemovedFromOffice = CanBeRemovedFromOffice(officeId)
                       };
        }

        #endregion
    }
}
