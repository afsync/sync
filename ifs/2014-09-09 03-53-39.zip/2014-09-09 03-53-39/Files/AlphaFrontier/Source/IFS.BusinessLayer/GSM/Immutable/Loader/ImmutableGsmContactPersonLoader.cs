﻿using System;
using System.Collections.Generic;
using Common.Logging;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.Immutable.Repository;
using IFS.BusinessLayer.Utilities;

namespace IFS.BusinessLayer.GSM.Immutable.Loader
{
    public class ImmutableGsmContactPersonLoader :  ILoadable<ImmutableGsmContactPerson>
    {
        public const string CACHE_KEY = "CACHE_IMMUTABLE_GLOBAL_CONTACT_PERSONS";
        private static readonly ILog _log = LogManager.GetLogger(typeof(ImmutableGsmContactPersonLoader));
        private static readonly object _dataLoadLockObject = new object();
        private Dictionary<int, ImmutableGsmContactPerson> _idxById;

        private readonly ImmutableGsmContactPersonRepository _gsmContactPersonRepository;

        public ImmutableGsmContactPersonLoader(ImmutableGsmContactPersonRepository gsmContactPersonRepository)
        {
            _gsmContactPersonRepository = gsmContactPersonRepository;
        }

        public string GetCacheKey(object id)
        {
            return CACHE_KEY;
        }

        public void Remove(object id, bool turnOffNotification = false)
        {
            var cacheKey = GetCacheKey(null);
            GlobalRuntimeCache.Remove(cacheKey);
            if (!turnOffNotification)
                CacheUpdateNotificationHelper.SendNotification(cacheKey);
        }

        public ImmutableGsmContactPerson GetById(int id)
        {
            ImmutableGsmContactPerson person = null;
            if (id > 0)
            {
                SelectAll();
                _idxById.TryGetValue(id, out person);
            }
            return person;
        }

        public ImmutableGsmContactPerson GetByName(string name, int organizationId)
        {
            throw new NotImplementedException();
        }

        public List<ImmutableGsmContactPerson> SelectAll()
        {
            var cacheKey = GetCacheKey(null);
            var persons = (CacheableList<ImmutableGsmContactPerson>)GlobalRuntimeCache.Get(cacheKey);
            if (persons == null)
            {
                lock (_dataLoadLockObject)
                {
                    persons = (CacheableList<ImmutableGsmContactPerson>) GlobalRuntimeCache.Get(cacheKey)
                              ?? LoadGsmContactPersonsToCache(cacheKey);
                }
            }
            return persons;
        }

        private CacheableList<ImmutableGsmContactPerson> LoadGsmContactPersonsToCache(string cacheKey)
        {
            _log.Info("Loading GSM contact persons");
            _log.Trace("Executing query in SelectAll");
            var persons = new CacheableList<ImmutableGsmContactPerson>(LoadGsmContactPersonsFromDb()) { CacheKey = cacheKey };
            _log.Trace("Finished executing query in SelectAll");
            GlobalRuntimeCache.Insert(persons);
            return persons;
        }

        private IEnumerable<ImmutableGsmContactPerson> LoadGsmContactPersonsFromDb()
        {
            var idxById = new Dictionary<int, ImmutableGsmContactPerson>();
            var persons = new List<ImmutableGsmContactPerson>();
            foreach (var person in _gsmContactPersonRepository.GetAllGsmContactPersons())
            {
                persons.Add(person);
                idxById[person.Id] = person;
            }
            _idxById = idxById;
            return persons;
        } 
    }
}
