﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.GSM.Immutable
{
    public class ImmutableGsmContactPerson : IAuditable, IImmutableWithId
    {
        private readonly int _id;
        private readonly string _firstName;
        private readonly string _lastName;
        private readonly string _role;
        private readonly string _phone;
        private readonly string _fax;
        private readonly string _email;
        private readonly int? _companyId;
        private readonly int? _organizationId;
        private readonly ReadOnlyCollection<int> _contactOfficeIds;

        public int Id { get { return _id; } }
        public string FirstName { get { return _firstName; } }
        public string LastName { get { return _lastName; } }
        public string Role { get { return _role; } }
        public string Phone { get { return _phone; } }
        public string Fax { get { return _fax; } }
        public string Email { get { return _email; } }
        public int? CompanyId { get { return _companyId; } }
        public int? OrganizationId { get { return _organizationId; } }
        public string FullName { get { return GetFullName(); } }

        public ReadOnlyCollection<int> ContactOfficeIds { get { return _contactOfficeIds; } }

        public ImmutableGsmContactPerson(int id =-1,
                                         string firstName ="",
                                         string lastName ="",
                                         string role="",
                                         string phone="",
                                         string fax="",
                                         string email="",
                                         int? companyId=0,
                                         int? organizationId=0, 
                                         ReadOnlyCollection<int> contactOfficeIds= null)
        {
            _id = id;
            _firstName = firstName;
            _lastName = lastName;
            _role = role;
            _phone = phone;
            _fax = fax;
            _email = email;
            _companyId = companyId;
            _organizationId = organizationId;
            _contactOfficeIds = contactOfficeIds;
        }
        
        public bool IsNew()
        {
            return Id <= 0;
        }

        public string GetAuditXml()
        {
            var sb = new StringBuilder("<Audit>");
            AuditUtilities.NameValuePair(sb, "Id", Id);
            AuditUtilities.NameValuePair(sb, "FirstName", FirstName);
            AuditUtilities.NameValuePair(sb, "LastName", LastName);
            AuditUtilities.NameValuePair(sb, "Role", Role);
            AuditUtilities.NameValuePair(sb, "Phone", Phone);
            AuditUtilities.NameValuePair(sb, "Fax", Fax);
            AuditUtilities.NameValuePair(sb, "Email", Email);
            AuditUtilities.NameValuePair(sb, "CompanyId", CompanyId);
            AuditUtilities.NameValuePair(sb, "OrganizationId", OrganizationId);
            return sb.Append("</Audit>").ToString();
        }

        public string GetFullName()
        {
            return FirstName + " " + LastName;
        }

        public bool IsEditableByOrganization(int organizationId)
        {
            return IsNew() || OrganizationId == organizationId;
        }
    }
}
