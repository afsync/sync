﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.Repository;

namespace IFS.BusinessLayer.GSM.Immutable
{
    public class ImmutableGsmContactPersonRelatedDataProcessor
    {
        private readonly GsmFundOfficeContactBlRepository _gsmFundOfficeContactRepository;
        private readonly ILoadable<ImmutableGsmCompany> _gsmCompanyLoader;

        public ImmutableGsmContactPersonRelatedDataProcessor(GsmFundOfficeContactBlRepository gsmFundOfficeContactRepository, ILoadable<ImmutableGsmCompany> getImmutableGsmCompanyLoader)
        {
            _gsmFundOfficeContactRepository = gsmFundOfficeContactRepository;
            _gsmCompanyLoader = getImmutableGsmCompanyLoader;
        }

        public virtual void ProcessSave(ImmutableGsmContactPerson gsmContactPerson, int newId, ObjectContainer oc)
        {
            var removedContactOfficeIds = RemoveRelativeData(gsmContactPerson, oc);
            var contactOfficeIdsToAdd = GetContactOfficeIdsToAdd(newId, gsmContactPerson.ContactOfficeIds.ToList(), removedContactOfficeIds);
            SaveContactPersonLinks(contactOfficeIdsToAdd, newId, oc);
        }

        private List<int> RemoveRelativeData(ImmutableGsmContactPerson gsmContactPerson, ObjectContainer oc)
        {
            var removedContactOfficeIds = new List<int>();
            if (!gsmContactPerson.IsNew())
            {
                var contactPersonOfficeLinks = GetContactPersonOfficeLinksToDelete(gsmContactPerson.Id, gsmContactPerson.ContactOfficeIds);
                RemoveGsmFundOfficeContactData(gsmContactPerson.Id, contactPersonOfficeLinks, oc);
                removedContactOfficeIds = RemoveContactPersonLinks(contactPersonOfficeLinks, oc);
            }
            return removedContactOfficeIds;
        }
        public virtual void RemoveFromOffice(int contactPersonId, int officeId, ObjectContainer oc)
        {
            var contactPersonOfficeLinks =
                GetExistingContactPersonOfficeLinks(contactPersonId)
                    .Where(link => link.CompanyOfficeId == officeId)
                    .ToList();
            RemoveGsmFundOfficeContactData(contactPersonId, contactPersonOfficeLinks, oc);
            RemoveContactPersonLinks(contactPersonOfficeLinks, oc);
        }
        private void RemoveGsmFundOfficeContactData(int gsmContactPersonId, IEnumerable<ContactPersonOffice> contactPersonOfficeLinks, ObjectContainer oc)
        {
            var organizationId = CSession.OrganizationID;
            foreach (var contactPersonOfficeLink in contactPersonOfficeLinks)
                RemoveGsmFundOfficeContactData(gsmContactPersonId, contactPersonOfficeLink.CompanyOfficeId, organizationId, oc);
        }
        private void RemoveGsmFundOfficeContactData(int contactId, int companyOfficeId, int organizationId, ObjectContainer oc)
        {
            // TODO: change code to get all data at once
            var fundOfficeContactLinks = _gsmFundOfficeContactRepository.GetByContactPersonAndOffice(contactId, companyOfficeId, organizationId);
            foreach (var link in fundOfficeContactLinks)
                link.BulkDelete(oc);
        }
      
        private IEnumerable<int> GetContactOfficeIdsToAdd(int gsmContactOfficeId, List<int> contactOfficeIds, List<int> removedContactOfficeIds)
        {
            contactOfficeIds.RemoveAll(removedContactOfficeIds.Contains);
            return contactOfficeIds.Except(GetExistingContactPersonOfficeLinks(gsmContactOfficeId).Select(link => link.CompanyOfficeId)).ToList();
        }

        private void SaveContactPersonLinks(IEnumerable<int> officiesToAdd, int contactPersonId, ObjectContainer oc)
        {
            foreach (var id in officiesToAdd)
                new ContactPersonOffice { CompanyOfficeId = id, ContactPersonId = contactPersonId }.BulkSave(oc);
        }
        
        public virtual void ProcessDelete(int idToDelete, ObjectContainer oc)
        {
            RemoveAllGsmFundOfficeContacts(idToDelete, oc);
            var contactPersonOfficeLinks = GetContactPersonOfficeLinksToDelete(idToDelete, null);
            RemoveContactPersonLinks(contactPersonOfficeLinks, oc);
        }

        private void RemoveAllGsmFundOfficeContacts(int contactPersonId, ObjectContainer oc)
        {
            foreach (var link in _gsmFundOfficeContactRepository.GetByContactPersonId(contactPersonId))
                link.BulkDelete(oc);
        }
        
        private List<ContactPersonOffice> GetContactPersonOfficeLinksToDelete(int gsmContactPersonId, IEnumerable<int> contactOfficeIds)
        {
            var existingContactPersonOfficeLinks = GetExistingContactPersonOfficeLinks(gsmContactPersonId);
            return contactOfficeIds != null
                    ? existingContactPersonOfficeLinks.Where(link => !contactOfficeIds.Contains(link.CompanyOfficeId)).ToList()
                    : existingContactPersonOfficeLinks.ToList();
        }
        private IEnumerable<ContactPersonOffice> GetExistingContactPersonOfficeLinks(int gsmContactPersonId)
        {
            return ContactPersonOffice.GetOfficesForContact(gsmContactPersonId);
        }
        private List<int> RemoveContactPersonLinks(IEnumerable<ContactPersonOffice> contactPersonOfficeLinks, ObjectContainer oc)
        {
            var removedIds = new List<int>();
            foreach (var contactPersonOfficeLink in contactPersonOfficeLinks)
            {
                contactPersonOfficeLink.BulkDelete(oc);
                removedIds.Add(contactPersonOfficeLink.CompanyOfficeId);
            }
            return removedIds;
        }

        public string GetCompanyName(int? companyId)
        {
            var company = companyId == null ? null : _gsmCompanyLoader.GetById(companyId.Value);
            return company == null || string.IsNullOrEmpty(company.CompanyName) ? "--" : company.CompanyName; 
        }

        public virtual bool IsOwnCompany(int companyId, int organizationId)
        {
            return organizationId == CSession.GsmOrgIdActual || _gsmCompanyLoader.GetById(companyId).OrganizationId == organizationId;
        }

        public virtual IList<GsmFundOfficeContact> GetFundOfficeContactPersons(int fundOfficeId)
        {
            return _gsmFundOfficeContactRepository.GetByFundOffice(fundOfficeId);
        }
    }
}
