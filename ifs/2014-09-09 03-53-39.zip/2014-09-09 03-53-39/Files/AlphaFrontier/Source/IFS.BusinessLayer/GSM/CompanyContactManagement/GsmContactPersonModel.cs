using System;
using IFS.BusinessLayer.GSM.Immutable;

namespace IFS.BusinessLayer.GSM.CompanyContactManagement
{
    public class GsmContactPersonModel
    {
        public int Id { get; set; }
        public ImmutableGsmContactPerson Person { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? ModifiedByUserId { get; set; }
        public int? ApprovedByUserId { get; set; }
        public bool IsReadyForDelete { get; set; }
        public int OrganizationId { get; set; }
        public bool CanBeRemoved { get; set; }
    }
}