﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.Repository;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Common;
using IFS.Interfaces.Entity;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.GSM.Immutable.Repository
{
    public class ImmutableGsmContactPersonRepository : ImmutableRepositoryBase<ImmutableGsmContactPerson, GsmContactPersonData>
    {
        private readonly IGsmContactPersonOfficesMapper<ImmutableGsmContactPerson, GsmContactPersonData> _officeMapper;
         public ImmutableGsmContactPersonRepository(
            IMapper<ImmutableGsmContactPerson, GsmContactPersonData> mapper, 
            AuditLogger<ImmutableGsmContactPerson> auditLogger, 
            ISequenceProvider sequence) 
        : base(mapper, auditLogger, sequence)
         {
             _officeMapper = mapper as IGsmContactPersonOfficesMapper<ImmutableGsmContactPerson, GsmContactPersonData>;
         }

        // For loader usually
        public virtual ReadOnlyCollection<ImmutableGsmContactPerson> GetAllGsmContactPersons()
        {
            List<IContactPersonOfficeData> contactOffises;
            using (var dbRepository = DbRepositoryFactory.GetContactPersonOfficeDbRepository())
            {
                contactOffises = dbRepository.GetAllOffices().ToList();
            }
            using(var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.SelectAll()
                    .Select(
                        data =>
                        _officeMapper.GetImmutableFromEntity((GsmContactPersonData)data,
                        contactOffises.Where(x => x.ContactPersonId == data.Id)
                        .Select(c => c.CompanyOfficeId).ToList().AsReadOnly()))
                    .ToList().AsReadOnly();
            }
        }

        public virtual ReadOnlyCollection<ImmutableGsmContactPerson> GetContactsForOffice(int officeId, int organizationId, int gsmOrgId)
        {
            List<IContactPersonOfficeData> contactOffises;
            using (var dbRepository = DbRepositoryFactory.GetContactPersonOfficeDbRepository())
            {
                contactOffises = dbRepository.GetAllOffices().ToList();
            }
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.GetContactsForOfficeByOrganization(officeId, organizationId, gsmOrgId)
                        .Select(data => _officeMapper.GetImmutableFromEntity((GsmContactPersonData)data,
                            contactOffises.Where(x => x.ContactPersonId == data.Id)
                        .Select(c => c.CompanyOfficeId).ToList().AsReadOnly()))
                        .ToList().AsReadOnly();
            }
        }

        public virtual ReadOnlyCollection<ImmutableGsmContactPerson> GetContactsForOffice(int officeId)
        {
            List<IContactPersonOfficeData> contactOffises;
            using (var dbRepository = DbRepositoryFactory.GetContactPersonOfficeDbRepository())
            {
                contactOffises = dbRepository.GetAllOffices().ToList();
            }
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.GetContactsForOffice(officeId)
                        .Select(data => _officeMapper.GetImmutableFromEntity((GsmContactPersonData)data,
                            contactOffises.Where(x => x.ContactPersonId == data.Id)
                        .Select(c => c.CompanyOfficeId).ToList().AsReadOnly()))
                        .ToList().AsReadOnly();
            }
        }

        public virtual ReadOnlyCollection<ImmutableGsmContactPerson> GetAvailableContactsForOffice(int companyId, int officeId, bool isOwnCompany, int organizationId)
        {
            List<IContactPersonOfficeData> contactOffises;
            using (var dbRepository = DbRepositoryFactory.GetContactPersonOfficeDbRepository())
            {
                contactOffises = dbRepository.GetAllOffices().ToList();
            }
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.GetAvailableContactsForOffice(companyId, officeId, isOwnCompany, organizationId)
                        .Select(data => _officeMapper.GetImmutableFromEntity((GsmContactPersonData)data,
                            contactOffises.Where(x => x.ContactPersonId == data.Id)
                        .Select(c => c.CompanyOfficeId).ToList().AsReadOnly()))
                        .ToList().AsReadOnly();
            }
        }

        public bool HasRelatedFunds(int contactPersonId)
        {
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.HasRelatedFunds(contactPersonId);
            }
        }

        public bool CanBeRemovedFromOffice(int contactPersonId, int officeId)
        {
            using (var dbRepository = DbRepositoryFactory.GetGsmContactPersonDbRepository())
            {
                return dbRepository.CanBeRemovedFromOffice(officeId, contactPersonId);
            }
        }
    }
}
