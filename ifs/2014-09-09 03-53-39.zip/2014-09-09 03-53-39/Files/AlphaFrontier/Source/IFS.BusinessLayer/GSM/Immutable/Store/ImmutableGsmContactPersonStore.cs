﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.BusinessLayer.GSM.Immutable.Repository;
using IFS.BusinessLayer.Repository;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.BusinessLayer.GSM.Immutable.Store
{
    public class ImmutableGsmContactPersonStore
    {
        public const string PERSON_WITH_EMAIL_ALREADY_EXISTS = "Person with such email already exists";

        private readonly ImmutableGsmContactPersonRepository _contactPersonRepository;
        private readonly GsmFundOfficeContactBlRepository _gsmFundOfficeContactRepository;
        private readonly ILoadable<ImmutableGsmContactPerson> _gsmContactPersonLoader;
        private readonly ImmutableGsmContactPersonRelatedDataProcessor _gsmContactPersonRelatedDataProcessor;
        private readonly ContactPersonHistoryDataProvider _contactPersonHistoryDataProvider;

        public ImmutableGsmContactPersonStore(ImmutableGsmContactPersonRepository contactPersonRepository,
            ILoadable<ImmutableGsmContactPerson> gsmContactPersonLoader, 
            ImmutableGsmContactPersonRelatedDataProcessor gsmContactPersonRelatedDataProcessor,
            ContactPersonHistoryDataProvider contactPersonHistoryDataProvider)
        {
            _contactPersonRepository = contactPersonRepository;
            _gsmContactPersonLoader = gsmContactPersonLoader;
            _gsmContactPersonRelatedDataProcessor = gsmContactPersonRelatedDataProcessor;
            _contactPersonHistoryDataProvider = contactPersonHistoryDataProvider;
        }

        public ReadOnlyCollection<ImmutableGsmContactPerson> GetContactsForOffice(int officeId)
        {
            return _contactPersonRepository.GetContactsForOffice(officeId);
        }
        public ReadOnlyCollection<ImmutableGsmContactPerson> GetContactsForOffice(int officeId, int organizationId)
        {
            return _contactPersonRepository.GetContactsForOffice(officeId, organizationId, CSession.GsmOrgIdActual);
        }

        public bool HasRelatedFunds(int contactPersonId)
        {
            return _contactPersonRepository.HasRelatedFunds(contactPersonId);
        }

        public bool CanBeRemovedFromOffice(int contactPersonId, int officeId)
        {
            return _contactPersonRepository.CanBeRemovedFromOffice(contactPersonId, officeId);
        }

        public ReadOnlyCollection<ImmutableGsmContactPerson> SelectAll()
        {
            return _gsmContactPersonLoader.SelectAll().AsReadOnly();
        }

        public ImmutableGsmContactPerson GetById(int contactId)
        {
            return _gsmContactPersonLoader.GetById(contactId);
        }

        public ReadOnlyCollection<GsmContactPersonView> SelectAllForOrganization(int organizationId, int companyId)
        {
            var gsmOrgId = CSession.GsmOrgIdActual;
            var mapper = new ImmutableGsmContactPersonMapper();
            var result = SelectAll().Where(x => x.OrganizationId == organizationId || x.OrganizationId == gsmOrgId);
            if (companyId > 0)
                result = result.Where(x => x.CompanyId == companyId);
            return result
                .Select(p => mapper.GetView(p, false, _gsmContactPersonRelatedDataProcessor.GetCompanyName(p.CompanyId), GetOfficeNames(p)))
                .OrderBy(x => x.LastName).ToList().AsReadOnly();
        }
        private List<string> GetOfficeNames(ImmutableGsmContactPerson person)
        {
            return (from id in person.ContactOfficeIds
                    select ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetById(id) into office
                    where office != null
                    select office.GetDisplayName()).ToList();
        }

        public ReadOnlyCollection<GsmContactPersonModel> GetContactPersonModelForFundOffice(int organizationId, GsmFundOffice gsmFundOffice)
        {
            var fundOfficeReadyForDelete = gsmFundOffice.IsReadyForDelete;
            var query = from person in SelectAll()
                        join contact in _gsmContactPersonRelatedDataProcessor.GetFundOfficeContactPersons(gsmFundOffice.Id)
                            on person.Id equals contact.ContactPersonId
                        select new GsmContactPersonModel
                        {
                            Id = contact.Id,
                            Person = person,
                            OrganizationId = contact.OrganizationId.HasValue ? contact.OrganizationId.Value : -1,
                            IsReadyForDelete = contact.IsReadyForDelete,
                            ModifiedDate = contact.ModifiedDate,
                            ModifiedByUserId = contact.ModifiedByUserId,
                            ApprovedByUserId = contact.ApprovedByUserId,
                            CanBeRemoved = contact.CanBeRemoved(organizationId, fundOfficeReadyForDelete)
                        };
            return query.ToList().AsReadOnly();
        }

        public ReadOnlyCollection<ImmutableGsmContactPerson> GetContactsAvailableForFund(int officeId, int fundOfficeId, int organizationId)
        {
            var officeContacts = GetContactsForOffice(officeId, organizationId);  // all persons for this office
            var alreadyAdded = _gsmContactPersonRelatedDataProcessor.GetFundOfficeContactPersons(fundOfficeId).Select(c => c.ContactPersonId).ToList();
            return officeContacts.Where(contact => !alreadyAdded.Contains(contact.Id)).OrderBy(x=>x.FirstName).ToList().AsReadOnly();
        }

        public ReadOnlyCollection<ImmutableGsmContactPerson> GetAvailableContactsForOffice(int companyId, int officeId, int organizationId)
        {
            var isOwnCompany = _gsmContactPersonRelatedDataProcessor.IsOwnCompany(companyId, organizationId);
            return _contactPersonRepository.GetAvailableContactsForOffice(companyId, officeId, isOwnCompany, organizationId);
        }

        public int Save(ImmutableGsmContactPerson gsmContactPerson)
        {
            using (var bsd = new BulkSaveData())
            {
                var id = Save(gsmContactPerson, bsd);
                bsd.SubmitChanges();
                return id;
            }
        }
        public int Save(ImmutableGsmContactPerson gsmContactPerson, IBulkSaveData bsd)
        {
            var id = _contactPersonRepository.Save(gsmContactPerson, bsd);
            UpdateRelations(gsmContactPerson, id, bsd);
            bsd.AddObjectToFlush(_gsmContactPersonLoader, null);
            return id;
        }
        private void UpdateRelations(ImmutableGsmContactPerson gsmContactPerson, int newContactPersonId, IBulkSaveData bsd)
        {
            var oc = new ObjectContainer();
            _gsmContactPersonRelatedDataProcessor.ProcessSave(gsmContactPerson, newContactPersonId, oc);
            bsd.AddSaveObjToContext(oc);
            bsd.AddDeleteObjToContext(oc);
        }

        public void Delete(int idToDelete)
        {
            using (var bsd = new BulkSaveData())
            {
                Delete(idToDelete, bsd);
                bsd.SubmitChanges();
            }
        }
        public void Delete(int idToDelete, IBulkSaveData bsd)
        {
            RemoveRelations(idToDelete);
            _contactPersonRepository.Delete(idToDelete, bsd);
            _contactPersonHistoryDataProvider.DeleteHistory(idToDelete);
            bsd.AddObjectToFlush(_gsmContactPersonLoader, null);
        }
        private void RemoveRelations(int idToDelete)
        {
            using (var bsd = new BulkSaveData())
            {
                var oc = new ObjectContainer();
                _gsmContactPersonRelatedDataProcessor.ProcessDelete(idToDelete, oc);
                bsd.AddDeleteObjToContext(oc);
                bsd.SubmitChanges();
            }
        }
       
        public  void RemoveFromOffice(int contactPersonId, int officeId)
        {
             using (var bsd = new BulkSaveData())
            {
                var oc = new ObjectContainer();
                _gsmContactPersonRelatedDataProcessor.RemoveFromOffice(contactPersonId,officeId,oc);
                 bsd.AddObjectToFlush(_gsmContactPersonLoader, null);
                 bsd.AddDeleteObjToContext(oc);
                 bsd.SubmitChanges();
            }
        }
     
    }
}
