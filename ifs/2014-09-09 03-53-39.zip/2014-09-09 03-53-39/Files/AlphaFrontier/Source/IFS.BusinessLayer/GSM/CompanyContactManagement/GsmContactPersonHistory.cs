﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.DataAccess.Entity;
using IFS.DataAccess.shared;

namespace IFS.BusinessLayer.GSM.CompanyContactManagement
{
    [Serializable]
    public class GsmContactPersonHistory : BaseAuditedEntity<GsmContactPersonHistoryData>
    {
        public int ContactPersonId { get; set; }
        public int? GsmCompanyId { get; set; }
        public DateTime ChangeDate { get; set; }
        public string Comments { get; set; }
        public string CompanyName { get; set; }
        public bool IsModified { get; set; }

        public static List<GsmContactPersonHistory> GetPersonHistory(int contactPersonId)
        {
            var query = from history in GetPersonHistoryInternal(contactPersonId)
                        join company in ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().SelectAll()
                            on history.GsmCompanyId equals company.Id into outer
                        from c in outer.DefaultIfEmpty()
                        select new GsmContactPersonHistory
                                   {
                                       Id = history.Id,
                                       ChangeDate = history.ChangeDate,
                                       CompanyName = (c == null ? GsmContactPersonHistoryManager.NOT_SELECTED_COMPANY : c.CompanyName),
                                       Comments = history.Comments,
                                       ContactPersonId = history.ContactPersonId,
                                       GsmCompanyId = history.GsmCompanyId
                                   };
            return query.ToList();
        }

        public static GsmContactPersonHistory GetFilledCommentsHistory(ImmutableGsmContactPerson contact, string commentText)
        {
            var commentsHistory = GetPersonHistory(contact.Id).FirstOrDefault();

            if (commentsHistory == null)
                commentsHistory = new GsmContactPersonHistory();
            else
                commentsHistory.InsertPending = false;

            commentsHistory.ChangeDate = DateTime.Now;
            commentsHistory.ContactPersonId = contact.Id;
            commentsHistory.GsmCompanyId = contact.CompanyId;
            commentsHistory.Comments = commentText;
            commentsHistory.IsModified = true;
            return commentsHistory;
        }
        
        private static IEnumerable<GsmContactPersonHistoryData> GetPersonHistoryInternal(int contactPersonId)
        {
            using (var context = new AfDataContext())
            {
                return context.GetTable<GsmContactPersonHistoryData>().Where(x => x.ContactPersonId == contactPersonId).ToList();
            }
        }
    }
}
