﻿using System.Linq;
using System.Collections.Generic;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.Immutable;

namespace IFS.BusinessLayer.GSM.CompanyContactManagement
{
    // TODO:
    // 1. Investigate possibility to use request cache
    // 2. Move order by to db layer
    // 3. Separate Add and Save functionality.
    public class GsmContactPersonHistoryManager
    {
        public const string NOT_SELECTED_COMPANY = "Not selected";
        private readonly ImmutableGsmContactPerson _contactPerson;
        private List<GsmContactPersonHistory> _history;
        private readonly IContactPersonHistoryDataProvider _dataProvider;

        public List<GsmContactPersonHistory> History
        {
            get { return _history ?? (_history = GetHistory()); }
        }

        public GsmContactPersonHistoryManager(ImmutableGsmContactPerson contactPerson, IContactPersonHistoryDataProvider dataProvider)
        {
            _contactPerson = contactPerson;
            _dataProvider = dataProvider;
        }

        private List<GsmContactPersonHistory> GetHistory()
        {
            return _dataProvider.GetHistory(_contactPerson.Id).OrderByDescending(x => x.ChangeDate).ToList();
        }

        public void Add(GsmContactPersonHistory historyItem)
        {
            if (!historyItem.GsmCompanyId.HasValue)
            {
                historyItem.CompanyName = NOT_SELECTED_COMPANY;
            }
            
            if (History.Count > 0)
            {
                if (historyItem.GsmCompanyId != History[0].GsmCompanyId)
                {
                    History.Insert(0, historyItem);
                }
            }
            else if (historyItem.GsmCompanyId.HasValue)
            {
                History.Insert(0, historyItem);
            }
            
            var modified = History.Where(x => x.IsModified).ToList();
            if (modified.Count > 0)
            {
                _dataProvider.BulkSave(modified);
            }
        }

        public void ClearHistory()
        {
            if (History.Count > 0)
            {
                _dataProvider.BulkDelete(History);
            }
        }
    }

    public interface IContactPersonHistoryDataProvider
    {
        List<GsmContactPersonHistory> GetHistory(int contactPersonId);
        void BulkSave(List<GsmContactPersonHistory> items);
        void BulkDelete(List<GsmContactPersonHistory> items);
    }

    public class ContactPersonHistoryDataProvider : IContactPersonHistoryDataProvider
    {
        public List<GsmContactPersonHistory> GetHistory(int contactPersonId)
        {
            return GsmContactPersonHistory.GetPersonHistory(contactPersonId);
        }
        
        public void BulkDelete(List<GsmContactPersonHistory> items)
        {
            var oc = new ObjectContainer();
            foreach (var item in items)
            {
                item.BulkDelete(oc);
            }
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        public void BulkSave(List<GsmContactPersonHistory> items)
        {
            var oc = new ObjectContainer();
            foreach (var item in items)
            {
                item.BulkSave(oc);
            }
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        public virtual void DeleteHistory(int contactPersonId)
        {
            BulkDelete(GetHistory(contactPersonId));
        }
    }
}
