﻿using System;
using System.Linq;
using System.Collections.Generic;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.BusinessLayer.Repository;
using WebUtilities;

namespace HedgeFrontier.pages.popups.GSM.CompanyContactManagement
{
    public partial class ClientContactPersonDetails : CBasePage
    {
        #region Constants and local variables

        private int _officeId;
        private int _contactId;
        private int _fundOfficeId;
        private ImmutableGsmOffice _office;

        #endregion

        #region  Properties

        private int OfficeId
        {
            get
            {
                if (_officeId != -1 && int.TryParse(Request.QueryString["officeId"], out _officeId))
                    _officeId = _officeId > 0 ? _officeId : -1;

                return _officeId;

            }
        }

        private int ContactId
        {
            get
            {
                if (_contactId != -1 && int.TryParse(Request.QueryString["contactId"], out _contactId))
                    _contactId = _contactId > 0 ? _contactId : -1;

                return _contactId;
            }
        }

        private ImmutableGsmOffice Office
        {
            get { return _office ?? (_office = ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetById(OfficeId)); }
        }

        private int FundOfficeId
        {
            get
            {
                if (_fundOfficeId != -1 && int.TryParse(Request.QueryString["fundOfficeId"], out _fundOfficeId))
                    _fundOfficeId = _fundOfficeId > 0 ? _fundOfficeId : -1;

                return _fundOfficeId;
            }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
                return;

            var user = CSession.User;
            CheckAccessRight(Component.IsAccessible(Component.FUND_MAINTAIN_GLOBAL_CONTACTS, user) ||
                            Component.IsAccessible(Component.FUND_MAINTAIN_RS_CONTACTS, user),
                            user, true);

            if (ContactId == -1 || OfficeId == -1) return;

            SetValues();
        }

        protected void btnSave_OnClick(object sender, EventArgs e)
        {
            var contact = GetGsmContactPersonFilledFromProperties(ContactId);
            try
            {
                var id = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().Save(contact);
                contact = new ImmutableGsmContactPersonMapper().CreateNewWithId(contact, id);
                SaveContactPersonHistory(contact);
                var gsmFundOfficeContactList = new GsmFundOfficeContactBlRepository().GetByFundOfficeId(FundOfficeId);

                if (!(from c in gsmFundOfficeContactList
                      where c.ContactPersonId == ContactId
                      select c).Any())
                    (new GsmFundOfficeContact
                    {
                        FundOfficeId = FundOfficeId,
                        ContactPersonId = contact.Id,
                        OrganizationId = CSession.OrganizationID,
                        ModifiedByUserId = CSession.UserID,
                        ModifiedDate = DateTime.Now
                    }).Save();

                CPopup.RefreshiFrameParentWindow();
                CPopup.Close();
            }
            catch (ValidationException vex)
            {
                spDuplicateEmail.Visible = true;
                spDuplicateEmail.InnerText = vex.Message;
            }
        }

        #region Auxiliary methods

        private void SetValues()
        {
            var contact = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().GetById(ContactId);
            var commentsHistory = GsmContactPersonHistory.GetPersonHistory(contact.Id).FirstOrDefault();

            tbFirstName.Text = contact.FirstName;
            tbLastName.Text = contact.LastName;
            tbRole.Text = contact.Role;
            tbPhone.Text = contact.Phone;
            tbFax.Text = contact.Fax;
            tbEmail.Text = contact.Email;
            tbComments.Text = commentsHistory != null ? commentsHistory.Comments : string.Empty;
        }

        private void SaveContactPersonHistory(ImmutableGsmContactPerson contact)
        {
            var commentsHistory = GsmContactPersonHistory.GetFilledCommentsHistory(contact, tbComments.Text.Trim());

            commentsHistory.Save();
        }

        private ImmutableGsmContactPerson GetGsmContactPersonFilledFromProperties(int contactId)
        {
            return new ImmutableGsmContactPerson(contactId,
                tbFirstName.Text.Trim(),
                tbLastName.Text.Trim(),
                tbRole.Text.Trim(),
                tbPhone.Text.Trim(),
                tbFax.Text.Trim(),
                tbEmail.Text.Trim(),
                Office.CompanyId,
                CSession.OrganizationID,
                new List<int> {OfficeId}.AsReadOnly());

        }


        #endregion
    }
}