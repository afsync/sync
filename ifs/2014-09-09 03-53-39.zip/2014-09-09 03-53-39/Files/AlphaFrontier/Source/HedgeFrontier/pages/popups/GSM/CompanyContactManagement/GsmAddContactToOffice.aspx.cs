﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.Interfaces.CloudContracts.DataContracts;

public partial class pages_popups_GSM_CompanyContactManagement_GsmAddContactToOffice : CBasePage
{
    #region <<< Constants >>>
    private const string CLOSING_SCRIPT = "<script type='text/javascript'>closeWindow('contact');</script>";
    #endregion

    #region <<< Query string parameters >>>
    private int CompanyId
    {
        get
        {
            if (Request.QueryString["companyId"] != null)
            {
                return Convert.ToInt32(Request.QueryString["companyId"]);
            }
            return -1;
        }
    }
    private int OfficeId
    {
        get
        {
            if (Request.QueryString["officeId"] != null)
            {
                return Convert.ToInt32(Request.QueryString["officeId"]);
            }
            return -1;
        }
    }
    #endregion

    #region <<< Event handlers >>>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        CheckAccessRightPopup(Component.GLOBAL_COMPANIES_CONTACTS_MANAGER);
        BindData();
    }

    protected void btnAddToOffice_Click(object sender, EventArgs e)
    {
        var personId = -1;
        int.TryParse(ddlCompanyContacts.SelectedValue, out personId);
        if (personId > 0)
        {
            var personOffice = new ContactPersonOffice { CompanyOfficeId = OfficeId, ContactPersonId = personId };
            personOffice.Save();
            Page.ClientScript.RegisterStartupScript(GetType(), "closeWindow", CLOSING_SCRIPT);
        }
    }

    #endregion

    #region <<< Methods >>>
    private void BindData()
    {
        var mapper = new ImmutableGsmContactPersonMapper();
        var persons =
            ImmutableRepositoryFactory.ImmutableGsmContactPersonStore()
                .GetAvailableContactsForOffice(CompanyId, OfficeId, CSession.CurrentOrganization.OrganizationID)
                .Select(c => mapper.GetView(c, false,string.Empty,new List<string>())).ToList();
        persons.Insert(0, new GsmContactPersonView{ Id = -1 ,FullName = "Not selected"});
        ddlCompanyContacts.DataSource = persons;
        ddlCompanyContacts.DataTextField = "FullName";
        ddlCompanyContacts.DataValueField = "Id";
        ddlCompanyContacts.DataBind();
        ddlCompanyContacts.Attributes.Add("onchange",String.Format("setButton(this,'{0}');",btnAddToOffice.ClientID));
    }

    #endregion
}