﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.FundProperty;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;

public partial class pages_popups_GlobalContactDetailPopup : CBasePage
{
    #region Properties
    private string ContactId
    {
        get { return Request.QueryString["contactId"]; }
    }
    private int _fundId = -1;
    private int FundID
    {
        get
        {
            if (-1 == _fundId && (IFSSession.MainTab == EMainTab.FUNDS || IFSSession.MainTab == EMainTab.GSM_MAIN))
                _fundId = IFSSession.BaseFundId;
            return _fundId;
        }
    }
    #endregion

    #region Page Events
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
            return;

        var user = CSession.User;
        CheckAccessRight((Component.IsAccessible(Component.FUND_MAINTAIN_GLOBAL_CONTACTS, user) ||
                        Component.IsAccessible(Component.FUND_MAINTAIN_RS_CONTACTS, user)) &&
                        Component.IsAccessible(Component.FUND_MAINTAIN_GENERAL_FUND_INFO, user),
                        user, true);
        BindData();
    }
    #endregion

    #region Methods
    private void BindData()
    {
        BaseFund baseFund = BaseFund.Loader.GetById(FundID);
        var person = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().GetById(ContactId.ParseInteger());

        if (baseFund == null || person == null)
            return;

        rpContacts.DataSource = new List<ImmutableGsmContactPerson> { person };
        rpContacts.DataBind();

        var company = ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().GetById(person.CompanyId == null ? -1 : person.CompanyId.Value);
        if (company != null)
        {
            rpCompanies.DataSource = new List<ImmutableGsmCompany>{ company };
            rpCompanies.DataBind();
        }

        var officeList = ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetFundOffices(baseFund)
                            .Select(f => f.Office)
                            .Where(office => person.ContactOfficeIds.IndexOf(office.Id) != -1).ToList();
        rpOffices.DataSource = officeList;
        rpOffices.DataBind();
    }
    #endregion
}