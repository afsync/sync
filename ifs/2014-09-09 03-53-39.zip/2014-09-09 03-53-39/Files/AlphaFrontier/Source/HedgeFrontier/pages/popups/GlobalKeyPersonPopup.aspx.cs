﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using IFS.BusinessLayer.FundProperty.GeneralFundProperty;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Mapper;
using IFS.BusinessLayer.GSM.Immutable.Store;
using IFS.Interfaces.CloudContracts.DataContracts;
using WebUtilities;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;

public partial class Pages_Fund_Maintain_GlobalKeyPersonPopup : CBasePage
{
    private readonly ImmutableGsmOfficeStore _gsmOfficeRepository = ImmutableRepositoryFactory.ImmutableGsmOfficeStore();
    private readonly ImmutableGsmContactPersonStore _gsmGsmContactPersonStore = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();
    
    #region Properties
    private int _fundId = -1;
    private int FundID
    {
        get
        {
            if (-1 == _fundId && (IFSSession.MainTab == EMainTab.FUNDS || IFSSession.MainTab == EMainTab.GSM_MAIN))
                _fundId = IFSSession.BaseFundId;
            return _fundId;
        }
    }
    #endregion

    #region Page Events
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
            return;

        var user = CSession.User;
        CheckAccessRight((Component.IsAccessible(Component.FUND_MAINTAIN_GLOBAL_CONTACTS, user) ||
                        Component.IsAccessible(Component.FUND_MAINTAIN_RS_CONTACTS, user)) &&
                        Component.IsAccessible(Component.FUND_MAINTAIN_GENERAL_FUND_INFO, user),
                        user, true);

        BindData();
    }

    protected void gvKeyPersons_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        DataKey key = gvKeyPersons.DataKeys[index];
        int contactID = Convert.ToInt32(key.Value);
        SaveKeyPerson(contactID);
    }

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        UnderlyingFund fund = UnderlyingFund.GetFund(FundID);

        if (!(fund is BaseFund))
            return;

        var gsmFundOfficeId = Convert.ToInt32(ddlCompany.SelectedValue);
        var gsmFundOffice =  GsmFundOffice.Loader.GetById(gsmFundOfficeId);
        var contactList =  _gsmGsmContactPersonStore.GetContactPersonModelForFundOffice(CSession.OrganizationID, gsmFundOffice);
        var keyPersons = ((BaseFund)fund).BaseFundProperties.KeyPersons.KeyPersons.ToList();

        ddlContact.DataSource = contactList.Select(contact => contact.Person).Where(person => !keyPersons.Any(kp => kp.KeyPersonType == KeyPerson.GLOBAL_CONTACT &&
                                                                                                                    kp.KeyPersonId == person.Id)).ToList();
        ddlContact.DataBind();

        CDropDown.BlankItem(ddlContact);
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (ddlContact.SelectedIndex > 0)
            SaveKeyPerson(int.Parse(ddlContact.SelectedValue));
    }

    protected void imgbtnGo_Click(object sender, ImageClickEventArgs e)
    {
        BaseFund baseFund = BaseFund.Loader.GetById(FundID);
        if (null == baseFund)
            return;

        string search = txtSearch.Text.ToLower();

        var officeList = _gsmOfficeRepository.GetFundOffices(baseFund);

        gvKeyPersons.DataSource = GetOfficeContactPersonsBySearchCriteria(officeList, search);
        gvKeyPersons.DataBind();

        SetDropDownDelectedIndexToDefault();
    }

    private void SetDropDownDelectedIndexToDefault()
    {
        CDropDown.SetValue(ddlCompany, -1);
        CDropDown.SetValue(ddlContact, -1);
    }

    private List<GsmContactPersonView> GetOfficeContactPersonsBySearchCriteria(IEnumerable<GsmOfficeModel> officeList, string search)
    {
        var contactList = new List<GsmContactPersonView>();
        var contactPersonMapper = new ImmutableGsmContactPersonMapper();
        foreach (var office in officeList)
        {
            var companyRepository = ImmutableRepositoryFactory.ImmutableGsmCompanyStore();
            int fundOfficeId = office.Id;
            var gsmFundOffice = GsmFundOffice.Loader.GetById(fundOfficeId);
            contactList.AddRange(_gsmGsmContactPersonStore.GetContactPersonModelForFundOffice(CSession.OrganizationID, gsmFundOffice)
                .Select(contact =>
                {
                    var companyName = companyRepository.GetById((int) contact.Person.CompanyId).CompanyName;
                    return contactPersonMapper.GetView(contact.Person, false, companyName, new List<string>());
                })
                .Where(person => person.FirstName.ToLower().IndexOf(search.ToLower()) != -1 || person.LastName.ToLower().IndexOf(search.ToLower()) != -1));
        }
        return contactList;
    }

    #endregion

    #region Methods
    private void SaveKeyPerson(int contactId)
    {
        UnderlyingFund fund = UnderlyingFund.GetFund(FundID);

        if (fund == null || !(fund is BaseFund))
            return;

        KeyPersonsProperties keyPersonsProperties = ((BaseFund)fund).BaseFundProperties.KeyPersons;

        if (!keyPersonsProperties.KeyPersons.Any(keyPerson => keyPerson.KeyPersonType == KeyPerson.GLOBAL_CONTACT && keyPerson.KeyPersonId == contactId))
        {
            ((BaseFund)fund).BaseFundProperties.ModifiedByUserId = CSession.UserID;
            keyPersonsProperties.AddGlobalKeyPerson(contactId);
            keyPersonsProperties.Save();
        }

        // refresh parent window
        CPopup.RefreshParentPage(true);

    }

    private void AddCompaniesToDdl(IEnumerable<GsmOfficeModel> officeList)
    {
        foreach (GsmOfficeModel office in officeList)
        {
            if (AttributeGroup.ADDRESS != office.GroupId)
            {
                var gsmCompany = ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().GetById(office.Office.CompanyId);
                ddlCompany.Items.Add(new ListItem((null != gsmCompany ? gsmCompany.CompanyName + " : " : "") + office.Office.GetDisplayName(), office.Id.ToString()));
            }
        }
    }

    private void BindData()
    {
        // Bind Company Dropdown
        var baseFund = BaseFund.Loader.GetById(FundID);
        if (baseFund == null)
            return;

        AddCompaniesToDdl(_gsmOfficeRepository.GetFundOffices(baseFund));
        CDropDown.BlankItem(ddlCompany);
        ddlCompany_SelectedIndexChanged(null, null);
    }
    #endregion
}
