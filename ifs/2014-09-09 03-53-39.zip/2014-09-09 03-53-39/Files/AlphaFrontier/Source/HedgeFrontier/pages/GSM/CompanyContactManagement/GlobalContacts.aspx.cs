﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.Interfaces.CloudContracts.DataContracts;

public partial class pages_GSM_CompanyContactManagement_GlobalContacts : CBasePage
{
    private const string JS_SHOWPERSONPOPUP = "javascript:OW_ShowGsmPersonDetails(-1,{0}); return false;";

    protected void Page_PreInit(object sender, EventArgs e)
    {
        ((GlobalCompanyContact)Master).OnFilterChanged += Rebind;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CheckAccessRight(Component.GLOBAL_COMPANIES_CONTACTS_MANAGER);
            IFSSession.SubTab = ESubTab.GLOBAL_CONTACTS;
            BindAddPerson(-1);
            BindData();
        }
    }
    protected void btnRefreshContacts_Click(object sender, EventArgs e)
    {
        BindData();
    }

    private void BindAddPerson(int selectedCompanyId)
    {
        btnAddPerson.Attributes.Add("onclick", String.Format(JS_SHOWPERSONPOPUP, selectedCompanyId));
    }

    private void BindData()
    {
        gsmContactPersonList.BindData(GetPersonsList().OrderBy(x=>x.LastName));
    }
    private void Rebind(object sender, GlobalCompanyContact.FilterEventArgs args)
    {
        gsmContactPersonList.BindData(GetPersonsList(args.FilterId));
        BindAddPerson(args.FilterId);
    }
    private static IEnumerable<GsmContactPersonView> GetPersonsList(int companyId = -1)
    {
        return ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().SelectAllForOrganization(CSession.OrganizationID,companyId);
    }
}
