﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Store;
using ListItem = System.Web.UI.WebControls.ListItem;

public partial class pages_popups_GSM_CompanyContactManagement_GsmContactPersonDetails : CBasePage
{
    #region <<< Constants >>>

    private const string CLOSING_SCRIPT = "<script type='text/javascript'>closeWindow('contacts');</script>";
    private const string JS_CONFIRMREMOVE = "return confirmRemove('{0}');";

    #endregion

    public bool IsReadonly { get; set; }
    public bool IsEnabled { get; set; }
    private bool _hasFullAccess;

    public bool IsHistoryCommentEditable
    {
        get { return _hasFullAccess; }
    }

    private ImmutableGsmContactPerson _contact;

    private ImmutableGsmContactPerson Contact
    {
        get
        {
            _contact = ContactId > 0
                ? _contact ?? (_contact = _contactPersonStore.GetById(ContactId))
                : new ImmutableGsmContactPerson(contactOfficeIds: new List<int>().AsReadOnly());

            return _contact;

        }
    }

    private readonly ImmutableGsmContactPersonStore _contactPersonStore =
        ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();

    private GsmContactPersonHistoryManager _historyManager;

    private GsmContactPersonHistoryManager HistoryManager
    {
        get
        {
            return _historyManager ??
                   (_historyManager =
                       new GsmContactPersonHistoryManager(Contact, new ContactPersonHistoryDataProvider()));
        }
    }

    private int ContactId
    {
        get
        {
            var contactId = Request.QueryString["contactId"];
            return string.IsNullOrEmpty(contactId) ? -1 : Convert.ToInt32(contactId);
        }
    }

    private int SelectedCompanyId
    {
        get
        {
            var selectedCompanyId = Request.QueryString["selectedCompanyId"];
            return string.IsNullOrEmpty(selectedCompanyId) ? -1 : Convert.ToInt32(selectedCompanyId);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        var user = CSession.User;
        var accessRight = Component.GetAccessRight(Component.GLOBAL_COMPANIES_CONTACTS_MANAGER, user);

        _hasFullAccess = (accessRight == ERight.READ_WRITE) && Contact.IsEditableByOrganization(CSession.OrganizationID);
        SetEnabled();
        BindScript();
        if (IsPostBack) return;
        CheckAccessRight(accessRight != ERight.NONE, user, true);
        BindData();
    }

    private void SetEnabled()
    {
        IsEnabled = _hasFullAccess;
        tbFirstName.Enabled = _hasFullAccess;
        tbLastName.Enabled = _hasFullAccess;
        tbRole.Enabled = _hasFullAccess;
        tbPhone.Enabled = _hasFullAccess;
        tbFax.Enabled = _hasFullAccess;
        tbEmail.Enabled = _hasFullAccess;
        ddlCompany.Enabled = _hasFullAccess;
        btnSave.Enabled = _hasFullAccess;
        SetDeleteButton();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().Delete(Contact.Id);
        Page.ClientScript.RegisterStartupScript(GetType(), "closeWindow", CLOSING_SCRIPT);

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        _contact = new ImmutableGsmContactPerson(_contact.Id, tbFirstName.Text.Trim(), tbLastName.Text.Trim(),
            tbRole.Text,
            tbPhone.Text, tbFax.Text, tbEmail.Text, GetCompanyId(), CSession.OrganizationID,
            ddlOffices.SelectedItems.ToList().AsReadOnly());
        try
        {
            var store = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();
            new ImmutableGsmContactPersonHelper().ValidateContactEmailMustBeUnique(_contact, store);
            var contactId = store.Save(_contact);
            ModifyComments();
            var history = new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = contactId,
                GsmCompanyId = _contact.CompanyId,
                Comments = tbComments.Text,
                IsModified = true
            };
            HistoryManager.Add(history);
            Page.ClientScript.RegisterStartupScript(GetType(), "closeWindow", CLOSING_SCRIPT);
        }
        catch (ValidationException vex)
        {
            spDuplicateEmail.Visible = true;
            spDuplicateEmail.InnerText = vex.Message;
        }
    }

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        // new contact not affected cache 
        //var contact = new GsmContactPerson {ContactCompanyId = GetCompanyId()};
        //BindOffices(contact.GetSelected());
        var companyId = GetCompanyId();
        var selectedOffices = ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetSelectedOffices(
            companyId.HasValue ? companyId.Value : -1, new List<int>());
        BindOffices(selectedOffices);
    }

    private void SetDeleteButton()
    {
        btnDelete.Enabled = ContactId > 0;
        if (!_hasFullAccess)
        {
            btnDelete.Enabled = false;
            btnDelete.ToolTip = "Sorry, your role of " + CSession.User.Role.RoleName +
                                " does not permit you to delete contact person";
        }
        else
        {
            if (ContactId > 0)
            {
                var hasFunds = _contactPersonStore.HasRelatedFunds(ContactId);
                btnDelete.Enabled = !hasFunds;
                if (!btnDelete.Enabled)
                {
                    btnDelete.ToolTip = "Please remove the contact person from any associated funds before deleting";
                }

            }
        }
    }

    private void BindCompaniesList()
    {
        if (_hasFullAccess)
        {
            var companies =
                ImmutableRepositoryFactory.ImmutableGsmCompanyStore()
                    .SelectOrganizationCompanies(CSession.CurrentOrganization.OrganizationID)
                    .Select(x => new GsmCompanyModel
                    {
                        CompanyId = x.Id,
                        CompanyName = x.CompanyName
                    }).OrderBy(x => x.CompanyName).ToList();
            companies.Insert(0, new GsmCompanyModel {CompanyId = -1, CompanyName = "Not Selected"});
            ddlCompany.DataSource = companies;
            ddlCompany.DataTextField = "CompanyName";
            ddlCompany.DataValueField = "CompanyId";
            ddlCompany.DataBind();
            var companyId = Contact.CompanyId > 0 ? Contact.CompanyId : SelectedCompanyId;
            if (companyId > 0)
            {
                ddlCompany.SelectedValue = companyId.ToString();
            }
        }
        else
        {
            ddlCompany.Items.Clear();
            if (Contact != null && Contact.CompanyId.HasValue)
            {
                var company = ImmutableRepositoryFactory.ImmutableGsmCompanyStore().GetById((int) Contact.CompanyId);
                ddlCompany.Items.Add(company != null
                    ? new ListItem {Text = company.CompanyName, Value = company.Id.ToString()}
                    : new ListItem {Text = "Not Selected", Value = "-1"});
            }
        }
    }

    private void BindData()
    {
        tbFirstName.Text = Contact.FirstName;
        tbLastName.Text = Contact.LastName;
        tbRole.Text = Contact.Role;
        tbPhone.Text = Contact.Phone;
        tbFax.Text = Contact.Fax;
        tbEmail.Text = Contact.Email;
        BindCompaniesList();
        var officestore = ImmutableRepositoryFactory.ImmutableGsmOfficeStore();
        int companyId = Contact != null && Contact.CompanyId.HasValue ? (int) Contact.CompanyId : -1;
        BindOffices(officestore.GetSelectedOffices(companyId, Contact.ContactOfficeIds));
        BindHistory();
        trComments.Attributes.Add("companyId", companyId.ToString(CultureInfo.InvariantCulture));
    }

    private void BindHistory()
    {
        rpContactPersonHistory.DataSource = HistoryManager.History;
        rpContactPersonHistory.DataBind();
    }

    private string GetScript(ICollection<SelectedOffice> data)
    {
        var result = string.Empty;
        var list = new List<string>();
        if (data.Count > 0)
        {
            list.AddRange(from item in data
                where !_contactPersonStore.CanBeRemovedFromOffice(Contact.Id, item.OfficeId)
                select item.OfficeId.ToString());
            if (list.Count > 0)
            {
                result = string.Format(JS_CONFIRMREMOVE, string.Join(", ", list));
            }
        }
        return result;
    }

    private void BindOffices(ICollection<SelectedOffice> data)
    {
        var onClickScript = GetScript(data);
        if (!string.IsNullOrEmpty(onClickScript))
        {
            btnSave.Attributes.Add("onclick", onClickScript);
        }

        lblNoData.Visible = data.Count <= 0;

        ddlOffices.DataSource = data;
        ddlOffices.DataBind();
        ddlOffices.SelectedItems = data.Where(x => x.IsSelected).Select(x => x.OfficeId).ToList();
        ddlOffices.Enabled = _hasFullAccess;
    }

    private int? GetCompanyId()
    {
        int companyId;
        int.TryParse(ddlCompany.SelectedValue, out companyId);
        return companyId != -1 ? companyId : (int?) null;
    }

    private void ModifyComments()
    {
        foreach (RepeaterItem item in rpContactPersonHistory.Items)
        {
            var tb = item.FindControl("tbComments") as TextBox;
            if (tb != null)
            {
                UpdateHistoryItem(tb);
            }
        }
    }

    private void UpdateHistoryItem(TextBox tb)
    {
        var comment = tb.Text;
        int id;
        int.TryParse(tb.Attributes["historyId"], out id);
        if (id > 0)
        {
            var historyItem = HistoryManager.History.SingleOrDefault(x => x.Id == id);
            if (historyItem != null && historyItem.Comments != comment)
            {
                historyItem.IsModified = true;
                historyItem.Comments = comment;
                historyItem.InsertPending = false;
            }
        }
    }

    private void BindScript()
    {
        ddlCompany.Attributes.Add("onchange", "setComments(this, '" + trComments.ClientID + "');");
    }

    private class GsmCompanyModel
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}