﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.GSM.Immutable.Store;
using IFS.BusinessLayer.Repository;
using IFS.Interfaces.Common;
using WebUtilities;

public partial class usercontrols_contacts_UCOfficeContacts : CBaseUserControl
{
    #region <<< Constants >>>
    private const string JS_ADDCONTACT = "javascript:addContactToOffice({0},{1}); return false;";
    private const string JS_ADD_CLIENT_CONTACT = "javascript:addClientContactToOffice({0},{1},{2}); return false;";
    private const string JS_CONFIRM_CONTACT = "return confirm('Are you sure you want to remove this contact?');";
    #endregion

    #region <<< Members >>>
    public bool IsRsContact { get; set; }
    private OfficeContactsBindingContext _context;

    private int? _lastModifiedUserId;
    public int? LastModifiedUserId
    {
        get { return _lastModifiedUserId ?? -1; }
        set { _lastModifiedUserId = value; }
    }

    private DateTime? _lastModifiedDate;
    public DateTime? LastModifiedDate
    {
        get { return _lastModifiedDate ?? DateTime.MinValue; }
        set { _lastModifiedDate = value; }
    }
    #endregion

    #region <<< Event handlers >>>
    protected void rpContacts_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        var contact = e.Item.DataItem as GsmContactPersonModel;
        if(contact == null) 
            return;

        var btn = e.Item.FindControl("btnRemoveContact") as ImageButton;
        if (btn != null)
            BindRemoveButton(btn, contact);
        
        var script = String.Format(JS_ADD_CLIENT_CONTACT, contact.Person.Id, _context.OfficeId, _context.FundOfficeId);

        var gsmOrgId = CSession.GsmOrgIdActual;//CSession.GSMOrgId;
        var spContactDetails = e.Item.FindControl("spContactDetails") as HtmlControl;
        spContactDetails.Visible = contact.OrganizationId == gsmOrgId;
        if (contact.OrganizationId != gsmOrgId)
        {
            var hlContactDetails = e.Item.FindControl("hlContactDetails") as HyperLink;
            hlContactDetails.Visible = true;
            hlContactDetails.Attributes.Add("onclick", script);
        }

        var pn = e.Item.FindControl("pnContactDetails") as Panel;
        if (pn != null)
        {
            var isReadyForDelete = e.Item.FindControl("lblIsReadyForDelete") as Label;
            if (_context.IsGsm && isReadyForDelete != null)
                isReadyForDelete.Visible = contact.IsReadyForDelete;
            BindDetails(contact.Person, pn);
        }
    }

    protected void btnRemoveContact_Click(object sender, ImageClickEventArgs e)
    {
        var btn = sender as ImageButton;
        if (btn != null)
        {
            int removeContactId;
            if (int.TryParse(btn.CommandArgument, out removeContactId))
            {
                var fundOfficeContact = new GsmFundOfficeContactBlRepository().GetById(removeContactId);
                if (fundOfficeContact != null) 
                    fundOfficeContact.Delete();
            }
        }
    }
    #endregion

    #region <<< Methods >>>
    private void BindRemoveButton(ImageButton btn, GsmContactPersonModel contact)
    {
        if (!contact.CanBeRemoved)
        {
            btn.Attributes.Add("style", "visibility:hidden");
        }
        else
        {
            if (_context.IsReadOnly)
            {
                btn.Attributes.Add("onclick", CPopup.NoAccessMsg);
            }
            else
            {
                btn.CommandArgument = contact.Id.ToString();
                btn.Attributes.Add("onclick", JS_CONFIRM_CONTACT);
            }
        }
    }

    private static void BindDetails(ImmutableGsmContactPerson person, Control pnDetails)
    {
        SetRowVisibility(pnDetails, "dvRole", person.Role);
        SetRowVisibility(pnDetails, "dvPhone", person.Phone);
        SetRowVisibility(pnDetails, "dvFax", person.Fax);
        SetRowVisibility(pnDetails, "dvEmail", person.Email);
    }

    public void BindData(OfficeContactsBindingContext context)
    {
        _context = context;
        BindAddButton();

        int fundOfficeId = context.FundOfficeId;
        var gsmFundOffice = GsmFundOffice.Loader.GetById(fundOfficeId);
        var data = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().GetContactPersonModelForFundOffice(CSession.OrganizationID, gsmFundOffice);

        SetLastModificationInfo(data);
        rpContacts.DataSource = data;
        rpContacts.DataBind();
    }

    private void SetLastModificationInfo(IEnumerable<GsmContactPersonModel> data)
    {
        var info = CSession.IsGSM
            ? new ImmutableGsmContactPersonHelper().GetLastModificationInfo(data)
            : new UserAndDate();
        LastModifiedUserId = info.UserId;
        LastModifiedDate = info.Date;
    }

    private void BindAddButton()
    {
        var isEnabled = !_context.Fund.IsGSMFund || !_context.IsOfficeReadyForDelete;
        btnAddContact.Enabled = isEnabled && Component.HasFullAccess(IsRsContact ? Component.FUND_MAINTAIN_RS_CONTACTS : Component.FUND_MAINTAIN_GLOBAL_CONTACTS, CSession.User);

        if (btnAddContact.Enabled)
        {
            btnAddContact.Attributes.Add("onclick", _context.IsReadOnly ? CPopup.NoAccessMsg : !_context.Fund.IsGSMFund && !IsRsContact
                    ? string.Format(JS_ADD_CLIENT_CONTACT, 0, _context.OfficeId, _context.FundOfficeId)
                      : string.Format(JS_ADDCONTACT, _context.OfficeId, _context.FundOfficeId));
        }
    }

    private static void SetRowVisibility(Control details, string id, string val)
    {
        var dv = details.FindControl(id) as HtmlGenericControl;
        if (dv != null)
            dv.Visible = !string.IsNullOrEmpty(val);
    }
    #endregion
}