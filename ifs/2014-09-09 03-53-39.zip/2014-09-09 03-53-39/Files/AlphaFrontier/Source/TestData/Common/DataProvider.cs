﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Loader;
using IFS.BusinessLayer.Utilities;
using TestData.DataObjects;
using IFS.BusinessLayer.Common;
using IFS.Interfaces.Common.Enums;
using TestData.Interfaces;

namespace TestData.Common
{
    public class DataProvider
    {
        private readonly Dictionary<int, List<InvestableFund>> Funds = new Dictionary<int, List<InvestableFund>>();
        private readonly Dictionary<int, List<KeyValuePair<int, string>>> Portfolios = new Dictionary<int, List<KeyValuePair<int, string>>>();
        private readonly Dictionary<int, Dictionary<string, List<EnumValue>>> EnumValues = new Dictionary<int, Dictionary<string, List<EnumValue>>>();
        private readonly Dictionary<int, bool> IsPortoflioLoadedforClient = new Dictionary<int, bool>();
        private readonly Dictionary<string, BaseFund> GsmFundsCache = new Dictionary<string, BaseFund>();

        private List<ImmutableGsmCompany> _globalCompanies;
        public List<ImmutableGsmCompany> GetGlobalCompaniesSafeList()
        {
            if (_globalCompanies == null)
                _globalCompanies = ImmutableLoaderFactory.GetImmutableGsmCompanyLoader().SelectAll();
            lock (Locks.GsmCompanyLock)
            {
                return _globalCompanies.ToList();
            }
        }

        public void AddGlobalCompany(ImmutableGsmCompany company)
        {
            lock (Locks.GsmCompanyLock)
            {
                _globalCompanies.Add(company);
            }
        }

        public void DeleteGlobalCompany(ImmutableGsmCompany company)
        {
            lock (Locks.GsmCompanyLock)
            {
                _globalCompanies.Remove(company);
            }
        }
        private List<ImmutableGsmContactPerson> _globalContactPersons;
        public List<ImmutableGsmContactPerson> GlobalContactPersons
        {
            get { return _globalContactPersons ?? (_globalContactPersons = GetContacts()); }
        }

        private List<EnumValue> _reliefMethodology;
        private List<EnumValue> ReliefMethodology
        {
            get
            {
                return _reliefMethodology ??
                       (_reliefMethodology =
                        new EnumValueHelper(EnumGroup.RELIEF_METHODOLOGY, CSession.OrganizationID).SelectForGroup());
            }
        }

        public void InitializeCache()
        {
            Organization.Loader.SelectAll();
            EnumValue.Loader.SelectAll();
            EnumGroup.Loader.SelectAll();
            User.Loader.SelectAll();
        }

        public void ClearLocalCache()
        {
            Funds.Clear();
            Portfolios.Clear();
            EnumValues.Clear();
            IsPortoflioLoadedforClient.Clear();
            GsmFundsCache.Clear();
        }

        public void LoadPortfolios(int organizationId)
        {
            lock (Locks.PortfolioLock)
            {
                if (!IsPortoflioLoadedforClient.ContainsKey(organizationId))
                {
                    Portfolio.Loader.SelectAll(new List<int> { organizationId });
                    IsPortoflioLoadedforClient[organizationId] = true;
                }
            }
        }

        public List<InvestableFund> GsmFunds(bool isDemo)
        {
            lock (Locks.FundLock)
            {
                var organizationId = isDemo ? AppConfiguration.GsmDemoOrganizationId : AppConfiguration.GsmOrganizationId;
                if (!Funds.ContainsKey(organizationId))
                    Funds[organizationId] = GetFunds(organizationId);
                return new List<InvestableFund>(Funds[organizationId]);
            }
        }

        public List<int> GetPortfolioOrganizations()
        {
            return Portfolios.Keys.ToList();
        }

        public bool CafmBulkDelete { get; set; }

        private static DataProvider _instance;
        public static DataProvider Instance
        {
            get { return _instance ?? (_instance = new DataProvider()); }
        }

        public int GetOrganizationIdByName(string organizationName)
        {
            if (String.IsNullOrEmpty(organizationName))
                throw new ValidationException("missing organization name for client fund");

            var client = Organization.Loader.GetByName(organizationName, -1);
            if (client == null)
                throw new CriticalException("Client with name " + organizationName + " doesn't exist. Create it first, exiting.", null);
            return client.OrganizationID;
        }

        public Organization GetOrganizationByName(string organizationName)
        {
            return Organization.Loader.GetByName(organizationName, -1);
        }

        public Organization GetOrganizationById(int organizationId)
        {
            var client = Organization.Loader.GetById(organizationId);
            if (client == null)
                throw new CriticalException("Client with Id " + organizationId + " doesn't exist. Create it first, exiting.", null);
            return client;
        }

        public BaseFund GetBaseFundByName(string fundName, int organizationId)
        {
            lock (Locks.FundLock)
            {
                if (!Funds.ContainsKey(organizationId))
                    Funds[organizationId] = GetFunds(organizationId);
                return (BaseFund)Funds[organizationId].FirstOrDefault(f =>
                    f.FundType == SystemType.BASEFUND && f.GetAllNames().Any(n => InvestableFund.GetClearName(n) == fundName));
            }
        }

        public int GetFundType(BaseFund fund)
        {
            var bf = fund.GsmFundId > 0 ? BaseFund.Loader.GetById(fund.GsmFundId) : fund;
            return bf.FormOfEntitySupportsFundSeries ? SystemType.FUND_SERIES : SystemType.FUND_CLASS;
        }

        public void AddFundToCache(InvestableFund fund)
        {
            lock (Locks.FundLock)
            {
                if (!Funds.ContainsKey(fund.OrganizationID))
                    Funds[fund.OrganizationID] = new List<InvestableFund>();

                Funds[fund.OrganizationID].Add(fund);
                fund.CacheKey = fund is BaseFund
                                    ? BaseFund.Loader.GetCacheKey(fund.FundID)
                                    : InvestableFund.Loader.GetCacheKey(fund.FundID);
                GlobalRuntimeCache.Insert(fund);
            }
        }

        public void DeleteBaseFundFromCache(InvestableFund fund)
        {
            lock (Locks.FundLock)
            {
                List<InvestableFund> funds;
                if (Funds.TryGetValue(fund.OrganizationID, out funds))
                    funds.Remove(fund);
            }
        }

        public void AddPortfolioToCache(Portfolio portfolio)
        {
            lock (Locks.PortfolioLock)
            {
                if (!Portfolios.ContainsKey(portfolio.OrganizationID))
                {
                    Portfolios[portfolio.OrganizationID] = new PortfolioCollection(UnderlyingFund.SelectPortfolios(UserUtil.ADMIN_USER_ID,
                        portfolio.OrganizationID)).Select(p => new KeyValuePair<int, string>(p.PortfolioID, p.FundName)).ToList();
                }
                Portfolios[portfolio.OrganizationID].Add(new KeyValuePair<int, string>(portfolio.PortfolioID, portfolio.FundName));
                portfolio.CacheKey = Portfolio.Loader.GetCacheKey(portfolio.PortfolioID);
                GlobalRuntimeCache.Insert(portfolio);
            }
        }

        public Portfolio GetPortfolioByName(string name, int organizationId)
        {
            lock (Locks.PortfolioLock)
            {
                if (!Portfolios.ContainsKey(organizationId))
                {
                    Portfolios[organizationId] = new PortfolioCollection(UnderlyingFund.SelectPortfolios(UserUtil.ADMIN_USER_ID, organizationId))
                            .Select(p => new KeyValuePair<int, string>(p.PortfolioID, p.FundName)).ToList();
                }
                var pId = Portfolios[organizationId].FirstOrDefault(p => p.Value == name);
                return pId.Key != 0 ? Portfolio.Loader.GetById(pId.Key) : null;
            }
        }

        private string GetPortfolioKey(PortfolioData portfolio)
        {
            return portfolio.PortfolioName + "_" + portfolio.OrganizationName;
        }

        public void AddEnumValuesToCache(PortfolioData portfolio, int enumValueGroupId, List<EnumValue> enumValues)
        {
            if (!enumValues.Any())
                return;

            var portfolioKey = GetPortfolioKey(portfolio);
            lock (Locks.EnumValuesLock)
            {
                if (!EnumValues.ContainsKey(enumValueGroupId))
                    EnumValues.Add(enumValueGroupId, new Dictionary<string, List<EnumValue>>());

                if (!EnumValues[enumValueGroupId].ContainsKey(portfolioKey))
                    EnumValues[enumValueGroupId][portfolioKey] = new List<EnumValue>();

                EnumValues[enumValueGroupId][portfolioKey].AddRange(enumValues);
            }
        }

        public IEnumerable<EnumValue> GetEnumValuesForPortfolio(PortfolioData portfolio, int enumValueGroupId)
        {
            var portfolioKey = GetPortfolioKey(portfolio);
            List<EnumValue> val;
            lock (Locks.EnumValuesLock)
            {
                if (!EnumValues.ContainsKey(enumValueGroupId) ||
                    !EnumValues[enumValueGroupId].TryGetValue(portfolioKey, out val))
                    throw new ValidationException("No enum value for portfolio:" + portfolio.PortfolioName);
            }
            return val;
        }

        public EnumValue GetEnumValueByName(PortfolioData portfolio, int enumValueGroupId, string enumValueName)
        {
            var enumValues = GetEnumValuesForPortfolio(portfolio, enumValueGroupId);
            var enumValue = enumValues.FirstOrDefault(c => c.EnumValueName == enumValueName);
            if (enumValue == null)
                throw new ValidationException("No enum value with name " + enumValueName + " for portfolio:" + portfolio.PortfolioName);

            return enumValue;
        }

        public int GetTypeIdByName(string name)
        {
            var type = new CompanyTypeDataProvider().GetCompanyGroupList().SingleOrDefault(x => x.Name.ToLower() == name);
            return type != null ? type.AttributeGroupId : -1;
        }

        public Series CloneSeries(Series series)
        {
            LoadToCache(series);  // workaround to avoid clone 
            return Series.CloneSeries(series);
        }

        public void LoadToCache(Series series)
        {
            var key = string.Format(Series.CLONED_SERIES_REQUEST_CACHE_KEY, series.SeriesID, series.SeriesFundID);
            var clonedSeries = RequestCache.Get(key) as Series;
            if (clonedSeries == null)
            {
                clonedSeries = Series.Loader.GetById(series.SeriesID);
                RequestCache.Insert(key, clonedSeries);
            }
        }

        public InvestableFund GetInvestableFund(Portfolio portfolio, string baseFundName, IFundNameInfo fundNameInfo)
        {
            if (String.IsNullOrEmpty(baseFundName)) 
                return null;
            var baseFund = Instance.GetBaseFundByName(baseFundName, portfolio.OrganizationID);
            if (baseFund == null)
                throw new ValidationException("Can't find baseFund for subscription. FundName = " + baseFundName);

            if (string.IsNullOrEmpty(fundNameInfo.SecurityName) &&
                    (string.IsNullOrEmpty(fundNameInfo.ClassName) || string.IsNullOrEmpty(fundNameInfo.SeriesName)))
                throw new ValidationException("SecurityName or Class and Series shoud be set.");
            InvestableFund subFund;
            if (!string.IsNullOrEmpty(fundNameInfo.ClassName) && !string.IsNullOrEmpty(fundNameInfo.SeriesName))
            {
                subFund = baseFund.InvestableFunds().FirstOrDefault(
                    x => x.FundType == SystemTypeBase.FUND_SERIES &&
                         x.FundName == fundNameInfo.SeriesName &&
                         x.ParentFund != null &&
                         x.ParentFund.FundName == fundNameInfo.ClassName);
                if (subFund == null)
                    throw new ValidationException("Can't find class or series for subscription. Class: " + fundNameInfo.ClassName + "; series: " + fundNameInfo.SeriesName);
            }
            else
            {
                var fundType = Instance.GetFundType(baseFund);
                subFund = baseFund.InvestableFunds().FirstOrDefault(
                        x => x.FundType == fundType && InvestableFund.GetClearName(x.FundName) == fundNameInfo.SecurityName);
                if (subFund == null)
                    throw new ValidationException("Can't find class or series for subscription. Security name:" + fundNameInfo.SecurityName + ", type = " + fundType);
            }

            return subFund;
        }

        public int GetClearerId(Portfolio portfolio, string clearerName)
        {
            var clearer = clearerName == null
                  ? portfolio.Clearers.FirstOrDefault()
                  : portfolio.Clearers.FirstOrDefault(c => c.EnumValueName == clearerName);
            if (clearer == null)
                throw new ValidationException("No clearer with name " + clearerName + " in portfolio " + portfolio.PortfolioName);
            return clearer.EnumValueID;
        }

        public int GetRegistrarId(Portfolio portfolio, string registrarName)
        {
            if (registrarName == null)
                return -1;

            var registrar = portfolio.Registrars.FirstOrDefault(c => c.EnumValueName == registrarName);
            if (registrar == null)
                throw new ValidationException("No registrar with name " + registrarName + " in portfolio " + portfolio.PortfolioName);
            return registrar.EnumValueID;
        }

        public int GetFundClassificationId(string fundType)
        {
            if (string.IsNullOrEmpty(fundType)) return EnumValue.HEDGE_FUND_ID;

            var fundTypeStr = fundType.ToLower();
            var enums = EnumGroup.Loader.GetById(EnumGroup.FUND_CLASSIFICATION).ValuesForOrg(-1);
            var enumVal = enums.FirstOrDefault(x => x.EnumValueName.ToLower() == fundTypeStr);
            if (enumVal == null)
                throw new ValidationException("Unknown Fund type. Valid types:" +
                                              string.Join(",", enums.Select(x => x.EnumValueName)) + ".");
            return enumVal.EnumValueID;
        }

        public string GetFundClassificationName(int fundClassificationId)
        {
            var enums = EnumGroup.Loader.GetById(EnumGroup.FUND_CLASSIFICATION).ValuesForOrg(-1);
            var enumVal = enums.FirstOrDefault(x => x.EnumValueID == fundClassificationId);
            if (enumVal == null)
            {
                Logger.LogError("Fund Classification is not found: " + fundClassificationId);
                return string.Empty;
            }
            return enumVal.EnumValueName;
        }

        private List<InvestableFund> GetFunds(int organizationId)
        {
            var result = ((BaseFundLoader)BaseFund.Loader).SelectAll(organizationId == -1
                ? null : new List<int> { organizationId }).Cast<InvestableFund>().ToList();
            if (CSession.IsGsmManager(organizationId))
                result.AddRange(((InvestableFundLoader)InvestableFund.Loader).SelectAll(new List<int> { organizationId }));
            return result;
        }

        private List<ImmutableGsmContactPerson> GetContacts()
        {
            return ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().SelectAll().ToList();
        }

        public int GetReliefMethodologyIdFromString(string methodology)
        {
            var s = methodology.ToLower();
            var result = ReliefMethodology.FirstOrDefault(x => x.EnumValueName.Equals(s, StringComparison.InvariantCultureIgnoreCase));
            if (result == null)
                throw new ValidationException("Unknown reliefMethodology: '" + methodology + "'. Valid types:" +
                                                  string.Join(",", ReliefMethodology.Select(x => x.EnumValueName)) + ".");
            return result.EnumValueID;
        }

        public EnumValue GetEnumValue(int enumGroupId, string name)
        {
            return ((EnumValueLoader)EnumValue.Loader).GetByName(name, -1, enumGroupId);
        }

        public int GetEnumValueId(int enumGroupId, string name)
        {
            var enumValue = !string.IsNullOrWhiteSpace(name) ? GetEnumValue(enumGroupId, name) : null;
            return enumValue == null ? 0 : enumValue.EnumValueID;
        }

        public void AddGsmFundToCache(string fundName, BaseFund fund)
        {
            lock (Locks.GsmFundLock)
            {
                GsmFundsCache.Add(fundName, fund);
            }
        }

        public BaseFund GetGsmFundByName(string fundName)
        {
            lock (Locks.GsmFundLock)
            {
                return GsmFundsCache[fundName];
            }
        }

        public int GetSourceId(string sourceName)
        {
            return GetEnumValueId(EnumGroup.PRICE_SOURCE, sourceName);
        }
    }
}
