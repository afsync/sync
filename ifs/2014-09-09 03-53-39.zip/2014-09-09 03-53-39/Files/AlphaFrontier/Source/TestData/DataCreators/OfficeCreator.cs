﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using TestData.Common;
using TestData.DataObjects;

namespace TestData.DataCreators
{
    public class OfficeCreator
    {
        #region <<< Methods >>>
        public ImmutableGsmOffice Create(OfficeData officeData, ImmutableGsmCompany company, List<ImmutableGsmContactPerson> globalPersons)
        {
            if (company == null)
            {
                throw new ValidationException("Can't create office for empty company");
            }

            if (String.IsNullOrEmpty(officeData.City))
            {
                throw new ValidationException("City is required for office");
            }
            var office = new ImmutableGsmOffice(0, company.Id, officeData.OfficeName,
                officeData.OfficeAddress1, officeData.OfficeAddress2,officeData.City,officeData.OfficeProvince,
                officeData.OfficeState,officeData.OfficeCountry,officeData.OfficeZip,officeData.OfficePhone,officeData.OfficeFax,officeData.OfficeEmail,officeData.OfficeWebsite,
                (officeData.OrganizationName == String.Empty) ? company.OrganizationId : DataProvider.Instance.GetOrganizationIdByName(officeData.OrganizationName));
            
            Logger.LogInfo(string.Format("Creating global office for company : city={0}, name={1}", officeData.City, office.OfficeName));
            
            var store = ImmutableRepositoryFactory.ImmutableGsmOfficeStore();
            store.ValidateUnique(office);
            var officeId = store.Save(office);

            AddPersons(officeData, officeId, globalPersons);
            return office;
        }
        public void AddPersons(OfficeData officeData, int officeId, List<ImmutableGsmContactPerson> globalPersons)
        {
            if (officeData.Persons != null)
            {
                foreach (var personRef in officeData.Persons)
                {
                    try
                    {
                        var person = globalPersons.FirstOrDefault(x => x.Email == personRef.Email);
                        if (person != null)
                        {
                            Logger.LogInfo("Linking Person to Office: "+person.Email);
                            var personOffice = new ContactPersonOffice { CompanyOfficeId = officeId, ContactPersonId = person.Id };
                            personOffice.Save();
                        }
                        else
                        {
                            throw new ValidationException("Linking person to office: Can't find person with following email: " + personRef.Email);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                    }
                }
            }
        }

        public GsmFundOffice AddOfficeToFund(int fundId, int officeId, int companyGroupId)
        {
            var fundOffice = new GsmFundOffice
            {
                FundId = fundId,
                OfficeId = officeId,
                CompanyGroupId = companyGroupId
            };
            fundOffice.Save();
            return fundOffice;
        }
        #endregion
    }
}
