﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Utilities;
using TestData.Common;
using TestData.DataObjects;
using TestData.Interfaces;

namespace TestData.DataCreators
{
    public class GlobalCompanyCreator: ICreator
    {
        #region <<< Members >>>
        private readonly List<ImmutableGsmContactPerson> _contactPersons = new List<ImmutableGsmContactPerson>();
        #endregion

        #region Public Methods

        public void Create(TestDataContainer testData)
        {
            if (testData.GlobalCompanies == null) return;
            foreach (var globalCompanyData in testData.GlobalCompanies)
            {
                try
                {
                    Create(globalCompanyData);
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
            }
            var companyLoader = (ILoadable<ImmutableGsmCompany>)SpringUtil.GetObject("immutableGsmCompanyLoader");
            companyLoader.Remove(null);
            var gsmOfficeLoader = ImmutableLoaderFactory.GetImmutableGsmOfficeLoader();
            gsmOfficeLoader.Remove(null);
            gsmOfficeLoader.SelectAll();
            companyLoader.SelectAll();
           
        }

        public void Delete(TestDataContainer testData)
        {
            if (testData.GlobalCompanies == null) return;
            var persons = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().SelectAll();
            foreach (var globalCompanyData in testData.GlobalCompanies)
            {
                try
                {
                    Delete(globalCompanyData, persons);
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
            }
        }

        public void Test(TestDataContainer testData)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region <<< Private Methods >>>

        public ImmutableGsmCompany Create(GlobalCompanyData globalCompanyData)
        {
            if (String.IsNullOrEmpty(globalCompanyData.Name))
            {
                throw new ValidationException("Name attribute is required for company");
            }
            var companyId=-1;
            var company = new ImmutableGsmCompany(companyId, globalCompanyData.Name, globalCompanyData.CompanyPhone,
                                                  globalCompanyData.CompanyFax, globalCompanyData.CompanyEmail,
                                                  globalCompanyData.CompanyWebsite,
                                                  string.IsNullOrEmpty(globalCompanyData.OrganizationName)
                                                      ? AppConfiguration.GsmOrganizationId
                                                      : DataProvider.Instance.GetOrganizationIdByName(
                                                          globalCompanyData.OrganizationName),
                                                          GetGroups(globalCompanyData.CompanyGroupsString).AsReadOnly(),
                                                          new List<int>().AsReadOnly());
            Logger.LogInfo("Creating global company : name=" + globalCompanyData.Name);

            var repo = ImmutableRepositoryFactory.ImmutableGsmCompanyStore();
            new ImmutableGsmCompanyValidator().ValidateCompanyNameIsUnique(DataProvider.Instance.GetGlobalCompaniesSafeList(), company);
            using (var bsd = new BulkSaveData())
            {
                 companyId = repo.Save(company, bsd);
                 bsd.SubmitChanges();
            }
            company = new ImmutableGsmCompanyMapper().CreateNewWithId(company, companyId);
            DataProvider.Instance.AddGlobalCompany(company);
            CreatePersons(globalCompanyData, company);
            CreateOffices(globalCompanyData, company);
            return company;
        }
        public void Delete(GlobalCompanyData globalCompanyData, ReadOnlyCollection<ImmutableGsmContactPerson> persons)
        {
            var storage = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();
            foreach (var person in GetPersons(globalCompanyData, persons))
            {
                storage.Delete(person.Id);
            }
            foreach (var gsmCompany in DataProvider.Instance.GetGlobalCompaniesSafeList().Where(x => x.CompanyName == globalCompanyData.Name))
            {
                using (var bsd = new BulkSaveData())
                {
                    ImmutableRepositoryFactory.ImmutableGsmCompanyStore().Delete(gsmCompany.Id, bsd);
                    bsd.SubmitChanges();
                }
                DataProvider.Instance.DeleteGlobalCompany(gsmCompany);
            }
        }
        public IEnumerable<ImmutableGsmContactPerson> GetPersons(GlobalCompanyData globalCompanyData, ReadOnlyCollection<ImmutableGsmContactPerson> persons)
        {
            var result = new List<ImmutableGsmContactPerson>();
            if (globalCompanyData.Persons != null)
            {
                foreach (var personData in globalCompanyData.Persons)
                {
                    var email = personData.ContactEmail.ToLower();
                    if (!string.IsNullOrEmpty(email))
                    {
                        result.AddRange(persons.Where(x => x.Email.ToLower() == email));
                    }
                }

            }
            return result;
        }
        private List<int> GetGroups(string groups)
        {
            var result = new List<int>();
            if (!String.IsNullOrEmpty(groups))
            {
                var names = groups.Split(',');
                result.AddRange(names.Select(name => DataProvider.Instance.GetTypeIdByName(name.ToLower())).Where(id => id > 0));
            }
            if (result.Count == 0)
            {
                throw new ValidationException("At least one type should be specified for company");
            }
            return result;
        }

        private void CreateOffices(GlobalCompanyData globalCompanyData, ImmutableGsmCompany company)
        {
            if (globalCompanyData.Offices != null)
            {
                var creator = new OfficeCreator();
                foreach (var officeData in globalCompanyData.Offices)
                {
                    try
                    {
                        creator.Create(officeData, company, _contactPersons);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                    }
                }
            }
        }
        public void CreatePersons(GlobalCompanyData globalCompanyData, ImmutableGsmCompany company)
        {
            if (globalCompanyData.Persons != null)
            {
                var creator = new ContactPersonCreator();
                foreach (var personData in globalCompanyData.Persons)
                {
                    try
                    {
                        var contact = creator.Create(personData, company);
                        _contactPersons.Add(contact);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                    }
                }
            }
        }
        #endregion
    }
}
