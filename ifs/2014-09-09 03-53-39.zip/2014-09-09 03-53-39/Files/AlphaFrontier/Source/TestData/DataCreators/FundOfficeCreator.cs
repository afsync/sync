﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmOffice;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Utilities;
using TestData.Common;
using TestData.DataObjects;
using TestData.Interfaces;

namespace TestData.DataCreators
{
    public class FundOfficeCreator: ICreator
    {
        #region <<< Public Methods >>>

        public void Create(TestDataContainer testData)
        {
            var clientFunds = testData.ClientFunds.Where(fundData => fundData.ClientCompanyOffices != null);
            foreach (var fundData in clientFunds)
            {
                foreach (var companyOfficeData in fundData.ClientCompanyOffices)
                {
                    var fundOfficeData = new FundOfficeData
                    {
                        CompanyName = companyOfficeData.Name,
                        CompanyType = companyOfficeData.CompanyGroupsString,
                        OfficeCity = companyOfficeData.City,
                        OfficeName = companyOfficeData.OfficeName,
                        OfficeContacts = companyOfficeData.Persons.Select(p => new PersonRef { Email = p.ContactEmail }).ToArray(),
                        IsApproved = companyOfficeData.IsApproved,
                        IsRSContact = companyOfficeData.IsRsContact
                    };
                    Create(fundOfficeData,
                                DataProvider.Instance.GetBaseFundByName(fundData.FundName, DataProvider.Instance.GetOrganizationIdByName(fundData.Client)),
                                DataProvider.Instance.GetGlobalCompaniesSafeList());
                }
            }
        }

        public void Delete(TestDataContainer testData)
        {
            throw new NotImplementedException();
        }

        public void Test(TestDataContainer testData)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region <<< Methods >>>
        public GsmFundOffice Create(FundOfficeData fundOfficeData, BaseFund fund, List<ImmutableGsmCompany> globalCompanies)
        {
            var company = globalCompanies.SingleOrDefault(x => x.CompanyName == fundOfficeData.CompanyName);
            if (company == null)
            {
                throw new ValidationException("Can't find global company name=" + fundOfficeData.CompanyName);
            }
            var office = FindOffice(company, fundOfficeData.OfficeCity, fundOfficeData.OfficeName);
            if (office == null)
            {
                throw new ValidationException(string.Format("Can't find office(officecity={0}, officename={1}) for company(companyname={2})", 
                                                fundOfficeData.OfficeCity, fundOfficeData.OfficeName, fundOfficeData.CompanyName));
            }

            var companyTypeId = DataProvider.Instance.GetTypeIdByName(fundOfficeData.CompanyType.ToLower());
            if (companyTypeId == -1)
            {
                throw new ValidationException("Can't find type id for name=" + fundOfficeData.CompanyType);
            }

            Logger.LogInfo(string.Format("Creating office for fund: company={0} officecity={1} officename={2}", 
                                    fundOfficeData.CompanyName, fundOfficeData.OfficeCity, fundOfficeData.OfficeName));
            var fundOffice = new GsmFundOffice
            {
                FundId = fund.FundID,
                OfficeId = office.Id,
                CompanyGroupId = companyTypeId,
                ModifiedByUserId = AppConfiguration.UserId,
                ModifiedDate = fundOfficeData.ModifiedDate,
                IsRsContact = fundOfficeData.IsRSContact
            };
            if (fundOfficeData.IsApproved)
                fundOffice.ApprovedByUserId = UserUtil.ADMIN_USER_ID;
            fundOffice.Save();
            AddPersonToOffice(fundOffice, fundOfficeData, fund.OrganizationID);
            return fundOffice;
        }
        private ImmutableGsmOffice FindOffice(ImmutableGsmCompany company, string officeCity, string officeName)
        {
            var cityOffices = company.CompanyOfficesIds.Select(ImmutableRepositoryFactory.ImmutableGsmOfficeStore().GetById).Where(x => x.OfficeCity == officeCity).ToList();
            if (cityOffices.Count == 0) return null;

            return String.IsNullOrEmpty(officeName) ?
                    cityOffices.FirstOrDefault() :
                    cityOffices.SingleOrDefault(x => x.OfficeName == officeName);
        }
        private void AddPersonToOffice(GsmFundOffice fundOffice, FundOfficeData fundOfficeData, int organizationId)
        {
            if (fundOfficeData.OfficeContacts != null)
            {
                foreach (var contact in fundOfficeData.OfficeContacts)
                {
                    try
                    {
                        var officePersons = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().GetContactsForOffice(fundOffice.OfficeId);

                        var person = FindByEmail(contact.Email, officePersons);
                        if (person != null)
                        {
                            var personFundOffice = new GsmFundOfficeContact
                            {
                                FundOfficeId = fundOffice.Id,
                                ContactPersonId = person.Id,
                                OrganizationId = organizationId,
                                ModifiedByUserId = AppConfiguration.UserId,
                                ModifiedDate = contact.ModifiedDate
                            };
                            if (fundOfficeData.IsApproved)
                            {
                                personFundOffice.ApprovedByUserId = UserUtil.ADMIN_USER_ID;
                            }

                            personFundOffice.Save();
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                    }
                }
            }
        }
        private ImmutableGsmContactPerson FindByEmail(string email, IEnumerable<ImmutableGsmContactPerson> persons)
        {
            return persons.SingleOrDefault(x => x.Email == email);
        }

        #endregion
    }
}
