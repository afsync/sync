﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;
using IFS.BusinessLayer.Utilities;
using TestData.Common;
using TestData.DataObjects;
using TestData.Interfaces;

namespace TestData.DataCreators
{
    public class ClientCompanyCreator: ICreator
    {
        #region <<< Public Methods >>>

        public void Create(TestDataContainer testData)
        {
            if (testData.ClientFunds == null) return;

            var clientFunds = testData.ClientFunds.Where(fundData => fundData.ClientCompanyOffices != null);

            foreach (var fundData in clientFunds)
            {
                foreach (var companyOfficeData in fundData.ClientCompanyOffices)
                {
                    companyOfficeData.OrganizationName = fundData.Client;
                    Create(companyOfficeData);
                }
            }

            var companyLoader = (ILoadable<ImmutableGsmCompany>)SpringUtil.GetObject("immutableGsmCompanyLoader"); 
            companyLoader.Remove(null);
            companyLoader.SelectAll();
            var gsmOfficeLoader = ImmutableLoaderFactory.GetImmutableGsmOfficeLoader();
            gsmOfficeLoader.Remove(null);
            gsmOfficeLoader.SelectAll();
            var gsmContactPersonLoader = ImmutableLoaderFactory.GetImmutableGsmContactPersonLoader();
            gsmContactPersonLoader.Remove(null);
            gsmContactPersonLoader.SelectAll();
        }

        public void Delete(TestDataContainer testData)
        {
            Logger.LogInfo("Started deleting client companies");
            if (testData.ClientFunds != null)
            {
                var persons = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().SelectAll();
                foreach (var companyOffice in testData.ClientFunds.Where(clientFund => clientFund.ClientCompanyOffices != null).
                    SelectMany(clientFund => clientFund.ClientCompanyOffices))
                {
                    Delete(companyOffice, persons);
                }
            }
            Logger.LogInfo("Finished deleting client companies");
        }

        public void Test(TestDataContainer testData)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region <<< Methods >>>
        public ImmutableGsmCompany Create(ClientCompanyData clientCompanyOfficeData)
        {
            var officeData = new OfficeData
            {
                City = clientCompanyOfficeData.City,
                OfficeName = clientCompanyOfficeData.OfficeName,
                OfficePhone = clientCompanyOfficeData.OfficePhone,
                OfficeFax = clientCompanyOfficeData.OfficeFax,
                OfficeEmail = clientCompanyOfficeData.OfficeEmail,
                OfficeWebsite = clientCompanyOfficeData.OfficeWebsite,
                OfficeAddress1 = clientCompanyOfficeData.OfficeAddress1,
                OfficeAddress2 = clientCompanyOfficeData.OfficeAddress2,
                OfficeProvince = clientCompanyOfficeData.OfficeProvince,
                OfficeCountry = clientCompanyOfficeData.OfficeCountry,
                OfficeState = clientCompanyOfficeData.OfficeState,
                OfficeZip = clientCompanyOfficeData.OfficeZip,
                OrganizationName = clientCompanyOfficeData.OrganizationName,
                Persons = clientCompanyOfficeData.Persons.Select(p => new PersonRef { Email = p.ContactEmail }).ToArray()
            };
            var globalCompanyData = new GlobalCompanyData
            {
                Name = clientCompanyOfficeData.Name,
                CompanyEmail = clientCompanyOfficeData.CompanyEmail,
                CompanyFax = clientCompanyOfficeData.CompanyFax,
                CompanyGroupsString = clientCompanyOfficeData.CompanyGroupsString,
                CompanyPhone = clientCompanyOfficeData.CompanyPhone,
                CompanyWebsite = clientCompanyOfficeData.CompanyWebsite,
                OrganizationName = clientCompanyOfficeData.OrganizationName,
                Offices = new[] { officeData },
                Persons = clientCompanyOfficeData.Persons
            };
            var globalCompanyCreator = new GlobalCompanyCreator();
            return globalCompanyCreator.Create(globalCompanyData);
        }
        public void Delete(ClientCompanyData clientCompanyOfficeData, ReadOnlyCollection<ImmutableGsmContactPerson> persons)
        {
            var creator = new GlobalCompanyCreator();
            var globalCompanyData = new GlobalCompanyData {Persons = clientCompanyOfficeData.Persons};
            var personStore=ImmutableRepositoryFactory.ImmutableGsmContactPersonStore();
            foreach (var person in creator.GetPersons(globalCompanyData, persons))
            {
                Logger.LogInfo("Deleting client Person name=" + person.FirstName + " " + person.LastName);
                personStore.Delete(person.Id);
            }
            foreach (var gsmCompany in DataProvider.Instance.GetGlobalCompaniesSafeList().Where(x => x.CompanyName == clientCompanyOfficeData.Name))
            {
                Logger.LogInfo("Deleting client Company name=" + gsmCompany.CompanyName);
                using (var bsd = new BulkSaveData())
                {
                    ImmutableRepositoryFactory.ImmutableGsmCompanyStore().Delete(gsmCompany.Id,bsd);
                    bsd.SubmitChanges();
                }
                
            }
        }
        #endregion

    }
}
