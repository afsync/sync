﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.CompanyContactManagement.ImmutableGsmCompany;
using IFS.BusinessLayer.GSM.Immutable;
using TestData.Common;
using TestData.DataObjects;
using TestData.Interfaces;

namespace TestData.DataCreators
{
    public class ContactPersonCreator : ICreator
    {
        #region <<< Public Methods >>>

        public void Create(TestDataContainer testData)
        {
            if (testData.GlobalPersons == null) return;
            foreach (var contactPersonData in testData.GlobalPersons)
            {
                try
                {
                    Create(contactPersonData, null);
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
            }
            ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().SelectAll();
        }

        public void Delete(TestDataContainer testData)
        {
            if (testData.GlobalPersons == null) return;
            foreach (var contactPersonData in testData.GlobalPersons)
            {
                try
                {
                    Delete(contactPersonData);
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
            }
        }

        public void Test(TestDataContainer testData)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region <<< Private Methods >>>
        public ImmutableGsmContactPerson Create(ContactPersonData contactPersonData, ImmutableGsmCompany company)
        {
            if (String.IsNullOrEmpty(contactPersonData.FirstName) || String.IsNullOrEmpty(contactPersonData.LastName) || String.IsNullOrEmpty(contactPersonData.ContactEmail))
            {
                throw new ValidationException("FirstName, LastName and Email are required");
            }

            var organizationId = (company != null) ? company.OrganizationId : AppConfiguration.GsmOrganizationId;
            if (contactPersonData.OrganizationName != String.Empty)
                organizationId = DataProvider.Instance.GetOrganizationIdByName(contactPersonData.OrganizationName);

            var contact = new ImmutableGsmContactPerson(-1, contactPersonData.FirstName, contactPersonData.LastName,
                contactPersonData.ContactRole, contactPersonData.ContactPhone,
                contactPersonData.ContactFax, contactPersonData.ContactEmail, company!=null?company.Id:-1, organizationId, new List<int>().AsReadOnly());
            Logger.LogInfo(string.Format("Creating global person contact : firstname={0}, lastname={1}, email={2}", contactPersonData.FirstName, contactPersonData.LastName, contactPersonData.ContactEmail));
            var contactId = ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().Save(contact);
            contact = new ImmutableGsmContactPerson(contactId, contact.FirstName, contact.LastName,
                contact.Role, contact.Phone,
                contact.Fax, contact.Email, contact.CompanyId, contact.OrganizationId, new List<int>().AsReadOnly());
            AddHistory(contact);
            return contact;
        }

        private void Delete(ContactPersonData contactPersonData)
        {
            var lowerCase = contactPersonData.ContactEmail.ToLower();
            var person = DataProvider.Instance.GlobalContactPersons.SingleOrDefault(x => x.Email.ToLower() == lowerCase);
            if (person != null)
            {
                ImmutableRepositoryFactory.ImmutableGsmContactPersonStore().Delete(person.Id);
            }
        }
        private void AddHistory(ImmutableGsmContactPerson contact)
        {
            var history = new GsmContactPersonHistory
            {
                ChangeDate = DateTime.Now,
                ContactPersonId = contact.Id,
                GsmCompanyId = contact.CompanyId,
                IsModified = true
            };
            (new GsmContactPersonHistoryManager(contact, new ContactPersonHistoryDataProvider())).Add(history);
        }
        #endregion
    }
}
