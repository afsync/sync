﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.Script.Serialization;
using CafmRepositoryFacade;
using CafmRepositoryFacade.SpRepositoryService;
using Common.Logging;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cafm;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.MergedPdf;
using IFS.BusinessLayer.PdfGenerator;
using IFS.BusinessLayer.Price.PriceFetchers;
using Microsoft.Security.Application;
using IFS.BusinessLayer.CloudServices.Reports;

namespace IFS.HedgeFrontier
{
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    [ScriptService]
    public class SpRepositoryManagerProxy : WebService
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(SpRepositoryManagerProxy));
        private const string RESTRICTED_CHARACTERS = "~\"#%&*:<>?/\\{|}";
        private static readonly SpRepositoryService _repositoryService = new SpRepositoryService();
        private const int SEARCH_RESULT_ROW_LIMIT = 1000;
        private const int MAX_NUMBER_OF_TREE_CHILDNODES_WITHOUT_PAGING = 100;

        #region Node names
        private const string PORTFOLIES_NODE_NAME = "PORTFOLIOS";
        private const string FUNDS_NODE_NAME = "FUNDS";
        private const string REPORTS_NODE_NAME = "REPORTS";
        private const string FUNDS_BY_STATUS_NODE_NAME = "STATUS";
        private const string FUNDS_BY_NAME_NODE_NAME = "ALL (BY NAME)";
        private const string ACTIVE_FUNDS_NODE_NAME = "Active";
        private const string PAST_FUNDS_NODE_NAME = "Past";
        private const string NEVER_INVESTED_FUNDS_NODE_NAME = "Never Invested";
        private const string INVESTMENTS_NODE_NAME = "Investments";
        #endregion

        #region Node abbreviations
        private const string PORTFOLIES_NODE_REL = "PORTFOLIOS";
        private const string FUNDS_NODE_REL = "FUNDS";
        private const string REPORTS_NODE_REL = "REPORTS";
        private const string FUNDS_BY_NAME_NODE_REL = "FUNDS_BY_NAME";
        private const string FUNDS_BY_STATUS_NODE_REL = "FUNDS_BY_STATUS";
        private const string ACTIVE_FUNDS_NODE_REL = "FUNDS_BY_STATUS_ACTIVE";
        private const string PAST_FUNDS_NODE_REL = "FUNDS_BY_STATUS_PAST";
        private const string NEVER_INVESTED_FUNDS_NODE_REL = "FUNDS_BY_STATUS_NEVER_INVESTED";
        private const string INVESTMENTS_NODE_REL = "INVESTMENTS";
        #endregion

        private const string PORTFOLIO_NODE_REL = "PORTFOLIO";
        private const string BASE_FUND_NODE_REL = "BASE_FUND";
        private const string REPORT_NODE_REL = "REPORT";
        private const string INVESTMENT_NODE_REL = "INVESTMENT";

        private const string AF_ENTITY_ID_FORMAT = "AF";
        private const string NON_LETTER_ALIAS = "!";
        private static readonly Regex _regexAfEntity = new Regex("^AF([0-9]+)$");

        private static readonly Regex _firstSymbolIsNotLetter = new Regex("^(?![A-Za-z]).+");
        private static readonly Regex _fundsByNameGrouped = new Regex("^FUNDS_BY_NAME_GROUPED_BY_(?<FundGroupedBy>[!A-Z])$");
        private static readonly Regex _fundsByStatus = new Regex("^FUNDS_BY_STATUS_(?<FundStatus>[_A-Za-z]+)$");
        private static readonly Regex _fundsByStatusGrouped = new Regex("^FUNDS_BY_STATUS_(?<FundStatus>[_A-Za-z]+)_GROUPED_BY_(?<FundGroupedBy>[!A-Z])$");
        private static readonly Regex _investmentsGrouped = new Regex("^INVESTMENTS_GROUPED_BY_(?<FundGroupedBy>[!A-Z])$");

        private static readonly Regex _regexEstimatePriceBackups = new Regex("_EPLS([0-9]+)$");

        public PortfolioCollection AllPortfolios
        {
            get { return CSession.Portfolios; }
        }

        private static string[] UserRoles
        {
            // TODO: Use real roles when implemented
            get { return new[] { "R1" }; }
        }

        static SpRepositoryManagerProxy()
        {
            _repositoryService.Url = CConfig.CafmRepositoryService;
            _repositoryService.Credentials = new NetworkCredential(CConfig.CafmUser, CConfig.CafmPassword, CConfig.CafmDomain);
        }

        private List<JsTreeNode> GetRootNodes()
        {
            _log.Debug("GetRootNodes()");
            try
            {
                var rootNodes = new List<JsTreeNode>
                       {
                            new JsTreeNode(PORTFOLIES_NODE_REL, PORTFOLIES_NODE_NAME, PORTFOLIES_NODE_REL,GetPortfolioNodes()),
                            new JsTreeNode(FUNDS_NODE_REL, FUNDS_NODE_NAME, FUNDS_NODE_REL, new List<JsTreeNode> { GetFundsByNameRootNode(), GetFundsByStatusRootNode()})
                       };
                if (CSession.IsGSM)
                    rootNodes.Add(new JsTreeNode(REPORTS_NODE_REL, REPORTS_NODE_NAME, REPORTS_NODE_REL, GetReportNodes()));
                return rootNodes;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetRootNodes method", ex);
                throw;
            }
        }

        private List<JsTreeNode> GetPortfolioNodes()
        {
            _log.Debug("GetPortfolioNodes()");
            try
            {
                var portfolioNodes = new List<JsTreeNode>();
                foreach (Portfolio portfolio in AllPortfolios)
                {
                    if (portfolio.OrganizationID == CSession.OrganizationID)
                    {
                        CafmRepositoryHelper.CreateFullFundSharepointStructure(portfolio);//For QA
                        var portfolioNode = new JsTreeNode(AF_ENTITY_ID_FORMAT + portfolio.PortfolioID, portfolio.FullName, PORTFOLIO_NODE_REL, false);
                        portfolioNodes.Add(portfolioNode);
                    }
                }
                return portfolioNodes;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetPortfolioNodes method", ex);
                throw;
            }
        }

        private List<JsTreeNode> GetReportNodes()
        {
            try
            {
                var reportNodes = new List<JsTreeNode>();
                foreach (var report in ReportsHelper.ERepositoryReports.Where(r=> !r.ParentReportId.HasValue))
                {
                    CafmRepositoryHelper.CheckReportStructure(CSession.OrganizationID.ToString(), report.ReportName, report.ReportId);//For QA
                    var reportNode = new JsTreeNode(AF_ENTITY_ID_FORMAT + report.SReportId, report.ReportName, REPORT_NODE_REL, false);
                    reportNodes.Add(reportNode);
                }
                return reportNodes;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetReportNodes method", ex);
                throw;
            }
        }

        private static JsTreeNode GetFundsByNameRootNode()
        {
            try
            {
                return new JsTreeNode (FUNDS_BY_NAME_NODE_REL, FUNDS_BY_NAME_NODE_NAME, FUNDS_BY_NAME_NODE_REL, false);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFundsByNameNode method", ex);
                throw;
            }
        }

        private static JsTreeNode GetFundsByStatusRootNode()
        {
            _log.Debug("GetFundsByStatusNode()");
            try
            {
                var activeFundsNode = new JsTreeNode(ACTIVE_FUNDS_NODE_REL, ACTIVE_FUNDS_NODE_NAME, ACTIVE_FUNDS_NODE_REL, false);
                var pastFundsNode = new JsTreeNode(PAST_FUNDS_NODE_REL, PAST_FUNDS_NODE_NAME, PAST_FUNDS_NODE_REL, false);
                var neverInvestedNode = new JsTreeNode(NEVER_INVESTED_FUNDS_NODE_REL, NEVER_INVESTED_FUNDS_NODE_NAME, NEVER_INVESTED_FUNDS_NODE_REL, false);

                return new JsTreeNode (FUNDS_BY_STATUS_NODE_REL, FUNDS_BY_STATUS_NODE_NAME, FUNDS_BY_STATUS_NODE_REL, false,
                    new List<JsTreeNode> { activeFundsNode, pastFundsNode, neverInvestedNode });
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFundsByStatusNode method", ex);
                throw;
            }
        }

        private static JsTreeNode GetFundNode(UnderlyingFund fund)
        {
            CafmRepositoryHelper.CreateFullFundSharepointStructure(fund);//For QA
            if (fund == null)
            {
                _log.Debug("GetFundNode was called with null parameter for the fund");
                throw new ArgumentNullException("fund", @"Fund should be provided");
            }
            _log.DebugFormat("GetFundNode(fund.FundId = '{0}')", fund.FundID);
            return new JsTreeNode(AF_ENTITY_ID_FORMAT + fund.FundID, fund.FundName, BASE_FUND_NODE_REL, false);
        }

        private List<JsTreeNode> GetFundNodesByStatus(string nodeId)
        {
            EInvestedStatus investedStatus;

            if (_fundsByStatusGrouped.IsMatch(nodeId))
            {
                var match = _fundsByStatusGrouped.Match(nodeId);
                investedStatus = (EInvestedStatus)Enum.Parse(typeof(EInvestedStatus), match.Groups["FundStatus"].Value, false);
                string fundGroupedBy = match.Groups["FundGroupedBy"].Value;

                return GetBaseFundByStatus(investedStatus)
                    .Where(baseFund => !fundGroupedBy.Equals(NON_LETTER_ALIAS)
                        ? baseFund.FundName.StartsWith(fundGroupedBy, StringComparison.OrdinalIgnoreCase)
                        : _firstSymbolIsNotLetter.IsMatch(baseFund.FundName))
                    .Select(GetFundNode)
                    .ToList();
            }
            else
            {
                var match = _fundsByStatus.Match(nodeId);
                investedStatus = (EInvestedStatus)Enum.Parse(typeof(EInvestedStatus), match.Groups["FundStatus"].Value, false);
                return GetIndexForFundsByStatus(investedStatus);
            }
        }

        public List<BaseFund> GetBaseFundByStatus(EInvestedStatus status)
        {
            var statusesByFundIds = new Dictionary<int, EInvestedStatus>();
            DateTime dateNow = DateTime.Today;
            foreach (var investment in AllPortfolios.SelectMany(portfolio => portfolio.Investments))
            {
                if (investment != null && investment.Allocations.Count > 0)
                {
                    var invStatus = investment.AllocationQuantity(dateNow) > 0 || investment.Allocations.Last().ExecutionDate > dateNow ? EInvestedStatus.ACTIVE : EInvestedStatus.PAST;

                    var invFundId = investment.Fund.BasefundId;
                    if (statusesByFundIds.ContainsKey(invFundId))
                    {
                        if (statusesByFundIds[invFundId] > invStatus)
                            statusesByFundIds[invFundId] = invStatus;
                    }
                    else
                    {
                        statusesByFundIds.Add(invFundId, invStatus);
                    }
                }
            }

            var baseFunds = GetBaseFunds().ToList();
            var fundIdsToUse = status != EInvestedStatus.NEVER_INVESTED
                                       ? statusesByFundIds.Where(x => x.Value == status).Select(x => x.Key)
                                       : baseFunds.Where(baseFund => !statusesByFundIds.Keys.Contains(baseFund.FundID)).Select(baseFund => baseFund.FundID);

            return baseFunds.Where(baseFund => fundIdsToUse.Contains(baseFund.FundID)).ToList();
        }

        private List<JsTreeNode> GetFundNodesByName(string nodeId)
        {
            var match = _fundsByNameGrouped.Match(nodeId);
            var fundGroupedBy = match.Groups["FundGroupedBy"].Value;

            return GetBaseFunds()
                    .Where(baseFund => !fundGroupedBy.Equals(NON_LETTER_ALIAS)
                        ? baseFund.FundName.StartsWith(fundGroupedBy, StringComparison.OrdinalIgnoreCase)
                        : _firstSymbolIsNotLetter.IsMatch(baseFund.FundName))
                    .Select(GetFundNode)
                    .ToList();
        }

        private List<JsTreeNode> GetSubfolders(string folderPath, bool isPortfolio, string parentPortfolioId)
        {
            var webServiceCallResult = IsAfEntity(folderPath)
                                           ? _repositoryService.GetSpItems(CSession.OrganizationID.ToString(), folderPath, DocLibObjectType.Folder, UserRoles)
                                           : _repositoryService.GetSpItemsByFullPath(IdToPath(folderPath), DocLibObjectType.Folder, UserRoles);

            if (!string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
            {
                throw new Exception(webServiceCallResult.ErrorMessage);
            }
            //u002f  - 'slash'
            List<JsTreeNode> folderContent = webServiceCallResult.Data
                .Where(f => !_regexAfEntity.IsMatch(f.Name) && (!f.Name.Contains("_") || f.CafmPortfolioId == parentPortfolioId || string.IsNullOrEmpty(f.CafmPortfolioId)))
                .Select(f => new JsTreeNode(PathToId(f.Path) + "_u002f_" + f.Name, f.DisplayName, GetFolderTypeByFolderName(f.Name), false))
                .ToList();

            if (isPortfolio)
            {
                int portfolioId = int.Parse(folderPath.Replace("AF", ""));
                var portfolio = AllPortfolios.GetById(portfolioId);
                if (portfolio.Investments.Count > 0)
                {
                    folderContent.Add(GetInvestmentsRootNode(portfolio, folderPath));
                }
            }
            else if (_regexEstimatePriceBackups.IsMatch(folderPath))
            {
                folderContent = GetEstimateFolders(folderPath, folderContent);
            }
            return folderContent;
        }

        private static List<JsTreeNode> GetEstimateFolders(string folderPath, IEnumerable<JsTreeNode> folderContent)
        {
            var result = new List<JsTreeNode>();
            // Group folders by NavDate
            var estimateFolders = folderContent.ToLookup(node => node.data.title);
            foreach (var estimateFolder in estimateFolders)
            {
                result.Add(new JsTreeNode(folderPath, estimateFolder.Key, PreDefinedFolders.EstimatePriceLockdown.Abbreviation, false) { state = "leaf" });
            }
            return result;
        }

        #region Data retrieve methods
        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString GetFolderStructure(string folderPath, bool isPortfolio, string parentPortfolioId)
        {
            try
            {
                if (CSession.OrganizationID <= 1)
                    throw new SecurityException("Session has expired. Please refresh the page.");

                string data;
                if (string.IsNullOrEmpty(folderPath))
                    data = JsonSerialize(GetRootNodes());
                else if (folderPath == FUNDS_BY_NAME_NODE_REL)
                    data = JsonSerialize(GetIndexForFundsByNames());
                else if (_fundsByNameGrouped.IsMatch(folderPath))
                    data = JsonSerialize(GetFundNodesByName(folderPath));
                else if (_investmentsGrouped.IsMatch(folderPath))
                    data = JsonSerialize(GetInvestmentChildNodes(AllPortfolios.GetById(int.Parse(parentPortfolioId)), folderPath));
                else if (folderPath.StartsWith(FUNDS_BY_STATUS_NODE_REL))
                    data = JsonSerialize(GetFundNodesByStatus(folderPath));
                else
                    data = JsonSerialize(GetSubfolders(folderPath, isPortfolio, parentPortfolioId));
                return new WebServiceCallResultString { Data = data };
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFolderStructure method", ex);
                return new WebServiceCallResultString { ErrorMessage = ex.Message };
            }
        }

        #region Index building methods
        private List<JsTreeNode> GetIndexForFundsByNames()
        {
            var baseFunds = GetBaseFunds().ToList();
            var baseFundNodes = baseFunds.Count() > MAX_NUMBER_OF_TREE_CHILDNODES_WITHOUT_PAGING
                                     ? GetIndexNodes(baseFunds.Select(baseFund => baseFund.FundName), FUNDS_BY_NAME_NODE_REL)
                                     : baseFunds.Select(GetFundNode).ToList();
            return baseFundNodes;
        }

        private List<JsTreeNode> GetIndexForFundsByStatus(EInvestedStatus investedStatus)
        {
            var fundsByStatus = GetBaseFundByStatus(investedStatus);

            var baseFundNodes = fundsByStatus.Count() > MAX_NUMBER_OF_TREE_CHILDNODES_WITHOUT_PAGING
                                ? GetIndexNodes(fundsByStatus.Select(baseFund => baseFund.FundName), FUNDS_BY_STATUS_NODE_REL + "_" + investedStatus)
                                : fundsByStatus.Select(GetFundNode).ToList();
            return baseFundNodes;
        }

        private List<JsTreeNode> GetIndexNodes(IEnumerable<string> entitiesToIndex, string indexType)
        {
            var alphabeticalIndex = new Dictionary<char, int>();
            int nonAlphabeticalIndexCount = 0;
            foreach (var entity in entitiesToIndex)
            {
                if (entity.Length > 0)
                {
                    char entityNameFirstCharacter = char.ToUpper(entity[0]);
                    if (char.IsLetter(entityNameFirstCharacter))
                    {
                        if (alphabeticalIndex.ContainsKey(entityNameFirstCharacter))
                        {
                            alphabeticalIndex[entityNameFirstCharacter]++;
                        }
                        else
                        {
                            alphabeticalIndex.Add(entityNameFirstCharacter, 1);
                        }
                    }
                    else
                    {
                        nonAlphabeticalIndexCount++;
                    }
                }
            }

            var indexNodes = alphabeticalIndex.Select(indexElement => new JsTreeNode(indexType + "_GROUPED_BY_" + indexElement.Key, indexElement.Key + " (" + indexElement.Value + ")", "INDEX_NODE", false))
                .ToList();

            if (nonAlphabeticalIndexCount > 0)
                indexNodes.Add(new JsTreeNode(indexType + "_GROUPED_BY_" + NON_LETTER_ALIAS, "Others" + " (" + nonAlphabeticalIndexCount + ")", "INDEX_NODE", false));

            return indexNodes;
        }
        #endregion

        private static IEnumerable<BaseFund> GetBaseFunds()
        {
            return BaseFund.GetBaseFundsForUser().Cast<BaseFund>();
        }

        private JsTreeNode GetInvestmentsRootNode(Portfolio portfolio, string nodeId)
        {
            if (portfolio == null)
            {
                _log.Debug("GetInvestmentsNode was called with null parameter for the portfolio");
                throw new ArgumentNullException("portfolio", @"Portfolio should be provided");
            }
            _log.DebugFormat("GetInvestmentsNode(portfolio.FundId = '{0}')", portfolio.FundID);

            try
            {
                var investmentNodes = new JsTreeNode(INVESTMENTS_NODE_REL, INVESTMENTS_NODE_NAME, INVESTMENTS_NODE_REL, false);
                investmentNodes.children.AddRange(GetInvestmentChildNodes(portfolio, nodeId));
                return investmentNodes;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetInvestmentsNode method", ex);
                throw;
            }
        }

        private IEnumerable<JsTreeNode> GetInvestmentChildNodes(Portfolio portfolio, string nodeId)
        {
            var investments = portfolio.Investments.Where(x => x.Fund.FundType != SystemType.SHORT_SALE).OrderBy(inv => inv.FundName).ToList();
            IEnumerable<JsTreeNode> investmentNodes;
            if (_investmentsGrouped.IsMatch(nodeId))
            {
                var match = _investmentsGrouped.Match(nodeId);
                var fundGroupedBy = match.Groups["FundGroupedBy"].Value;
                investmentNodes = investments.Where(inv => inv.FundName.StartsWith(fundGroupedBy)).Select(GetInvestmentNode);
            }
            else
            {
                investmentNodes = investments.Count() > MAX_NUMBER_OF_TREE_CHILDNODES_WITHOUT_PAGING
                    ? GetIndexNodes(investments.Select(investment => investment.FundName), INVESTMENTS_NODE_REL)
                    : investments.Select(GetInvestmentNode);
            }
            return investmentNodes;
        }

        private JsTreeNode GetInvestmentNode(Investment investment)
        {
            //For QA
            CafmRepositoryHelper.CreateFullFundSharepointStructure(investment.Fund);

            return new JsTreeNode(AF_ENTITY_ID_FORMAT + investment.FundID, investment.FundName, INVESTMENT_NODE_REL, false);
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultCollection GetFolderContent(string folderPath, bool onlyFiles, string selectedNodeName)
        {
            _log.DebugFormat("GetFolderContent(folderPath = '{0}', onlyFiles = '{1}')", folderPath, onlyFiles);
            try
            {
                if (string.IsNullOrEmpty(folderPath))
                {
                    _log.Debug("GetFolderContent was called with null parameter for the folder path");
                    throw new ArgumentNullException("folderPath", @"Folder path should be provided");
                }

                WebServiceCallResultCollection webServiceCallResult;
                if (_regexEstimatePriceBackups.IsMatch(folderPath) && !string.IsNullOrEmpty(selectedNodeName) && selectedNodeName != "Price Backups")
                {
                    // Metadata field "CafmItemName" (display name) has NavDate for estimate folder.
                    // Get files from all estimates folders for selected NavDate.
                    webServiceCallResult = _repositoryService.GetFilesInSubFoldersByFullPath(IdToPath(folderPath), "CafmItemName", selectedNodeName, UserRoles);
                }
                else
                {
                    webServiceCallResult = _repositoryService.GetSpItemsByFullPath(IdToPath(folderPath),
                        onlyFiles ? DocLibObjectType.File : DocLibObjectType.FolderAndFile, UserRoles);
                }

                if (!string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                {
                    return webServiceCallResult;
                }
                var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader, BusinessLayer.User.Loader, true);
                webServiceCallResult.Data =
                    metadataManager.GetPopulatedAndFilteredMetadata(
                        webServiceCallResult.Data.Where(item => !_regexAfEntity.IsMatch(item.Name))
                            .OrderBy(item => item.DisplayName)
                            .ToArray());
                webServiceCallResult = CafmRepositoryHelper.HideNotPublishedEstimateAttachments(webServiceCallResult);
                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFolderContent method", ex);
                return new WebServiceCallResultCollection { ErrorMessage = ex.Message };
            }
        }
        #endregion

        #region File operations
        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public void UploadFile()
        {
            const string successResultTemplate = "{\"success\":true}";
            const string errorResultTemplate = "{{\"success\":false,\"message\":\"{0}\"}}";
            const string unknownErrorResultTemplate = "{{\"success\":false,\"message\":\"Error with uploading {0}\"}}";

            var filePath = IdToPath(HttpContext.Current.Request.Form["filePath"]);
            var fileComment = HttpContext.Current.Request.Form["fileComment"];
            var documentType = HttpContext.Current.Request.Form["ddlDocumentType"];
            var documentDateFrom = HttpContext.Current.Request.Form["documentDateFrom"];
            var documentDateTo = HttpContext.Current.Request.Form["documentDateTill"];
            var filePortfolioId = HttpContext.Current.Request.Form["filePortfolioId"];

            bool isBrowserIe = string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["qqfile"]);
            //TODO Remove isBrowserIe dependencies when they will be not required for debug with FF purposes
            var fileName = isBrowserIe ? Path.GetFileName(HttpContext.Current.Request.Files[0].FileName) : HttpContext.Current.Request.QueryString["qqfile"];

            _log.DebugFormat("UploadFile(filePath = '{0}', fileName = '{1}', fileComment = '{2}')", filePath, fileName, fileComment);

            try
            {
                Stream inputStream = isBrowserIe ? HttpContext.Current.Request.Files[0].InputStream : HttpContext.Current.Request.InputStream;

                int inputStreamLength = Convert.ToInt32(inputStream.Length);
                var fileContent = new byte[inputStreamLength];
                var binaryReader = new BinaryReader(inputStream);
                binaryReader.Read(fileContent, 0, inputStreamLength);

                var fundid = GetFundIdFromPath(filePath);

                var baseFundId = CafmRepositoryHelper.TryGetBaseFundId(fundid);

                var callResult = _repositoryService.UploadFileByFullPath(filePath + "/" + fileName, fileContent, true,
                    GetMetadata(fileComment, documentType, documentDateFrom, documentDateTo, filePortfolioId, baseFundId), UserRoles);
                HttpContext.Current.Response.Write(string.IsNullOrEmpty(callResult.ErrorMessage)
                                                       ? successResultTemplate
                                                       : string.Format(CultureInfo.CurrentCulture, errorResultTemplate, callResult.ErrorMessage.Replace("\"", "\\\"")));

                if (string.IsNullOrEmpty(callResult.ErrorMessage) && CConfig.CafmCreateFoldersOnTheFly)
                {
                    // If database(tblFileCafm) and sharepoint are unsynchronized, after db refresh
                    var cafmFileId = callResult.Data;
                    FileCafmFactory.DeleteFromFileCafm(cafmFileId);
                }

                var uFund = UnderlyingFund.GetFund(fundid);

                var organization = uFund != null ? Organization.Loader.GetById(uFund.OrganizationID) : null;
                if (organization != null && organization.SendFileToExternalDest)
                {
                    CafmRepositoryHelper.UpdateTblFileTransfer(callResult.Data, fileName, AttachedDocumentType.None, -1, uFund.OrganizationID, fundid);
                }
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in UploadFile method", ex);
                HttpContext.Current.Response.Write(Encoder.HtmlEncode(string.Format(CultureInfo.CurrentCulture, unknownErrorResultTemplate, fileName)));
            }
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(UseHttpGet = true)]
        public void DownloadFile()
        {
            var queryString = HttpContext.Current.Request.QueryString;
            var response = HttpContext.Current.Response;
            var organizationId = CSession.OrganizationID;
            var cafmFileId = queryString["fileId"];
            var fileVersion = queryString["fileVersion"];
            var documentTypeString = queryString["documentType"];

            try
            {
                AttachedDocumentType documentType;
                if (!string.IsNullOrEmpty(documentTypeString) &&
                    (Enum.TryParse(documentTypeString, out documentType) && documentType == AttachedDocumentType.SecurityPricing))
                {
                    organizationId = CSession.GsmOrgIdActual;//CSession.GSMOrgId;
                }

                var fileInfo = GetFileInfo(organizationId, cafmFileId, fileVersion);
                if (string.IsNullOrEmpty(fileVersion))
                    fileVersion = fileInfo.Version;
                var filePath = fileInfo.Path + "/" + fileInfo.Name;
                _log.DebugFormat("DownloadFile(filePath = '{0}', displayFileName = '{1}', fileVersion = '{2}')", filePath, fileInfo.DisplayName, fileVersion);

                var fileContent = _repositoryService.DownloadFileVersion(filePath, fileVersion);

                response.AppendHeader("Content-Disposition", string.Format(CultureInfo.CurrentCulture, "attachment; filename=\"{0}\"", fileInfo.DisplayName));
                response.BinaryWrite(fileContent.Data);
                response.Flush();
                response.End();
            }
            catch (ThreadAbortException)
            {
                //
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in DownloadFile method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(UseHttpGet = true)]
        public void DownloadMergedPdfFiles(string date, string price, string portfolios)
        {
            var response = HttpContext.Current.Response;
            response.Clear();
            try
            {
                DateTime navDate = DateTime.Parse(date);
                var priceType = (PriceType)int.Parse(price);
                IEnumerable<int> portfolioIds = portfolios.Split(',').Select(int.Parse);
                var organizationId = CSession.OrganizationID;
                var selectedPortfolios = CSession.Portfolios.Where(p => portfolioIds.Contains(p.PortfolioID));

                var files = PreparePdfFiles(organizationId, priceType, selectedPortfolios, navDate);

                FormatResponse(response, files);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occurred in DownloadMergedPdfFiles method", ex);
                response.Clear();
                response.Write("<script>alert('Error occurred. Please check parameters passed.');window.opener=null;window.close();</script>");
            }
            response.End();
        }

        public List<byte[]> PreparePdfFiles(int organizationId, PriceType priceType, IEnumerable<Portfolio> selectedPortfolios, DateTime navDate)
        {
            var mergedPdfManager = new MergedPdfManager(new FileCafmBLRepository());
            var entityAttachments = mergedPdfManager.GetPdfEstimateAttachments(priceType, selectedPortfolios, navDate);
            return GetPdfEstimateAttachmentsAsBinary(entityAttachments, organizationId);
        }

        private List<byte[]> GetPdfEstimateAttachmentsAsBinary(IEnumerable<CFileCafm> entityAttachments, int organizationId)
        {
            var files = new List<byte[]>();
            foreach (var entityAttachment in entityAttachments)
            {
                var fileInfo = GetFileInfo(organizationId, entityAttachment.CafmFileId, null);
                if (fileInfo == null)
                    continue;

                var fileName = fileInfo.Path + "/" + fileInfo.Name;
                files.Add(_repositoryService.DownloadFileVersion(fileName, fileInfo.Version).Data);
            }
            return files;
        }

        private static void FormatResponse(HttpResponse response, List<byte[]> files)
        {
            if (files.Any())
            {
                var generator = new PdfExportGenerator(false);
                byte[] pdfSource = generator.MergePdfs(files);

                response.ClearHeaders();
                response.ContentType = "application/pdf";
                response.AddHeader("Content-Disposition", "attachment; filename=MergedAttachments.pdf");
                response.OutputStream.Write(pdfSource, 0, pdfSource.Length);
                response.OutputStream.Flush();
                response.OutputStream.Close();
            }
            else
                response.Write(
                    "<script>alert('No PDF files found for the selected portfolio/date/filter');window.opener=null;window.close();</script>");
        }

        private static SpObjectInfo GetFileInfo(int organizationId, string cafmFileId, string fileVersion)
        {
            var allFileVersions = CafmRepositoryHelper.CafmRepository.GetAllFileVersions(organizationId, cafmFileId).ToList();
            return allFileVersions.Any() ? GetFileInfoByVersion(allFileVersions, fileVersion) : ProcessFileNotFound();
        }

        private static SpObjectInfo GetFileInfoByVersion(List<SpObjectInfo> allFileVersions, string fileVersion)
        {
            SpObjectInfo fileInfo;
            if (string.IsNullOrEmpty(fileVersion))
            {
                var maxVersion = allFileVersions.Max(f => double.Parse(f.Version)).ToString("F1");
                fileInfo = allFileVersions.First(f => f.Version == maxVersion);
            }
            else
            {
                fileInfo = allFileVersions.First(f => f.Version == fileVersion);
            }
            return fileInfo;
        }

        private static SpObjectInfo ProcessFileNotFound()
        {
            if (CConfig.CafmCreateFoldersOnTheFly)
                return null;
                    
            throw new CafmException("File not found in the sharepoint");
        }


        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultCollection GetAllFileVersion(string internalFileName)
        {
            _log.DebugFormat("GetAllFileVersion(internalFileName = '{0}')", internalFileName);

            try
            {
                if (string.IsNullOrEmpty(internalFileName))
                {
                    _log.Debug("GetAllFileVersion was called with null parameter for the file path");
                    throw new ArgumentNullException("internalFileName", @"internalFileName should be provided");
                }

                var webServiceCallResult = _repositoryService.GetAllFileVersions(CSession.OrganizationID.ToString(), internalFileName);

                if (string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                {
                    var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader, BusinessLayer.User.Loader, true);
                    webServiceCallResult.Data = metadataManager.GetPopulatedAndFilteredMetadata(webServiceCallResult.Data).ToArray();
                }
                else if (CConfig.CafmCreateFoldersOnTheFly && webServiceCallResult.ErrorMessage.StartsWith("Can't retrieve file or folder by unique name"))
                {
                    webServiceCallResult.ErrorMessage = "This file is absent in the Sharepoint storage. It could be after DB refresh. You can upload new file";
                }

                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetAllFileVersion method", ex);
                return new WebServiceCallResultCollection { ErrorMessage = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString ValidateToDeleteFile(string cafmFileId)
        {
            _log.DebugFormat("ValidateToDeleteFile(cafmFileId = '{0}')", cafmFileId);
            string validationMessage = null;
            string allowDeletion = null;
            try
            {
                if (string.IsNullOrEmpty(cafmFileId))
                {
                    _log.Debug("DeleteFile was called with null parameter for the FileId");
                    throw new ArgumentNullException("cafmFileId", @"FileId should be provided");
                }

                var fileInfo = GetFileInfo(CSession.OrganizationID, cafmFileId, null);
                var cafmFiles = FileCafmFactory.GetByFileId(fileInfo.Name);
                var deletingManager = new CafmDeletingManager(fileInfo, cafmFiles.FirstOrDefault());

                deletingManager.ValidateToDeleteFile();
            }
            catch (ValidationException ex)
            {
                validationMessage = ex.Message;
                allowDeletion = "1";
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in ValidateToDeleteFile method", ex);
                validationMessage = ex.Message;
                allowDeletion = "0";
            }
            return new WebServiceCallResultString
                       {
                           Data = allowDeletion,
                           ErrorMessage = validationMessage,
                       };
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResult DeleteFile(string cafmFileId)
        {
            _log.DebugFormat("DeleteFile(cafmFileId = '{0}')", cafmFileId);

            try
            {
                if (string.IsNullOrEmpty(cafmFileId))
                {
                    _log.Debug("DeleteFile was called with null parameter for the FileId");
                    throw new ArgumentNullException("cafmFileId", @"FileId should be provided");
                }

                CafmDeletingManager.CheckAccess();

                var fileInfo = GetFileInfo(CSession.OrganizationID, cafmFileId, null);
                var cafmFile = FileCafmFactory.GetByFileId(fileInfo.Name).FirstOrDefault();
                
                var result = _repositoryService.DeleteFileByFullPath(fileInfo.Path + "/" + fileInfo.Name, UserRoles);

                if (!string.IsNullOrEmpty(result.ErrorMessage))
                {
                    throw new Exception(result.ErrorMessage);
                }

                FileCafmFactory.DeleteFromFileCafm(cafmFileId);

                if (cafmFile != null && cafmFile.EntityType == (int)AttachedDocumentType.EstimatePriceLockdown)
                {
                    CafmDeletingManager.DeleteEstimateAttachments(cafmFile.EntityId, fileInfo.DisplayName);
                }

                return result;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in DeleteFile method", ex);
                return GetWebServiceCallResult(ex.Message);
            }
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString EditFolderMetadata(SpObjectInfo spObjectInfo)
        {
            var result = new WebServiceCallResultString();
            try
            {
                var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader, BusinessLayer.User.Loader, false);
                metadataManager.ValidateFolderMetadata(spObjectInfo);

                result = _repositoryService.UpdateFolderMetadata(CSession.OrganizationID.ToString(), spObjectInfo.Name,

                    new[] 
                    { 
                        new KeyValueElement { Key = "CafmItemName", Value = spObjectInfo.DisplayName },
                        new KeyValueElement { Key = "CafmPortfolioId", Value = spObjectInfo.CafmPortfolioId },
                        new KeyValueElement { Key = "CafmFundId", Value = spObjectInfo.CafmFundId }
                    }, UserRoles);
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResult EditFileMetadata(SpObjectInfo spObjectInfo)
        {
            try
            {
                var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader,
                    BusinessLayer.User.Loader, false);
                metadataManager.ValidateFileMetadata(spObjectInfo);

                var newFileName = spObjectInfo.DisplayName;

                var organizationId = CSession.OrganizationID;
                var fileInfo = GetFileInfo(organizationId, spObjectInfo.Name, null);
                var filePath = Path.Combine(fileInfo.Path, fileInfo.Name);
                var currentFolderContent = _repositoryService.GetSpItemsByFullPath(Path.GetDirectoryName(filePath), DocLibObjectType.File, UserRoles);
                if (currentFolderContent.Data.Any(item => item.DisplayName.ToLower() == newFileName.ToLower() && item.Name != Path.GetFileName(filePath)))
                {
                    return GetWebServiceCallResult("File with same name already exists.");
                }

                WebServiceCallResult webServiceCallResult = _repositoryService.SaveItemsMetadata(
                    new[] { filePath }, false, GetFileMetadata(spObjectInfo));

                if (string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                {
                    CafmRepositoryHelper.CafmManager.RenameFile(Path.GetFileName(filePath), newFileName);
                }

                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in EditFileMetadata method", ex);
                return GetWebServiceCallResult(ex.Message);
            }
        }

        

        private KeyValueElement[] GetFileMetadata(SpObjectInfo spObjectInfo)
        {
            var metadata = new List<KeyValueElement>
                {
                        new KeyValueElement {Key = "CafmItemName", Value = spObjectInfo.DisplayName },
                        new KeyValueElement { Key = "CafmDocFromDate", Value = spObjectInfo.CafmDocFromDate },
                        new KeyValueElement { Key = "CafmDocToDate", Value = spObjectInfo.CafmDocToDate },
                        new KeyValueElement { Key = "CafmComment", Value = spObjectInfo.CafmComment },
                        new KeyValueElement { Key = "CafmDocType", Value = spObjectInfo.CafmDocType }                    
                };

            if (BusinessLayer.Component.HasFullAccess(BusinessLayer.Component.ADMIN_USERS_GROUP, CSession.User))
            {
                metadata.AddRange(new[]
                    {
                        new KeyValueElement { Key = "CafmPortfolioId", Value = spObjectInfo.CafmPortfolioId },
                        new KeyValueElement { Key = "CafmFundId", Value = spObjectInfo.CafmFundId },
                        new KeyValueElement { Key = "CafmFileSource", Value = spObjectInfo.CafmFileSource }                        
                    });
            }

            return metadata.ToArray();
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString IsFileExists(string fileNameWithPath)
        {
            _log.DebugFormat("IsFileExists(fileNameWithPath = '{0}')", fileNameWithPath);

            try
            {
                if (string.IsNullOrEmpty(fileNameWithPath))
                {
                    _log.Debug("IsFileExists was called with null parameter for the fileNameWithPath");
                    throw new ArgumentNullException("filePath", @"File path should be provided");
                }

                return _repositoryService.IsFileExists(CSession.OrganizationID.ToString(), Path.GetFileName(fileNameWithPath));
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in IsFileExists method", ex);
                return new WebServiceCallResultString { ErrorMessage = ex.Message };
            }
        }

        #endregion

        #region Folder operation
        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString CreateFolder(string folderPath)
        {
            _log.DebugFormat("CreateFolder(folderPath = '{0}')", folderPath);

            try
            {
                if (string.IsNullOrEmpty(folderPath))
                {
                    _log.Debug("CreateFolder was called with null parameter for the folder path");
                    throw new ArgumentNullException("folderPath", @"Folder path should be provided");
                }

                WebServiceCallResultString webServiceCallResult = _repositoryService.CreateFolderByFullPath(IdToPath(folderPath), GetMetadata(), UserRoles);
                if (!string.IsNullOrEmpty(webServiceCallResult.Data))
                {
                    webServiceCallResult.Data = PathToId(webServiceCallResult.Data);
                }
                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in CreateFolder method", ex);
                return new WebServiceCallResultString { ErrorMessage = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString RenameFolder(string folderPath, string newName)
        {
            _log.DebugFormat("RenameFolder(folderPath = '{0}', newName = '{1}')", folderPath, newName);

            try
            {
                if (string.IsNullOrEmpty(folderPath))
                {
                    _log.Debug("RenameFolder was called with null parameter for the folder path");
                    throw new ArgumentNullException("folderPath", @"Folder path should be provided");
                }
                if (string.IsNullOrEmpty(newName))
                {
                    _log.Debug("RenameFolder was called with null parameter for the folder new name");
                    throw new ArgumentNullException("newName", @"Folder new name should be provided");
                }

                if (!Regex.IsMatch(newName, string.Format(CultureInfo.CurrentCulture, "[{0}]", RESTRICTED_CHARACTERS)))
                {
                    WebServiceCallResultString webServiceCallResult =
                        _repositoryService.RenameFolderByFullPath(IdToPath(folderPath), newName, GetMetadata(), UserRoles);

                    if (string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                        webServiceCallResult.Data = PathToId(webServiceCallResult.Data);
                    return webServiceCallResult;
                }
                throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, "A folder name cannot contain any of the following characters: {0}",
                                                          RESTRICTED_CHARACTERS));
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in RenameFolder method", ex);
                return new WebServiceCallResultString { ErrorMessage = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResult RemoveFolder(string folderPath)
        {
            _log.DebugFormat("RemoveFolder(folderPath = '{0}')", folderPath);
            try
            {
                if (string.IsNullOrEmpty(folderPath))
                {
                    _log.Debug("RemoveFolder was called with null parameter for the folder path");
                    throw new ArgumentNullException("folderPath", @"Folder path should be provided");
                }

                var webServiceCallResult = _repositoryService.GetSpItemsByFullPath(IdToPath(folderPath), DocLibObjectType.FolderAndFile, UserRoles);
                if (!string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                {
                    return webServiceCallResult;
                }
                if (webServiceCallResult.Data.Any())
                {
                    throw new InvalidOperationException("This folder contains files or subfolders and cannot be deleted.");
                }
                return _repositoryService.RemoveFolderByFullPath(IdToPath(folderPath), UserRoles);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in RemoveFolder method", ex);
                return GetWebServiceCallResult(ex.Message);
            }
        }

        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultCollection GetFolderInfo(string folderPath)
        {
            _log.DebugFormat("GetFolderInfo(folderPath = '{0}')", folderPath);

            try
            {
                if (string.IsNullOrEmpty(folderPath))
                {
                    _log.Debug("GetFolderInfo was called with null parameter for the folder path");
                    throw new ArgumentNullException("folderPath", @"Folder path should be provided");
                }

                var webServiceCallResult = _repositoryService.GetFolderInfo(CSession.OrganizationID.ToString(), Path.GetFileName(IdToPath(folderPath)));
                if (!string.IsNullOrEmpty(webServiceCallResult.ErrorMessage))
                {
                    return webServiceCallResult;
                }
                var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader, BusinessLayer.User.Loader, false);
                webServiceCallResult.Data = metadataManager.GetPopulatedAndFilteredMetadata(webServiceCallResult.Data);
                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFolderInfo method", ex);
                return new WebServiceCallResultCollection { ErrorMessage = ex.Message };
            }
        }
        #endregion

        #region Utility public methods
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultString GetVersion()
        {
            _log.Debug("GetVersion()");
            try
            {
                return _repositoryService.GetVersion();
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetVersion method", ex);
                return new WebServiceCallResultString { ErrorMessage = ex.Message };
            }
        }
        #endregion

        #region Search
        [WebMethod(EnableSession = true)]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public WebServiceCallResultCollection Search(string cafmFields, string fullTextKey, string searchPath, string searchType, string sortColumnName, string sortOrder, bool filesOnly)
        {
            _log.DebugFormat("Search(cafmFields = '{0}', fullTextKey = '{1}', searchPath = '{2}', searchType = '{3}', sortColumnName = '{4}', sortOrder = '{5}')",
                cafmFields, fullTextKey, searchPath, searchType, sortColumnName, sortOrder);
            try
            {
                if (searchPath == "ROOT")
                {
                    searchPath = string.Format("{0}/Root/", CSession.OrganizationID);
                }

                if (searchPath.StartsWith("AF"))//If path to portfolio get this portfolio
                {
                    int id;
                    if (int.TryParse(searchPath.Remove(0, 2), out id))
                    {
                        var portfolio = AllPortfolios.FirstOrDefault(x => x.PortfolioID == id);
                        if (portfolio != null)
                        {
                            searchPath = string.Format("{0}/Root/", CSession.OrganizationID);
                            cafmFields = cafmFields.Insert(1, string.Format("{{'Name':'CafmPortfolioId','Value':'{0}','SPType':'Text','SPOperator':'Contains'}}{1}",
                                id, cafmFields.Contains("}") ? "," : string.Empty));
                        }
                    }
                }

                var pagingSettings = new PagingSettings
                             {
                                 SortColumnName = sortColumnName,
                                 IsAscending = sortOrder == "asc",
                                 RowLimit = SEARCH_RESULT_ROW_LIMIT
                             };

                var queryFields = new JavaScriptSerializer().Deserialize<CafmField[]>(cafmFields).ToList();
                var searchMode = CamlBuilder.GetSearchMode(queryFields, fullTextKey);
                var camlString = CamlBuilder.GetCamlString(queryFields, searchPath, searchMode, pagingSettings, UserRoles);

                var webServiceCallResult = _repositoryService.Search(
                    CSession.OrganizationID.ToString(),
                    camlString,
                    fullTextKey,
                    searchPath,
                    searchMode, // Search mode: by fields (metadata) or full text, or both
                    searchType == "byPhrase" ? FullTextSearchType.Sequence : (searchType == "byAny" ? FullTextSearchType.Any : FullTextSearchType.All),
                    pagingSettings,
                    UserRoles);
                var metadataManager = new CafmMetadataManager(InvestableFund.Loader, Portfolio.Loader, BusinessLayer.User.Loader, false);
                webServiceCallResult.Data = metadataManager.GetPopulatedAndFilteredMetadata(webServiceCallResult.Data);
                webServiceCallResult = CafmRepositoryHelper.HideNotPublishedEstimateAttachments(webServiceCallResult);
                return webServiceCallResult;
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in Search method", ex);
                return new WebServiceCallResultCollection { ErrorMessage = ex.Message };
            }
        }

        #endregion

        #region Autocomplete retrieve methods
        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetFund(string userInput)
        {
            try
            {
                var currentUserFunds = GetBaseFunds()
                    .Select(baseFund => new KeyValueElement { Key = baseFund.FundID.ToString(), Value = baseFund.FundName })
                    .Concat
                        (
                            InvestableFund.GetAllInvestableFunds(CSession.OrganizationID)
                            .Select(fundClass => new KeyValueElement { Key = fundClass.FundID.ToString(), Value = fundClass.FundName })
                        );

                return GetMetadataList(currentUserFunds, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFund method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetFundXref(string userInput)
        {
            try
            {
                var currentUserFunds = GetBaseFunds()
                    .Select(baseFund => new KeyValueElement { Key = baseFund.FundID.ToString(), Value = baseFund.FundDescription })
                    .Concat
                        (
                            InvestableFund.GetAllInvestableFunds(CSession.OrganizationID)
                            .Select(fundClass => new KeyValueElement { Key = fundClass.FundID.ToString(), Value = fundClass.FundDescription })
                        );

                return GetMetadataList(currentUserFunds, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFundXref method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetBaseFund(string userInput)
        {
            try
            {
                var currentUserFunds = GetBaseFunds()
                    .Select(baseFund => new KeyValueElement { Key = baseFund.FundID.ToString(), Value = baseFund.FundName });

                return GetMetadataList(currentUserFunds, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occurred in GetBaseFund method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetBaseFundXref(string userInput)
        {
            try
            {
                var currentUserFunds = GetBaseFunds()
                    .Select(baseFund => new KeyValueElement { Key = baseFund.FundID.ToString(), Value = baseFund.FundDescription });

                return GetMetadataList(currentUserFunds, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occurred in GetBaseFundXref method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetPortofolio(string userInput)
        {
            try
            {
                var currentClientPortfolios = CSession.Portfolios.Select(p => new KeyValueElement { Key = p.PortfolioID.ToString(), Value = p.PortfolioName });
                return GetMetadataList(currentClientPortfolios, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetPortofolio method", ex);
                throw;
            }
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetPortofolioXref(string userInput)
        {
            var currentClientPortfolios = CSession.Portfolios.Select(p => new KeyValueElement { Key = p.PortfolioID.ToString(), Value = p.IfsPortfolioId }
                            );
            return GetMetadataList(currentClientPortfolios, userInput);
        }

        [WebMethod(EnableSession = true)]
        public List<KeyValueElement> GetUserLogin(string userInput)
        {
            try
            {
                var currentClientUsers = CSession.CurrentOrganization.Users.Select(u => new KeyValueElement { Key = u.UserID.ToString(), Value = u.UserFullName });
                return GetMetadataList(currentClientUsers, userInput);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetUserLogin method", ex);
                throw;
            }
        }

        private static List<KeyValueElement> GetMetadataList(IEnumerable<KeyValueElement> items, string userInput)
        {
            try
            {
                return items.Where(item => item.Value != null && item.Value.ToString().ToLower().Contains(userInput.ToLower())).Take(30).ToList();
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetMetadataList method", ex);
                throw;
            }
        }
        #endregion

        #region Private helper methods
        private static int GetFundIdFromPath(string path)
        {
            int fundid = -1;
            var afEntityFolderName = path.Split('/').Reverse().FirstOrDefault(pathPart => _regexAfEntity.IsMatch(pathPart));
            if (!string.IsNullOrEmpty(afEntityFolderName))
                int.TryParse(Regex.Replace(afEntityFolderName, @"\D", ""), out fundid);

            return fundid;
        }

        private static bool IsAfEntity(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
            {
                _log.Debug("IsAfEntity was called with null parameter for the folder path");
                throw new ArgumentNullException("folderPath", @"Folder path should be provided");
            }
            _log.DebugFormat("IsAfEntity(folderPath = '{0}')", folderPath);
            return _regexAfEntity.IsMatch(folderPath);
        }

        private static IEnumerable<string> GetPredefinedFolderPrefixes()
        {
            _log.Debug("GetPredefinedFolderPrefixes()");
            try
            {
                return typeof(PreDefinedFolders).GetFields(BindingFlags.Public | BindingFlags.Static).Select(prop => ((PreDefinedFolder)prop.GetValue(null)).Abbreviation);
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetPredefinedFolderPrefixes method", ex);
                throw;
            }
        }

        private static string GetFolderTypeByFolderName(string folderName)
        {
            if (string.IsNullOrEmpty(folderName))
            {
                _log.Debug("GetFolderTypeByFolderName was called with null parameter for the folder name");
                throw new ArgumentNullException("folderName", @"Folder name should be provided");
            }
            _log.DebugFormat("GetFolderTypeByFolderName(folderName = '{0}')", folderName);
            try
            {
                string folderPrefix = Regex.Match(folderName, "(?<AF_PREFIX>^[A-Z]+)([0-9]+$)").Groups["AF_PREFIX"].Value;
                if (!string.IsNullOrEmpty(folderPrefix))
                {
                    string[] predefinedPrefixes = GetPredefinedFolderPrefixes().ToArray();
                    if (predefinedPrefixes.Contains(folderPrefix))
                    {
                        return folderPrefix;
                    }
                }
                return "default";
            }
            catch (Exception ex)
            {
                _log.Error("Exception occured in GetFolderTypeByFolderName method", ex);
                throw;
            }
        }

        private static WebServiceCallResult GetWebServiceCallResult(string errorMessage)
        {
            return new WebServiceCallResult
            {
                ErrorMessage = errorMessage,
                IsUnknownException = true
            };
        }

        private static string JsonSerialize(object obj)
        {
            return (new JavaScriptSerializer()).Serialize(obj);
        }

        private static string PathToId(string path)
        {
            return path.Replace("/", "_u002f_").Replace(" ", "_u0020_");
        }

        private static string IdToPath(string id)
        {
            return id.Replace("_u002f_", "/").Replace("_u0020_", " ");
        }

        private static KeyValueElement[] GetMetadata(string comment, string documentType = null, string documentDateFrom = null, string documentDateTo = null, string filePortfolioId = null, int baseFundId = -1)
        {
            DateTime dateFrom;
            DateTime dateTo;
            int portfolioId;
            return new[]
                    {
                       new KeyValueElement {Key = "CafmFileSource", Value = FileSource.Generic},
                       new KeyValueElement {Key = "CafmUserId", Value = CSession.User.UserID},
                       new KeyValueElement {Key = "CafmUserLogin", Value = CSession.User.UserName},
                       new KeyValueElement {Key = "CafmComment", Value = comment},
                       new KeyValueElement {Key = "CafmDocType", Value = documentType},
                       new KeyValueElement {Key = "CafmDocFromDate", Value = TryParseDate(documentDateFrom, out dateFrom) ? dateFrom.ToUniversalTime() : (DateTime?)null},
                       new KeyValueElement {Key = "CafmDocToDate", Value = TryParseDate(documentDateTo, out dateTo) ? dateTo.ToUniversalTime() : (DateTime?)null},
                       new KeyValueElement {Key = "CafmPortfolioId", Value = int.TryParse(filePortfolioId, out portfolioId) && portfolioId > 0 ? filePortfolioId : string.Empty},
                       new KeyValueElement {Key = "CafmBaseFundId", Value = baseFundId > 0 ? baseFundId.ToString(CultureInfo.InvariantCulture) : string.Empty}
                    };
        }

        private static bool TryParseDate(string dateToParse, out DateTime resultDate)
        {
            return DateTime.TryParseExact(dateToParse, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out resultDate);
        }

        private static KeyValueElement[] GetMetadata()
        {
            return GetMetadata(string.Empty);
        }
        #endregion

        #region Private classes for info transfer
        // ReSharper disable InconsistentNaming
        // ReSharper disable UnusedAutoPropertyAccessor.Local
        /// <summary>
        /// This class contains properties in lower case and not clear names for direct serialization to JSON.
        /// jQuery plugin jsTree requires data to populate tree just in this format.
        /// </summary>
        private class JsTreeNode
        {
            // ReSharper disable MemberCanBePrivate.Local
            //contains node attributes like id
            public JsTreeNodeAttributes attr { get; set; }
            //contains node attributes like title
            public JsTreeNodeData data { get; set; }
            //contains node status like "open"/"closed"
            public string state { get; set; }
            public List<JsTreeNode> children { get; private set; }
            // ReSharper restore MemberCanBePrivate.Local

            private JsTreeNode(string id, string title, string rel)
            {
                children = new List<JsTreeNode>();

                if (!string.IsNullOrEmpty(title))
                {
                    data = new JsTreeNodeData { title = title };
                }

                if (!string.IsNullOrEmpty(id) || !string.IsNullOrEmpty(rel))
                {
                    if (attr == null)
                    {
                        attr = new JsTreeNodeAttributes();
                    }
                    attr.id = id;
                    attr.rel = rel;
                }
            }

            public JsTreeNode(string id, string title, string rel, bool isOpened)
                : this(id, title, rel)
            {
                state = isOpened ? "open" : "closed";
            }

            public JsTreeNode(string id, string title, string rel, List<JsTreeNode> children)
                : this(id, title, rel)
            {
                this.children = children;
            }

            public JsTreeNode(string id, string title, string rel, bool isOpened, List<JsTreeNode> children)
                : this(id, title, rel, isOpened)
            {
                this.children = children;
            }
        }

        /// <summary>
        /// This class contains properties in lower case and not clear names for direct serialization to JSON.
        /// jQuery plugin jsTree requires data to populate tree just in this format.
        /// </summary>
        private class JsTreeNodeAttributes
        {
            //id contains item path in Sharepoint
            public string id { get; set; }
            //rel contains node type, to attach icon and specific behavior
            public string rel { get; set; }
        }

        /// <summary>
        /// This class contains properties in lower case and not clear names for direct serialization to JSON.
        /// jQuery plugin jsTree requires data to populate tree just in this format.
        /// </summary>
        private class JsTreeNodeData
        {
            // title contains node display text
            public string title { get; set; }
        }
        // ReSharper restore UnusedAutoPropertyAccessor.Local
        // ReSharper restore InconsistentNaming
        #endregion
    }
}