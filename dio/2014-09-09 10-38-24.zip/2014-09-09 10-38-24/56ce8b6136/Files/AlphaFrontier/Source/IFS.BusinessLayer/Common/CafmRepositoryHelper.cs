﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using CafmRepositoryFacade;
using CafmRepositoryFacade.SpRepositoryService;
using IFS.BusinessLayer.Cafm;
using IFS.BusinessLayer.Price;
using IFS.BusinessLayer.Utilities;
using IFS.DataAccess.Entity;
using IFS.DataAccess.shared;
using Common.Logging;
using IFS.BusinessLayer.CloudServices.Reports;
using Microsoft.Win32;
using File = IFS.Interfaces.Common.File;

namespace IFS.BusinessLayer.Common
{
    public static class CafmRepositoryHelper
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(CafmRepositoryHelper));
        private static volatile CafmRepository _cafmRepository;
        private static readonly List<int> _existedFundIds = new List<int>();
        private readonly static object _lock = new object();

        public static CafmRepository CafmRepository
        {
            get
            {
                if (_cafmRepository == null)
                {
                    lock (_lock)
                    {
                        if (_cafmRepository == null)
                        {
                            var cafmRepository = (CafmRepository)SpringUtil.GetObject("CafmRepository");
                            cafmRepository.Initialize(CreateRepositoryService(), CConfig.CafmCreateFoldersOnTheFly);
                            _cafmRepository = cafmRepository;
                        }
                    }
                }

                return _cafmRepository;
            }
        }

        private static SpRepositoryServiceWrapper CreateRepositoryService()
        {
            if (string.IsNullOrEmpty(CConfig.CafmUser))
                throw new ArgumentNullException("userName", "User login should be provided");
            if (string.IsNullOrEmpty(CConfig.CafmPassword))
                throw new ArgumentNullException("userPassword", "User password should be provided");

            var repositoryService = new SpRepositoryService
            {
                Url = CConfig.CafmRepositoryService,
                Credentials = new NetworkCredential(CConfig.CafmUser, CConfig.CafmPassword, CConfig.CafmDomain)
            };
            return new SpRepositoryServiceWrapper(repositoryService);
        }

        public static CafmManager CafmManager
        {
            get { return new CafmManager(); }
        }

        public static void CreateFullFundSharepointStructure(UnderlyingFund fund)
        {
            //If CConfig.CafmCreateFoldersOnTheFly==false we already have it
            if (CConfig.CafmCreateFoldersOnTheFly && !_existedFundIds.Contains(fund.FundID))
            {
                CreateFullFundSharepointStructureOnTheFly(fund);
                _existedFundIds.Add(fund.FundID);
            }
        }

        public static void CheckReportStructure(string organizationId, string reportName, GsmReportId gsmReportId)
        {
            var reportId = (int) gsmReportId;
            if (!_existedFundIds.Contains(reportId))
            {
                var afFolderName = CafmRepository.GetAlphaFrontierEntityFolderName(reportId);
                if (!CafmRepository.IsFolderExists(organizationId, afFolderName))
                {
                    var user = CSession.User;
                    var metaData = new MetaData
                        {
                            CafmClient = organizationId,
                            CafmFundId = "",
                            CafmUserId = user.UserID.ToString(),
                            CafmUserLogin = user.UserName,
                        };
                    try
                    {
                        CafmRepository.CreateReport(organizationId, reportId.ToString(), reportName, metaData, afFolderName);
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            //if folder was created by something else do not throw an exception.
                            if (!CafmRepository.IsFolderExists(organizationId, afFolderName))
                                throw;
                        }
                        catch (Exception exCheck)
                        {
                            _log.Error("Error checking for folder", exCheck);
                            throw ex;
                        }
                    }
                }
                _existedFundIds.Add(reportId);
            }
        }

        public static string UploadReportFile(string organizationId, DateTime reportDate, string reportName,
            string fileName, byte[] fileContent, PreDefinedFolder folderStructure = null)
        {
            var eReport = ReportsHelper.GetRepositoryReport(reportName);
            CheckReportStructure(organizationId, reportName, eReport.ReportId);

            var curYear = reportDate.Year.ToString();
            var curMonth = reportDate.ToString("MMMM");
            var preDefinedYearFolder = new PreDefinedFolder(curYear, curYear, folderStructure);
            var preDefinedMonthFolder = new PreDefinedFolder(curMonth, curMonth, preDefinedYearFolder);
            if(folderStructure != null)
            {
                preDefinedYearFolder.SpecialFolderId = folderStructure.SpecialFolderId;
                preDefinedMonthFolder.SpecialFolderId = folderStructure.SpecialFolderId;
            }

            var user = CSession.User;
            var metaData = new MetaData
            {
                CafmClient = organizationId,
                CafmFundId = "",
                CafmUserId = user.UserID.ToString(),
                CafmUserLogin = user.UserName,
            };
            return CafmManager.UploadFile(organizationId, eReport.SReportId, preDefinedMonthFolder, fileName, fileContent, null, null, metaData, null);

        }

        public static void CreateFullFundSharepointStructureOnTheFly(UnderlyingFund fund)
        {
            var orgId = fund.OrganizationID.ToString();
            var fundId = fund.FundID.ToString();
            if (CafmRepository.IsFolderExists(orgId, CafmRepository.GetAlphaFrontierEntityFolderName(fundId)))
                return;//All folders are in SharePoint

            var user = CSession.User;
            var metaData = new MetaData
            {
                CafmClient = orgId,
                CafmFundId = fundId,
                CafmUserId = user.UserID.ToString(),
                CafmUserLogin = user.UserName,
            };

            if (fund.ParentFundID > 0)
            {
                CreateFullFundSharepointStructureOnTheFly(UnderlyingFund.GetFund(fund.ParentFundID));
                new CafmManager().CreateFund(orgId, fund, metaData);
            }
            else
            {
                if (fund.FundType == SystemType.PORTFOLIO)
                    new CafmManager().CreatePortfolio(orgId,fund,metaData);
                else
                    CreateBaseFund(fund, user);
            }
        }

        public static void CreatePortfolio(Portfolio portfolio, User user = null)
        {
            try
            {
                if (user == null)
                    user = CSession.User;
                var metaData = new MetaData
                {
                    CafmClient = portfolio.OrganizationID.ToString(),
                    CafmPortfolioId = portfolio.PortfolioID.ToString(),
                    CafmUserId = user.UserID.ToString(),
                    CafmUserLogin = user.UserName,
                };
                _log.DebugFormat("CreatePortfolio(organizationId = '{0}', portfolioId = '{1}', portfolioName = '{2}')", portfolio.OrganizationID, portfolio.PortfolioID, portfolio.PortfolioName);
                new CafmManager().CreatePortfolio(metaData.CafmClient, portfolio, metaData);
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                throw new AFException(ex.Message);
            }
        }

        public static void CreateBaseFund(UnderlyingFund fund, User user = null, string fundName = null)
        {
            try
            {
                if (user == null)
                    user = CSession.User;
                var metaData = CreateNewMetaData(fund, user);
                fundName = fundName ?? fund.FundName;
                _log.DebugFormat("CreateBaseFund(organizationId = '{0}', fundID = '{1}', fundName = '{2}')", fund.OrganizationID, fund.FundID, fundName);
                new CafmManager().CreateFund(metaData.CafmClient, fund, metaData,fundName);
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                throw new AFException(ex.Message);
            }
        }

        private static MetaData CreateNewMetaData(UnderlyingFund fund, User user)
        {
            return new MetaData
            {
                CafmClient = fund.OrganizationID.ToString(),
                CafmFundId = fund.FundID.ToString(),
                CafmUserId = user.UserID.ToString(),
                CafmUserLogin = user.UserName,
            };
        }

        public static void CreateFundSeries(InvestableFund fund)
        {
            CreateFundClass(fund);
        }

        public static void CreateFundClass(InvestableFund fund, User user = null)
        {
            try
            {
                if (user == null)
                    user = CSession.User;
                _log.DebugFormat("CreateFund(organizationId = '{0}', parentFundId = '{1}', fundID = '{2}', fundName = '{3}')",
                    fund.OrganizationID, fund.ParentFundID, fund.FundID, fund.FundName);

                var metaData = CreateNewMetaData(fund, user);
                CreateFullFundSharepointStructure(fund.ParentFund);//For QA
                new CafmManager().CreateFund(metaData.CafmClient, fund, metaData);
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                throw new AFException(ex.Message);
            }
        }

        public static WebServiceCallResultCollection HideNotPublishedEstimateAttachments(WebServiceCallResultCollection inputCollection)
        {
            var user = CSession.User;
            if (Component.IsAccessible(Component.PUBLISH_ATTACHMENTS, user))
                return inputCollection;

            var resultList = new List<SpObjectInfo>();
            foreach (var item in inputCollection.Data)
            {
                var cafmFiles = FileCafmFactory.GetByFileId(item.Name);
                // if entity is null this means it was uploaded through e-rep directly
                var cafmFile = cafmFiles != null ? cafmFiles.FirstOrDefault() : null;
                if (cafmFile != null && cafmFile.EntityType == (int)AttachedDocumentType.EstimatePriceLockdown)
                {
                    var estimate = EstimateAttachment.GetEstimateAttachments(cafmFile.EntityId).FirstOrDefault(e => e.AttachmentName == cafmFile.FileName);
                    // Note: estimate can be null in case when CAFM and DB are unsynchronized.
                    if (estimate != null && !estimate.IsPublished())
                        continue;
                }
                resultList.Add(item);
            }

            var result = new WebServiceCallResultCollection {Data = resultList.ToArray()};
            return result;
        }

        public static void RenameAlphaFrontierEntity(UnderlyingFund fund)
        {
            try
            {
                var fundName = fund.IsGSMFund && fund is BaseFund ? ((BaseFund)fund).InitialGsmFundName : fund.FundName;
                CafmRepository.RenameAlphaFrontierEntity(fund.OrganizationID.ToString(), fund.FundID.ToString(), fundName, new MetaData());
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                if (!CConfig.CafmCreateFoldersOnTheFly)
                    throw new AFException(ex.Message);
            }
        }

        public static void RemoveAlphaFrontierEntity(UnderlyingFund fund)
        {
            try
            {
                _log.DebugFormat("RemoveAlphaFrontierEntity(organizationId = '{0}', itemId = '{1}')", fund.OrganizationID, fund.FundID);
                CafmRepository.RemoveAlphaFrontierEntity(fund.OrganizationID.ToString(), fund.FundID.ToString());

                if (fund is Portfolio)
                {
                    _log.DebugFormat("DeleteFromFileCafm(entityId = '{0}', documentType = '{1}')", fund.FundID, AttachedDocumentType.CreditProvider);
                    FileCafmFactory.DeleteFromFileCafm(fund.FundID, AttachedDocumentType.CreditProvider);
                }
                else if (fund is SideLetter)
                {
                    _log.DebugFormat("DeleteFromFileCafm(entityId = '{0}', documentType = '{1}')", fund.FundID, AttachedDocumentType.SideLetter);
                    FileCafmFactory.DeleteFromFileCafm(fund.FundID, AttachedDocumentType.SideLetter);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                if (!CConfig.CafmCreateFoldersOnTheFly)
                    throw new Exception(ex.Message, ex.InnerException);
            }
        }

        public static void DebugFormat(this ILog log, string formatString, params object[] appenders)
        {
            if (log.IsDebugEnabled)
                log.Debug(string.Format(formatString, appenders));
        }

        public static bool IsFundHasRepositoryFiles(UnderlyingFund fund)
        {
            try
            {
                var isFundAPortfolio = fund is Portfolio;
                var fieldName = isFundAPortfolio ? "CafmPortfolioId" : "CafmFundId";
                _log.DebugFormat("IsFundHasRepositoryFiles(organizationID = {0}, fundId = '{1}', fieldName = '{2}')", fund.OrganizationID, fund.FundID, fieldName);
                return CafmRepository.IsFundHasRepositoryFiles(fund.OrganizationID, fund.FundID, fieldName);
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                throw;
            }
        }

        public static string GetFileContentType(string ext)
        {
            var mime = "application/octet-stream";
            var rk = Registry.ClassesRoot.OpenSubKey(ext);
            if (rk != null && rk.GetValue("Content Type") != null)
                mime = rk.GetValue("Content Type").ToString();
            return mime;
        }

        /// <summary>
        /// Update TblFileTransfer to keep link for files to be sent to external Client
        /// </summary>
        public static void UpdateTblFileTransfer(string cafmFileId, string fileName, AttachedDocumentType documentType, int entityId, int orgId, int fundId)
        {
            using (var afDbDataContext = new AfDataContext())
            {
                var table = afDbDataContext.GetTable<FileTransferData>();
                var item = table.FirstOrDefault(x => x.CafmFileId == cafmFileId && x.EntityId == entityId && x.EntityType == (int)documentType &&
                        x.OrganizationId == orgId && x.FundId == fundId);

                if (item == null)
                {
                    item = new FileTransferData
                    {
                        CafmFileId = cafmFileId,
                        EntityType = (int)documentType,
                        EntityId = entityId
                    };
                    table.InsertOnSubmit(item);
                }
                ////Set new name
                item.FileName = fileName;
                item.OrganizationId = orgId;
                item.FundId = fundId;
                item.FileDate = DateTime.Now;
                afDbDataContext.SubmitChanges();
            }
        }

        public static int TryGetBaseFundId(int fundId)
        {
            try
            {
                var investableFund = InvestableFund.Loader.GetById(fundId);
                return investableFund != null ? investableFund.Basefund.FundID : -1;
            }
            catch (Exception exc)
            {
                _log.Warn("Failed to get BaseFundId for fund [id=" + fundId + "]", exc);
                return -1;
            }
        }

        public static byte[] GetCafmFile(int organizationId, string cafmFileId)
        {
            return CafmRepository.DownloadFileByCafmFileName(organizationId, cafmFileId);
        }

        public static void MoveTicketFileInCafm(Allocation allocation, int sourceFundId, int destinationFundId)
        {
            CreateFullFundSharepointStructure(allocation.Fund);

            var allocationId = allocation.Id.ToString(CultureInfo.InvariantCulture);
            var organizationId = allocation.OrganizationId.ToString(CultureInfo.InvariantCulture);

            var srcFundId = sourceFundId.ToString(CultureInfo.InvariantCulture);
            var dstFundId = destinationFundId.ToString(CultureInfo.InvariantCulture);

            if (CafmRepository.IsPreDefinedFolderExists(organizationId, PreDefinedFolders.TradeExecutionTicket, srcFundId, allocationId))
            {
                var folderDisplayAppendix = string.Format("{0}_{1}", allocationId,  allocation.ExecutionDate.ToShortDateString());
                CafmRepository.MovePreDefinedFolder(organizationId, PreDefinedFolders.TradeExecutionTicket, srcFundId, dstFundId, allocationId, folderDisplayAppendix);
            }
        }

        public static void AddTicketFileToCafm(Allocation allocation, File ticketFile)
        {
            CreateFullFundSharepointStructureOnTheFly(allocation.Fund);

            var fundId = allocation.FundID.ToString(CultureInfo.InvariantCulture);
            var baseFundId = allocation.Fund.ParentFundID.ToString(CultureInfo.InvariantCulture);
            var portfolioId = allocation.PortfolioId.ToString(CultureInfo.InvariantCulture);
            var userId = CSession.User.Id.ToString(CultureInfo.InvariantCulture);
            var organizationId = allocation.OrganizationId.ToString(CultureInfo.InvariantCulture);

            var metadata = new MetaData
            {
                CafmFundId = fundId,
                CafmPortfolioId = portfolioId,
                CafmUserId = userId,
                CafmUserLogin = CSession.User.UserName,
                CafmFileSource = FileSource.GetAllocationTradeExecutionFileSource(allocation.AllocationTypeId),
                CafmBaseFundId = baseFundId
            };

            CafmManager.UploadFile(organizationId, fundId, PreDefinedFolders.TradeExecutionTicket, Path.GetFileName(ticketFile.FileName), ticketFile.FileBlob,
                AttachedDocumentType.TradeExecutionTicket, allocation.Id, string.Format("{0}_{1}", allocation.Id, allocation.ExecutionDate.ToShortDateString()),
                metadata, null);
        }

    }
}