﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using IFS.BusinessLayer.Export;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.BusinessLayer.CloudServices.Reports
{
    public class ERepositoryReportsStructure
    {
        private readonly string _reportName;
        private readonly GsmReportId _reportId;
        private readonly string _sReportId;
        private readonly GsmReportId? _parentReportId;

        public string ReportName { get { return _reportName; } }
        public GsmReportId ReportId { get { return _reportId; } }
        public string SReportId { get { return _sReportId; } }
        public GsmReportId? ParentReportId { get { return _parentReportId; } }

        public ERepositoryReportsStructure(string reportName, GsmReportId reportId, GsmReportId? parentReportId)
        {
            _reportId = reportId;
            _sReportId = ((int)reportId).ToString();
            _reportName = reportName;
            _parentReportId = parentReportId;
        }
    }

    public interface IReportsHelper
    {
        ExportResult GetExportResult(BaseOpenXmlExcelExporter excelGenerator, string fileName);
    }

    public class ReportsHelperNonStatic : IReportsHelper
    {
        //
        // In the words of Buzz Lightyear - Statics, Statics everywhere...
        //
        // This bridge is to help refactor out statics here.

        public ExportResult GetExportResult(BaseOpenXmlExcelExporter excelGenerator, string fileName)
        {
            return ReportsHelper.GetExportResult(excelGenerator, fileName);
        }
    }

    public enum GsmReportId
    {
        ClientSpecificSecurityReport = 1,
        PriceEntryDetailsReport = 2,
        ReconciliationReport = 3,
        EstimateReconciliationReport = 4,
        FinalReconciliationReport = 5,
        OutstandingFinalsAndEstimatesReport = 6
    }

    public class ReportsHelper
    {
        public const string ALL_PORTFOLIOS_STRING = "All Portfolios";
        public const string CLIENT_SPECIFIC_SECURITY_REPORT = "Clients supported by GSM";
        public const string PRICE_ENTRY_DETAILS__REPORT = "PriceEntryDetailsReport";
        public const string RECONCILIATION_REPORT = "Reconciliation Reports";
        public const string FINAL_RECONCILIATION_REPORT = "Final_Rec_Report";
        public const string ESTIMATE_RECONCILIATION_REPORT = "Estimate_Rec_Report";
        public const string OUTSTANDING_FINALS_AND_ESTIMATES_REPORT = "Outstanding_finals_and_estimates_report";

        public static readonly List<ERepositoryReportsStructure> ERepositoryReports = new List<ERepositoryReportsStructure>
             {
                 new ERepositoryReportsStructure(CLIENT_SPECIFIC_SECURITY_REPORT, GsmReportId.ClientSpecificSecurityReport, null),
                 new ERepositoryReportsStructure(PRICE_ENTRY_DETAILS__REPORT, GsmReportId.PriceEntryDetailsReport, null),
                 new ERepositoryReportsStructure(RECONCILIATION_REPORT, GsmReportId.ReconciliationReport, null),
                 new ERepositoryReportsStructure(ESTIMATE_RECONCILIATION_REPORT, GsmReportId.EstimateReconciliationReport, GsmReportId.ReconciliationReport),
                 new ERepositoryReportsStructure(FINAL_RECONCILIATION_REPORT, GsmReportId.FinalReconciliationReport, GsmReportId.ReconciliationReport),
                 new ERepositoryReportsStructure(OUTSTANDING_FINALS_AND_ESTIMATES_REPORT, GsmReportId.OutstandingFinalsAndEstimatesReport, GsmReportId.ReconciliationReport)
             };

        public static ERepositoryReportsStructure GetRepositoryReport(string reportName)
        {
            return ERepositoryReports.FirstOrDefault(r => r.ReportName == reportName);
        }

        public static ExportResult GetExportResult(BaseOpenXmlExcelExporter excelGenerator, string fileName)
        {
            return new ExportResult { FileName = fileName, Exported = excelGenerator.ExportToExcel() };
        }

        public static string GetPortfolioString(Portfolio portfolio)
        {
            return portfolio == null ? ALL_PORTFOLIOS_STRING : portfolio.PortfolioName;
        }

        public static string GetPortfolioString(int portfolioId)
        {
            var portfolio = portfolioId > 0 ? Portfolio.GetById(portfolioId) : null;
            return GetPortfolioString(portfolio);
        }

        public static List<PortfolioView> GetPortfolioView(IEnumerable<Portfolio> portfolios)
        {
            return portfolios.Select(p => p.GetView<PortfolioView>()).ToList();
        }
    }
}
