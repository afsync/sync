﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using IFS.BusinessLayer.CloudServices.Reports;
using IFS.BusinessLayer.Common;
using IFS.NUnitTests.BusinessLayer.shared;
using NUnit.Framework;
using Expression = Spring.Expressions.Expression;

namespace IFS.NUnitTests.Tests.ReflectionHelperTests
{
    [TestFixture]
    public class ReflectionHelperTest
    {
        private class Owner
        {
            public Owner()
            {}
            public Owner(int privateReadonlyField)
            {
                _privateReadonlyField = privateReadonlyField;
            }
            public int PublicField;
            protected int ProtectedField;
            private int _privateField;
            private readonly int _privateReadonlyField;
            public int PrivateFieldValue
            {
                get { return _privateField; }
                set { _privateField = value; }
            }
            public int ProtectedFieldValue
            {
                get { return ProtectedField; }
                set { ProtectedField = value; }
            }
            public int PublicProperty { get; set; }
            private int PrivateProperty { get; set; }
            protected int ProtectedProperty { get; set; }
            public int PublicGetPrivateSet { get; private set; }
            public int PublicGetProtectedSet { get; protected set; }
            protected int ProtectedGetPrivateSet { get; private set; }
            public int PrivateGetPublicSet { private get; set; }
            public int ProtectedGetPublicSet { protected get; set; }
            protected int PrivateGetProtectedSet { private get; set; }

            public int? NullableProperty { get; set; }

            public int PublicGetNoSet
            {
                get { return 7; }
            }

            public int NoGetPublicSet
            {
                set { }
            }

            public Owner OwnerProperty { get; set; }
        }

        private class Descendant : Owner
        {
        }

        private void TestProperty(PropertyInfo property)
        {
            ReflectedField.GenericGetter getter = ReflectedField.CreateGetDelegate(property);
            ReflectedField.GenericSetter setter = ReflectedField.CreateSetDelegate(property);
            const int value = 100;

            var obj = new Owner();
            setter(obj, value);

            Assert.AreEqual(value, getter(obj));
        }

        private void TestClassProperties<T>()
            where T : Owner
        {
            TestProperty(ReflectionHelper.GetPropertyInfo<T>(t => t.PublicProperty));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("PrivateProperty"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("ProtectedProperty"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("PublicGetPrivateSet"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("PublicGetProtectedSet"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("ProtectedGetPrivateSet"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("PrivateGetPublicSet"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>("ProtectedGetPublicSet"));
            TestProperty(ReflectionHelper.GetPropertyInfo<T>(t => t.NullableProperty));
        }

        [Test]
        public void CreateDelegateNullThrows()
        {
            PropertyInfo pi = null;
            Assert.Throws<ArgumentNullException>(() => ReflectedField.CreateGetDelegate(pi));
            Assert.Throws<ArgumentNullException>(() => ReflectedField.CreateSetDelegate(pi));
            Assert.Throws<ArgumentNullException>(() => ReflectedField.CreateGetDelegate(null, "aaa"));
            Assert.Throws<ArgumentNullException>(() => ReflectedField.CreateSetDelegate(null, "aaa"));
        }

        [Test]
        public void DescendantPropertiesAccessTest()
        {
            TestClassProperties<Descendant>();
        }

        

        [Test]
        public void GetPropertyInfoTest()
        {
            PropertyInfo property = ReflectionHelper.GetPropertyInfo<Owner>(t => t.PublicProperty);
            PropertyInfo expected = typeof (Owner).GetProperty("PublicProperty");
            Assert.AreEqual(expected, property);
        }

        [Test]
        public void GetPropertyNameTest()
        {
            Assert.AreEqual("PublicProperty", ReflectionHelper.GetPropertyName<Owner>(tc => tc.PublicProperty));
            Assert.Throws<ArgumentNullException>(() => ReflectionHelper.GetPropertyName<Owner>(null));
        }

        [Test]
        public void GetReflectedFieldReturnsNullForInvalidProperty()
        {
            Assert.IsNull(ReflectionHelper.GetReflectedField<Owner>("ppppp"));
        }

        [Test]
        public void GetReflectedFieldReturnsSameInstances()
        {
            Assert.AreEqual(
                ReflectionHelper.GetReflectedField<Owner>("PublicProperty"),
                ReflectionHelper.GetReflectedField<Owner>("PublicProperty"));
        }

        [Test]
        public void GetReflectedFieldTest()
        {
            Assert.IsNotNull(ReflectionHelper.GetReflectedField<Owner>("PublicProperty"));
        }

        [Test]
        public void IsNullableForNullableFails()
        {
            Assert.IsFalse(typeof (int).IsNullable());
            Assert.IsFalse(typeof (object).IsNullable());
        }

        [Test]
        public void IsNullableForNullableSucceeds()
        {
            Assert.IsTrue(typeof (int?).IsNullable());
        }

        [Test]
        public void NoGetPublicSet()
        {
            ReflectedField.GenericSetter setter = ReflectedField.CreateSetDelegate<Owner>("NoGetPublicSet");
            ReflectedField.GenericGetter getter = ReflectedField.CreateGetDelegate<Owner>("NoGetPublicSet");
            Assert.IsNotNull(setter);
            Assert.IsNull(getter);
        }

        [Test]
        public void NotNullableSetNullTest()
        {
            ReflectedField.GenericSetter setter = ReflectedField.CreateSetDelegate<Owner>(t => t.PublicProperty);
            ReflectedField.GenericGetter getter = ReflectedField.CreateGetDelegate<Owner>(t => t.PublicProperty);

            var obj = new Owner();
            setter(obj, null);

            Assert.AreEqual(0, getter(obj));
        }

        [Test]
        public void OwnerPropertiesAccessTest()
        {
            TestClassProperties<Owner>();
        }

        [Test, Explicit]
        public void PerfomanceMeasureWithNullCheckAndWithout()
        {
            ReflectedField.GenericSetter setterNullable = ReflectedField.CreateSetDelegate<Owner>(t => t.PublicProperty);
            ReflectedField.GenericSetter setterNonNullable =
                ReflectedField.CreateSetDelegate<Owner>(t => t.NullableProperty);
            var obj = new Owner();
            const int iterations = 1000000;
            setterNullable(obj, null);
            setterNonNullable(obj, null);

            var stopwatch = new Stopwatch();
            stopwatch.Start();
            for (int i = 0; i < iterations; i++)
                setterNullable(obj, null);
            stopwatch.Stop();
            Console.WriteLine("Setter nullable: {0}", stopwatch.ElapsedMilliseconds);
            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < iterations; i++)
                setterNonNullable(obj, null);
            stopwatch.Stop();
            Console.WriteLine("Setter nonnullable: {0}", stopwatch.ElapsedMilliseconds);
            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < iterations; i++)
                typeof(Owner).GetProperty("NullableProperty").SetValue(obj, null, null);
            stopwatch.Stop();
            Console.WriteLine("Reflection setter: {0}", stopwatch.ElapsedMilliseconds);
            stopwatch.Reset();
            stopwatch.Start();
            for (int i = 0; i < iterations; i++)
                obj.NullableProperty = null;
            stopwatch.Stop();
            Console.WriteLine("Coded setter: {0}", stopwatch.ElapsedMilliseconds);
        }

        [Test, Explicit]
        public void PerfomanceMeasureConstructor()
        {
            const int iterations = 1000000;
            Action measured = () => new Owner();
            Console.WriteLine("Constructor call: {0}", measured.MeasureIterationsMs(iterations));

            var obj = new object[0];
            measured = () =>
            {
                ConstructorInfo constructor = typeof(Owner).GetConstructor(Type.EmptyTypes);
                var value = (Owner)constructor.Invoke(obj);
            };
            Console.WriteLine("Reflection call: {0}", measured.MeasureIterationsMs(iterations));


            Func<object> objectFactory = null;
            measured = () =>
            {
                if (objectFactory == null)
                    objectFactory = CreateFactory(typeof(Owner));
                var value = objectFactory();
            };

            Console.WriteLine("Generic method: {0}", measured.MeasureIterationsMs(iterations));

            measured = () => objectFactory();
            Console.WriteLine("Generic method without init: {0}", measured.MeasureIterationsMs(iterations));

            measured = () => Activator.CreateInstance(typeof(Owner));
            Console.WriteLine("Activator Create: {0}", measured.MeasureIterationsMs(iterations));

            var lambdaFactory = CreateFactoryLambda(typeof (Owner));
            lambdaFactory();
            measured = () => lambdaFactory();
            Console.WriteLine("Lambda Create: {0}", measured.MeasureIterationsMs(iterations));
        }

        private static MethodInfo mi = typeof(ReflectionHelperTest).GetMethod("CreateObject", BindingFlags.Static | BindingFlags.Public);

        public static Func<object> CreateFactory(Type type)
        {
            return (Func<object>)Delegate.CreateDelegate(typeof(Func<object>),
                                                          mi.MakeGenericMethod(new[] { typeof(Owner) }));
        }

        public static Func<object> CreateFactoryLambda(Type type)
        {
            Expression<Func<object>> lambda =
                System.Linq.Expressions.Expression.Lambda<Func<object>>(
                    System.Linq.Expressions.Expression.New(type.GetConstructor(Type.EmptyTypes)));
            return lambda.Compile();
        }


        public static object CreateObject<T>() where T : new()
        {
            return new T();
        }


        /// <summary>
        /// This test shows access
        /// </summary>
        [Test, Explicit]
        public void PerformanceSpringExpressionTest()
        {
            var obj = new Owner() { OwnerProperty = new Owner() { PublicProperty = 100 } };
            var springExpr = Expression.Parse("OwnerProperty.PublicProperty");
            var reflExpr = new ReflectedExpression(typeof(Owner), "OwnerProperty.PublicProperty");

            springExpr.GetValue(obj);
            reflExpr.Evaluate(obj);

            const int iterations = 1000000;
            Console.WriteLine(string.Format("Iterations : {0}", iterations));

            object val;

            Action measured = () => val = springExpr.GetValue(obj);
            var time = measured.MeasureIterationsMs(iterations);
            Console.WriteLine("Spring call: {0}", time);

            measured = () => reflExpr.Evaluate(obj);
            time = measured.MeasureIterationsMs(iterations);
            Console.WriteLine("Dynamic call: {0}", time);

            measured = () => val = obj.OwnerProperty.PublicProperty;
            time = measured.MeasureIterationsMs(iterations);
            Console.WriteLine("Direct call: {0}", time);
        }

        [Test]
        public void PublicGetNoSet()
        {
            ReflectedField.GenericSetter setter = ReflectedField.CreateSetDelegate<Owner>(t => t.PublicGetNoSet);
            ReflectedField.GenericGetter getter = ReflectedField.CreateGetDelegate<Owner>(t => t.PublicGetNoSet);
            Assert.IsNull(setter);
            Assert.IsNotNull(getter);
        }

        [Test]
        public void ReflectedTypeEnumeratorTest()
        {
            var reflectedType = new ReflectedType(typeof (Owner));
            string[] reflected = reflectedType.Properties.Select(s => s.Name).ToArray();
            string[] testReflected =
                typeof (Owner).GetProperties(ReflectedType.InstancePropertyBindingFlags).Select(p => p.Name).ToArray();

            int result1 = reflected.Except(testReflected).Count();
            int result2 = testReflected.Except(reflected).Count();

            Assert.AreEqual(0, result1);
            Assert.AreEqual(0, result2);

            foreach (ReflectedField field in reflectedType.Properties)
                Assert.AreEqual(field, reflectedType.GetProperty(field.Name));
        }

        [Test]
        public void ReflectedTypeHasPropertyTest()
        {
            var reflectedType = new ReflectedType(typeof (Owner));
            Assert.IsTrue(reflectedType.HasProperty("PublicProperty"));
            Assert.IsFalse(reflectedType.HasProperty("NonExistantProperty"));
        }

        [Test]
        public void ReflectedFieldsCountTest()
        {
            var mockAllocation = new MockAllocationSubscription();
            var fieldsViaHelperCount = ReflectionHelper.GetType(mockAllocation.GetType()).Fields.Count();
            var fieldsViaReflectionCount = mockAllocation.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Count();

            Assert.AreEqual(fieldsViaHelperCount, fieldsViaReflectionCount);

        }

        [Test]
        public void CloneTest()
        {
            var mockAllocation = new MockAllocationSubscription(100);
            object clonedObject = Activator.CreateInstance(mockAllocation.GetType());
            foreach (var reflectedField in ReflectionHelper.GetType(mockAllocation.GetType()).Fields)
            {

                var sourceValue = reflectedField.Getter(mockAllocation);
                reflectedField.Setter(clonedObject, sourceValue);
            }
            Assert.AreEqual(((MockAllocationSubscription)clonedObject).AllocationID, mockAllocation.AllocationID);

        }

        [Test]
        public void PublicFieldTest()
        {
            var obj = new Owner{PublicField = 100};
            var obj2 = new Owner();
            var field = ReflectionHelper.GetType(obj.GetType()).GetField("PublicField");
            Assert.AreEqual(field.Getter(obj),100);
            field.Setter(obj2, 666);
            Assert.AreEqual(obj2.PublicField, 666);

        }

        [Test]
        public void ProtectedFieldTest()
        {
            var obj = new Owner {ProtectedFieldValue = 100};
            var obj2 = new Owner();
            var field = ReflectionHelper.GetType(obj.GetType()).GetField("ProtectedField");
            Assert.AreEqual(field.Getter(obj), 100);
            field.Setter(obj2, 666);
            Assert.AreEqual(obj2.ProtectedFieldValue, 666);

        }

        [Test]
        public void PrivateFieldTest()
        {
            var obj = new Owner { PrivateFieldValue = 100 };
            var obj2 = new Owner();
            var field = ReflectionHelper.GetType(obj.GetType()).GetField("_privateField");
            Assert.AreEqual(field.Getter(obj), 100);
            field.Setter(obj2, 666);
            Assert.AreEqual(obj2.PrivateFieldValue, 666);

        }

        [Test]
        public void PrivateReadonlyFieldTest()
        {
            var obj = new Owner(100);
            var field = ReflectionHelper.GetType(obj.GetType()).GetField("_privateReadonlyField");
            Assert.AreEqual(field.Getter(obj), 100);
            Assert.IsNull(field.Setter);
        }

        [Test]
        public void TestERepositoryReportsForRootReports()
        {
            //when
            var reports = ReportsHelper.ERepositoryReports.OrderBy(r => r.ReportId).Where(r => r.ParentReportId == null).ToList();

            //then
            Assert.That(reports.Count, Is.EqualTo(3));

            Assert.That(reports[0].ReportId, Is.EqualTo(GsmReportId.ClientSpecificSecurityReport));
            Assert.That(reports[0].ReportName, Is.EqualTo(ReportsHelper.CLIENT_SPECIFIC_SECURITY_REPORT));

            Assert.That(reports[1].ReportId, Is.EqualTo(GsmReportId.PriceEntryDetailsReport));
            Assert.That(reports[1].ReportName, Is.EqualTo(ReportsHelper.PRICE_ENTRY_DETAILS__REPORT));

            Assert.That(reports[2].ReportId, Is.EqualTo(GsmReportId.ReconciliationReport));
            Assert.That(reports[2].ReportName, Is.EqualTo(ReportsHelper.RECONCILIATION_REPORT));
        }

        [Test]
        public void TestERepositoryReportsForChildReportsForClientsSupportedByGsm()
        {
            //when
            var reports = ReportsHelper.ERepositoryReports.FindAll(r => r.ParentReportId == GsmReportId.ClientSpecificSecurityReport);

            //then
            Assert.That(reports, Is.Empty);
        }

        [Test]
        public void TestERepositoryReportsForChildReportsForPriceEntryDetailsReport()
        {
            //when
            var reports = ReportsHelper.ERepositoryReports.FindAll(r => r.ParentReportId == GsmReportId.PriceEntryDetailsReport);

            //then
            Assert.That(reports, Is.Empty);
        }

        [Test]
        public void TestERepositoryReportsForChildReportsForReconciliationReports()
        {
            //when
            var reports = ReportsHelper.ERepositoryReports.OrderBy(r => r.ReportId).Where(r => r.ParentReportId == GsmReportId.ReconciliationReport).ToList();

            //then
            Assert.That(reports.Count, Is.EqualTo(3));

            Assert.That(reports[0].ReportId, Is.EqualTo(GsmReportId.EstimateReconciliationReport));
            Assert.That(reports[0].ReportName, Is.EqualTo(ReportsHelper.ESTIMATE_RECONCILIATION_REPORT));

            Assert.That(reports[1].ReportId, Is.EqualTo(GsmReportId.FinalReconciliationReport));
            Assert.That(reports[1].ReportName, Is.EqualTo(ReportsHelper.FINAL_RECONCILIATION_REPORT));

            Assert.That(reports[2].ReportId, Is.EqualTo(GsmReportId.OutstandingFinalsAndEstimatesReport));
            Assert.That(reports[2].ReportName, Is.EqualTo(ReportsHelper.OUTSTANDING_FINALS_AND_ESTIMATES_REPORT));
        }
    }
}