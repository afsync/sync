﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Common.Logging;
using IFS.BusinessLayer.AutoFac;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Utilities;
using SpSecurityPricing = IFS.BusinessLayer.SecurityPricing.SecurityPricing;

namespace IFS.BusinessLayer.GSM.CentralPricing
{
    public interface ISecurityPricingStore
    {
        int Count { get; }
        ISecurityPriceIndexByDateCollection SecurityPriceIndexByDateCollection { get; }
        ISecurityPriceIndexByStatusCollection SecurityPriceIndexByStatus { get; }
        ISecurityPriceIndexByFundIdsCollection SecurityPriceIndexByFundIdsCollection { get; }
        List<int> Get50Ids();
        void SelectAll();
        bool Remove(int key);
        SpSecurityPricing GetById(int key);
        bool ProcessNotification(int key);
        void BulkProcessNotification(List<int> keys);
        void Update(SpSecurityPricing updatedSp);
        void BulkUpdate(List<int> securityPricingIds);
        void RemoveAll();
    }

    public class SecurityPricingStore : ISecurityPricingStore
    {
//      ReSharper disable InconsistentNaming
        public const string CACHE_KEY = "CACHE_SECURITY_PRICING";
        public const string BULK_CACHE_KEY = "CACHE_SECURITY_PRICING_BULK";
//      ReSharper restore InconsistentNaming

        private static readonly ILog _log = LogManager.GetLogger(typeof(SecurityPricingStore));
        private readonly ISecurityPricingRepository _securityPricingRepository;
        private readonly ICacheUpdateNotifier _cacheUpdateNotifier;
        private ConcurrentDictionary<int, SpSecurityPricing> _securityPricings;
        private ISecurityPriceIndexByDateCollection _securityPriceIndexByDateCollection;
        private ISecurityPriceIndexByStatusCollection _securityPriceIndexByStatusCollection;
        private ISecurityPriceIndexByFundIdsCollection _securityPriceIndexByFundIdsCollection;

        public int Count { get { return _securityPricings.Count; } }
        public List<int> Get50Ids()
        {
            return _securityPricings.Keys.Take(50).ToList();
        }

        public ISecurityPriceIndexByDateCollection SecurityPriceIndexByDateCollection
        { get { return _securityPriceIndexByDateCollection; } }

        public virtual ISecurityPriceIndexByStatusCollection SecurityPriceIndexByStatus
        { get { return _securityPriceIndexByStatusCollection; } }

        public virtual ISecurityPriceIndexByFundIdsCollection SecurityPriceIndexByFundIdsCollection
        { get { return _securityPriceIndexByFundIdsCollection; } }

        public SecurityPricingStore(ISecurityPricingRepository iSecurityPricingRepository, ICacheUpdateNotifier iNotificationProcessor)
        {
            _securityPricingRepository = iSecurityPricingRepository;
            _cacheUpdateNotifier = iNotificationProcessor;
            _securityPricings = new ConcurrentDictionary<int, SpSecurityPricing>();
            _securityPriceIndexByDateCollection = new SecurityPriceIndexByDateCollection();
            _securityPriceIndexByStatusCollection = new SecurityPriceIndexByStatusCollection();
            _securityPriceIndexByFundIdsCollection = new SecurityPriceIndexByFundIdsCollection();
        }

        public void SelectAll()
        {
            _log.Info("Loading All Security Prices - Start");
            var securityPricings = _securityPricingRepository.SelectAllPricings();
            _securityPricings = ToIndex(securityPricings);
            var pricesByDate = securityPricings.GroupBy(sp => sp.EffectiveDate).ToDictionary(g => g.Key, ToIndex);
            _securityPriceIndexByDateCollection = new SecurityPriceIndexByDateCollection(pricesByDate);
            _securityPriceIndexByStatusCollection = new SecurityPriceIndexByStatusCollection(ToIndex(securityPricings),
                ToIndex(securityPricings.Where(sp => sp.IsApproved)), 
                ToIndex(securityPricings.Where(sp => sp.IsPendingApproval)), 
                ToIndex(securityPricings.Where(sp => sp.IsRejectedWithAttachements)));

            var pricesByFundIds = securityPricings.GroupBy(sp => sp.FundId).ToDictionary(g => g.Key, ToIndex);
            _securityPriceIndexByFundIdsCollection = new SecurityPriceIndexByFundIdsCollection(pricesByFundIds);
            _log.Info("Loading All Security Prices - End");
        }

        private static ConcurrentDictionary<int, SpSecurityPricing> ToIndex(IEnumerable<SpSecurityPricing> securityPricings)
        {
            return new ConcurrentDictionary<int, SpSecurityPricing>(securityPricings.ToDictionary(sp => sp.Id));
        }

        public bool Remove(int key)
        {
            _log.Info("Removing SecurityPricing with Id: " + key);
            var tryRemove = RemoveSecurityPricing(key);
            if (tryRemove)
                _cacheUpdateNotifier.SendNotification(CACHE_KEY, key);
            return tryRemove;
        }

        public virtual SpSecurityPricing GetById(int key)
        {
            SpSecurityPricing securityPricing;
            if (!_securityPricings.TryGetValue(key, out securityPricing))
            {
                _log.Info("Fetching SecurityPricing with Id: " + key);
                securityPricing = _securityPricingRepository.GetPricingById(key);
                AddToIndexes(securityPricing);
            }
            return securityPricing;
        }

        public bool ProcessNotification(int key)
        {
            _log.Info("Processing Notification for Id: " + key);
            var removeSecurityPricing = RemoveSecurityPricing(key);
            GetById(key);
            return removeSecurityPricing;
        }

        public void BulkProcessNotification(List<int> keys)
        {
            if (keys.Count > 0)
            {
                keys.ForEach(key => RemoveSecurityPricing(key));
                _securityPricingRepository.GetPricingByIds(keys).ForEach(AddToIndexes);
            }
        }

        public void Update(SpSecurityPricing updatedSp)
        {
            _log.Info("Updating SecurityPricing with Id: " + updatedSp.Id);
            RemoveAndSendNotificationIfNew(updatedSp.Id);
            AddToIndexes(_securityPricingRepository.GetPricingById(updatedSp.Id));
        }

        public virtual void BulkUpdate(List<int> securityPricingIds)
        {
            securityPricingIds.ForEach(id => RemoveSecurityPricing(id));
            _securityPricingRepository.GetPricingByIds(securityPricingIds).ForEach(AddToIndexes);
            _cacheUpdateNotifier.SendNotification(BULK_CACHE_KEY, metadataKeyCollection: securityPricingIds);
        }

        public void RemoveAll()
        {
            _log.Info("Remove All SecurityPricings");
            _securityPricings = new ConcurrentDictionary<int, SpSecurityPricing>();
            _securityPriceIndexByDateCollection = new SecurityPriceIndexByDateCollection();
            _securityPriceIndexByStatusCollection = new SecurityPriceIndexByStatusCollection();
            _securityPriceIndexByFundIdsCollection = new SecurityPriceIndexByFundIdsCollection(); 
        }

        private bool RemoveSecurityPricing(int key)
        {
            SpSecurityPricing removedSp;
            var isRemoved = _securityPricings.TryRemove(key, out removedSp);
            if (isRemoved)
            {
                _securityPriceIndexByDateCollection.Remove(removedSp.EffectiveDate, removedSp);
                _securityPriceIndexByStatusCollection.Remove(removedSp);
                _securityPriceIndexByFundIdsCollection.Remove(removedSp);
            }
            return isRemoved;
        }
       
        private void AddToIndexes(SpSecurityPricing sp)
        {
            if (sp != null)
            {
                _securityPricings.TryAdd(sp.Id, sp);
                _securityPriceIndexByDateCollection.Add(sp.EffectiveDate, sp);
                _securityPriceIndexByStatusCollection.Add(sp);
                _securityPriceIndexByFundIdsCollection.Add(sp);
            }
        }

        private void RemoveAndSendNotificationIfNew(int id)
        {
            if (!Remove(id))
                _cacheUpdateNotifier.SendNotification(CACHE_KEY, id);
        }

        public static SecurityPricingStore GetInstance()
        {
            return (SecurityPricingStore)SpringUtil.GetObject("SecurityPricingStore");
            //return AutoFacContainer.Resolve<SecurityPricingStore>();
        }
    }
}
