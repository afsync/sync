﻿using System;
using System.Collections.Generic;
using IFS.Interfaces.Rounding;

namespace IFS.Interfaces.CloudContracts.DataContracts.Returns
{
    [Serializable]
    public class ReturnsPageData
    {
        public List<ReturnsGridEstimateRow> GridRows { get; set; }
        public bool IsDeletedAllowedForReturns { get; set; }
        public InvestmentView Investment { get; set; }
        public DateTime SeriesLastModifiedDate { get; set; }
        public int SeriesOrganizationId { get; set; }
        public bool IsEditable { get; set; }
        public bool HasFutureAllocations { get; set; }
        public bool CurrentLockdownIsSoftLockdown { get; set; }
        public UnderlyingFundView FundView { get; set; }
        public CNav FundLastCPrice { get; set; }
        public bool HasAttachements { get; set; }
        public CAmount MarketValueEntered { get; set; }
        public bool HasUserAccess { get; set; }
        public bool HasPriceFromCpAccess { get; set; }
        public bool IsDeleteAllowed { get; set; }
    }
}
