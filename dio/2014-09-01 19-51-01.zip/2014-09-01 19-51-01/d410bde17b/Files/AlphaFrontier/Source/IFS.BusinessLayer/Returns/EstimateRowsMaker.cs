﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.GSM.CentralPricing;
using IFS.BusinessLayer.Price;
using IFS.BusinessLayer.Price.Snapshot;
using IFS.BusinessLayer.Repository;
using IFS.BusinessLayer.Trade;
using IFS.Interfaces.CloudContracts.DataContracts.Returns;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.Returns
{
    public class EstimateRowsMaker: ReturnsOperationBase
    {
        private List<int> SelectedPortfolioIds { get; set; }
        private List<EstimateAttachment> _allEstimateAttachments;

        public List<EstimateAttachment> GetAllEstimateAttachments()
        {
            return _allEstimateAttachments ?? (_allEstimateAttachments = DataPoint == null
                ? new List<EstimateAttachment>() : new EstimateAttachmentBLRepository().GetByEstimateIdList(DataPoint.Estimates.Select(e => e.Id).ToList()));
        }

        private PortfolioLockdown _currentLockdown;
        private PortfolioLockdown CurrentLockdown
        {
            get
            {
                return _currentLockdown ?? (_currentLockdown = _portfolio.LockdownAsOfDate(_returnDate));
            }
        }

        public EstimateRowsMaker(Portfolio portfolio, UnderlyingFund fund, DateTime returnDate, ReturnsPageMode mode, List<PortfolioLockdown> fundLockdowns,
            List<EstimateAttachment> allEstimateAttachments, List<int> selectedPortfolioIds = null)
            : base(portfolio, fund, returnDate, mode)
        {
            SelectedPortfolioIds = selectedPortfolioIds;
            _allEstimateAttachments = allEstimateAttachments;
            _fundLockdowns = fundLockdowns;
        }

        public ReturnsPageData GetReturnsData()
        {
            var mvEntered = InitializeDataForPortfolioAndReturnMarketValueEntered(_returnDate, _fund);
            var investment = Investment;
            return new ReturnsPageData
            {
                GridRows = GetRows(),
                IsDeletedAllowedForReturns = IsDeletedAllowedForReturns(),
                SeriesLastModifiedDate = FundSeries.SeriesModifiedDate,
                SeriesOrganizationId = FundSeries.SeriesOrganizationId,
                IsEditable = IsEditable(),
                Investment = investment != null ? investment.GetView(_returnDate) : null,
                HasFutureAllocations = HasFutureAllocations(),
                CurrentLockdownIsSoftLockdown = CurrentLockdown != null && CurrentLockdown.IsSoftLockdown,
                FundView = _fund.GetView(),
                FundLastCPrice = (_fund is InvestableFund) ? _fund.LastCPrice(_returnDate) : null,
                HasAttachements = HasAttachements(),
                HasUserAccess = true,
                HasPriceFromCpAccess = HasPriceFromCpUserAccess(),
                MarketValueEntered = mvEntered
            };
        }

        public ReturnsPageData GetLockdownsData()
        {
            var returnsData = GetReturnsData();
            returnsData.IsDeleteAllowed = DatapointContainNoEstimates();
            return returnsData;
        }

        private bool DatapointContainNoEstimates()
        {
            return DataPoint == null || DataPoint.ContainsNoEstimates();
        }

        private bool HasAttachements()
        {
            var attachManager = new EstimateAttachmentManager(0, _returnDate, null, null, _fund.FundID, null, null);
            return !(_fund is Portfolio) && _mode == ReturnsPageMode.Returns ? attachManager.HasAttachments(SelectedPortfolioIds) : 
                attachManager.HasAttachmentsForPortfolio(_portfolio.Id,GetAllEstimateAttachments());
        }

        private bool HasFutureAllocations()
        {
            var endDate = GetLockdownDate();
            return _fund.InvestmentsAcrossPortfolios().Any(i => i.Allocations.Any(a => IsFutureAllocation(a, endDate)));
        }

        private DateTime GetLockdownDate()
        {
            return CurrentLockdown != null ? CurrentLockdown.LockdownDataEndDate : _returnDate;
        }

        private bool IsFutureAllocation(Allocation a, DateTime endDate)
        {
            return a.ExecutionDate.Date > endDate || (a.ExecutionDate.Date == endDate && !(a is AllocationCashDistribution));
        }

        internal bool IsEditable()
        {
            var df = DataPoint as DataFund;
            return df == null || Double.IsNaN(df.DataDividendsBase);
        }

        public List<ReturnsGridEstimateRow> GetRows()
        {
            return (!(_fund is BaseFund) && null != DataPoint)
                ? BuildRows(DataPoint.Estimates, GetSnapshotEstimate())
                : new List<ReturnsGridEstimateRow>();
        }

        internal bool IsDeletedAllowedForReturns()
        {
            return _mode == ReturnsPageMode.Returns && !_portfolio.HasSoftLockedAllocations(Investment, CurrentLockdown);
        }

        internal SnapshotEstimate GetSnapshotEstimate()
        {
            return CurrentLockdown != null ? CurrentLockdown.GetSnapshotEstimateByFundId(_fund.FundID) : null;
        }

        internal bool LockdownSharesIsNotNanNotZero(SnapshotEstimate snapshotEstimate)
        {
            var lockdownShares = snapshotEstimate != null ? snapshotEstimate.EstimateLockdownQuantity : CQuantity.NaN;
            return !RoundingBase.IsNaN(lockdownShares) && lockdownShares != CQuantity.Zero();
        }

        internal bool LiveSharesIsNotNanNotZero()
        {
            var availableShares = Investment != null ? Investment.AllocationQuantity(_returnDate) : CQuantity.NaN;
            return !RoundingBase.IsNaN(availableShares) && availableShares != CQuantity.Zero();
        }

        internal List<ReturnsGridEstimateRow> BuildRows(IEnumerable<Estimate> dataEstimates, SnapshotEstimate snapshotEstimate)
        {
            var isSharesNotNanNotZero = LiveSharesIsNotNanNotZero() && LockdownSharesIsNotNanNotZero(snapshotEstimate);
            var estimateRows = new List<ReturnsGridEstimateRow>();
            foreach (var estimate in dataEstimates)
            {
                if (!double.IsNaN(estimate.EstimateReturn) || (DataPoint is DataPortfolio))
                {
                    if (snapshotEstimate != null && estimate.EstimateId == snapshotEstimate.EstimateId && (_mode == ReturnsPageMode.PriceLockDown || isSharesNotNanNotZero))
                        estimateRows.Add(GetSnapshotEstimateRow(snapshotEstimate));

                    estimateRows.Add(GetEstimateRow(estimate));
                }
            }
            return estimateRows;
        }

        internal ReturnsGridEstimateRow GetEstimateRow(Estimate estimate)
        {
            var estimateRow = PopulateEstimateRow(estimate);
            estimateRow.EstimateType = GetEstimateType(estimate);
            return estimateRow;
        }

        internal string GetEstimateType(Estimate estimate)
        {
            return estimate.EstimateIsFinal ? "Final" : "Estimate " + DataPoint.GetEstimateIndex(estimate);
        }

        internal ReturnsGridEstimateRow GetSnapshotEstimateRow(Estimate estimate)
        {
            var estimateRow = PopulateEstimateRow(estimate);
            estimateRow.EstimateType = GetSnapshotEstimateType(estimate);
            estimateRow.IsSnapshot = true;
            estimateRow.LockdownShares = estimate.EstimateLockdownQuantity != null ? estimate.EstimateLockdownQuantity.Value : double.NaN;
            return estimateRow;
        }

        internal string GetSnapshotEstimateType(Estimate estimate)
        {
            return estimate.EstimateIsFinal ? "Final (Locked)" : "Estimate (" + (CurrentLockdown.IsSoftLockdown ? "Soft " : "") + "Locked)";
        }

        internal ReturnsGridEstimateRow PopulateEstimateRow(Estimate estimate)
        {
            return new ReturnsGridEstimateRow
            {
                EstimateId = estimate.EstimateId,
                EstimateType = estimate.EstimateIsFinal ? "Final" : "Estimate",
                DateReceived = estimate.EstimateDate,
                EstimateNav = estimate.EstimateCNav.Value,
                EstimateReturn = estimate.EstimateReturn,
                EstimateAsReturn = estimate.EstimateAsReturn,
                EnteredBy = User.GetUserFullName(estimate.EstimateUserId),
                PriceSource = estimate.PriceSource,
                EstimateIsFlatStale = estimate.EstimateIsFlatStale,
                TimeStamp = estimate.EstimateTimeStamp,
                EstimateIsFinal = estimate.EstimateIsFinal,
                LastUpdateTimeStamp = estimate.EstimateLastUpdateTimeStamp,
                LockdownAsOfDate = GetLockdownAsOfDate(),
                LocalMarketValue = estimate.EstimatePortfolioMV.Value,
                UnadjustedReturn = estimate.UnadjustedReturn,
                ApplyManagementFee = estimate.ApplyManagementFee,
                IsGross = estimate.IsGross,
                SecurityPricingId = estimate.SecurityPricingId.HasValue ? estimate.SecurityPricingId.Value.ToString() : string.Empty,
                EditedFromCp = estimate.EditedFromCP.HasValue ? estimate.EditedFromCP.Value.ToString().ToLower() : "false",
                PublishedBy = GetEnteredByForLastPublishedAttachment(estimate),
                HasAttachements = HasAttachements(estimate.EstimateId),
                UpdateCount = GetUpdateCount(estimate.EstimateId, estimate.SecurityPricingId)
            };
        }

        private DateTime GetLockdownAsOfDate()
        {
            return FundLockdowns.Any(l => l.LockdownAsOfDate == _returnDate && l.IsLocked) ? _returnDate : DateTime.MinValue;
        }

        internal bool HasPriceFromCpUserAccess()
        {
            var supportGsm = Organization.Loader.GetById(CSession.OrganizationID).SupportGsm;
            return supportGsm && Component.HasFullAccess(Component.PRICE_UPDATES_CLIENT_SIDE, CSession.User);
        }

        internal static CAmount InitializeDataForPortfolioAndReturnMarketValueEntered(DateTime returnDate, UnderlyingFund fund)
        {
            var portfolio = fund as Portfolio;
            return portfolio != null ? portfolio.MarketValueEntered(returnDate) : null;
        }

        private string GetEnteredByForLastPublishedAttachment(Estimate estimate)
        {
            var lastPublishedAttachment = GetLastPublishedAttachment(estimate.EstimateId,_portfolio.PortfolioID);
            return lastPublishedAttachment == null ? string.Empty : lastPublishedAttachment.PublishedBy;
        }
        private EstimateAttachment GetLastPublishedAttachment(int estimateId, int portfolioId)
        {
            var attachments = GetAllEstimateAttachments().Where(e =>
                        e.EstimateId == estimateId &&
                        (e.PortfolioId == null || e.PortfolioId <= 0 || e.PortfolioId == portfolioId) &&
                        e.IsPublishable()).ToList();
            if (attachments.Count == 0)
                return null;
            var publishedAttachments = attachments.Where(estAtt => estAtt.IsPublished()).OrderBy(estAtt => estAtt.PublishedDate).ToList();
            return attachments.Count == publishedAttachments.Count ? publishedAttachments.Last() : null;
        }

        private bool HasAttachements(int estimateId)
        {
            var attachManager = new EstimateAttachmentManager(estimateId, _returnDate, null, null, _fund.FundID, null, null);
            return !(_fund is Portfolio) && _mode == ReturnsPageMode.Returns
                       ? attachManager.HasAttachments(SelectedPortfolioIds, GetAllEstimateAttachments())
                       : attachManager.HasAttachmentsForPortfolio(_portfolio.FundID, GetAllEstimateAttachments());
        }
       
        private int GetUpdateCount(int estimateId, int? securityPricingId)
        {
            var updateManager = new EstimateAttachmentUpdateManager(SecurityPricingStore.GetInstance(),_returnDate, _fund.FundID, null, null);
            return !(_fund is Portfolio) && _mode == ReturnsPageMode.Returns
                ? updateManager.GetUpdates(SelectedPortfolioIds, estimateId, securityPricingId ?? -1).Count
                : updateManager.GetUpdatesByPortfolio(Investment != null ? Investment.PortfolioID : -1, estimateId, securityPricingId ?? -1, GetAllEstimateAttachments()).Count;
        }
    }
}
