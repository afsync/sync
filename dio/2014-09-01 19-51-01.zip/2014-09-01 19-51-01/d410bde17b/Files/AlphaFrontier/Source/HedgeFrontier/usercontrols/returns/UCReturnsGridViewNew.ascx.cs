using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using HedgeFrontier.Common;
using IFS.BusinessLayer;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Returns;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Rounding;
using IFS.UI.IFSControls;
using WebUtilities;
using System.Collections.Generic;
using AntiXssEncoder = Microsoft.Security.Application.Encoder;

public partial class usercontrols_returns_UCReturnsGridViewNew : CBaseUserControl, IReturnsGridViewNew
{
    private const string IMAGE_FOLDER = "~/images/";
    public ReturnsPageMode Mode { get; set; }

    #region Members
    // ReSharper disable InconsistentNaming
    public enum EstimateFilter
    {
        ALL = 0,
        LOCKEDNAV = 1,
        FINAL = 2
    }
    // ReSharper restore InconsistentNaming

    
    private DateTime _returnDate;
    private StringBuilder _error = new StringBuilder();
    private StringBuilder _messages = new StringBuilder();
    private int _fundId = -1;
    //private Data _data;
    private Boolean _dataPointModified;
    //private Series _fundSeries;
    #endregion

    #region Properties
    public List<ReturnsGridEstimateRow> EstimateRows
    {
        get { return (List<ReturnsGridEstimateRow>)ViewState[GetViewStateKey("EstimateRows")]; }
        set
        {
            ViewState[GetViewStateKey("EstimateRows")] = value;
        }

    }

    public DateTime ReturnDate
    {
        get
        {
            if (_returnDate == DateTime.MinValue)
                _returnDate = (DateTime)ViewState[GetViewStateKey("ReturnDate")];
            return _returnDate;
        }
        set
        {
            _returnDate = DateTime.MinValue;
            ViewState[GetViewStateKey("ReturnDate")] = value;
        }
    }
   
    public bool IsReturnsScreen 
    {
        get { return Mode == ReturnsPageMode.Returns; }
    }

    public int FundId
    {
        get
        {
            if (_fundId == -1 && ViewState[GetViewStateKey("FundID")] != null)
                _fundId = (int)ViewState[GetViewStateKey("FundID")];
            if (_fundId == -1 && Request["fundId"] != null)
                _fundId = Convert.ToInt32(Request["fundId"]);
            return _fundId;
        }
        set
        {
            _fundId = -1;
            ViewState[GetViewStateKey("FundID")] = value;
        }
    }

    public UnderlyingFundView FundView
    {
        get
        {
            return (UnderlyingFundView)ViewState[GetViewStateKey("FundView")];
        }
        set { ViewState[GetViewStateKey("FundView")] = value; }
    }
    public CNav FundLastCPrice { get; set; }
   
    public EstimateFilter Filter { get; set; }

    public StringBuilder ErrorMessage
    {
        get { return _error; }
    }

    public StringBuilder Messages
    {
        get { return _messages; }
    }

    public InvestmentView FundInvestmentView { get; set; }

    private List<int> _selectedPortfolioIdList;
    private List<int> SelectedPortfolioIdList
    {
        get
        {
            if (IFSSession.SelectedPortfolioId == null) return null;
            return _selectedPortfolioIdList ?? (_selectedPortfolioIdList = IFSSession.SelectedPortfolioId.ToList());
        }
    }

    private int SelectedPortfolioId
    {
        get { return IFSSession.PortfolioId; }
    }

    public CBulkEditGridView UnderlyingGridView
    {
        get { return estimGV; }
    }

    public string UnderlyingGridViewClientId
    {
        get { return estimGV.ClientID; }
    }

    //private Data LiveDataPoint { get; set; }

    public String IsDirtyJavaScriptFunction { get; set; }

    public String DeleteCheckedJavaScriptFunction { get; set; }

    //TODO: probably should be in ViewState
    public int SeriesOrganizationId { get; set; }
    public bool HasFutureAllocations { get; set; }
    public bool CurrentLockdownIsSoftLockdown { get; set; }
    public bool IsDataPointEditable { get; set; }
    public bool HasAttachements { get; set; }

    public DateTime LastModifiedDate
    {
        get
        {
            var lastModifiedDateTicks = long.MinValue;
            if (ViewState[GetViewStateKey("LastModifiedDateTicks")] != null)
                long.TryParse(ViewState[GetViewStateKey("LastModifiedDateTicks")].ToString(), out lastModifiedDateTicks);
            return lastModifiedDateTicks == long.MinValue ? DateTime.Now : new DateTime(lastModifiedDateTicks);
        }
        set
        {
            ViewState[GetViewStateKey("LastModifiedDateTicks")] = value.Ticks;
        }
    }

    public bool HasFinalRow
    {
        get
        {
            return (from row in estimGV.Rows.Cast<GridViewRow>()
                    let hdnIsFinal = row.Cells[0].FindControl("hdnIsFinal") as HiddenField
                    where hdnIsFinal != null && bool.Parse(hdnIsFinal.Value)
                    select 1).Any();
        }
    }

    public int AttachmentUpdateCount { get; private set; }

    public bool StaleAllowed
    {
        get { return estimGV.Rows.Count == 0 && estimGV.EnableInsert && estimGV.InsertTableRow != null; }
    }

    public bool StaleMode { get; set; }
    
    private bool IsDeletedAllowedForReturns { get; set; }

    #endregion

    #region GridView Events
    protected void estimGV_OnPreRender(object sender, EventArgs e)
    {
        var rowCount = estimGV.Rows.Count;

        if (estimGV.EnableInsert)
        {
            var insertRow = estimGV.InsertTableRow;
            var controls = new ReturnsGridViewControls(insertRow);

            controls.CtrlPriceSource.RemoveListItem(EnumValue.CASH_DISTRIBUTION);
            controls.CtrlPriceSource.RemoveListItem(EnumValue.MANUAL);
            AttachJavascript(controls, insertRow.UniqueID);
            controls.TxtDateReceived.Text = DateTime.Now.ToShortDateString();

            var availableShares = new CQuantity(0);
            if (FundInvestmentView != null)
            {
                availableShares = new CQuantity(FundInvestmentView.Quantity);
                controls.LblAvailableShares.Text = availableShares.Value.ToString(CQuantity.FORMAT_STRING);
            }
            var pnlUploadPricing = controls.UploadDocument;
            if (pnlUploadPricing != null)
            {
                var hasAttachments = HasAttachements;
                pnlUploadPricing.Attributes.Add("pricingId", "0");
                pnlUploadPricing.Attributes.Add("mode", Mode.ToString());
                pnlUploadPricing.Attributes.Add("portfolioIds", Mode == ReturnsPageMode.Returns ? string.Join(",", SelectedPortfolioIdList) : SelectedPortfolioId.ToString());
                pnlUploadPricing.Attributes.Add("securityPricingId", "0");
                pnlUploadPricing.Attributes.Add("organizationId", SeriesOrganizationId.ToString());
                pnlUploadPricing.Attributes.Add("fundId", FundId.ToString());
                pnlUploadPricing.Attributes.Add("effectiveDate", ReturnDate.ToString());
                pnlUploadPricing.Attributes.Add("isFinal", "false");
                pnlUploadPricing.Attributes.Add("isEstimateLocked", "false");
                var btnAttach = new ImageButton { ID = "btnAttach", ImageUrl = ResolveUrl(IMAGE_FOLDER + (hasAttachments ? "Attachement.png" : "NoAttachement.png")) };
                btnAttach.Attributes["onClick"] += "javascript:showUploadPricingDocumentDialog(this);return false;";
                pnlUploadPricing.Controls.Add(btnAttach);
            }

            controls.HdnLastUpdateTimeStamp.Value = DateTime.Now.Ticks.ToString();

            if ((FundView is InvestableFundView) && ((InvestableFundView)FundView).IsTemporary)
                controls.ChkIsFinal.Enabled = false;

            PopulateStaledRow(controls, availableShares);
        }

        if (FundView is PortfolioView)
        {
            estimGV.Columns[0].Visible = false; //EstimateType
            estimGV.Columns[1].Visible = false; //NAV           
            estimGV.Columns[4].Visible = false;  //Hide Available Shares
        }
        else
        {
            // Hide MV and Available shares if not invested into selevcted portfolio
            estimGV.Columns[3].Visible = FundInvestmentView != null; // Local MV
            estimGV.Columns[4].Visible = FundInvestmentView != null; // Available Shares      
        }

        if (rowCount > 0)
        {
            var chkDeleteEstimate = (CheckBox)estimGV.Rows[rowCount - 1].Cells[7].FindControl("chkDeleteThisEstimate");
            chkDeleteEstimate.Visible = true;
           
            //checking for future allocations
            if (chkDeleteEstimate.Enabled && HasFutureAllocations)
            {
                chkDeleteEstimate.Enabled = false;
                chkDeleteEstimate.ToolTip = @"You cannot delete this price as the fund has future allocations.";
            }

            //attaching JavaScript if the checkbox is enabled
            if (chkDeleteEstimate.Enabled)
                chkDeleteEstimate.Attributes["onClick"] += "ChkMarkParentCheckBox('" + AntiXssEncoder.HtmlEncode(chkDeleteEstimate.ClientID) + "','" + (rowCount - 1) + "','" +
                    AntiXssEncoder.HtmlEncode(FundView.FullName).Replace("'", "\\\'") + "');" + AntiXssEncoder.HtmlEncode(DeleteCheckedJavaScriptFunction);
        }

        //For Portfolio returns page, hide the "InsertRow" , if an entry is already created
        if ((FundView is PortfolioView) && (rowCount == 1))
            estimGV.InsertTableRow.Visible = false;
    }

    protected void estimGV_OnRowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        var key = estimGV.DataKeys[e.RowIndex];
        if (key != null)
        {
            int estimateID;
            int.TryParse(key.Value.ToString(), out estimateID);

            var controls = new ReturnsGridViewControls(estimGV.Rows[e.RowIndex]);

            var row = EstimateRows.FirstOrDefault(r => r.EstimateId == estimateID);
            PopulateDataObjects(row, controls, true);
            row.IsDirty = true;
            _dataPointModified = true;
        }
    }

    protected void estimGV_OnRowInserting(object sender, GridViewInsertEventArgs e)
    {
        if (_dataPointModified)
            return;

        var controls = new ReturnsGridViewControls(estimGV.InsertTableRow);
        var newEstimateRow = new ReturnsGridEstimateRow { EstimateId = -1, EstimateIsFinal = controls.ChkIsFinal.Checked, IsDirty = true};
        EstimateRows.Add(newEstimateRow);
        PopulateDataObjects(newEstimateRow, controls, false);
        _dataPointModified = true;
    }

    private void SetColumnsVisiblity()
    {
        const int publishedByColumnIndex = 13;
        estimGV.Columns[publishedByColumnIndex].Visible = Component.IsAccessible(Component.PUBLISH_ATTACHMENTS, CSession.User)
            && (Mode != ReturnsPageMode.Returns || SelectedPortfolioIdList.Count == 1);//only if only one portfolio is selected in case of Return page
    }

    protected void estimGV_OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            SetColumnsVisiblity();
        }
        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            bool asReturn;
            DateTime dateReceived, asOfDate;
            var estimateCNav = CNav.NaN;
            var availableShares = CQuantity.NaN;

            bool isSnapshot;
            CPercent estimateReturn;
            CQuantity lockdownShares;
            int securityPricingId;

            var hdnEstimateReturn = (HiddenField)e.Row.FindControl("hdnEstimateReturn");
            var hdnLocalMV = (HiddenField)e.Row.FindControl("hdnLocalMV");
            var hdnEstimateNav = (HiddenField)e.Row.FindControl("hdnEstimateNav");

            var controls = new ReturnsGridViewControls(e.Row);

            bool.TryParse(DataBinder.Eval(e.Row.DataItem, "EstimateAsReturn").ToString(), out asReturn);
            DateTime.TryParse(DataBinder.Eval(e.Row.DataItem, "DateReceived").ToString(), out dateReceived);
            DateTime.TryParse(DataBinder.Eval(e.Row.DataItem, "LockdownAsOfDate").ToString(), out asOfDate);
            CPercent.TryParse(DataBinder.Eval(e.Row.DataItem, "EstimateReturn").ToString(), false, out estimateReturn);
            Boolean.TryParse(DataBinder.Eval(e.Row.DataItem, "IsSnapshot").ToString(), out isSnapshot);
            CQuantity.TryParse(DataBinder.Eval(e.Row.DataItem, "LockdownShares").ToString(), out lockdownShares);
            int.TryParse(DataBinder.Eval(e.Row.DataItem, "securityPricingId").ToString(), out securityPricingId);
            var isNotLocked = dateReceived > asOfDate || IsDeletedAllowedForReturns;

            var estimatePriceSource = EnumValue.Loader.GetById((int)DataBinder.Eval(e.Row.DataItem, "PriceSource"));

            var isFinal = (CheckBox)e.Row.FindControl("chkIsFinal");
            if (isFinal != null)
            {
                e.Row.Cells[0].Controls.Remove(isFinal);
                var lblEstimateType = new Label { Text = DataBinder.Eval(e.Row.DataItem, "EstimateType").ToString() };
                e.Row.Cells[0].Controls.Add(lblEstimateType);
            }

            var isPriceSourceCashDistribution = estimatePriceSource != null &&
                                                 estimatePriceSource.EnumValueName == EnumValue.CASH_DISTRIBUTION;

            if (controls.TxtNav != null)
            {
                CNav.TryParse(DataBinder.Eval(e.Row.DataItem, "EstimateNav").ToString(), out estimateCNav);
                controls.TxtNav.Text = estimateCNav == RoundingBase.FAKE_ZERO ? "0" : estimateCNav.ToString();
                controls.TxtNav.Bold = !asReturn;
                controls.TxtNav.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
                hdnEstimateNav.Value = estimateCNav.ToString("#,##0.00000000;(#,##0.00000000)");
            }

            AttachJavascript(e.Row.UniqueID, controls);

            if (controls.TxtReturn != null)
            {
                controls.TxtReturn.Text = RoundingBase.IsNaN(estimateReturn) ? "" : estimateReturn.PercentValue.ToString();

                controls.TxtReturn.Bold = asReturn;
                controls.TxtReturn.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
                hdnEstimateReturn.Value = controls.TxtReturn.Text + "%";
            }

            if (controls.HdnAsReturn != null)
                controls.HdnAsReturn.Value = asReturn.ToString();

            if (FundInvestmentView != null)
            {
                availableShares = (isSnapshot) ? lockdownShares : FundInvestmentView.AllocationQuantity;
            }
            if (!RoundingBase.IsNaN(availableShares))
                controls.LblAvailableShares.Text = availableShares.Value.ToString(CQuantity.FORMAT_STRING);

            if (controls.TxtLocalMV != null)
            {
                CAmount mv;
                if (FundInvestmentView != null)
                {
                    mv = availableShares * estimateCNav;
                }
                else if (FundView is PortfolioView)
                {
                    double marketValue;
                    double.TryParse(DataBinder.Eval(e.Row.DataItem, "LocalMarketValue").ToString(), out marketValue);
                    mv = double.IsNaN(marketValue) ? CAmount.NaN : new CAmount(marketValue);
                }
                else
                {
                    mv = CAmount.NaN;
                }
                controls.TxtLocalMV.Text = RoundingBase.IsNaN(mv) ? "" : mv.ToString();
                controls.TxtLocalMV.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
                hdnLocalMV.Value = !string.IsNullOrEmpty(controls.TxtLocalMV.Text)
                    ? new CAmount(double.Parse(controls.TxtLocalMV.Text)).ToString(CAmount.FORMAT_STRING)
                    : string.Empty;
            }

            AttachJavascript(controls, e.Row.UniqueID);

            if (controls.TxtDateReceived != null)
            {
                DateTime.TryParse(DataBinder.Eval(e.Row.DataItem, "DateReceived").ToString(), out dateReceived);
                controls.TxtDateReceived.Text = dateReceived.ToShortDateString();
                controls.TxtDateReceived.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
            }

            if (controls.CtrlPriceSource != null)
            {
                controls.CtrlPriceSource.ValueInt = (int)DataBinder.Eval(e.Row.DataItem, "PriceSource");
                controls.CtrlPriceSource.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
                if (controls.CtrlPriceSource.Enabled)
                {
                    if (!isPriceSourceCashDistribution)
                        controls.CtrlPriceSource.RemoveListItem(EnumValue.CASH_DISTRIBUTION);
                    if (estimatePriceSource== null || estimatePriceSource.EnumValueName != EnumValue.MANUAL)
                        controls.CtrlPriceSource.RemoveListItem(EnumValue.MANUAL);
                }
            }

            if (controls.DdlIsFlatStale != null)
            {
                CDropDown.SetText(controls.DdlIsFlatStale, ((bool)DataBinder.Eval(e.Row.DataItem, "EstimateIsFlatStale")) ? "Yes" : "No");
                controls.DdlIsFlatStale.Enabled = !isSnapshot && !isPriceSourceCashDistribution;
            }

            if (controls.HdnLastUpdateTimeStamp != null)
            {
                DateTime lastUpdate;
                DateTime.TryParse(DataBinder.Eval(e.Row.DataItem, "LastUpdateTimeStamp").ToString(), out lastUpdate);
                controls.HdnLastUpdateTimeStamp.Value = lastUpdate.Ticks.ToString();
            }

            if (isSnapshot)
            {
                e.Row.CssClass = CurrentLockdownIsSoftLockdown ? "LockdownSoft" : "Lockdown"; 
            }

            var chkDeleteEstimate = (CheckBox)e.Row.Cells[7].FindControl("chkDeleteThisEstimate");
            if (chkDeleteEstimate != null)
            {
                if (!(chkDeleteEstimate.Enabled = isNotLocked))
                {
                    chkDeleteEstimate.ToolTip = @"You cannot delete this price as the date received is before the ""lockdown as of"" date.";
                }

                if (chkDeleteEstimate.Enabled && isPriceSourceCashDistribution)
                {
                    chkDeleteEstimate.Enabled = false;
                    chkDeleteEstimate.ToolTip = @"You cannot delete this price as the estimate has been created by Cash Distribution.";
                }
            }

            var pnlEditSecurityPricing = e.Row.FindControl("pnlEditSecurityPricing") as Panel;
            if (pnlEditSecurityPricing != null)
            {
                pnlEditSecurityPricing.Visible = securityPricingId > 0;

                var editSpEstimateClicked = controls.HdnEditedFromCP != null && !string.IsNullOrEmpty(controls.HdnEditedFromCP.Value) &&
                                        bool.Parse(controls.HdnEditedFromCP.Value);

                if (securityPricingId > 0 && estimatePriceSource != null
                    && estimatePriceSource.EnumValueName == "Manual" && !editSpEstimateClicked)
                {
                    controls.CtrlPriceSource.Enabled = false;
                }
            }
            var isEstimateFinal = DataBinder.Eval(e.Row.DataItem, "EstimateType").ToString() == "Final";
            if (controls.IsGross != null)
            {
                controls.IsGross.Enabled = !(isSnapshot || isEstimateFinal);
            }

            var pnlUploadPricing = e.Row.FindControl("pnlUploadDocument") as Panel;
            if (pnlUploadPricing != null)
            {
                var isEstimateLocked = DataBinder.Eval(e.Row.DataItem, "EstimateType").ToString().Contains("Locked").ToString();
                var estimateId = DataBinder.Eval(e.Row.DataItem, "EstimateId").ToString();

                var hasAttachments = bool.Parse(DataBinder.Eval(e.Row.DataItem, "HasAttachements").ToString());
                var updateCount = int.Parse(DataBinder.Eval(e.Row.DataItem, "UpdateCount").ToString());
                AttachmentUpdateCount += updateCount;
                pnlUploadPricing.Attributes.Add("pricingId", estimateId);
                pnlUploadPricing.Attributes.Add("mode", Mode.ToString());
                pnlUploadPricing.Attributes.Add("portfolioIds", Mode == ReturnsPageMode.Returns ? string.Join(",", SelectedPortfolioIdList) : SelectedPortfolioId.ToString());
                pnlUploadPricing.Attributes.Add("securityPricingId", securityPricingId.ToString());
                pnlUploadPricing.Attributes.Add("organizationId", SeriesOrganizationId.ToString());
                pnlUploadPricing.Attributes.Add("fundId", FundId.ToString());
                pnlUploadPricing.Attributes.Add("effectiveDate", ReturnDate.ToString());
                pnlUploadPricing.Attributes.Add("isFinal", isEstimateFinal.ToString());
                pnlUploadPricing.Attributes.Add("isEstimateLocked", isEstimateLocked);
                var btnUpdate = new LinkButton { ID = "btnUpdate", Text = updateCount > 0 ? "Update" : "" };
                btnUpdate.Attributes["onClick"] += "javascript:showUpdatePricingDocumentDialog(this);return false;";
                pnlUploadPricing.Controls.Add(btnUpdate);
                var btnAttach = new ImageButton { ID = "btnAttach", ImageUrl = ResolveUrl(IMAGE_FOLDER + (hasAttachments ? "Attachement.png" : "NoAttachement.png")) };
                btnAttach.Attributes["onClick"] += "javascript:showUploadPricingDocumentDialog(this);return false;";
                pnlUploadPricing.Controls.Add(btnAttach);
            }
        }
    }

    private void AttachScriptToFinal()
    {
        if (estimGV.InsertTableRow != null && estimGV.InsertTableRow.Visible)
        {
            var controls = new ReturnsGridViewControls(estimGV.InsertTableRow);
            if (controls.ChkIsFinal != null && controls.IsGross != null)
                controls.ChkIsFinal.Attributes.Add("onclick", "setGross(this,'"+controls.IsGross.ClientID+"');");
        }
    }

    public void ShowUpdates(bool visible)
    {
        foreach (GridViewRow row in estimGV.Rows)
        {
            var btnUpdate = row.FindControl("btnUpdate");
            if (btnUpdate != null)
                btnUpdate.Visible = visible;
            var btnAttach = row.FindControl("btnAttach");
            if (btnAttach != null)
                btnAttach.Visible = !visible;
        }
    }

    private void AttachJavascript(ReturnsGridViewControls controls, string postfix)
    {
        if (controls.TxtNav == null || controls.TxtReturn == null || controls.HdnAsReturn == null || controls.TxtLocalMV == null)
            return;

        var onChangeFn = "SetData_" + postfix + "()";
        var sb = new StringBuilder(3000);
        sb.Append("<script>");
        sb.Append("var returnsType = '").Append(FundView is PortfolioView ? "P" : "F").Append("';");
        sb.Append("function ").Append(onChangeFn).Append("{");
        sb.Append("_navTextBox = document.getElementById('").Append(controls.TxtNav.RealValueCtrlID).Append("_field');");
        sb.Append("_returnTextBox = document.getElementById('").Append(controls.TxtReturn.UniqueID).Append("_field');");
        sb.Append("_asReturnHiddenFld = document.getElementById('").Append(controls.HdnAsReturn.UniqueID).Append("');");
        sb.Append("_fundId = ").Append(FundId.ToString()).Append(";");
        sb.Append("_endDate = '").Append(ReturnDate.ToShortDateString()).Append("';");

        if (FundInvestmentView != null)
        {
            sb.Append("_portfolioId = ").Append(FundInvestmentView.PortfolioId).Append(";");
            sb.Append("_investmentId = ").Append(FundInvestmentView.Id).Append(";");
            sb.Append("_localMV = document.getElementById('").Append(controls.TxtLocalMV.UniqueID).Append("_field');");
        }

        if (controls.ChkIsFinal != null)
            sb.Append("ReturnsSecurityPricing.SetAcceptNoneRow(" + FundId + ");");

        sb.Append("}; </script>");
        Page.ClientScript.RegisterClientScriptBlock(GetType(), onChangeFn, sb.ToString());

        if (controls.ChkIsFinal != null)
            controls.ChkIsFinal.Attributes["onClick"] += IsDirtyJavaScriptFunction;

        if (controls.DdlIsFlatStale != null && (FundView is InvestableFundView))
        {
            controls.DdlIsFlatStale.Visible = true;
            controls.DdlIsFlatStale.Attributes["onFocus"] += "ConvertLabelsToTextBox(document.getElementById('" + controls.TxtNav.MaskValueCtrlID + "'),true);";
            controls.DdlIsFlatStale.Attributes["onchange"] += IsDirtyJavaScriptFunction + onChangeFn + ";GetLastEstimate('" + ReturnDate.ToShortDateString() + 
                "','" + controls.DdlIsFlatStale.ClientID + "'); return false;";
        }
    }
    public void UpdateEstimateGridViewControl()
    {
        estimGV.Save();
    }
    public bool SetEditModeInEstimateGridView()
    {
        return estimGV.GridMode == CBulkEditGridView.GridModeType.EDIT;
    }
    public void FlushDataOnError(string message)
    {
        ErrorMessage.Append(message);
        //TODO: probably flush list
        /*DataPoint = null;
        FundSeries = null;*/
    }
  

    public bool IsCheckedDeleteLastEstimate()
    {
        foreach (GridViewRow row in estimGV.Rows)
        {
            var chkDeleteEstimate = (CheckBox)row.Cells[7].FindControl("chkDeleteThisEstimate");
            if (chkDeleteEstimate != null && chkDeleteEstimate.Checked)
            {
                return true;
            }
        }

        return false;
    }

    public List<ReturnsGridEstimateRow> GetRows()
    {
        var rows = EstimateRows;

        if (IsCheckedDeleteLastEstimate())
        {
            rows = new List<ReturnsGridEstimateRow>(EstimateRows);
            //var isInserted = rows.Exists(row => row.EstimateId == -1);
            //var rowPositionToDelete = isInserted ? rows.Count - 1 : rows.Count - 2;
            var rowPositionToDelete = rows.Count - 1;
            rows.RemoveAt(rowPositionToDelete);
        }

        return rows;
    }

    public void SetSaveResultMessages(ReturnsSaveResult returnsSaveResult)
    {
        if (returnsSaveResult.Messages != null)
        {
            FlushDataOnError(returnsSaveResult.Messages.ErrorMessage);
            Messages.Append(returnsSaveResult.Messages.Message);
        }
    }

    #endregion

    #region Methods

    private void AttachJavascript(string postfix, ReturnsGridViewControls rowControls)
    {
        var sb = new StringBuilder();
        sb.Append("_navTextBox = $get('").Append(rowControls.TxtNav.RealValueCtrlID).Append("_field');");
        sb.Append("_returnTextBox = $get('").Append(rowControls.TxtReturn.UniqueID).Append("_field');");
        sb.Append("_asReturnHiddenFld = $get('").Append(rowControls.HdnAsReturn.UniqueID).Append("');");
        sb.Append("_fundId = ").Append(FundId.ToString()).Append(";");
        sb.Append("_endDate = '").Append(ReturnDate.ToShortDateString()).Append("';");

        if (FundInvestmentView != null)
        {
            sb.Append("_portfolioId = ").Append(FundInvestmentView.PortfolioId).Append(";");
            sb.Append("_investmentId = ").Append(FundInvestmentView.Id).Append(";");
            sb.Append("_localMV = $get('").Append(rowControls.TxtLocalMV.UniqueID).Append("_field');");
        }

        sb.Append("_warnBeforeUnload = false;");
        //Create a function with SB contents inside//
        var onChangeFn = "SetData_" + postfix + "()";
        var jsOnChange = "<script>var returnsType = 'F';function " + onChangeFn + "{" + sb + "}</script>";
        Page.ClientScript.RegisterClientScriptBlock(GetType(), onChangeFn, jsOnChange);
    }

    public void BindGrid(ReturnsPageData gridData)
    {
        FundView = gridData.FundView;
        FundLastCPrice = gridData.FundLastCPrice;
        var dataSource = gridData.GridRows;
        EstimateRows = gridData.GridRows;
        IsDeletedAllowedForReturns = gridData.IsDeletedAllowedForReturns;
        LastModifiedDate = gridData.SeriesLastModifiedDate;
        SeriesOrganizationId = gridData.SeriesOrganizationId;
        estimGV.EnableInsert = !EstimateRows.Exists(row => row.EstimateIsFinal);
        IsDataPointEditable = gridData.IsEditable;
        FundInvestmentView = gridData.Investment;
        HasFutureAllocations = gridData.HasFutureAllocations;
        CurrentLockdownIsSoftLockdown = gridData.CurrentLockdownIsSoftLockdown;
        HasAttachements = gridData.HasAttachements;
        switch (Filter)
        {
            case EstimateFilter.LOCKEDNAV:
                dataSource = dataSource.Where(estimate => estimate.IsSnapshot).ToList();
                break;
            case EstimateFilter.FINAL:
                dataSource = dataSource.Where(estimate => estimate.EstimateIsFinal).ToList();
                break;
        }

        estimGV.DataSource = dataSource;
        estimGV.GridMode = CBulkEditGridView.GridModeType.EDIT;
        estimGV.DataBind();
        AttachScriptToFinal();
    }


    private void PopulateDataObjects(ReturnsGridEstimateRow row, ReturnsGridViewControls controls, bool isUpdates)
    {
        var estimateMv = CAmount.NaN;
        DateTime dateReceived;
        long lastUpdateTicks;
        int priceSource;
        bool asReturn;
        CPercent estimateReturn;
        CPercent.TryParse(controls.TxtReturn.RealValue, true, out estimateReturn);

        if (FundView is PortfolioView && string.IsNullOrEmpty(controls.TxtReturn.RealValue))
            estimateReturn = CPercent.NaN;

        var estimateNav = CNav.Parse(controls.TxtNav.RealValue);
        if (!String.IsNullOrEmpty(controls.TxtLocalMV.RealValue))
            estimateMv = CAmount.Parse(controls.TxtLocalMV.RealValue);
        DateTime.TryParse(controls.TxtDateReceived.Text, out dateReceived);
        Boolean.TryParse(controls.HdnAsReturn.Value, out asReturn);
        int.TryParse(controls.CtrlPriceSource.Value, out priceSource);
        long.TryParse(controls.HdnLastUpdateTimeStamp.Value, out lastUpdateTicks);

        row.EstimateReturn = estimateReturn.Value;
        row.UnadjustedReturn = estimateReturn.Value;

        row.EstimateNav = estimateNav == 0 ? Data.CNAV_FAKE_ZERO.Value : estimateNav.Value;
        row.EstimateAsReturn = asReturn;
        row.PriceSource = priceSource;
        row.DateReceived = dateReceived.Date;
        row.LastUpdateTimeStamp = new DateTime(lastUpdateTicks);
      
        row.LocalMarketValue = FundView is PortfolioView ? estimateMv.Value : CAmount.NaN.Value; //Portfolio Returns page
        row.EstimateIsFlatStale = controls.DdlIsFlatStale.SelectedItem.Text.ToUpper().Equals("YES");

        var editSpEstimateClicked = controls.HdnEditedFromCP != null && !string.IsNullOrEmpty(controls.HdnEditedFromCP.Value) &&
                                    bool.Parse(controls.HdnEditedFromCP.Value);
        //TODO: analyze!!!!
        row.EditedFromCp = !String.IsNullOrEmpty(row.SecurityPricingId) && isUpdates && editSpEstimateClicked ? "true" : "false";

        if (controls.IsGross != null)
            row.IsGross = controls.IsGross.Checked;
    }

    //TODO: implement it for Price Lockdown without accessing to business object DataPoint
    /*public bool EnableLockdownDelete()
    {
        return LiveDataPoint == null || LiveDataPoint.Estimates == null || LiveDataPoint.Estimates.Count == 0;
    }*/

    public bool IsEditable(StringBuilder message)
    {
        if (!IsDataPointEditable)
        {
            message.Append("Cannot edit this return because there's an OP&L saved for it");
        }
        return IsDataPointEditable;
    }

    public void SetDataPointModified()
    {
        _dataPointModified = true;
    }

    public bool IsDataPointModified()
    {
        return _dataPointModified;
    }

    private void PopulateStaledRow(ReturnsGridViewControls controls, CQuantity availableShares)
    {
        // If current entity is Portfolio, it means we are on Portfolio Returns view.
        // This view doesn't support multiple lines mode, so calling this would corrupt single row's state.
        if (FundView is PortfolioView)
            return;

        if (StaleMode)
        {
            var lastPrice = FundLastCPrice;
            var localMv = lastPrice * availableShares;
            controls.TxtReturn.Value = "0";
            controls.HdnReturn.Value = "0%";
            controls.HdnAsReturn.Value = "False";
            controls.TxtNav.Value = controls.HdnNav.Value = lastPrice.ToString("#,##0.00000000;(#,##0.00000000)");
            controls.TxtLocalMV.Value = controls.HdnLocalMV.Value = localMv.ToString(CAmount.FORMAT_STRING);
            controls.TxtNav.Bold = true;
            controls.DdlIsFlatStale.SelectedValue = "1";
            controls.CtrlPriceSource.Value = "-1";
            var script = "<script> $(document).ready(function(){document.getElementById('" + controls.TxtNav.MaskValueCtrlID + "').onclick();";
            //At least one field have to fire onchange event to make current row "dirty"
            script += "document.getElementById('" + controls.CtrlPriceSource.DdlEnumClientID + "').value=" + controls.CtrlPriceSource.EnumStaleID + ";});</script>";
            Page.ClientScript.RegisterClientScriptBlock(GetType(), "StaleSecurities_" + estimGV.UniqueID, script);
        }
        else
        {
            controls.TxtReturn.Value = controls.HdnReturn.Value = controls.TxtNav.Value = "";
            controls.HdnNav.Value = controls.TxtLocalMV.Value = controls.HdnLocalMV.Value = "";
            controls.TxtNav.Bold = false;
            controls.CtrlPriceSource.Value = "0";
            controls.DdlIsFlatStale.SelectedValue = "2";
        }
    }

    #endregion

    private class ReturnsGridViewControls
    {
        public CheckBox ChkIsFinal { get; private set; }
        public DropDownList DdlIsFlatStale { get; private set; }
        public VirtualTextBox TxtNav { get; private set; }
        public HiddenField HdnNav { get; private set; }
        public Label LblAvailableShares { get; private set; }
        public VirtualTextBox TxtReturn { get; private set; }
        public HiddenField HdnReturn { get; private set; }
        public VirtualTextBox TxtLocalMV { get; private set; }
        public HiddenField HdnLocalMV { get; private set; }
        public HiddenField HdnAsReturn { get; private set; }
        public VirtualTextBox TxtDateReceived { get; private set; }
        public usercontrols_dataformat_UCEnum CtrlPriceSource { get; private set; }
        public HiddenField HdnLastUpdateTimeStamp { get; private set; }
        public HiddenField HdnEditedFromCP { get; private set; }
        public CheckBox IsGross { get; private set; }
        public Panel UploadDocument { get; private set; }

        public ReturnsGridViewControls(Control row)
        {
            if (row == null)
                return;

            ChkIsFinal = row.FindControl("chkIsFinal") as CheckBox;
            TxtNav = row.FindControl("txtEstimateNav") as VirtualTextBox;
            HdnNav = row.FindControl("hdnEstimateNav") as HiddenField;
            TxtReturn = row.FindControl("txtEstimateReturn") as VirtualTextBox;
            HdnReturn = row.FindControl("hdnEstimateReturn") as HiddenField;
            HdnAsReturn = row.FindControl("hdnAsReturn") as HiddenField;
            TxtLocalMV = row.FindControl("txtLocalMV") as VirtualTextBox;
            HdnLocalMV = row.FindControl("hdnLocalMV") as HiddenField;
            TxtDateReceived = row.FindControl("txtDateReceived") as VirtualTextBox;
            CtrlPriceSource = row.FindControl("ctrlPriceSource") as usercontrols_dataformat_UCEnum;
            HdnLastUpdateTimeStamp = row.FindControl("hdnLastUpdateTimeStamp") as HiddenField;
            LblAvailableShares = row.FindControl("lblAvailableShares") as Label;
            DdlIsFlatStale = row.FindControl("ddlIsFlatStale") as DropDownList;
            HdnEditedFromCP = row.FindControl("hdnEditedFromCP") as HiddenField;
            IsGross = row.FindControl("chkIsGross") as CheckBox;
            UploadDocument = row.FindControl("pnlUploadDocument") as Panel;
        }
    }

}