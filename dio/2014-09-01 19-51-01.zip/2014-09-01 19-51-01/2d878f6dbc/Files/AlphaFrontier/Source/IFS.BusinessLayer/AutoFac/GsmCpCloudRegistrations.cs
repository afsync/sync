﻿using Autofac;
using IFS.BusinessLayer.CloudServices.CentralPricing;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.GSM.CentralPricing;
using IFS.DataAccess.Entity;
using IFS.DbRepository;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.DbRepository;

namespace IFS.BusinessLayer.AutoFac
{
    public class GsmCpCloudRegistrations : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<CentralPricingService>().As<ICentralPricingService>();
            builder.RegisterType<CentralPricingGridFactory>().AsSelf();
            builder.RegisterType<CentralPricingDataProviderFactory>().AsSelf();

            builder.Register(c => new SecurityPricingFactory(
                c.Resolve<SecurityPricingGroupRepository>(),
                c.Resolve<GenericSequenceProvider<SecurityPricingGroupSequenceData>>(), 
                c.Resolve<GenericSequenceProvider<SecurityPricingAttachmentGroupSequenceData>>(), 
                Organization.Loader, 
                InvestableFund.Loader)).AsSelf();

            builder.Register(c => 
                new SecurityPricingGroupRepository(
                    c.Resolve<ISecurityPricingGroupDbRepository>(),
                    c.Resolve<GenericSequenceProvider<SecurityPricingGroupSequenceData>>()))
                .AsSelf().As<SecurityPricingGroupRepository>();
            builder.RegisterType<SecurityPricingGroupDbRepository>().As<ISecurityPricingGroupDbRepository>();

            //builder.RegisterInstance(SecurityPricingStore.GetInstance()).As<ISecurityPricingStore>().ExternallyOwned();

        }
    }
}
