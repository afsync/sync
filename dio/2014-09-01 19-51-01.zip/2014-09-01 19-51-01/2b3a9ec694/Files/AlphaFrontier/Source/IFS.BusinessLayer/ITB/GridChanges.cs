﻿using System.Collections.Generic;

namespace IFS.BusinessLayer.Itb
{
    public class GridParams
    {
        public string GridId { get; set; }
        public int ChecklistId { get; set; }
    }
    
    public class GridChanges
    {
        public GridParams IO { get; set; }
        public List<RowChanges> Changes { get; set; }

        public GridChanges()
        {
            Changes = new List<RowChanges>();
        }
    }

    public class RowChanges
    {
        public Dictionary<string, string> Changes { get; set; }
    }
}
