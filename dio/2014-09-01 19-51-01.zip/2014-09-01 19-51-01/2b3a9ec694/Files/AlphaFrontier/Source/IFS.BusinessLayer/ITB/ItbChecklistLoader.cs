﻿using System;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChecklistLoader
    {
        public virtual ChecklistBase GetById(int checklistId)
        {
            throw new NotImplementedException();
        }
    }
}
