﻿using System.Collections.Generic;
using System.Linq;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesProcessor
    {
        private readonly ItbChangeProcessorObjectFactory _factory;

        public ItbChangesProcessor(ItbChangeProcessorObjectFactory factory)
        {
            _factory = factory;
        }

        public List<GridChanges> Process(List<GridChanges> changes)
        {
            var processedChanges = changes.Select(ProcessGridChanges);
            return processedChanges.ToList();
        }

        private GridChanges ProcessGridChanges(GridChanges gridChanges)
        {
            return new GridChanges {Changes = gridChanges.Changes.Select(ProcessRowChanges).ToList()};
        }

        private RowChanges ProcessRowChanges(RowChanges rowChanges)
        {
            var processor = new ItbChangeProcessor(_factory);
            return processor.Process(rowChanges);
        }
    }
}
