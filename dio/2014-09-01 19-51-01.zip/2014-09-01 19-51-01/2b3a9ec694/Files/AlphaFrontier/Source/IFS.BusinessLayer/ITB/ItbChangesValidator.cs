﻿using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesValidator
    {
        public virtual void Validate(ChecklistBase checklist)
        {
            throw new System.NotImplementedException();
        }
    }
}
