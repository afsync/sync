﻿using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangeProcessorTests
    {
        [Test]
        public void TestProcessVerifyFactoryBehavior()
        {
            //given
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var mockLoader = new Mock<ItbChecklistLoader>();
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object);

            //when
            processor.Process(rowChanges);

            //then
            mockObjectFactory.Verify(m => m.GetViewer(It.IsAny<RowChanges>()), Times.Once());
            mockObjectFactory.Verify(m => m.GetLoader(), Times.Once());
            mockObjectFactory.Verify(m => m.GetValidator(), Times.Once());
            mockObjectFactory.Verify(m => m.GetSaver(), Times.Once());
        }

        [Test]
        public void TestProcessVerifyParserBehavior()
        {
            //given
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var mockLoader = new Mock<ItbChecklistLoader>();
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object);

            //when
            processor.Process(rowChanges);

            //then
            mockViewer.Verify(m => m.GetChecklistId(), Times.Once());
        }

        [Test]
        public void TestProcessVerifyLoaderBehavior()
        {
            //given
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            mockViewer.Setup(p => p.GetChecklistId()).Returns(1231441);
            var mockLoader = new Mock<ItbChecklistLoader>();
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object);

            //when
            processor.Process(rowChanges);

            //then
            mockLoader.Verify(m => m.GetById(1231441), Times.Once());
        }

        [Test]
        public void TestProcessVerifyValidatorBehavior()
        {
            //given
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            mockViewer.Setup(p => p.GetChecklistId()).Returns(1231441);
            var mockLoader = new Mock<ItbChecklistLoader>();
            var checklist = Mock.Of<ChecklistBase>();
            mockLoader.Setup(p => p.GetById(1231441)).Returns(checklist);
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object);

            //when
            processor.Process(rowChanges);

            //then
            mockValidator.Verify(m => m.Validate(checklist), Times.Once());
        }

        [Test]
        public void TestProcessVerifySaverBehavior()
        {
            //given
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            mockViewer.Setup(p => p.GetChecklistId()).Returns(1231441);
            var mockLoader = new Mock<ItbChecklistLoader>();
            var checklist = Mock.Of<ChecklistBase>();
            mockLoader.Setup(p => p.GetById(1231441)).Returns(checklist);
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object);

            //when
            processor.Process(rowChanges);

            //then
            mockSaver.Verify(m => m.Save(checklist), Times.Once());
        }
    }
}
