﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Collections;
using IFS.BusinessLayer.Price;
using IFS.BusinessLayer.Price.Snapshot;
using IFS.BusinessLayer.Returns;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Entity;
using IFS.Interfaces.Rounding;
using IFS.NUnitTests.BusinessLayer.shared;
using IFS.NUnitTests.Helpers;
using IFS.NUnitTests.MockResults;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ReturnsTests
{
    [TestFixture]
    public class EstimateRowsMakerTests
    {
        private const int BASE_FUND_ID = 1;
        private const int FUND_CLASS_ID = 10;
        private const int PORTFOLIO_ID = 100;
        MockPortfolio _portfolio;
        MockFundClass _fundClass;
        MockBaseFund _baseFund;
        DateTime _returnDate = new DateTime(2009, 01, 31);
        private EstimateRowsMaker _rowMaker;

        [SetUp]
        public void Setup()
        {
            _portfolio = GetMockedPortfolio();
            _fundClass = new MockFundClass(FUND_CLASS_ID);
            _baseFund = new MockBaseFund(BASE_FUND_ID);
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.Returns, null, new List<EstimateAttachment>());
        }

        private MockPortfolio GetMockedPortfolio()
        {
            var portfolioMock = new Mock<MockPortfolio>(PORTFOLIO_ID);
            portfolioMock.Setup(p => p.HasSoftLockedAllocations(It.IsAny<Investment>(), It.IsAny<PortfolioLockdown>())).Returns(false);
            portfolioMock.CallBase = true;
            return portfolioMock.Object;
        }

        [TearDown]
        public void TearDown()
        {
            _portfolio = null;
            _fundClass = null;
            _baseFund = null;
            _rowMaker = null;
            PortfolioLockdownCollectionLoaderHelper.Clear();
        }

        [Test]
        public void IsDeletedAllowedForReturns_Test()
        {
            PortfolioLockdownCollectionLoaderHelper.InsertCollection(_portfolio.Id, new PortfolioLockdownCollection());
            
            var rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.Returns, null,null);
            Assert.IsTrue(rowMaker.IsDeletedAllowedForReturns());

            rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null,null);
            Assert.IsFalse(rowMaker.IsDeletedAllowedForReturns());
        }

        [Test]
        public void GetRows_ForBaseFundShouldBeEmpty()
        {
            var rows = new EstimateRowsMaker(_portfolio, _baseFund, _returnDate, ReturnsPageMode.Returns, null,null).GetRows();
            Assert.AreEqual(0, rows.Count);
        }

        [Test]
        public void GetInvestment_NonExistingInvestment()
        {
            var portfolio = new MockPortfolio();
            Assert.IsNull(_rowMaker.GetInvestment(portfolio));
        }

        [Test]
        public void GetInvestment_WithZeroQuantityForPriceLockdown()
        {
            var portfolio = new MockPortfolio();
            var rowMakerPriceLockdown = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null,null);
            portfolio.Investments.Add(new MockInvestment { FundID = FUND_CLASS_ID, Allocations = new List<Allocation> { new AllocationSubscription() { ExecutionDate = _returnDate.AddDays(1) } } });
            Assert.IsNull(rowMakerPriceLockdown.GetInvestment(portfolio));
        }

        [Test]
        public void GetInvestment_WithZeroQuantityForReturns()
        {
            var portfolio = new MockPortfolio();
            portfolio.Investments.Add(new MockInvestment { FundID = FUND_CLASS_ID, Allocations = new List<Allocation> { new AllocationSubscription() { ExecutionDate = _returnDate.AddDays(1) } } });
            Assert.IsNotNull(_rowMaker.GetInvestment(portfolio));
        }

        [Test]
        public void GetSnapshotEstimate_ForPortfolioWithoutLockdowns()
        {
            PortfolioLockdownCollectionLoaderHelper.InsertCollection(_portfolio.Id, new PortfolioLockdownCollection());
            var snapshotEstimate = _rowMaker.GetSnapshotEstimate();
            Assert.IsNull(snapshotEstimate);
        }

        [Test]
        public void GetSnapshotEstimate_LockdownContainingNoSuitableLockedPriceForFund()
        {
            PopulateProtfolioWithLockdown(0, 0, 0);
            Assert.IsNull(_rowMaker.GetSnapshotEstimate());
        }

        [Test]
        public void GetSnapshotEstimate_LockdownDoesNotContainSnapshotForPrice()
        {
            PopulateProtfolioWithLockdown(FUND_CLASS_ID, 0, -1);
            Assert.IsNull(_rowMaker.GetSnapshotEstimate());
        }

        [Test]
        public void GetSnapshotEstimate_ShouldReturnSuitableSnapshotEstimate()
        {
            PopulateProtfolioWithLockdown(FUND_CLASS_ID, 1, 1);
            Assert.IsNotNull(_rowMaker.GetSnapshotEstimate());
        }

        [Test]
        public void LockdownSharesIsNotNanNotZero_WithNullForSnapshot()
        {
            Assert.IsFalse(_rowMaker.LockdownSharesIsNotNanNotZero(null));
        }

        [Test]
        public void LockdownSharesIsNotNanNotZero_WithNanAndZeroQuantityInSnapshot()
        {
            Assert.IsFalse(_rowMaker.LockdownSharesIsNotNanNotZero(new SnapshotEstimate { EstimateLockdownQuantity = CQuantity.NaN }));
            Assert.IsFalse(_rowMaker.LockdownSharesIsNotNanNotZero(new SnapshotEstimate { EstimateLockdownQuantity = CQuantity.Zero() }));
        }

        [Test]
        public void LockdownSharesIsNotNanNotZero_WithPositiveQuantity()
        {
            Assert.IsTrue(_rowMaker.LockdownSharesIsNotNanNotZero(new SnapshotEstimate { EstimateLockdownQuantity = new CQuantity(100) }));
        }

        [Test]
        public void LiveSharesIsNotNanNotZero_WithNullForInvestment()
        {
            Assert.IsFalse(_rowMaker.LiveSharesIsNotNanNotZero());
        }

        [Test]
        public void LiveSharesIsNotNanNotZero_WithZeroQuantityForInvestment()
        {
            _portfolio.Investments.Add(new MockInvestment { FundID = FUND_CLASS_ID });
            Assert.IsFalse(_rowMaker.LiveSharesIsNotNanNotZero());
        }

        [Test]
        public void LiveSharesIsNotNanNotZero_WithPositiveQuantity()
        {
            _portfolio.Investments.Add(new MockInvestment { FundID = FUND_CLASS_ID, Allocations = new List<Allocation> { new AllocationSubscription { Quantity = 100 } } });
            Assert.IsTrue(_rowMaker.LiveSharesIsNotNanNotZero());
        }

        [Test]
        public void PopulateEstimateRow_CheckProperObjectPopulation()
        {
            MockResults.MockResultSingleton.SetResult("PortfolioLockDownDbRepository.SelectByOrganization", new Dictionary<int, List<IPortfolioLockdownData>>());
            const int estimateId = 111;
            const bool estimateIsFinal = true;
            var dateReceived = new DateTime(2010, 10, 1);
            const double estimateNav = 100;
            const double estimateReturn = 10;
            const bool estimateAsReturn = true;
            const int userId = 200;
            const int priceSource = 1;
            const bool estimateIsFlatStale = true;
            var timeStamp = new DateTime(2010, 10, 2);
            var lastUpdateTimeStamp = new DateTime(2010, 10, 3);
            var localMarketValue = new CAmount(100);
            const int unadjustedReturn = 200;
            const bool applyManagementFee = true;
            const bool isGross = true;
            const int securityPricingId = 1;
            const bool editedFromCp = true;

            var estimate = new MockEstimate
            {
                EstimateId = estimateId,
                EstimateIsFinal = estimateIsFinal,
                EstimateDate = dateReceived,
                EstimateNav = estimateNav,
                EstimateReturn = estimateReturn,
                EstimateAsReturn = true,
                EstimateUserId = 200,
                PriceSource = priceSource,
                EstimateIsFlatStale = estimateIsFlatStale,
                EstimateTimeStamp = timeStamp,
                EstimateLastUpdateTimeStamp = lastUpdateTimeStamp,
                ParentData = new DataFund { DataPortfolioMV = localMarketValue },
                UnadjustedReturn = unadjustedReturn,
                ApplyManagementFee = applyManagementFee,
                IsGross = isGross,
                SecurityPricingId = securityPricingId,
                EditedFromCP = editedFromCp
            };
            var row = _rowMaker.PopulateEstimateRow(estimate);

            Assert.IsNotNull(row);
            Assert.AreEqual(estimateId, row.EstimateId);
            Assert.AreEqual("Final", row.EstimateType);
            Assert.AreEqual(estimateIsFinal, row.EstimateIsFinal);
            Assert.AreEqual(dateReceived, row.DateReceived);
            Assert.AreEqual(estimateNav, row.EstimateNav);
            Assert.AreEqual(estimateReturn, row.EstimateReturn);
            Assert.AreEqual(estimateAsReturn, row.EstimateAsReturn);
            Assert.AreEqual(User.Loader.GetById(userId).UserFullName, row.EnteredBy);
            Assert.AreEqual(priceSource, row.PriceSource);
            Assert.AreEqual(estimateIsFlatStale, row.EstimateIsFlatStale);
            Assert.AreEqual(timeStamp, row.TimeStamp);
            Assert.AreEqual(lastUpdateTimeStamp, row.LastUpdateTimeStamp);
            Assert.AreEqual(localMarketValue.Value, row.LocalMarketValue);
            Assert.AreEqual(unadjustedReturn, row.UnadjustedReturn);
            Assert.AreEqual(applyManagementFee, row.ApplyManagementFee);
            Assert.AreEqual(isGross, row.IsGross);
            Assert.AreEqual(securityPricingId.ToString(), row.SecurityPricingId);
            Assert.AreEqual(editedFromCp.ToString().ToLower(), row.EditedFromCp);

            estimate.EstimateIsFinal = false;
            row = _rowMaker.PopulateEstimateRow(estimate);
            Assert.AreEqual("Estimate", row.EstimateType);
        }

        [Test]
        public void TestEstimateRowLockDownAsOfDateFieldEqualsCurrentLockdownAsOfDate()
        {
            //given
            var currentLockdownAsOfDate = new DateTime(2013, 1, 31);
            var nextLockdownAsOfDate = new DateTime(2013, 2, 28);
            var portfolioLockdowns = new List<PortfolioLockdown>
            {
                Mock.Of<PortfolioLockdown>(l=>l.LockdownAsOfDate == currentLockdownAsOfDate && l.IsLocked),
                Mock.Of<PortfolioLockdown>(l=>l.LockdownAsOfDate == nextLockdownAsOfDate && l.IsLocked)
            };
            var rowMaker = new EstimateRowsMaker(new Portfolio(), new FundClass(), currentLockdownAsOfDate,
                ReturnsPageMode.PriceLockDown, portfolioLockdowns, new List<EstimateAttachment>());
            var estimate = Mock.Of<Estimate>(e=>e.EstimateReturn == 0 && e.ParentData == Mock.Of<IFS.BusinessLayer.Data>(d=>d.DataPortfolioMV == CAmount.NaN) && e.EstimateIsFinal && e.EstimateCNav == CNav.NaN && e.EstimateUserId==-1);

            //when
            
            var returnsGridEstimateRows = rowMaker.BuildRows(new List<Estimate> {estimate}, null);

            //then
            Assert.That(returnsGridEstimateRows.Single().LockdownAsOfDate, Is.EqualTo(currentLockdownAsOfDate));
        }

        [Test]
        public void TestEstimateRowLockDownAsOfDateFieldEqualsMinDateIfCurrentLockdownIsNotApplied()
        {
            //given
            var previousLockdown1 = new DateTime(2012, 11, 30);
            var previousLockdown2 = new DateTime(2012, 12, 31);
            var currentLockdownAsOfDate = new DateTime(2013, 1, 31);
            var portfolioLockdowns = new List<PortfolioLockdown>
            {
                Mock.Of<PortfolioLockdown>(l=>l.LockdownAsOfDate == previousLockdown1 && l.IsLocked),
                Mock.Of<PortfolioLockdown>(l=>l.LockdownAsOfDate == previousLockdown2 && l.IsLocked)
            };
            var rowMaker = new EstimateRowsMaker(new Portfolio(), new FundClass(), currentLockdownAsOfDate,
                ReturnsPageMode.PriceLockDown, portfolioLockdowns, new List<EstimateAttachment>());
            var estimate = Mock.Of<Estimate>(e => e.EstimateReturn == 0 && e.ParentData == Mock.Of<IFS.BusinessLayer.Data>(d => d.DataPortfolioMV == CAmount.NaN) && e.EstimateIsFinal && e.EstimateCNav == CNav.NaN && e.EstimateUserId == -1);

            //when

            var returnsGridEstimateRows = rowMaker.BuildRows(new List<Estimate> { estimate }, null);

            //then
            Assert.That(returnsGridEstimateRows.Single().LockdownAsOfDate, Is.EqualTo(DateTime.MinValue));
        }

        [Test]
        public void GetEstimateTypeTest()
        {
            Assert.AreEqual("Estimate 1", _rowMaker.GetEstimateType(new Estimate()));
            Assert.AreEqual("Final", _rowMaker.GetEstimateType(new Estimate() { EstimateIsFinal = true }));
        }

        [Test]
        public void GetSnapshotEstimateTypeTest()
        {
            var lockdown = new MockPortfolioLockdown(1) { LockdownDataEndDate = _returnDate, IsSoftLockdown = true };
            PortfolioLockdownCollectionLoaderHelper.InsertCollection(PORTFOLIO_ID, new PortfolioLockdownCollection(new CacheableList<PortfolioLockdown> { lockdown }));

            Assert.AreEqual("Estimate (Soft Locked)", _rowMaker.GetSnapshotEstimateType(new Estimate()));

            lockdown.IsSoftLockdown = false;
            Assert.AreEqual("Estimate (Locked)", _rowMaker.GetSnapshotEstimateType(new Estimate()));
            Assert.AreEqual("Final (Locked)", _rowMaker.GetSnapshotEstimateType(new Estimate() { EstimateIsFinal = true }));
        }

        [Test]
        public void GetSnapshotEstimateRowTest()
        {
            MockResults.MockResultSingleton.SetResult("PortfolioLockDownDbRepository.SelectByOrganization", new Dictionary<int, List<IPortfolioLockdownData>>());
            var lockdown = new MockPortfolioLockdown(1) { LockdownDataEndDate = _returnDate };
            PortfolioLockdownCollectionLoaderHelper.InsertCollection(PORTFOLIO_ID, new PortfolioLockdownCollection(new CacheableList<PortfolioLockdown> { lockdown }));

            var estimate = new Estimate { EstimateId = 111, ParentData = new DataFund { DataPortfolioMV = new CAmount(0) } };
            var row = _rowMaker.GetSnapshotEstimateRow(estimate);

            Assert.AreEqual(true, row.IsSnapshot);
            Assert.AreEqual(double.NaN, row.LockdownShares);

            estimate.EstimateLockdownQuantity = new CQuantity(100);
            row = _rowMaker.GetSnapshotEstimateRow(estimate);
            Assert.AreEqual(100, row.LockdownShares);
        }

        [Test]
        public void BuildRows_AddsEstimateWithPositiveReturn()
        {
            FillInvestment();
            InitializeLockdown();

            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);

            Assert.AreEqual(1, rows.Count);
            Assert.IsNotNull(rows.Find(r => r.EstimateId == 111));
        }

        [Test]
        public void BuildRows_ShouldIgnoreEstimateWithZeroReturn()
        {
            FillInvestment();
            InitializeLockdown();

            var est = GetEstimate<Estimate>(111, double.NaN, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);

            Assert.AreEqual(0, rows.Count);
        }

        [Test]
        public void BuildRows_ShouldAddBothLiveAndSnapshotEstimates()
        {
            FillInvestment();
            InitializeLockdown();

            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var snapshotEst = GetEstimate<SnapshotEstimate>(111, 110, new CAmount(0), new CQuantity(10));

            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, snapshotEst);
            Assert.AreEqual(2, rows.Count);
        }

        [Test]
        public void BuildRows_ShouldAddEstimateWithZeroReturnIfDataPortfolio()
        {
            MockResults.MockResultSingleton.SetResult("EstimateAttachmentDbRepository.GetByEstimateIdsList",new List<IEstimateAttachmentData>());
            FillInvestment();
            InitializeLockdown();

            var est = GetEstimate<Estimate>(111, double.NaN, new CAmount(0), new CQuantity(0));

            _rowMaker = new EstimateRowsMaker(_portfolio, new MockPortfolioClass { SeriesId = 3 }, new DateTime(2011, 1, 31), ReturnsPageMode.Returns, null,null);
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);
            Assert.AreEqual(1, rows.Count);
        }

        [Test]
        public void IsEditable_WhenDataDividendsBaseIsNaN()
        {
            var isEditable = _rowMaker.IsEditable();
            Assert.IsTrue(isEditable);
        }

        [Test]
        public void TestHasPriceFromCpUserAccess_OrgDontSupportGsm()
        {
            CSession.OrganizationID = 1;
            Assert.AreEqual(false, new EstimateRowsMaker(_portfolio, new MockBaseFund(101), new DateTime(2011, 1, 31), ReturnsPageMode.Returns, null,null).HasPriceFromCpUserAccess());
        }

        [Test]
        public void TestHasPriceFromCpUserAccess_OrgSupportsGsm_UserHasAccess()
        {
            CSession.OrganizationID = 11;
            CSession.User.UserRoleID = 16;
            Assert.AreEqual(true, new EstimateRowsMaker(_portfolio, new MockBaseFund(101), new DateTime(2011, 1, 31), ReturnsPageMode.Returns, null,null).HasPriceFromCpUserAccess());
        }
        [Test]
        public void TestHasPriceFromCpUserAccess_OrgSupportsGsm_UserHasNoAccess()
        {
            CSession.OrganizationID = 11;
            CSession.User.UserRoleID = 17;
            Assert.AreEqual(false, new EstimateRowsMaker(_portfolio, new MockBaseFund(101), new DateTime(2011, 1, 31), ReturnsPageMode.Returns, null,null).HasPriceFromCpUserAccess());
        }
        [Test]
        public void TestHasAttachmentWithPortfolioIdEquals()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment> { new EstimateAttachment { EstimateId = 111, PortfolioId=_portfolio.Id} };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null, attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);

            Assert.AreEqual(1, rows.Count);
            Assert.IsTrue(rows[0].HasAttachements);
        }
        [Test]
        public void TestPublishedByStringEmpty()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment> { new EstimateAttachment { EstimateId = 111, PortfolioId = _portfolio.Id, } };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null, attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);
            Assert.IsEmpty(rows[0].PublishedBy);
        }

        [Test]
        public void TestPublishedByValueExists()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment>
            {
                new EstimateAttachment
                {
                    EstimateId = 111,
                    PortfolioId = _portfolio.Id,
                    PublishedByUserId = 200,
                    PublishedDate = new DateTime(2012, 2, 2),
                    SecurityPricingAttachmentId = 100
                }
            };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null,
                attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> {est}, null);
            Assert.IsNotEmpty(rows[0].PublishedBy);
        }
        [Test]
        public void TestPublishedByValueExistsPortfolioIsNull()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment>
            {
                new EstimateAttachment
                {
                    EstimateId = 111,
                    PortfolioId = null,
                    PublishedByUserId = 200,
                    PublishedDate = new DateTime(2012, 2, 2),
                    SecurityPricingAttachmentId = 100
                }
            };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null,
                attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);
            Assert.IsNotEmpty(rows[0].PublishedBy);
        }
        [Test]
        public void TestPublishedByValueExistsPortfolioIsMinusOne()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment>
            {
                new EstimateAttachment
                {
                    EstimateId = 111,
                    PortfolioId = null,
                    PublishedByUserId = 200,
                    PublishedDate = new DateTime(2012, 2, 2),
                    SecurityPricingAttachmentId = 100
                }
            };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null,
                attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);
            Assert.IsNotEmpty(rows[0].PublishedBy);
        }
        [Test]
        public void TestPublishedByIsLastByPublishDate()
        {
            FillInvestment();
            InitializeLockdown();
            var attachments = new List<EstimateAttachment>
            {
                new EstimateAttachment
                {
                    EstimateId = 111,
                    PortfolioId = _portfolio.Id,
                    PublishedByUserId = 200,
                    PublishedDate = new DateTime(2012, 2, 2),
                    SecurityPricingAttachmentId = 100
                },
                new EstimateAttachment
                {
                    EstimateId = 111,
                    PortfolioId = _portfolio.Id,
                    PublishedByUserId = 300,
                    PublishedDate = new DateTime(2011, 2, 2),
                    SecurityPricingAttachmentId = 100
                }
            };
            _rowMaker = new EstimateRowsMaker(_portfolio, _fundClass, _returnDate, ReturnsPageMode.PriceLockDown, null, attachments);
            var est = GetEstimate<Estimate>(111, 110, new CAmount(0), new CQuantity(0));
            var rows = _rowMaker.BuildRows(new List<Estimate> { est }, null);
            Assert.AreEqual("FirstName200 LastName200 02/02/2012 00:00",rows[0].PublishedBy);
        }

        [Test]
        public void TestsGetAllEstimateAttachmentsWhenLiveDataIsNull()
        {
            //given
            var fund = new Mock<FundClass>();
            fund.Setup(x => x.SeriesOriginal(It.IsAny<int>())).Returns(Mock.Of<SeriesPortfolio>());

            _rowMaker = new EstimateRowsMaker(_portfolio, fund.Object, _returnDate, ReturnsPageMode.PriceLockDown, null, null);

            //when
            var attachments = _rowMaker.GetAllEstimateAttachments();

            //then
            Assert.That(attachments, Is.Empty);
        }

        [Test]
        public void TestsGetAllEstimateAttachmentsWhenLiveDataIsNotNull()
        {
            //given
            var series = Mock.Of<Series>();
            var data = new Mock<DataCollection>(series);
            data.Setup(x => x.GetForEndDate(It.IsAny<DateTime>())).Returns(new DataPortfolio {Estimates = new List<Estimate>{new Estimate{Id = 3}}});
            series.SeriesData = data.Object;
            var fund = new Mock<FundClass>();
            fund.Setup(x => x.SeriesOriginal(It.IsAny<int>())).Returns(series);
            var attachmentsData = new List<IEstimateAttachmentData> { new EstimateAttachmentData(), new EstimateAttachmentData() };
            MockResultSingleton.SetResult("EstimateAttachmentDbRepository.GetByEstimateIdsList", attachmentsData);
            _rowMaker = new EstimateRowsMaker(_portfolio, fund.Object, _returnDate, ReturnsPageMode.PriceLockDown, null, null);

            //when
            var attachments = _rowMaker.GetAllEstimateAttachments();

            //then
            Assert.That(attachments, Has.Count.EqualTo(2));
        }

        [Test]
        public void TestsGetAllEstimateAttachmentsCaching()
        {
            //given
            var fund = new Mock<FundClass>();
            fund.Setup(x => x.SeriesOriginal(It.IsAny<int>())).Returns(Mock.Of<SeriesPortfolio>());

            _rowMaker = new EstimateRowsMaker(_portfolio, fund.Object, _returnDate, ReturnsPageMode.PriceLockDown, null, null);

            //when
            var attachments1 = _rowMaker.GetAllEstimateAttachments();
            var attachments2 = _rowMaker.GetAllEstimateAttachments();
            //then
            Assert.That(attachments1, Is.SameAs(attachments2));
        }


        private void PopulateProtfolioWithLockdown(int fundId, int lockdownEstimateSnapshotId, int lockdownSnapshotId)
        {
            const int investmentId = 1;
            var investment = new MockInvestment(investmentId) { FundID = fundId };
            _portfolio.Investments.Add(investment);
            var lockdown = new MockPortfolioLockdown(1) { LockdownDataEndDate = _returnDate };


            var lockdownPrice = new MockLockdownPrice(lockdown) { LockdownInvestmentId = investmentId, LockdownEstimateSnapshotId = lockdownEstimateSnapshotId };
            lockdownPrice.SetInvestment(investment);
            lockdown.LockdownPrices = new List<LockdownPrice> { lockdownPrice };

            lockdown.AddSnapshotEstimate(lockdownSnapshotId, new SnapshotEstimate());

            PortfolioLockdownCollectionLoaderHelper.InsertCollection(PORTFOLIO_ID, new PortfolioLockdownCollection(new CacheableList<PortfolioLockdown> { lockdown }));
        }

        private T GetEstimate<T>(int estimateId, double estimateReturn, CAmount marketValue, CQuantity estimateLockdownQuantity) where T : Estimate, new()
        {
            return new T
            {
                EstimateId = estimateId,
                EstimateReturn = estimateReturn,
                ParentData = new DataFund { DataPortfolioMV = marketValue },
                EstimateLockdownQuantity = estimateLockdownQuantity
            };
        }

        private void FillInvestment()
        {
            _portfolio.Investments.Add(new MockInvestment { FundID = FUND_CLASS_ID, Allocations = new List<Allocation> { new AllocationSubscription { Quantity = 100 } } });
        }

        private void InitializeLockdown()
        {
            MockResults.MockResultSingleton.SetResult("PortfolioLockDownDbRepository.SelectByOrganization", new Dictionary<int, List<IPortfolioLockdownData>>());
            var lockdown = new MockPortfolioLockdown(1) { LockdownDataEndDate = _returnDate };
            PortfolioLockdownCollectionLoaderHelper.InsertCollection(PORTFOLIO_ID, new PortfolioLockdownCollection(new CacheableList<PortfolioLockdown> { lockdown }));
        }
    }
}
