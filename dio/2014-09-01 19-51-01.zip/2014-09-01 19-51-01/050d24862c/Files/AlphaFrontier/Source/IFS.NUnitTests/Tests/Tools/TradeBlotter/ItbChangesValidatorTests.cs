﻿using System;
using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangesValidatorTests
    {
        [Test]
        public void TestValidateVerifyReviewedByWhenItIsNotEqualToConfirmedBy()
        {
            //given
            var changes = new RowChanges{{"Reviewed", "09/01/2014" }};
            var viewer = new ItbChangesViewer(changes);
            var validator = new ItbChangesValidator(viewer, 31231);
            var checklist = new TradeChecklist
            {
                ChecklistProperties = new ChecklistSubscription
                {
                    ControlAgreementConfirmed = new ChecklistItemDateTime { EnteredByUserId = 4574574, FieldValue = new DateTime(2014, 8, 12)}
                }
            };

            //when
            validator.Validate(checklist);

            //then
            Assert.That(!changes.ContainsKey("ReviewedColor"));
            Assert.That(!changes.ContainsKey("ReviewedTip"));
        }

        [Test]
        public void TestValidateVerifyReviewedByWhenItIsEqualToConfirmedBy()
        {
            //given
            var changes = new RowChanges { { "Reviewed", "09/01/2014" } };
            var viewer = new ItbChangesViewer(changes);
            var validator = new ItbChangesValidator(viewer, 31231);
            var checklist = new TradeChecklist
            {
                ChecklistProperties = new ChecklistSubscription
                {
                    ControlAgreementConfirmed = new ChecklistItemDateTime { EnteredByUserId = 31231, FieldValue = new DateTime(2014, 8, 12) }
                }
            };

            //when
            validator.Validate(checklist);

            //then
            Assert.AreEqual("255,255,255", changes["ReviewedColor"]);
            Assert.AreEqual("Cannot be reviewed by the same user who confirmed it.", changes["ReviewedTip"]);
        }

        [Test]
        public void TestValidateVerifyReviewedDateWhenItIsMoreThanConfirmedDate()
        {
            //given
            var changes = new RowChanges { { "Reviewed", "09/01/2014" } };
            var viewer = new ItbChangesViewer(changes);
            var validator = new ItbChangesValidator(viewer, 1);
            var checklist = new TradeChecklist
            {
                ChecklistProperties = new ChecklistSubscription
                {
                    ControlAgreementConfirmed = new ChecklistItemDateTime { FieldValue = new DateTime(2014,8,15) }
                }
            };

            //when
            validator.Validate(checklist);

            //then
            Assert.That(!changes.ContainsKey("ReviewedColor"));
            Assert.That(!changes.ContainsKey("ReviewedTip"));
        }

        [Test]
        public void TestValidateVerifyReviewedDateWhenItIsEqualToConfirmedDate()
        {
            //given
            var changes = new RowChanges { { "Reviewed", "09/01/2014" } };
            var viewer = new ItbChangesViewer(changes);
            var validator = new ItbChangesValidator(viewer, 1);
            var checklist = new TradeChecklist
            {
                ChecklistProperties = new ChecklistSubscription
                {
                    ControlAgreementConfirmed = new ChecklistItemDateTime { FieldValue = new DateTime(2014, 9, 1) }
                }
            };

            //when
            validator.Validate(checklist);

            //then
            Assert.That(!changes.ContainsKey("ReviewedColor"));
            Assert.That(!changes.ContainsKey("ReviewedTip"));
        }

        [Test]
        public void TestValidateVerifyReviewedDateWhenItIsLessThanConfirmedDate()
        {
            //given
            var changes = new RowChanges { { "Reviewed", "09/01/2014" } };
            var viewer = new ItbChangesViewer(changes);
            var validator = new ItbChangesValidator(viewer, 1);
            var checklist = new TradeChecklist
            {
                ChecklistProperties = new ChecklistSubscription
                {
                    ControlAgreementConfirmed = new ChecklistItemDateTime { FieldValue = new DateTime(2014, 9, 12) }
                }
            };

            //when
            validator.Validate(checklist);

            //then
            Assert.AreEqual("255,255,255", changes["ReviewedColor"]);
            Assert.AreEqual("Confirm date shound not be more than reviewed date.", changes["ReviewedTip"]);
        }
    }
}
