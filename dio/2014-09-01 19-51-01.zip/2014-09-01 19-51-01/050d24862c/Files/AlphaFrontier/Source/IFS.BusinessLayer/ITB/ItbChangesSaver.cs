﻿using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesSaver
    {
        public virtual void Save(TradeChecklist checklist)
        {
            throw new System.NotImplementedException();
        }
    }
}
