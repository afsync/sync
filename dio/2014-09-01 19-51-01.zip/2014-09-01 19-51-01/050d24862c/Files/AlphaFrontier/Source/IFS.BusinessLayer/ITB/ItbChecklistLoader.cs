﻿using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChecklistLoader
    {
        public virtual TradeChecklist GetById(int checklistId)
        {
            return TradeChecklist.GetById(checklistId);
        }
    }
}
