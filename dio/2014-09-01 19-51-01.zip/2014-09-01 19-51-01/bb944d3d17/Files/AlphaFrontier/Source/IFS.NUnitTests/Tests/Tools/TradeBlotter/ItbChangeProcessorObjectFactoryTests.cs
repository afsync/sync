﻿using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangeProcessorObjectFactoryTests
    {
        [Test]
        public void TestGetValidator()
        {
            //given
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            var factory = new ItbChangeProcessorObjectFactory();

            //when
            var result = factory.GetValidator(mockViewer.Object, It.IsAny<int>());

            //then
            Assert.IsNotNull(result);
        }

        [Test]
        public void TestGetViewer()
        {
            //given
            var changes = new RowChanges();
            var factory = new ItbChangeProcessorObjectFactory();

            //when
            var result = factory.GetViewer(changes);

            //then
            Assert.IsNotNull(result);
        }
    }
}
