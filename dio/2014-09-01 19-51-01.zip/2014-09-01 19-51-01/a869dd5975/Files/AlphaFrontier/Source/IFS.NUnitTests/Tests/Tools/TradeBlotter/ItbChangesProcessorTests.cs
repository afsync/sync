﻿using System.Collections.Generic;
using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangesProcessorTests
    {
        [Test]
        public void TestProcessForEmptyListOfGridChanges()
        {
            //given
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            var processor = new ItbChangesProcessor(mockObjectFactory.Object);
            
            //when
            processor.Process(new List<GridChanges>());

            //then
            mockObjectFactory.Verify(m => m.GetViewer(It.IsAny<RowChanges>()),Times.Never());
            mockObjectFactory.Verify(m => m.GetLoader(), Times.Never());
            mockObjectFactory.Verify(m => m.GetValidator(), Times.Never());
            mockObjectFactory.Verify(m => m.GetSaver(), Times.Never());
        }

        [Test]
        public void TestProcessForListOfOneGridChanges()
        {
            //given
            var mockLoader = new Mock<ItbChecklistLoader>();
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var gridChanges = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges }, 
                IO = new GridParams()
            };
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangesProcessor(mockObjectFactory.Object);

            //when
            processor.Process(new List<GridChanges>{gridChanges});

            //then
            mockObjectFactory.Verify(m => m.GetViewer(rowChanges), Times.Once());
            mockObjectFactory.Verify(m => m.GetLoader(), Times.Once());
            mockObjectFactory.Verify(m => m.GetValidator(), Times.Once());
            mockObjectFactory.Verify(m => m.GetSaver(), Times.Once());
        }

        [Test]
        public void TestProcessForListOfSomeGridChanges()
        {
            //given
            var mockLoader = new Mock<ItbChecklistLoader>();
            var mockValidator = new Mock<ItbChangesValidator>();
            var mockSaver = new Mock<ItbChangesSaver>();
            var rowChanges1 = new RowChanges {{"1", "2"}};
            var rowChanges2 = new RowChanges {{"3", "4"}};
            var mockViewer1 = new Mock<ItbChangesViewer>(rowChanges1);
            var mockViewer2 = new Mock<ItbChangesViewer>(rowChanges2);
            var gridChanges1 = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges1 }, IO = new GridParams { ChecklistId = 2}
            };
            var gridChanges2 = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges2 }, IO = new GridParams { ChecklistId = 3}
            };
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges1)).Returns(mockViewer1.Object);
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges2)).Returns(mockViewer2.Object);
            mockObjectFactory.Setup(f => f.GetLoader()).Returns(mockLoader.Object);
            mockObjectFactory.Setup(f => f.GetValidator()).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver()).Returns(mockSaver.Object);
            var processor = new ItbChangesProcessor(mockObjectFactory.Object);

            //when
            processor.Process(new List<GridChanges> { gridChanges1, gridChanges2 });

            //then
            mockObjectFactory.Verify(m => m.GetViewer(rowChanges1), Times.Once());
            mockObjectFactory.Verify(m => m.GetViewer(rowChanges2), Times.Once());
            mockObjectFactory.Verify(m => m.GetLoader(), Times.Exactly(2));
            mockObjectFactory.Verify(m => m.GetValidator(), Times.Exactly(2));
            mockObjectFactory.Verify(m => m.GetSaver(), Times.Exactly(2));
        }
    }
}
