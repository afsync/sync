﻿using System.Collections.Generic;
using System.Linq;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesProcessor
    {
        private readonly ItbChangeProcessorObjectFactory _factory;

        public ItbChangesProcessor(ItbChangeProcessorObjectFactory factory)
        {
            _factory = factory;
        }

        public List<GridChanges> Process(List<GridChanges> changes)
        {
            var processedChanges = changes.Select(ProcessGridChanges);
            return processedChanges.ToList();
        }

        private GridChanges ProcessGridChanges(GridChanges gridChanges)
        {
            var processor = new ItbChangeProcessor(_factory);
            var savedResult = processor.Process(gridChanges.Changes.First(), gridChanges.IO.ChecklistId);
            return new GridChanges { Changes = new List<RowChanges> { savedResult } };
        }
    }
}
