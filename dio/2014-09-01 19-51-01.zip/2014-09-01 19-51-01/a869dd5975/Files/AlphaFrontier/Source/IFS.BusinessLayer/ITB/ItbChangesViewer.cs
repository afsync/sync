﻿
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesViewer
    {
        private readonly RowChanges _changes;

        public ItbChangesViewer(RowChanges changes)
        {
            _changes = changes;
        }
    }
}
