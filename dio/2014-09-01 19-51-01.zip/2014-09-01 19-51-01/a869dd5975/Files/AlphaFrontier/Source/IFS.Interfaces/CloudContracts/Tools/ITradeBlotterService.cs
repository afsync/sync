﻿using System.Collections.Generic;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.Interfaces.CloudContracts.Tools
{
    public interface ITradeBlotterService
    {
        TradeBlotterPageData GetPageData(ItbPageParameters parameters, SessionData sessionData);
        XmlResult GenerateGrid(ItbPageParameters parameters, SessionData sessionData);
        FabricRequestResult<List<GridChanges>> ProcessGridChanges(List<GridChanges> gridChanges, SessionData sessionData);
    }
}
