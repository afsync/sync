﻿using System;
using System.Collections.Generic;

namespace IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter
{
    [Serializable]
    public class GridParams
    {
        public string GridId { get; set; }
        public int ChecklistId { get; set; }
    }

    [Serializable]
    public class GridChanges
    {
        public GridParams IO { get; set; }
        public List<RowChanges> Changes { get; set; }

        public GridChanges()
        {
            Changes = new List<RowChanges>();
        }
    }

    [Serializable]
    public class RowChanges : Dictionary<string, string> {  }
}
