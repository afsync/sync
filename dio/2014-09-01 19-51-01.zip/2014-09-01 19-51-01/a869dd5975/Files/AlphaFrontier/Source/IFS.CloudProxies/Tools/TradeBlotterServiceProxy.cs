﻿using System.Collections.Generic;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using IFS.Interfaces.CloudContracts.Tools;

namespace IFS.CloudProxies.Tools
{
    public class TradeBlotterServiceProxy : CloudProxyBase, ITradeBlotterService
    {
        private const string GET_PAGE_DATA = "TradeBlotterService_GetPageData";
        private const string GENERATE_GRID = "TradeBlotterService_GenerateGrid";
        private const string PROCESS_GRID_CHANGES = "TradeBlotterService_ProcessGridChanges";
        
        public TradeBlotterPageData GetPageData(ItbPageParameters parameters, SessionData sessionData)
        {
            return Execute<TradeBlotterPageData>(parameters, sessionData, GET_PAGE_DATA);
        }

        public XmlResult GenerateGrid(ItbPageParameters parameters, SessionData sessionData)
        {
            return Execute<XmlResult>(parameters, sessionData, GENERATE_GRID);
        }

        public FabricRequestResult<List<GridChanges>> ProcessGridChanges(List<GridChanges> parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<List<GridChanges>>>(parameters, sessionData, PROCESS_GRID_CHANGES);
        }
    }
}
