﻿using System.Collections.Generic;
using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbGridChangesProcessorTests
    {
        [Test]
        public void TestProcessForEmptyListOfGridChanges()
        {
            //given
            var changeProcessor = new Mock<ItbChangeProcessor>(null,0);
            var processor = new ItbGridChangesProcessor(changeProcessor.Object);
            
            //when
            var result =  processor.Process(new List<GridChanges>());

            //then
            Assert.That(result.Count, Is.EqualTo(0));
            changeProcessor.Verify(m => m.Process(It.IsAny<RowChanges>(), It.IsAny<int>()), Times.Never());
        }

        [Test]
        public void TestProcessForListOfOneGridChanges()
        {
            //given
            var rowChanges = new RowChanges();
            var gridChanges = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges },
                IO = new GridParams { ChecklistId = 3, GridId = "grid3"}
            };
            var resultChanges = new RowChanges();
            var changeProcessor = new Mock<ItbChangeProcessor>(null, 0);
            changeProcessor.Setup(f => f.Process(rowChanges, 3)).Returns(resultChanges);
            var processor = new ItbGridChangesProcessor(changeProcessor.Object);

            //when
            var result = processor.Process(new List<GridChanges>{gridChanges});

            //then
            Assert.That(result.Count, Is.EqualTo(1));
            Assert.That(result[0].Changes.Count, Is.EqualTo(1));
            Assert.That(result[0].Changes[0], Is.SameAs(resultChanges));
            Assert.That(result[0].IO.ChecklistId, Is.EqualTo(3));
            Assert.That(result[0].IO.GridId, Is.EqualTo("grid3"));
            changeProcessor.Verify(m => m.Process(It.IsAny<RowChanges>(), It.IsAny<int>()), Times.Once());
        }

        [Test]
        public void TestProcessForListOfSomeGridChanges()
        {
            //given
            var rowChanges1 = new RowChanges { { "1", "2" } };
            var gridChanges1 = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges1 },
                IO = new GridParams { ChecklistId = 3, GridId = "grid3" }
            };
            var rowChanges2 = new RowChanges { { "3", "4" } };
            var gridChanges2 = new GridChanges
            {
                Changes = new List<RowChanges> { rowChanges2 },
                IO = new GridParams { ChecklistId = 10, GridId = "grid4" }
            };
            var resultChanges1 = new RowChanges();
            var resultChanges2 = new RowChanges();
            var changeProcessor = new Mock<ItbChangeProcessor>(null, 0);
            changeProcessor.Setup(f => f.Process(rowChanges1, 3)).Returns(resultChanges1);
            changeProcessor.Setup(f => f.Process(rowChanges2, 10)).Returns(resultChanges2);
            var processor = new ItbGridChangesProcessor(changeProcessor.Object);

            //when
            var result = processor.Process(new List<GridChanges> { gridChanges1, gridChanges2 });

            //then
            Assert.That(result.Count, Is.EqualTo(2));
            Assert.That(result[0].Changes.Count, Is.EqualTo(1));
            Assert.That(result[0].Changes[0], Is.SameAs(resultChanges1));
            Assert.That(result[1].Changes.Count, Is.EqualTo(1));
            Assert.That(result[1].Changes[0], Is.SameAs(resultChanges2));
        }
    }
}
