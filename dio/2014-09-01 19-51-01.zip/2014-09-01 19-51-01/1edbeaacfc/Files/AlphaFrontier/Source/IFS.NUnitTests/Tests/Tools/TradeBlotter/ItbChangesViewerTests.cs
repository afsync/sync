﻿using System;
using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangesViewerTests
    {
        [Test]
        public void TestGetReviewedDateWhenDateIsNotChanged()
        {
            //given
            var changes = new RowChanges();
            var viewer = new ItbChangesViewer(changes);

            //when
            var result = viewer.GetReviewedDate();

            //then
            Assert.AreEqual(DateTime.MinValue, result);
        }

        [Test]
        public void TestGetReviewedDateWhenDateIsChanged()
        {
            //given
            var changes = new RowChanges{{"Reviewed","09/01/2014"}};
            var viewer = new ItbChangesViewer(changes);

            //when
            var result = viewer.GetReviewedDate();

            //then
            Assert.AreEqual(new DateTime(2014,9,1), result);
        }

        [Test]
        public void TestSetReviewedDateValidationError()
        {
            //given
            var changes = new RowChanges();
            var viewer = new ItbChangesViewer(changes);

            //when
            viewer.SetReviewedDateValidationError("error message");
            var result = viewer.GetChanges();

            //then
            Assert.AreEqual("255,255,255", result["ReviewedColor"]);
            Assert.AreEqual("error message", result["ReviewedTip"]);
        }

        [Test]
        public void TestSetReviewedDateValidationErrorWithSomeErrors()
        {
            //given
            var changes = new RowChanges();
            var viewer = new ItbChangesViewer(changes);

            //when
            viewer.SetReviewedDateValidationError("error message");
            viewer.SetReviewedDateValidationError("error message 2");
            var result = viewer.GetChanges();

            //then
            Assert.AreEqual("error message\r\nerror message 2", result["ReviewedTip"]);
        }
    }
}
