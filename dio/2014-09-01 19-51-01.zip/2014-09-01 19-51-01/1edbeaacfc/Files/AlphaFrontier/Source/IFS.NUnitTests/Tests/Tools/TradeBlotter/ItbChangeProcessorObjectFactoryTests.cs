﻿using IFS.BusinessLayer.Itb;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangeProcessorObjectFactoryTests
    {
        [Test]
        public void TestGetValidator()
        {
            //given
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<ItbChangesViewer>());
            var factory = new ItbChangeProcessorObjectFactory();

            //when
            var result = factory.GetValidator(mockViewer.Object, It.IsAny<int>());

            //then
            Assert.IsNotNull(result);
        }
    }
}
