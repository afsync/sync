﻿using System;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesViewer
    {
        private readonly RowChanges _changes;

        public ItbChangesViewer(RowChanges changes)
        {
            _changes = changes;
        }

        public RowChanges GetChanges()
        {
            return _changes;
        }

        public DateTime GetReviewedDate()
        {
            var reviewedDateString = GetFieldValue("Reviewed");
            return string.IsNullOrEmpty(reviewedDateString) ? DateTime.MinValue : DateTime.Parse(_changes["Reviewed"]);
        }

        public void SetReviewedDateValidationError(string validationMessage)
        {
            _changes["ReviewedColor"] = "255,255,255";
            AddValidationMessage(validationMessage, "ReviewedTip");
        }

        private void AddValidationMessage(string validationMessage, string fieldKey)
        {
            var tip = GetFieldValue(fieldKey);
            if (!string.IsNullOrEmpty(tip))
                _changes[fieldKey] += "\r\n" + validationMessage;
            else
                _changes[fieldKey] = validationMessage;
        }

        private string GetFieldValue(string fieldKey)
        {
            return _changes.ContainsKey(fieldKey) ? _changes[fieldKey] : string.Empty;
        }
    }
}
