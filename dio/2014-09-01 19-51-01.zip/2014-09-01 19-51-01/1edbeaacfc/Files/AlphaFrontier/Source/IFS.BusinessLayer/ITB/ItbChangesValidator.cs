﻿using System;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesValidator
    {
        private readonly int _userId;
        private readonly ItbChangesViewer _viewer;

        public ItbChangesValidator(ItbChangesViewer viewer, int userId)
        {
            _userId = userId;
            _viewer = viewer;
        }

        public virtual void Validate(ChecklistBase checklist)
        {
            ValidateReviewedDate(checklist);
        }

        private void ValidateReviewedDate(ChecklistBase checklist)
        {
            var reviewedDate = _viewer.GetReviewedDate();
            if (reviewedDate !=  DateTime.MinValue)
            {
                ValidateReviewedDateValue(checklist, reviewedDate);
                ValidateReviewedDateUser(checklist);
            }
        }

        private void ValidateReviewedDateValue(ChecklistBase checklist, DateTime reviewedDate)
        {
            if (checklist.ControlAgreementConfirmed.FieldValue > reviewedDate)
                _viewer.SetReviewedDateValidationError("Confirm date shound not be more than reviewed date.");
        }

        private void ValidateReviewedDateUser(ChecklistBase checklist)
        {
            if (checklist.ControlAgreementConfirmed.EnteredByUserId == _userId)
                _viewer.SetReviewedDateValidationError("Cannot be reviewed by the same user who confirmed it.");
        }
    }
}
