﻿using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangeProcessor
    {
        private readonly ItbChangeProcessorObjectFactory _factory;
        private readonly int _userId;

        public ItbChangeProcessor(ItbChangeProcessorObjectFactory factory, int userId)
        {
            _factory = factory;
            _userId = userId;
        }

        public virtual RowChanges Process(RowChanges changes, int checklistId)
        {
            var viewer = _factory.GetViewer(changes);
            var checklist = GetChecklist(checklistId);
            ValidateChanges(viewer, checklist);
            SaveChanges(viewer, checklist);
            return GetSavedChanges(viewer, checklist);
        }

        private ChecklistBase GetChecklist(int checklistId)
        {
            var loader = _factory.GetLoader();
            return loader.GetById(checklistId);
        }


        private RowChanges GetSavedChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            return new RowChanges();
        }

        private void SaveChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            _factory.GetSaver().Save(checklist);
        }

        private void ValidateChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            _factory.GetValidator(viewer, _userId).Validate(checklist);
        }
    }
}
