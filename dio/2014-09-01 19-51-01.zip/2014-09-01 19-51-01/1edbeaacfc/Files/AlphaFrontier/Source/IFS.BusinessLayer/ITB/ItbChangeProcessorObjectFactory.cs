﻿using System;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangeProcessorObjectFactory
    {
        public virtual ItbChangesViewer GetViewer(RowChanges changes)
        {
            throw new NotImplementedException();
        }

        public virtual ItbChecklistLoader GetLoader()
        {
            throw new NotImplementedException();
        }

        public virtual ItbChangesSaver GetSaver()
        {
            throw new NotImplementedException();
        }

        public virtual ItbChangesValidator GetValidator(ItbChangesViewer viewer, int userId)
        {
            return new ItbChangesValidator(viewer, userId);
        }
    }
}
