﻿using System;
using System.Linq;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangesViewer
    {
        private readonly RowChanges _changes;

        public ItbChangesViewer(RowChanges changes)
        {
            _changes = changes;
        }

        public virtual int GetChecklistId()
        {
            return Convert.ToInt32(_changes.Changes["id"].Split('$').LastOrDefault());
        }

    }
}
