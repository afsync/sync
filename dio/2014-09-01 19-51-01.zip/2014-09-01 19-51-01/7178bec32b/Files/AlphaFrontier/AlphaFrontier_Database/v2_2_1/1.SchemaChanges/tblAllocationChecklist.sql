IF (NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tblAllocationChecklist'))
	BEGIN
		CREATE TABLE tblAllocationChecklist(
			ChecklistId int not null, 
			AllocationId int not null, 
			ChecklistType int not null, 
			CreatedDate datetime null,
			CreatedBy int null,
			ModifiedDate datetime null,
			ModifiedBy int null,
			CONSTRAINT [PK_tblAllocationChecklist] PRIMARY KEY CLUSTERED 
			(
				[ChecklistId] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END