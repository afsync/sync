IF (NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tblControlAgreementSection'))
	BEGIN
		CREATE TABLE tblControlAgreementSection(
			SectionId int not null, 
			ChecklistId int null,
			Comments nvarchar(max) null,
			CommentsEnteredBy int null,
			Confirmed datetime null,
			ConfirmedBy int null,
			Reviewed datetime null,
			ReviewedBy int null
			CONSTRAINT [PK_tblControlAgreementSection] PRIMARY KEY CLUSTERED 
			(
				[SectionId] ASC
			)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
		) ON [PRIMARY]
	END