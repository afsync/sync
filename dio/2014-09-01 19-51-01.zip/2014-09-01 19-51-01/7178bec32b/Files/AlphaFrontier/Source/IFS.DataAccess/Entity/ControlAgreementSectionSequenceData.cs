﻿using System.Data.Linq.Mapping;
using IFS.Interfaces.Entity;

namespace IFS.DataAccess.Entity
{
    [Table(Name = "tblControlAgreementSectionSequence")]
    public class ControlAgreementSectionSequenceData : IEntityObjectWithId
    {
        [Column(Name = "SectionSequenceId", IsDbGenerated = true, IsPrimaryKey = true)]
        public int Id { get; set; }
    }
}
