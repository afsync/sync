﻿using System.Data.Linq.Mapping;
using IFS.Interfaces.Entity;

namespace IFS.DataAccess.Entity
{
    [Table(Name = "tblAllocationChecklistSequence")]
    public class AllocationChecklistSequenceData : IEntityObjectWithId
    {
        [Column(Name = "ChecklistSequenceId", IsDbGenerated = true, IsPrimaryKey = true)]
        public int Id { get; set; }
    }
}
