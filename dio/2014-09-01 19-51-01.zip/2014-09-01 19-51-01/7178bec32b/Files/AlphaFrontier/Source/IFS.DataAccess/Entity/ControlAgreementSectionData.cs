﻿using System;
using System.Data.Linq.Mapping;
using IFS.Interfaces.Entity;

namespace IFS.DataAccess.Entity
{
    [Table(Name = "tblControlAgreementSection")]
    public class ControlAgreementSectionData : IControlAgreementSectionData
    {
        [Column(Name = "SectionId", IsPrimaryKey = true)]
        public int Id { get; set; }

        [Column(Name = "ChecklistId")]
        public int ChecklistId { get; set; }

        [Column(Name = "Comments")]
        public string Comments { get; set; }

        [Column(Name = "CommentsEnteredBy")]
        public int CommentsEnteredBy { get; set; }

        [Column(Name = "Confirmed")]
        public DateTime Confirmed { get; set; }

        [Column(Name = "ConfirmedBy")]
        public int ConfirmedBy { get; set; }

        [Column(Name = "Reviewed")]
        public DateTime Reviewed { get; set; }

        [Column(Name = "ReviewedBy")]
        public int ReviewedBy { get; set; }
    }
}
