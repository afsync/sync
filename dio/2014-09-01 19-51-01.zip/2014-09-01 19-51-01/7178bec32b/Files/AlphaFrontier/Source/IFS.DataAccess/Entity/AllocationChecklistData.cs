﻿using System;
using System.Data.Linq.Mapping;
using IFS.Interfaces.Entity;

namespace IFS.DataAccess.Entity
{
    [Table(Name = "tblAllocationChecklist")]
    public class AllocationChecklistData :  IAllocationChecklistData
    {
        [Column(Name = "ChecklistId", IsPrimaryKey = true)]
        public int Id { get; set; }

        [Column(Name = "AllocationId")]
        public int AllocationId { get; set; }

        [Column(Name = "ChecklistType")]
        public int ChecklistType { get; set; }

        [Column(Name = "CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [Column(Name = "CreatedBy")]
        public int CreatedBy { get; set; }

        [Column(Name = "ModifiedDate")]
        public DateTime ModifiedDate { get; set; }

        [Column(Name = "ModifiedBy")]
        public int ModifiedBy { get; set; }
    }
}
