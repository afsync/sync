using System.Collections.Generic;
using IFS.Interfaces.Entity;

namespace IFS.Interfaces.DbRepository
{
    public interface IChecklistSectionsDbRepository: IDbRepository
    {
        IControlAgreementSectionData GetControlAgreementSection(int checklistId);
        IEnumerable<IControlAgreementSectionData> GetControlAgreementSections(List<int> checklistIds);
    }
}
