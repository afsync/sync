using IFS.Interfaces.DbRepository;
using Spring.Context;
using Spring.Context.Support;

namespace IFS.Interfaces.Factories
{
    public class DbRepositoryFactory
    {
        public static ISeriesDbRepository GetSeriesDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISeriesDbRepository)ctx.GetObject("SeriesDbRepository");
        }

        public static ICompanyDbRepository GetCompanyDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICompanyDbRepository)ctx.GetObject("CompanyDbRepository");
        }

        public static IWireDetailsDbRepository GetWireDetailsDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IWireDetailsDbRepository)ctx.GetObject("WireDetailsDbRepository");
        }

        public static IUserDbRepository GetUserDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IUserDbRepository)ctx.GetObject("UserDbRepository");
        }

        public static IGlsImportDataDbRepository GetGlsImportDataDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGlsImportDataDbRepository)ctx.GetObject("GlsImportDataDbRepository");
        }
        public static IIssCashDbRepository GetIssCashDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IIssCashDbRepository)ctx.GetObject("IssCashDbRepository");
        }

        public static IOrganizationDataDbRepository GetOrganizationDataDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IOrganizationDataDbRepository)ctx.GetObject("OrganizationDataDbRepository");
        }

        public static IPortfolioLockDownDbRepository GetPortfolioLockDownDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IPortfolioLockDownDbRepository)ctx.GetObject("PortfolioLockDownDbRepository");
        }
        public static IBenchmarkAssignmentDbRepository GetBenchmarkAssignmentDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IBenchmarkAssignmentDbRepository)ctx.GetObject("BenchmarkAssignmentDbRepository");
        }
        public static IClientBenchmarkDbRepository GetClientBenchmarkDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IClientBenchmarkDbRepository)ctx.GetObject("ClientBenchmarkDbRepository");
        }
        public static IMailTemplateDbRepository GetMailTemplateDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IMailTemplateDbRepository)ctx.GetObject("MailTemplateDbRepository");
        }
        public static IUnderlyingFundDbRepository GetUnderlyingFundDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IUnderlyingFundDbRepository)ctx.GetObject("UnderlyingFundDbRepository");
        }
        public static ISecurityPricingListDbRepository GetSecurityPricingListDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISecurityPricingListDbRepository)ctx.GetObject("SecurityPricingListDbRepository");
        }
        public static ITransactionViewDbRepository GetTransactionViewDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ITransactionViewDbRepository)ctx.GetObject("TransactionViewDbRepository");
        }
        public static ISecurityPricingCommentsDbRepository GetPricingCommentsDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISecurityPricingCommentsDbRepository)ctx.GetObject("SecurityPricingCommentsDbRepository");
        }

        public static IEnumValueDbRepository GetEnumValueDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IEnumValueDbRepository)ctx.GetObject("EnumValueDbRepository");
        }

        public static IUserOrganizationLinkDbRepository GetUserOrganizationLinkDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IUserOrganizationLinkDbRepository)ctx.GetObject("UserOrganizationLinkDbRepository");
        }
  
        public static ICurrencyDbRepository GetCurrencyDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICurrencyDbRepository)ctx.GetObject("CurrencyDbRepository");
        }
        public static ICountryDbRepository GetCountryDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICountryDbRepository)ctx.GetObject("CountryDbRepository");
        }
        public static ICustomAumDbRepository GetCustomAumDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICustomAumDbRepository)ctx.GetObject("CustomAumDbRepository");
        }
        public virtual ICorporateActionDbRepository GetCorporateActionDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICorporateActionDbRepository)ctx.GetObject("CorporateActionDbRepository");
        }
        public static ICorporateActFundXrefDbRepository GetCorporateActFundXrefDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICorporateActFundXrefDbRepository)ctx.GetObject("CorporateActFundXrefDbRepository");
        }
        public static IDataSnapshotDbRepository GetDataSnapshotDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IDataSnapshotDbRepository)ctx.GetObject("DataSnapshotDbRepository");
        }
        public static ITransactionDbRepository GetTransactionDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ITransactionDbRepository)ctx.GetObject("TransactionDbRepository");
        }
        public static IChecklistDbRepository GetChecklistDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IChecklistDbRepository)ctx.GetObject("ChecklistDbRepository");
        }
        public static IDbMaintenanceDbRepository GetDbMaintenanceDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IDbMaintenanceDbRepository)ctx.GetObject("DbMaintenanceDbRepository");
        }
        public static ILockedTransactionXrefDbRepository GetLockedTransactionXrefDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ILockedTransactionXrefDbRepository)ctx.GetObject("LockedTransactionXrefDbRepository");
        }

        public static IChecklistLinkDbRepository GetChecklistLinkDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IChecklistLinkDbRepository)ctx.GetObject("ChecklistLinkDbRepository");
        }
        public static IGlobalContactsViewDbRepository GetGlobalContactsViewDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGlobalContactsViewDbRepository)ctx.GetObject("GlobalContactsViewDbRepository");
        }

        public virtual IAllocationDbRepository GetAllocationDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAllocationDbRepository)ctx.GetObject("AllocationDbRepository");
        }

        public static IAllocationSnapshotDbRepository GetAllocationSnapshotDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAllocationSnapshotDbRepository)ctx.GetObject("AllocationSnapshotDbRepository");
        }

        public virtual IAvgActualExchangeInDbRepository GetAvgActualExchangeInDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAvgActualExchangeInDbRepository)ctx.GetObject("AvgActualExchangeInDbRepository");
        }

        public static IAvgActualExchangeInSnapshotDbRepository GetAvgActualExchangeInSnapshotDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAvgActualExchangeInSnapshotDbRepository)ctx.GetObject("AvgActualExchangeInSnapshotDbRepository");
        }

        public static ITradeOrderDbRepository GetTradeOrderDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ITradeOrderDbRepository)ctx.GetObject("TradeOrderDbRepository");
        }
        public static IRedemptionLotDbRepository GetRedemptionLotDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IRedemptionLotDbRepository)ctx.GetObject("RedemptionLotDbRepository");
        }
        public static IRedemptionLotDbRepository GetAvgActualRedemptionLotDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IRedemptionLotDbRepository)ctx.GetObject("AvgActualRedemptionLotDbRepository");
        }
        public static IAccessDataDbRepository GetAccessDataDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAccessDataDbRepository)ctx.GetObject("AccessDataDbRepository");
        }
        public static IRateDbRepository GetRateDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IRateDbRepository)ctx.GetObject("RateDbRepository");
        }
        public static ILayoutDbRepository GetLayoutDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ILayoutDbRepository)ctx.GetObject("LayoutDbRepository");
        }
        public static ILayoutSharesDbRepository GetLayoutSharesDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ILayoutSharesDbRepository)ctx.GetObject("LayoutSharesDbRepository");
        }
        public static IAttributeDetailsDbRepository GetAttributeDetailsDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAttributeDetailsDbRepository)ctx.GetObject("AttributeDetailsDbRepository");
        }
        public static ICacheUpdateNotificationDbRepository GetCacheUpdateNotificationDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICacheUpdateNotificationDbRepository)ctx.GetObject("CacheUpdateNotificationDbRepository");
        }
        public static IDueEstimateAndFinalsCommentDbRepository GetDueEstimateAndFinalsCommentDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IDueEstimateAndFinalsCommentDbRepository)ctx.GetObject("DueEstimateAndFinalsCommentDbRepository");
        }
        public static IPvtEqtyAllocationBreakupDbRepository GetPvtEqtyAllocationBreakupDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IPvtEqtyAllocationBreakupDbRepository)ctx.GetObject("PvtEqtyAllocationBreakupDbRepository");
        }

        public static IFileCafmDbRepository GetFileCafmDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IFileCafmDbRepository) ctx.GetObject("FileCafmDbRepository");      
        }
        public static ITradeOrderPendingDbRepository GetPendingTradeOrderDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ITradeOrderPendingDbRepository)ctx.GetObject("PendingTradeOrderDbRepository");
        }
        public static IConfigDataDbRepository GetConfigDataDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IConfigDataDbRepository)ctx.GetObject("ConfigDataDbRepository");
        }
        public static IWfDeletedAllocationDbRepository GetWfDeletedAllocationDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IWfDeletedAllocationDbRepository)ctx.GetObject("WfDeletedAllocationDbRepository");
        }
        public static IClientCreditTermsDbRepository GetClientCreditTermsDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IClientCreditTermsDbRepository)ctx.GetObject("ClientCreditTermsDbRepository");
        }
        public static IPortfolioGroupDbRepository GetPortfolioGroupDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IPortfolioGroupDbRepository)ctx.GetObject("PortfolioGroupDbRepository");
        }
        public static ISnapshotEstimateDbRepository GetSnapshotEstimateDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISnapshotEstimateDbRepository)ctx.GetObject("SnapshotEstimateDbRepository");
        }
        public static IContactDbRepository GetContactDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IContactDbRepository)ctx.GetObject("ContactDbRepository");
        }

        public static IPortfolioNavInformationDbRepository GetPortfolioNavInformationDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IPortfolioNavInformationDbRepository)ctx.GetObject("PortfolioNavInformationDbRepository");
        }
        public static IPortfolioInvestorActivityDbRepository GetPortfolioInvestorActivityDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IPortfolioInvestorActivityDbRepository)ctx.GetObject("PortfolioInvestorActivityDbRepository");
        }
        public static IGsmFundOfficeContactDbRepository GetGsmFundOfficeContactDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmFundOfficeContactDbRepository)ctx.GetObject("GsmFundOfficeContactDbRepository");
        }
        public static IGsmFundLinkDbRepository GetGsmFundLinkDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmFundLinkDbRepository)ctx.GetObject("GsmFundLinkDbRepository");
        }

        public static IGsmCompanyDbRepository GetGsmCompanyDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmCompanyDbRepository)ctx.GetObject("GsmCompanyDbRepository");
        }
        public static IGsmFundOfficeDbRepository GetGsmFundOfficeDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmFundOfficeDbRepository)ctx.GetObject("GsmFundOfficeDbRepository");
        }
        public static ICompanyGroupDbRepository GetCompanyGroupDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ICompanyGroupDbRepository)ctx.GetObject("CompanyGroupDbRepository");
        }

        public static IGsmContactPersonDbRepository GetGsmContactPersonDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmContactPersonDbRepository)ctx.GetObject("GsmContactPersonDbRepository");
        }
        public virtual IInvestmentDbRepository GetInvestmentDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IInvestmentDbRepository)ctx.GetObject("InvestmentDbRepository");
        }
        public virtual ILiquidityLayoutDbRepository GetLiquidityLayoutDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ILiquidityLayoutDbRepository)ctx.GetObject("LiquidityLayoutDbRepository");
        }
        public static IGsmOfficeDbRepository GetGsmOfficeDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IGsmOfficeDbRepository)ctx.GetObject("GsmOfficeDbRepository");
        }
        public static IContactPersonOfficeDbRepository GetContactPersonOfficeDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IContactPersonOfficeDbRepository)ctx.GetObject("ContactPersonOfficeDbRepository");
        }
        public static IEstimateAttachmentDbRepository GetEstimateAttachmentDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IEstimateAttachmentDbRepository)ctx.GetObject("EstimateAttachmentDbRepository");
        }
        public virtual IAvgActualExchangeDbRepository GetAvgActualExchangeDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAvgActualExchangeDbRepository)ctx.GetObject("AvgActualExchangeDbRepository");
        }
        public static IEstimateDbRepository GetEstimateDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IEstimateDbRepository)ctx.GetObject("EstimateDbRepository");
        }

        public static ISecurityPricingDbRepository GetSecurityPricingDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISecurityPricingDbRepository)ctx.GetObject("SecurityPricingDbRepository");
        }
        public virtual ITradeExecutionDbRepository GetTradeExecutionDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (ITradeExecutionDbRepository)ctx.GetObject("TradeExecutionDbRepository");
        }
        public virtual IExchangeDbRepository GetExchangeDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IExchangeDbRepository)ctx.GetObject("ExchangeDbRepository");
        }
        public virtual IAllocationCashDetailsDbRepository GetAllocationCashDetailsDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAllocationCashDetailsDbRepository)ctx.GetObject("AllocationCashDetailsDbRepository");
        }
        public virtual IRedemptionHoldbackPaymentDbRepository GetRedemptionHoldbackPaymentDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (IRedemptionHoldbackPaymentDbRepository)ctx.GetObject("RedemptionHoldbackPaymentDbRepository");
        }

        public static ISnapshotDbRepository GetSnapshotDbRepository()
        {
            IApplicationContext ctx = ContextRegistry.GetContext();
            return (ISnapshotDbRepository)ctx.GetObject("SnapshotDbRepository");
        }
        public static IAllocationChecklistDbRepository GetAllocationChecklistDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IAllocationChecklistDbRepository)ctx.GetObject("AllocationChecklistDbRepository");
        }
        public static IChecklistSectionsDbRepository GetChecklistSectionsDbRepository()
        {
        	IApplicationContext ctx = ContextRegistry.GetContext();
            return (IChecklistSectionsDbRepository)ctx.GetObject("ChecklistSectionsDbRepository");
        }
    }
}
