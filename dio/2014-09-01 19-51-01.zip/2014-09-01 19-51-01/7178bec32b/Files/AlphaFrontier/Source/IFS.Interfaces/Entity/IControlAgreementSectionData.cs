﻿using System;

namespace IFS.Interfaces.Entity
{
    public interface IControlAgreementSectionData : IEntityObjectWithId
    {
        int ChecklistId { get; set; }
        string Comments { get; set; }
        int CommentsEnteredBy { get; set; }
        DateTime Confirmed { get; set; }
        int ConfirmedBy { get; set; }
        DateTime Reviewed { get; set; }
        int ReviewedBy { get; set; }
    }

}
