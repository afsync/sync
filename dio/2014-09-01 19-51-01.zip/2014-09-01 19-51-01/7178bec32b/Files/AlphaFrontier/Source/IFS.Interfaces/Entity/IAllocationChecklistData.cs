﻿using System;

namespace IFS.Interfaces.Entity
{
    public interface IAllocationChecklistData : IEntityObjectWithId
    {
        int AllocationId { get; set; }
        int ChecklistType { get; set; }
        DateTime CreatedDate { get; set; }
        int CreatedBy { get; set; }
        DateTime ModifiedDate { get; set; }
        int ModifiedBy { get; set; } 
    }
}
