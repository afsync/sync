using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.Interfaces.Entity;

namespace IFS.Interfaces.DbRepository
{
    public interface IAllocationChecklistDbRepository: IDbRepository
    {
        IAllocationChecklistData GetAllocationChecklist(int allocationId);
        IEnumerable<IAllocationChecklistData> GetAllocationChecklists(List<int> allocationIds);
    }
}
