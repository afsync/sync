using System.Collections.Generic;
using System.Linq;
using IFS.DataAccess.Entity;
using IFS.Interfaces.DbRepository;
using IFS.Interfaces.Entity;

namespace IFS.DbRepository
{
    public class ChecklistSectionsDbRepository: DbRepository, IChecklistSectionsDbRepository
    {
        public IControlAgreementSectionData GetControlAgreementSection(int checklistId)
        {
            return Context.GetTable<ControlAgreementSectionData>().FirstOrDefault(p =>  p.ChecklistId == checklistId);
        }

        public IEnumerable<IControlAgreementSectionData> GetControlAgreementSections(List<int> checklistIds)
        {
            return Context.GetTable<ControlAgreementSectionData>().Where(p => checklistIds.Contains(p.ChecklistId)).ToList();
        }
    }
}
