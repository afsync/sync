using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.DataAccess.Entity;
using IFS.Interfaces.DbRepository;
using IFS.Interfaces.Entity;

namespace IFS.DbRepository
{
    public class AllocationChecklistDbRepository : DbRepository, IAllocationChecklistDbRepository
    {
        public IAllocationChecklistData GetAllocationChecklist(int allocationId)
        {
            return Context.GetTable<AllocationChecklistData>().SingleOrDefault(p => p.AllocationId == allocationId);
        }

        public IEnumerable<IAllocationChecklistData> GetAllocationChecklists(List<int> allocationIds)
        {
            return Context.GetTable<AllocationChecklistData>().Where(p => allocationIds.Contains(p.AllocationId)).ToList();
        }
    }
}
