﻿using System;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Repository.Checklists;
using IFS.DataAccess.Entity;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ChecklistTests
{
    [TestFixture]
    public class ControlAgreementSectionMapperTests
    {
        [Test]
        public void TestGetControlAgreementSection()
        {
            // Given
            var dataObject = new ControlAgreementSectionData()
            {
                Id = 1,
                ChecklistId = 2,
                Comments = "Text",
                CommentsEnteredBy = 3,
                Confirmed = new DateTime(2010, 1, 1),
                ConfirmedBy = 4,
                Reviewed = new DateTime(2011, 1, 1),
                ReviewedBy = 5
            };

            var mapper = new ControlAgreementSectionMapper();

            //When
            var immutableObject = mapper.GetControlAgreementSection(dataObject);

            //Then
            //Then
            Assert.That(immutableObject.Id, Is.EqualTo(1));
            Assert.That(immutableObject.ChecklistId, Is.EqualTo(2));
            Assert.That(immutableObject.Comments, Is.EqualTo("Text"));
            Assert.That(immutableObject.CommentsEnteredBy, Is.EqualTo(3));
            Assert.That(immutableObject.Confirmed, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(immutableObject.ConfirmedBy, Is.EqualTo(4));
            Assert.That(immutableObject.Reviewed, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(immutableObject.ReviewedBy, Is.EqualTo(5));
        }

        [Test]
        public void TestGetEntityData()
        {
            // Given
            var dataObject = new ControlAgreementSection(1, 2, "Text",3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            var mapper = new ControlAgreementSectionMapper();

            //When
            var entityData = mapper.GetEntityData(dataObject);

            //Then
            Assert.That(entityData.Id, Is.EqualTo(1));
            Assert.That(entityData.ChecklistId, Is.EqualTo(2));
            Assert.That(entityData.Comments, Is.EqualTo("Text"));
            Assert.That(entityData.CommentsEnteredBy, Is.EqualTo(3));
            Assert.That(entityData.Confirmed, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(entityData.ConfirmedBy, Is.EqualTo(4));
            Assert.That(entityData.Reviewed, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(entityData.ReviewedBy, Is.EqualTo(5));
        }
    }
}
