﻿using System;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Repository.Checklists;
using IFS.DataAccess.Entity;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ChecklistTests
{
    [TestFixture]
    public class AllocationChecklistMapperTest
    {
        [Test]
        public void TestGetAllocationChecklist()
        {
            // Given
            var dataObject = new AllocationChecklistData()
                                 {
                                     Id = 1,
                                     AllocationId = 2,
                                     ChecklistType = 3,
                                     CreatedDate = new DateTime(2010, 1, 1),
                                     CreatedBy = 4,
                                     ModifiedDate = new DateTime(2011, 1, 1),
                                     ModifiedBy = 5
                                 };

            var mapper = new AllocationChecklistMapper();

            //When
            var immutableObject = mapper.GetAllocationChecklist(dataObject);

            //Then
            //Then
            Assert.That(immutableObject.Id, Is.EqualTo(1));
            Assert.That(immutableObject.AllocationId, Is.EqualTo(2));
            Assert.That(immutableObject.ChecklistType, Is.EqualTo(3));
            Assert.That(immutableObject.CreatedDate, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(immutableObject.CreatedBy, Is.EqualTo(4));
            Assert.That(immutableObject.ModifiedDate, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(immutableObject.ModifiedBy, Is.EqualTo(5));
        }

        [Test]
        public void TestGetEntityData()
        {
            // Given
            var dataObject = new AllocationChecklist(1, 2, 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            var mapper = new AllocationChecklistMapper();

            //When
            var entityData = mapper.GetEntityData(dataObject);

            //Then
            Assert.That(entityData.Id, Is.EqualTo(1));
            Assert.That(entityData.AllocationId, Is.EqualTo(2));
            Assert.That(entityData.ChecklistType, Is.EqualTo(3));
            Assert.That(entityData.CreatedDate, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(entityData.CreatedBy, Is.EqualTo(4));
            Assert.That(entityData.ModifiedDate, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(entityData.ModifiedBy, Is.EqualTo(5));
        }


    }
}
