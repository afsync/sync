﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.IFSUser.userPreferences;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ChecklistTests
{
    [TestFixture]
    public class AllocationChecklistTests
    {
        [Test]
        public void TestConstructor()
        {
            //Given

            //When
            var allocationChecklist = new AllocationChecklist(1, 2, 3, new DateTime(2010, 1, 1), 4,
                                                              new DateTime(2011, 1, 1), 5);

            //Then
            Assert.That(allocationChecklist.Id, Is.EqualTo(1));
            Assert.That(allocationChecklist.AllocationId, Is.EqualTo(2));
            Assert.That(allocationChecklist.ChecklistType, Is.EqualTo(3));
            Assert.That(allocationChecklist.CreatedDate, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(allocationChecklist.CreatedBy, Is.EqualTo(4));
            Assert.That(allocationChecklist.ModifiedDate, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(allocationChecklist.ModifiedBy, Is.EqualTo(5));
        }


        [Test]
        public void TestGetAuditXml()
        {
            //Given
            var allocationChecklist = new AllocationChecklist(1, 2, 3, new DateTime(2010, 1, 1), 4,
                                                            new DateTime(2011, 1, 1), 5);
            //When
            var auditXml = allocationChecklist.GetAuditXml();

            //Then
            Assert.That(auditXml, Is.EqualTo("<Audit><Id>1</Id><AllocationId>2</AllocationId><ChecklistType>3</ChecklistType>" +
                "<CreatedDate>01/01/2010</CreatedDate><CreatedBy>4</CreatedBy><ModifiedDate>01/01/2011</ModifiedDate><ModifiedBy>5</ModifiedBy></Audit>"));
        }
    }
}
