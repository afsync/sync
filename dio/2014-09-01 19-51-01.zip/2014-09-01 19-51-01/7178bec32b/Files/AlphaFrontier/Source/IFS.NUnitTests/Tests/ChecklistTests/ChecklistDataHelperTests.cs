﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer.Checklists;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ChecklistTests
{
    [TestFixture]
    public class ChecklistDataHelperTests
    {
        [Test]
        public void NullDateTest()
        {
            Assert.That(ChecklistDataHelper.NullDate, Is.EqualTo(new DateTime(1900,1,1)));
        }

        [Test]
        public void NullUserIdTest()
        {
            Assert.That(ChecklistDataHelper.NullUserId, Is.EqualTo(-1));
        }

        [Test]
        public void GetShortDateTest()
        {
            //Given
            var date = new DateTime(2014, 1, 15);

            //When
            var dateStr = ChecklistDataHelper.GetShortDate(date);

            //Then
            Assert.That(dateStr, Is.EqualTo("01/15/2014"));
        }

    }
}
