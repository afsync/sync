using System.Collections.Generic;
using IFS.Interfaces.DbRepository;
using IFS.Interfaces.Entity;
using IFS.NUnitTests.MockResults;

namespace IFS.NUnitTests.DbRepository
{
    public class MockChecklistSectionsDbRepository: MockDbRepository, IChecklistSectionsDbRepository
    {
        public IControlAgreementSectionData GetControlAgreementSection(int checklistId)
        {
            return (IControlAgreementSectionData)MockResultSingleton.GetResult("ChecklistSectionsDbRepository.GetControlAgreementSection");
        }

        public IEnumerable<IControlAgreementSectionData> GetControlAgreementSections(List<int> checklistIds)
        {
            return (List<IControlAgreementSectionData>)MockResultSingleton.GetResult("ChecklistSectionsDbRepository.GetControlAgreementSections");
        }
    }
}
