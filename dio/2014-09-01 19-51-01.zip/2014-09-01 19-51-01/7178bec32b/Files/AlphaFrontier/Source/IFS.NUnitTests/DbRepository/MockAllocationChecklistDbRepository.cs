using System;
using System.Collections.Generic;
using IFS.Interfaces.DbRepository;
using IFS.Interfaces.Entity;
using IFS.NUnitTests.MockResults;

namespace IFS.NUnitTests.DbRepository
{
    public class MockAllocationChecklistDbRepository: MockDbRepository, IAllocationChecklistDbRepository
    {
        public IAllocationChecklistData GetAllocationChecklist(int allocationId)
        {
            return (IAllocationChecklistData)MockResultSingleton.GetResult("AllocationChecklistDbRepository.GetAllocationChecklist");
        }

        public IEnumerable<IAllocationChecklistData> GetAllocationChecklists(List<int> allocationIds)
        {
            return (List<IAllocationChecklistData>)MockResultSingleton.GetResult("AllocationChecklistDbRepository.GetAllocationChecklists");
        }

      
    }
}
