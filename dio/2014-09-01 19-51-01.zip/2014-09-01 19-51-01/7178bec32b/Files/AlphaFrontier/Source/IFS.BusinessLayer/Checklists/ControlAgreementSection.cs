﻿using System;
using System.Text;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.Checklists
{
    public class ControlAgreementSection : IAuditable
    {
        public readonly int Id;
        public readonly int ChecklistId;
        public readonly string Comments;
        public readonly int CommentsEnteredBy;
        public readonly DateTime Confirmed;
        public readonly int ConfirmedBy;
        public readonly DateTime Reviewed;
        public readonly int ReviewedBy;

        public ControlAgreementSection(int id, int checklistId, string comments, int commentsEnteredBy, DateTime confirmed, int confirmedBy, DateTime reviewed, int reviewedBy)
        {
            Id = id;
            ChecklistId = checklistId;
            Comments = comments;
            CommentsEnteredBy = commentsEnteredBy;
            Confirmed = confirmed;
            ConfirmedBy = confirmedBy;
            Reviewed = reviewed;
            ReviewedBy = reviewedBy;
        }

        public string GetAuditXml()
        {
            var sb = new StringBuilder("<Audit>");
            AuditUtilities.NameValuePair(sb, "Id", Id);
            AuditUtilities.NameValuePair(sb, "ChecklistId", ChecklistId);
            AuditUtilities.NameValuePair(sb, "Comments", Comments);
            AuditUtilities.NameValuePair(sb, "CommentsEnteredBy", CommentsEnteredBy);
            AuditUtilities.NameValuePair(sb, "Confirmed", ChecklistDataHelper.GetShortDate(Confirmed));
            AuditUtilities.NameValuePair(sb, "ConfirmedBy", ConfirmedBy);
            AuditUtilities.NameValuePair(sb, "Reviewed", ChecklistDataHelper.GetShortDate(Reviewed));
            AuditUtilities.NameValuePair(sb, "ReviewedBy", ReviewedBy);
            return sb.Append("</Audit>").ToString();
        }

    }
}
