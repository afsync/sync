﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer.Common;
using IFS.DataAccess.Entity;
using IFS.DataAccess.shared;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class ControlAgreementSectionSequenceProvider : ISequenceProvider
    {
        public int GetNextSequenceNumber()
        {
            using (var context = new AfDataContext())
            {
                var cass = new ControlAgreementSectionSequenceData();
                context.GetTable<ControlAgreementSectionSequenceData>().InsertOnSubmit(cass);
                context.SubmitChanges();
                return cass.Id;
            }
        }

        public List<int> GetNextSequenceNumberList(int capacity)
        {
            throw new NotImplementedException();
        }
    }
}
