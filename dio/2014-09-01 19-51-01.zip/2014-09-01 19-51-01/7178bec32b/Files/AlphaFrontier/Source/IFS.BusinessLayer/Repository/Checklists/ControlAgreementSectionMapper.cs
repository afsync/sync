﻿using IFS.BusinessLayer.Checklists;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Entity;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class ControlAgreementSectionMapper
    {
        public ControlAgreementSection GetControlAgreementSection(IControlAgreementSectionData data)
        {
            return new ControlAgreementSection(data.Id, data.ChecklistId, data.Comments,
                                           data.CommentsEnteredBy, data.Confirmed, data.ConfirmedBy, data.Reviewed, data.ReviewedBy);
        }

        public ControlAgreementSectionData GetEntityData(ControlAgreementSection section)
        {
            return new ControlAgreementSectionData
            {
                Id = section.Id,
                ChecklistId = section.ChecklistId,
                Comments = section.Comments,
                CommentsEnteredBy = section.CommentsEnteredBy,
                Reviewed = section.Reviewed,
                ReviewedBy = section.ReviewedBy,
                Confirmed = section.Confirmed,
                ConfirmedBy = section.ConfirmedBy
            };
        }
    }
}
