﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer.Common;
using IFS.DataAccess.Entity;
using IFS.DataAccess.shared;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class AllocationChecklistSequenceProvider: ISequenceProvider
    {
        public int GetNextSequenceNumber()
        {
            using (var context = new AfDataContext())
            {
                var acs = new AllocationChecklistSequenceData();
                context.GetTable<AllocationChecklistSequenceData>().InsertOnSubmit(acs);
                context.SubmitChanges();
                return acs.Id;
            } 
        }

        public List<int> GetNextSequenceNumberList(int capacity)
        {
            throw new NotImplementedException();
        }
    }
}
