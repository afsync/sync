﻿using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Common;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class AllocationChecklistBlRepository
    {
        private readonly AllocationChecklistMapper _checklistMapper;
        private readonly AuditLogger<AllocationChecklist> _auditLogger;
        private readonly ISequenceProvider _checklistSequence;

        public AllocationChecklistBlRepository(AllocationChecklistMapper mapper, AuditLogger<AllocationChecklist> auditLogger, ISequenceProvider sequence)
        {
            _checklistMapper = mapper;
            _auditLogger = auditLogger;
            _checklistSequence = sequence;
        }

        public int Create(AllocationChecklist checklist, IBulkSaveData bsd)
        {
            var id = _checklistSequence.GetNextSequenceNumber();
            var checklistWithId = new AllocationChecklist(id, checklist.AllocationId, checklist.ChecklistType, checklist.CreatedDate, checklist.CreatedBy,
                checklist.ModifiedDate, checklist.ModifiedBy);
            var entityObject = _checklistMapper.GetEntityData(checklistWithId);
            bsd.InsertOnSubmit(entityObject);
            _auditLogger.LogAuditRecord(null, checklistWithId, bsd, AuditAction.ACTION_SAVE);
            return id;
        }
    }
}
