﻿using System;

namespace IFS.BusinessLayer.Checklists
{
    public class ChecklistDataHelper
    {
        public static DateTime NullDate
        {
            get { return new DateTime(1900, 1, 1); }
        }

        public static int NullUserId
        {
            get { return -1; }
        }

        public static string GetShortDate(DateTime dateTime)
        {
            return dateTime.ToString("MM/dd/yyyy");
        }
    }
}
