﻿using IFS.BusinessLayer.Checklists;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Entity;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class AllocationChecklistMapper
    {
        public AllocationChecklist GetAllocationChecklist(IAllocationChecklistData data)
        {
            return new AllocationChecklist(data.Id, data.AllocationId, data.ChecklistType,
                                           data.CreatedDate, data.CreatedBy, data.ModifiedDate, data.ModifiedBy);
        }

        public AllocationChecklistData GetEntityData(AllocationChecklist checklist)
        {
            return new AllocationChecklistData
            {
                Id = checklist.Id,
                AllocationId = checklist.AllocationId,
                ChecklistType = checklist.ChecklistType,
                CreatedDate = checklist.CreatedDate,
                CreatedBy = checklist.CreatedBy,
                ModifiedDate = checklist.ModifiedDate,
                ModifiedBy = checklist.ModifiedBy,
            };
        }
    }
}
