﻿using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Common;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class ControlAgreementSectionBlRepository
    {
        private readonly ControlAgreementSectionMapper _sectionMapper;
        private readonly AuditLogger<ControlAgreementSection> _auditLogger;
        private readonly ISequenceProvider _sectionSequence;

        public ControlAgreementSectionBlRepository(ControlAgreementSectionMapper mapper, AuditLogger<ControlAgreementSection> auditLogger, ISequenceProvider sequence)
        {
            _sectionMapper = mapper;
            _auditLogger = auditLogger;
            _sectionSequence = sequence;
        }

        public int Create(ControlAgreementSection section, IBulkSaveData bsd)
        {
            var id = _sectionSequence.GetNextSequenceNumber();
            var sectionWithId = new ControlAgreementSection(id, section.ChecklistId, section.Comments, section.CommentsEnteredBy, section.Confirmed, 
                section.ConfirmedBy, section.Reviewed, section.ReviewedBy);
            var entityObject = _sectionMapper.GetEntityData(sectionWithId);
            bsd.InsertOnSubmit(entityObject);
            _auditLogger.LogAuditRecord(null, sectionWithId, bsd, AuditAction.ACTION_SAVE);
            return id;
        }
    }
}
