﻿using System;
using System.Text;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.Checklists
{
    public class AllocationChecklist : IAuditable
    {
        public readonly int Id;
        public readonly int AllocationId;
        public readonly int ChecklistType;
        public readonly DateTime CreatedDate;
        public readonly int CreatedBy;
        public readonly DateTime ModifiedDate;
        public readonly int ModifiedBy;

        public AllocationChecklist(int id, int allocationId, int checklistType, DateTime createdDate, int createdBy, DateTime modifiedDate, int modifiedBy)
        {
            Id = id;
            AllocationId = allocationId;
            ChecklistType = checklistType;
            CreatedDate = createdDate;
            CreatedBy = createdBy;
            ModifiedDate = modifiedDate;
            ModifiedBy = modifiedBy;
        }

        public string GetAuditXml()
        {
            var sb = new StringBuilder("<Audit>");
            AuditUtilities.NameValuePair(sb, "Id", Id);
            AuditUtilities.NameValuePair(sb, "AllocationId", AllocationId);
            AuditUtilities.NameValuePair(sb, "ChecklistType", ChecklistType);
            AuditUtilities.NameValuePair(sb, "CreatedDate", ChecklistDataHelper.GetShortDate(CreatedDate));
            AuditUtilities.NameValuePair(sb, "CreatedBy", CreatedBy);
            AuditUtilities.NameValuePair(sb, "ModifiedDate", ChecklistDataHelper.GetShortDate(ModifiedDate));
            AuditUtilities.NameValuePair(sb, "ModifiedBy", ModifiedBy);
            return sb.Append("</Audit>").ToString();
        }


    }
}
