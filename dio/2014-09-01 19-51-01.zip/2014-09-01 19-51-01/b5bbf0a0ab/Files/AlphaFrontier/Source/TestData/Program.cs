﻿using System;
using System.Globalization;
using System.Linq;
using System.Threading;
using IFS.BusinessLayer.AutoFac;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using TestData.Common;
using TestData.Common.CommandLineParameters;

namespace TestData
{
    //TODO:
    // 2. Use GlobalRuntimeCache instead of GetInvestableFund and GetBaseFund
    // 6. Replace XDocument with SAX
    // 8. Series.CloneSeries code should be optimized
    class Program
    {
        private static readonly string Usage = @"Creates test data for QA" + Environment.NewLine +
                                               "Parameters:" + Environment.NewLine +
                                               "-c filename         create test data specified in file(filename)" +
                                               Environment.NewLine +
                                               "-d filename         delete test data specified in file(filename)" +
                                               Environment.NewLine +
                                               "-m                  run maintenance on DB to cleanup logs, reindex, etc." +
                                               Environment.NewLine +
                                               "-r OrganizationName         reload cache of organization"+
                                               Environment.NewLine +
                                               "-attsp                startup folder for attachments(filesources)";
            

        static void Main(string[] args)
        {
            try
            {
                Session.CurrentParameters = new TestDataParameters(args);
                Logger.ConfigureLogging(Session.CurrentParameters.LogSuffix);
                Logger.LogInfo("Program started");
                
                if (!Session.CurrentParameters.Actions.Any())
                {
                    ShowUsage();
                    Environment.Exit(1);
                }
                
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");

                AutoFacContainer.RegisterDependencies();

                // Set timeout for cafm operations to 200 seconds, because default value (100 sec) sometimes is not enough when deleting GSM client
                CafmRepositoryHelper.CafmRepository.SetTimeout(200);

                //CConfig.CheckDbAndApplicationVersionsMatch();
                if (!AppConfiguration.DisableLoadingCacheOnStartup)
                {
                    GlobalRuntimeCache.InitializeCache();
                }
                var creator = new TestDataCreator();
                creator.Process(Session.CurrentParameters);
                Logger.LogInfo("Program completed");
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Failed to complete operation with first parameter: " + (args.Length > 0 ? args[0] : string.Empty));
            }
            Environment.Exit(Logger.HasError ? 1 : 0);
        }

        private static void ShowUsage()
        {
            Console.WriteLine(Usage);
            Environment.Exit(1);
        }

        
    }
}
