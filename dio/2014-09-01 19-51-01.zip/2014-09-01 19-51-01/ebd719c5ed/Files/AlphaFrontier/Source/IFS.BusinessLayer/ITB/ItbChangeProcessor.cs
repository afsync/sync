﻿using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangeProcessor
    {
        private readonly ItbChangeProcessorObjectFactory _factory;

        public ItbChangeProcessor(ItbChangeProcessorObjectFactory factory)
        {
            _factory = factory;
        }

        public virtual RowChanges Process(RowChanges changes, int checklistId)
        {
            var viewer = _factory.GetViewer(changes);
            var checklist = GetChecklist(checklistId);
            ValidateChanges(viewer, checklist);
            SaveChanges(viewer, checklist);
            return GetSavedChanges(viewer, checklist);
        }

        private ChecklistBase GetChecklist(int checklistId)
        {
            var loader = _factory.GetLoader();
            return loader.GetById(checklistId);
        }


        private RowChanges GetSavedChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            return new RowChanges();
        }

        private void SaveChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            _factory.GetSaver().Save(checklist);
        }

        private void ValidateChanges(ItbChangesViewer viewer, ChecklistBase checklist)
        {
            _factory.GetValidator().Validate(checklist);
        }
    }
}
