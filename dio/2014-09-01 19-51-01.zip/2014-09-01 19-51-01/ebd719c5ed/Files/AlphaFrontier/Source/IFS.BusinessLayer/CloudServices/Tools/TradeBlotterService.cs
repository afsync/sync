﻿using System.Collections.Generic;
using IFS.BusinessLayer.EJSGrid.Itb;
using IFS.BusinessLayer.Fund.StaticClassWrappers;
using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using IFS.Interfaces.CloudContracts.Tools;

namespace IFS.BusinessLayer.CloudServices.Tools
{
    public class TradeBlotterService : CloudServiceBase, ITradeBlotterService
    {
        public TradeBlotterPageData GetPageData(ItbPageParameters parameters, SessionData sessionData) 
        {
            return Execute(sessionData, () => GetPageData(parameters));
        }

        private TradeBlotterPageData GetPageData(ItbPageParameters parameters)
        {
            var loader = new ItbPageDataLoader(new PortfolioWrapper());

            var pageData = new TradeBlotterPageData
            {
                ChecklistTypes = new List<string> {"Regular", "Shared"},
                Portfolios = loader.GetPortfolios(),
                Tabs = new List<string> {"Control Agreement"},
                GridContent = GenerateGridContent(parameters)
            };
            return pageData;
        }

        public XmlResult GenerateGrid(ItbPageParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () => new XmlResult {ReportXml = GenerateGridContent(parameters)});
        }

        private string GenerateGridContent(ItbPageParameters parameters)
        {
            var rows = GenerateGridRows(parameters);
            var generator = new EjsGridXmlBuilderFactoryForItb(rows);
            var grid = generator.GetGridBuilder();
            return grid.GetXmlDocument();
        }

        private IEnumerable<AllocationRow> GenerateGridRows(ItbPageParameters parameters)
        {
            var allocationsLoader = new ItbAllocationsLoader(parameters, Portfolio.Loader);
            var tradeRowGenerator = new AllocationRowGenerator();
            var checkListRowGenerator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader);
            var rowGenerator = new ItbRowsNester(allocationsLoader, tradeRowGenerator, checkListRowGenerator);
            return rowGenerator.GetAllocationRows();
        }

        public FabricRequestResult<List<GridChanges>> ProcessGridChanges(List<GridChanges> gridChanges, SessionData sessionData)
        {
            var factory = new ItbChangeProcessorObjectFactory();
            var changeProcessor = new ItbChangeProcessor(factory);
            var processor = new ItbGridChangesProcessor(changeProcessor);
            return new FabricRequestResult<List<GridChanges>>{ Value = processor.Process(gridChanges)};
        }
    }
}
