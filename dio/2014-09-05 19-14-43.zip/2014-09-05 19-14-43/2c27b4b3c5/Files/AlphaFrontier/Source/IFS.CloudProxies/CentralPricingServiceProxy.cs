﻿using System;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.CentralPricing;
using IFS.Interfaces.CloudContracts.DataContracts.SecurityPricingGrid;
using IFS.Interfaces.Common;

namespace IFS.CloudProxies
{
    public class CentralPricingServiceProxy : CloudProxyBase, ICentralPricingService
    {
        private const string GET_PRICING_SUMMARY_GRID_XML = "CentralPricingService_GetPricingSummaryGridXml";
        private const string GET_PRICING_DETAILS_GRID_XML = "CentralPricingService_GetPricingDetailsGridXml";
        private const string GET_PRICING_DETAILS_GRID_XML_NEW = "CentralPricingService_GetPricingDetailsGridXmlNew";
        private const string GET_SECURITY_LOOKUP_FUND_LIST = "CentralPricingService_GetSecurityLookupFundList";
        private const string GET_PAGE_DATA = "CentralPricingService_GetPageData";
        private const string GET_PORTFOLIO_LIST = "CentralPricingService_GetPortfolioList";
        private const string GET_EDIT_FORM_DATA = "CentralPricingService_GetEditFormData";
        private const string GET_CLASS_LEVEL_FORM_DATA = "CentralPricingService_GetClassLevelFormData";
        private const string GET_CLASS__LOWEST_LEVEL_FORM_DATA = "CentralPricingService_GetClassLowestLevelFormData";
        private const string GET_SERIES_LEVEL_FORM_DATA = "CentralPricingService_GetSeriesLevelFormData";
        private const string SAVE_GROUP_PRICE = "CentralPricingService_SaveGroupedSecurityPrices";
        private const string SAVE_CLASS_GROUP_PRICE = "CentralPricingService_SaveClassGroupPrices";
        private const string SAVE_GROUP_CLASS_LOWEST_LEVEL_PRICE = "CentralPricingService_SaveGroupedClassLowestLevelSecurityPrices";
        private const string GET_SECURITY_PRICINGS_STATISTICS = "CentralPricingService_GetSecurityPricingsStatistics";

        public FabricRequestResult<string> GetPricingSummaryGridXml(PricingSummaryParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<string>>(parameters, sessionData, GET_PRICING_SUMMARY_GRID_XML);
        }

        public FabricRequestResult<string> GetPricingDetailsGridXml(PricingDetailsParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<string>>(parameters, sessionData, GET_PRICING_DETAILS_GRID_XML);
        }

        public FabricRequestResult<string> GetReadonlyPricingDetailsGrid(PricingDetailsParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<string>>(parameters, sessionData, GET_PRICING_DETAILS_GRID_XML_NEW);
        }

        public CollectionRequestResult<SecurityLookupView> GetSecurityLookupFundList(SecurityLookupParameters parameters, SessionData sessionData)
        {
            return Execute<CollectionRequestResult<SecurityLookupView>>(parameters, sessionData, GET_SECURITY_LOOKUP_FUND_LIST);
        }

        public SecurityPricingDetailsPageData GetPageData(SessionData sessionData)
        {
            return Execute<SecurityPricingDetailsPageData>(null, sessionData, GET_PAGE_DATA);
        }

        public CollectionRequestResult<PortfolioView> GetPortfolioList(int organizationId, SessionData sessionData)
        {
            return Execute<CollectionRequestResult<PortfolioView>>(organizationId, sessionData, GET_PORTFOLIO_LIST);
        }

        public FabricRequestResult<GroupPriceEditModel> GetEditFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<GroupPriceEditModel>>(parameters, sessionData, GET_EDIT_FORM_DATA);
        }

        public FabricRequestResult<GroupPriceEditModel> GetClassLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<GroupPriceEditModel>>(parameters, sessionData, GET_CLASS_LEVEL_FORM_DATA);
        }

        public FabricRequestResult<GroupPriceLowestLevelModel> GetClassLowestLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<GroupPriceLowestLevelModel>>(parameters, sessionData, GET_CLASS__LOWEST_LEVEL_FORM_DATA);
        }

        public FabricRequestResult<GroupPriceLowestLevelModel> GetSeriesLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute<FabricRequestResult<GroupPriceLowestLevelModel>>(parameters, sessionData, GET_SERIES_LEVEL_FORM_DATA);
        }

        public FabricRequestResult SaveBasefundGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData)
        {
            return Execute<FabricRequestResult>(groupPrice, sessionData, SAVE_GROUP_PRICE);
        }

        public FabricRequestResult SaveGroupedClassLowestLevelSecurityPrices(GroupPriceLowestLevelModel groupPrice, SessionData sessionData)
        {
            return Execute<FabricRequestResult>(groupPrice, sessionData, SAVE_GROUP_CLASS_LOWEST_LEVEL_PRICE);
        }


        public FabricRequestResult SaveClassGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData)
        {
            return Execute<FabricRequestResult>(groupPrice, sessionData, SAVE_CLASS_GROUP_PRICE);
        }

        public FabricRequestResult<SecurityPricingsStatistics> GetSecurityPricingsStatistics(SessionData sessionData)
        {
            return Execute<FabricRequestResult<SecurityPricingsStatistics>>(null, sessionData, GET_SECURITY_PRICINGS_STATISTICS);
        }
    }
}
