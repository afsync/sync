﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Common.Logging;
using IFS.BusinessLayer;
using IFS.Controllers.CentralPricing;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.CentralPricing;

namespace HedgeFrontier.Areas.CentralPricing.Controllers
{
    public class PricingScreenController : Controller
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(PricingScreenController));
        private static ICentralPricingService _centralPricingService;

        public PricingScreenController(ICentralPricingService centralPricingService)
        {
            _centralPricingService = centralPricingService;
        }


        [HttpGet]
        public ActionResult Index()
        {
            var result = _centralPricingService.GetPageData(CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return View(result);
        }

        [HttpGet]
        public ActionResult GetPortfoliosForClient(int clientId)
        {
            var result = _centralPricingService.GetPortfolioList(clientId, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetGridXmlData()
        {
            return Content(GetGridXml());
        }

        [HttpPost]
        public ActionResult EditForm(EditFormParameters parameters)
        {
            var result = _centralPricingService.GetEditFormData(parameters, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return PartialView(result.Value);
        }

        [HttpPost]
        public ActionResult ClassLevelPrice(EditFormParameters parameters)
        {
            var result = _centralPricingService.GetClassLevelFormData(parameters, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return PartialView(result.Value);
        }
        [HttpPost]
        public ActionResult ClassLowestLevelPrice(EditFormParameters parameters)
        {
            var result = _centralPricingService.GetClassLowestLevelFormData(parameters, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return PartialView(result.Value);
        }
        [HttpPost]
        public ActionResult SeriesLevelPrice(EditFormParameters parameters)
        {
            var result = _centralPricingService.GetSeriesLevelFormData(parameters, CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return PartialView(result.Value);
        }
        [HttpPost]
        public ActionResult Save(GroupPriceEditModel model, IEnumerable<HttpPostedFileBase> attachments)
        {
            var result = _centralPricingService.SaveBasefundGroupPrices(AddUploadedFilesToModel(model, attachments), CSession.GetSessionData());
            var errorResult = GetJsonResult(result);
            if (errorResult != null)
                errorResult.ContentType = "text/html";   // cannot return json when publishing file on server
            return errorResult;
        }

        private GroupPriceEditModel AddUploadedFilesToModel(GroupPriceEditModel model, IEnumerable<HttpPostedFileBase> files)
        {
            var uploadedFiles = new List<UploadedFileModel>();
            if (files != null)
            {
                var target = new MemoryStream();
                foreach (var file in files.Where(file => file != null))
                {
                    file.InputStream.CopyTo(target);
                    uploadedFiles.Add(new UploadedFileModel
                    {
                        FileName = Path.GetFileName(file.FileName),
                        FileContent = target.ToArray()
                    });
                }
            }
            model.UploadedFiles = uploadedFiles;
            return model;
        }


        [HttpPost]
        public ActionResult SaveClassLevelPrice(GroupPriceEditModel model)
        {
            var result = _centralPricingService.SaveClassGroupPrices(model, CSession.GetSessionData());
            return GetJsonResult(result);
        }
        [HttpPost]
        public ActionResult SaveClassLowestLevelPrice(GroupPriceLowestLevelModel model)
        {
            var result = _centralPricingService.SaveGroupedClassLowestLevelSecurityPrices(model, CSession.GetSessionData());
            return GetJsonResult(result);
        }

        [HttpPost]
        public ActionResult SaveSeriesLevelPrice(GroupPriceLowestLevelModel model)
        {
            var result = _centralPricingService.SaveGroupedClassLowestLevelSecurityPrices(model, CSession.GetSessionData());
            return GetJsonResult(result);
        }

        [HttpGet]
        public ActionResult GetSecurityPricingStatistics()
        {
            var result = _centralPricingService.GetSecurityPricingsStatistics(CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return Json(result.Value, JsonRequestBehavior.AllowGet);
        }

        private JsonResult GetJsonResult(FabricRequestResult res)
        {
            JsonResult result = null;
            if (res != null && res.Failed)
            {
                _log.Error(res.InnerException);
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                result = new JsonResult { Data = res.InnerException.Message };
            }
            return result;
        }

        private string GetGridXml()
        {
            var pageController = new CentralPricingPageController(Request.Params);
            var result = pageController.IsDetailsMode()
                             ? _centralPricingService.GetReadonlyPricingDetailsGrid(pageController.GetDetailsParameters(), CSession.GetSessionData())
                             : _centralPricingService.GetPricingSummaryGridXml(pageController.GetSummaryParameters(), CSession.GetSessionData());
            if (result.Failed)
                throw result.InnerException;
            return result.Value;
        }
    }
}