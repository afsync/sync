using System;
using Autofac;
using IFS.BusinessLayer.AutoFac;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.CentralPricing;
using IFS.Interfaces.CloudContracts.DataContracts.SecurityPricingGrid;

namespace IFS.BusinessLayer.Appistry.DependancyResolver
{
    public class ServicesResolver
    {
        public object ProcessRequest(object parameters, SessionData sessionData, string svcName)
        {
            object result;
            switch (svcName)
            {
                case "CentralPricingService_GetPricingSummaryGridXml":
                    result= Resolve().GetPricingSummaryGridXml((PricingSummaryParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetPricingDetailsGridXml":
                    result = Resolve().GetPricingDetailsGridXml((PricingDetailsParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetPricingDetailsGridXmlNew":
                    result = Resolve().GetReadonlyPricingDetailsGrid((PricingDetailsParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetSecurityLookupFundList":
                    result = Resolve().GetSecurityLookupFundList((SecurityLookupParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetPageData":
                    result = Resolve().GetPageData(sessionData);
                    break;
                case "CentralPricingService_GetPortfolioList":
                    result = Resolve().GetPortfolioList((int)parameters, sessionData);
                    break;
                case "CentralPricingService_GetEditFormData":
                    result = Resolve().GetEditFormData((EditFormParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetClassLevelFormData":
                    result = Resolve().GetClassLevelFormData((EditFormParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetClassLowestLevelFormData":
                    result = Resolve().GetClassLowestLevelFormData((EditFormParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_GetSeriesLevelFormData":
                    result = Resolve().GetSeriesLevelFormData((EditFormParameters)parameters, sessionData);
                    break;
                case "CentralPricingService_SaveGroupedSecurityPrices":
                    result = Resolve().SaveBasefundGroupPrices((GroupPriceEditModel)parameters, sessionData);
                    break;
                case "CentralPricingService_SaveClassGroupPrices":
                    result = Resolve().SaveClassGroupPrices((GroupPriceEditModel)parameters, sessionData);
                    break;
                case "CentralPricingService_SaveGroupedClassLowestLevelSecurityPrices":
                    result = Resolve().SaveGroupedClassLowestLevelSecurityPrices((GroupPriceLowestLevelModel)parameters, sessionData);
                    break;
                case "CentralPricingService_GetSecurityPricingsStatistics":
                    result = Resolve().GetSecurityPricingsStatistics(sessionData);
                    break;
                default:
                    result = new FabricRequestResult { InnerException = new Exception("No Service found.") };
                    break;
            }
            return result;
        }

        private static ICentralPricingService Resolve()
        {
            return AutoFacContainer.Container.Resolve<ICentralPricingService>();
        }
        
    }
}