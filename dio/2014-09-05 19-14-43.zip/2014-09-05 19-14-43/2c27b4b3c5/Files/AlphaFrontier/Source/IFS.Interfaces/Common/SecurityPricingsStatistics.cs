﻿using System;

namespace IFS.Interfaces.Common
{
    [Serializable]
    public class SecurityPricingsStatistics
    {
        public int PendingApprovalCount { get; set; }
        public int RejectedCount { get; set; }
    }
}
