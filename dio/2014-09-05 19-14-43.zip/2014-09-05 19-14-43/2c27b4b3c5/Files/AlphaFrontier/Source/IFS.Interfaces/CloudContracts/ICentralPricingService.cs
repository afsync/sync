﻿using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.CentralPricing;
using IFS.Interfaces.CloudContracts.DataContracts.SecurityPricingGrid;
using IFS.Interfaces.Common;

namespace IFS.Interfaces.CloudContracts
{
    public interface ICentralPricingService
    {
        FabricRequestResult<string> GetPricingSummaryGridXml(PricingSummaryParameters parameters, SessionData sessionData);
        FabricRequestResult<string> GetPricingDetailsGridXml(PricingDetailsParameters parameters, SessionData sessionData);
        FabricRequestResult<string> GetReadonlyPricingDetailsGrid(PricingDetailsParameters parameters, SessionData sessionData);
        CollectionRequestResult<SecurityLookupView> GetSecurityLookupFundList(SecurityLookupParameters parameters, SessionData sessionData);
        SecurityPricingDetailsPageData GetPageData(SessionData sessionData);
        CollectionRequestResult<PortfolioView> GetPortfolioList(int organizationId, SessionData sessionData);
        FabricRequestResult<GroupPriceEditModel> GetEditFormData(EditFormParameters parameters, SessionData sessionData);
        FabricRequestResult<GroupPriceEditModel> GetClassLevelFormData(EditFormParameters parameters, SessionData sessionData);
        FabricRequestResult<GroupPriceLowestLevelModel> GetClassLowestLevelFormData(EditFormParameters parameters, SessionData sessionData);
        FabricRequestResult<GroupPriceLowestLevelModel> GetSeriesLevelFormData(EditFormParameters parameters, SessionData sessionData);
        FabricRequestResult SaveBasefundGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData);
        FabricRequestResult SaveClassGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData);
        FabricRequestResult SaveGroupedClassLowestLevelSecurityPrices(GroupPriceLowestLevelModel groupPrice, SessionData sessionData);
        FabricRequestResult<SecurityPricingsStatistics> GetSecurityPricingsStatistics(SessionData sessionData);
    }
}
