﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.GSM.CentralPricing;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.CentralPricing;
using IFS.Interfaces.CloudContracts.DataContracts.SecurityPricingGrid;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.CloudServices.CentralPricing
{
    public class CentralPricingService : CloudServiceBase, ICentralPricingService
    {
        private readonly CentralPricingGridFactory _centralPricingGridFactory;
        private readonly ISecurityPricingStore _securityPricingStore;
        private readonly CentralPricingDataProviderFactory _centralPricingDataProviderFactory;
        private readonly SecurityPricingFactory _securityPricingFactory;

        public CentralPricingService(CentralPricingGridFactory centralPricingGridFactory,
            CentralPricingDataProviderFactory centralPricingDataProviderFactory, SecurityPricingFactory securityPricingFactory)
        {
            _centralPricingGridFactory = centralPricingGridFactory;
            _securityPricingStore = SecurityPricingStore.GetInstance();
            _centralPricingDataProviderFactory = centralPricingDataProviderFactory;
            _securityPricingFactory = securityPricingFactory;
        }

        public FabricRequestResult<string> GetPricingSummaryGridXml(PricingSummaryParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData,
                () => new FabricRequestResult<string> { Value = _centralPricingGridFactory.CreatePricingSummary(parameters).GenerateXml() });
        }

        public FabricRequestResult<string> GetPricingDetailsGridXml(PricingDetailsParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData,
                () => new FabricRequestResult<string> { Value = _centralPricingGridFactory.CreatePricingDetailsGrid(parameters).GenerateXml() });
        }

        public FabricRequestResult<string> GetReadonlyPricingDetailsGrid(PricingDetailsParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData,() => new FabricRequestResult<string> { Value = GetReadonlyPricingDetailsGrid(parameters) });
        }

        public CollectionRequestResult<SecurityLookupView> GetSecurityLookupFundList(SecurityLookupParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData,
                           () => new CollectionRequestResult<SecurityLookupView>(GetSecurityLookupFundList(parameters)));
        }

        public SecurityPricingDetailsPageData GetPageData(SessionData sessionData)
        {
            return Execute(sessionData,
                () => _centralPricingDataProviderFactory.CreateCentralPricingPageDataProvider(CSession.User).GetInitialPageData());
        }

        public CollectionRequestResult<PortfolioView> GetPortfolioList(int organizationId, SessionData sessionData)
        {
            return Execute(sessionData, () => new CollectionRequestResult<PortfolioView>(
                    _centralPricingDataProviderFactory.CreatePortfolioListProvider(organizationId).GetPortfolioList()));
        }

        public FabricRequestResult<GroupPriceEditModel> GetEditFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () =>
            {
                var groupPriceEditModel =
                    new GroupedPriceEditModelDataProvider(Organization.Loader, Portfolio.Loader, InvestableFund.Loader,
                        EnumValue.Loader).GetModel(parameters);
                return new FabricRequestResult<GroupPriceEditModel> { Value = groupPriceEditModel };
            });
        }

        public FabricRequestResult<GroupPriceEditModel> GetClassLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () =>
            {
                var groupPriceEditModel =
                    new GroupedPriceEditModelDataProvider(Organization.Loader, Portfolio.Loader, InvestableFund.Loader,
                        EnumValue.Loader).GetClassModel(parameters);
                return new FabricRequestResult<GroupPriceEditModel> { Value = groupPriceEditModel };
            });
        }

        public FabricRequestResult<GroupPriceLowestLevelModel> GetClassLowestLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () =>
            {
                var groupPriceEditModel =
                    new GroupPriceLowestLevelModelDataProvider(Organization.Loader, Portfolio.Loader, InvestableFund.Loader,
                        EnumValue.Loader).GetClassModel(parameters);
                return new FabricRequestResult<GroupPriceLowestLevelModel> { Value = groupPriceEditModel };
            });
        }

        public FabricRequestResult<GroupPriceLowestLevelModel> GetSeriesLevelFormData(EditFormParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () =>
            {
                var groupPriceEditModel =
                    new GroupPriceLowestLevelModelDataProvider(Organization.Loader, Portfolio.Loader, InvestableFund.Loader, EnumValue.Loader).GetSeriesModel(parameters);
                return new FabricRequestResult<GroupPriceLowestLevelModel> { Value = groupPriceEditModel };
            });
        }

        public FabricRequestResult SaveBasefundGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData)
        {
            return Execute(sessionData, () => _securityPricingFactory.CreateSpGroupModelSaver().SaveBasefundGroupPrices(groupPrice));
        }

        public FabricRequestResult SaveClassGroupPrices(GroupPriceEditModel groupPrice, SessionData sessionData)
        {
            return Execute(sessionData, () => _securityPricingFactory.CreateSpGroupModelSaver().SaveClassGroupPrices(groupPrice));
        }

        public FabricRequestResult SaveGroupedClassLowestLevelSecurityPrices(GroupPriceLowestLevelModel groupPrice, SessionData sessionData)
        {
            return Execute(sessionData, () => _securityPricingFactory.CreateSpGroupModelSaver().SaveGroupedPriceModel(groupPrice));
        }

        public FabricRequestResult<SecurityPricingsStatistics> GetSecurityPricingsStatistics(SessionData sessionData)
        {
            return Execute(sessionData, () =>
            {
                var stats = _securityPricingStore.SecurityPriceIndexByStatus.GetPricingStatusCounts(CSession.OrganizationID);
                return new FabricRequestResult<SecurityPricingsStatistics> { Value = stats };
            });
        }

        private string GetReadonlyPricingDetailsGrid(PricingDetailsParameters parameters)
        {
            var rowsProvider = _centralPricingGridFactory.CreatePricingDetailsGridRowsProvider(parameters);
            var pricingGrid = _centralPricingGridFactory.CreatePricingDetailsReport();
            return pricingGrid.GenerateXml(rowsProvider.GetRows());
        }

        private List<SecurityLookupView> GetSecurityLookupFundList(SecurityLookupParameters parameters)
        {
            var basefunds = 
                _securityPricingStore.SecurityPriceIndexByStatus.GetBaseFundListByStatus(parameters.TimeLapse,parameters.SpStatus);
            return basefunds.Select(GetSecurityLookupView()).ToList();
        }

        private static Func<UnderlyingFund, SecurityLookupView> GetSecurityLookupView()
        {
            return invFund => new SecurityLookupView { id = invFund.FundID, value = invFund.FundName };
        }
    }
}
