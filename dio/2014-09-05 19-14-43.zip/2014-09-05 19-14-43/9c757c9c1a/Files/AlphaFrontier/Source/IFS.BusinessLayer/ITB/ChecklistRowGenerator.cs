﻿using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Repository.Checklists;

namespace IFS.BusinessLayer.Itb
{
    public class ChecklistRowGenerator
    {
        private readonly ILoadable<User> _userLoader;
        private readonly ILoadable<EnumValue> _enumLoader;
        private readonly AllocationChecklistRepository _checklistLoader;
        private readonly ControlAgreementSectionRepository _checklistSectionLoader;

        public ChecklistRowGenerator(ILoadable<User> userLoader,  ILoadable<EnumValue> enumLoader, AllocationChecklistRepository checklistLoader, ControlAgreementSectionRepository checklistSectionLoader)
        {
            _userLoader = userLoader;
            _enumLoader = enumLoader;
            _checklistLoader = checklistLoader;
            _checklistSectionLoader = checklistSectionLoader;
        }

        public virtual ChecklistRow GetRow(Allocation allocation)
        {
            var checklistSection = GetChecklistSection(allocation);
            return GenerateRow(allocation, checklistSection);
        }

        private ChecklistRow GenerateRow(Allocation allocation, ControlAgreementSection checklistSection)
        {
            var creditProviderProperties = allocation.Investment.Portfolio.PortfolioProperties.CreditProvider;
            var userFullName = GetUserFullName(creditProviderProperties.PerformedBy);

            return new ChecklistRow
            {
                ChecklistId = checklistSection.ChecklistId,
                CreditProvider = creditProviderProperties.CreditProviderName,
                CreditProviderBy = userFullName,
                TypeOfNotice = GetTypeOfNotice(creditProviderProperties.NoticeType),
                TypeOfNoticeBy = userFullName,
                EffectiveDate = creditProviderProperties.NoticeDate,
                EffectiveDateBy = userFullName,
                Comments = checklistSection.Comments,
                CommentsBy = GetUserFullName(checklistSection.CommentsEnteredBy),
                ConfirmedDate = checklistSection.Confirmed,
                ConfirmedBy = GetUserFullName(checklistSection.ConfirmedBy),
                ReviewedDate = checklistSection.Reviewed,
                ReviewedBy = GetUserFullName(checklistSection.ReviewedBy),
                IsControlAgreementSectionEditable = checklistSection.AreConfirmedAndCommentsFieldsEnabled(),
                IsReviewedEditable = checklistSection.IsReviewedFieldEnabled()
            };
        }

        private ControlAgreementSection GetChecklistSection(Allocation allocation)
        {
            var checklist = _checklistLoader.GetByAllocationId(allocation.AllocationID);
            return _checklistSectionLoader.GetByChecklistId(checklist.Id);
        }

        private string GetUserFullName(int userId)
        {
            var user = _userLoader.GetById(userId);
            return user != null ? user.UserFullName : string.Empty;
        }

        private string GetTypeOfNotice(int noticeType)
        {
            var enumValue = _enumLoader.GetById(noticeType);
            return enumValue != null ? enumValue.EnumValueName : string.Empty;
        }
    }
}
