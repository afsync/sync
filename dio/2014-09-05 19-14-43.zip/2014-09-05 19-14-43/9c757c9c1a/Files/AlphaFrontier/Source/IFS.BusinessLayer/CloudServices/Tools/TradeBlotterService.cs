﻿using System.Collections.Generic;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.EJSGrid.Itb;
using IFS.BusinessLayer.Fund.StaticClassWrappers;
using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Repository.Checklists;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using IFS.Interfaces.CloudContracts.Tools;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.CloudServices.Tools
{
    public class TradeBlotterService : CloudServiceBase, ITradeBlotterService
    {
        public TradeBlotterPageData GetPageData(ItbPageParameters parameters, SessionData sessionData) 
        {
            return Execute(sessionData, () => GetPageData(parameters));
        }

        private TradeBlotterPageData GetPageData(ItbPageParameters parameters)
        {
            var loader = new ItbPageDataLoader(new PortfolioWrapper());

            var pageData = new TradeBlotterPageData
            {
                ChecklistTypes = new List<string> {"Regular", "Shared"},
                Portfolios = loader.GetPortfolios(),
                Tabs = new List<string> {"Control Agreement"},
                GridContent = GenerateGridContent(parameters)
            };
            return pageData;
        }

        public XmlResult GenerateGrid(ItbPageParameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () => new XmlResult {ReportXml = GenerateGridContent(parameters)});
        }

        private string GenerateGridContent(ItbPageParameters parameters)
        {
            var rows = GenerateGridRows(parameters);
            var generator = new EjsGridXmlBuilderFactoryForItb(rows);
            var grid = generator.GetGridBuilder();
            return grid.GetXmlDocument();
        }

        private IEnumerable<AllocationRow> GenerateGridRows(ItbPageParameters parameters)
        {
            var allocationsLoader = new ItbAllocationsLoader(parameters, Portfolio.Loader);
            var tradeRowGenerator = new AllocationRowGenerator();
            var checklistLoader = CreateAllocationChecklistLoader();
            var checklistSectionLoader = CreateControlAgreementSectionRepository();
            var checkListRowGenerator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, checklistLoader, checklistSectionLoader);
            var rowGenerator = new ItbRowsNester(allocationsLoader, tradeRowGenerator, checkListRowGenerator);
            return rowGenerator.GetAllocationRows();
        }

        //TODO: should be moved into factory
        private static ControlAgreementSectionRepository CreateControlAgreementSectionRepository()
        {
            return new ControlAgreementSectionRepository(new ControlAgreementSectionMapper(),
                                                    new AuditLogger<ControlAgreementSection>(),
                                                    new ControlAgreementSectionSequenceProvider(),
                                                    new DbRepositoryFactory());
        }

        //TODO: should be moved into factory
        private AllocationChecklistRepository CreateAllocationChecklistLoader()
        {
            return new AllocationChecklistRepository(new AllocationChecklistMapper(),
                                                    new AuditLogger<AllocationChecklist>(),
                                                    new AllocationChecklistSequenceProvider(),
                                                    new DbRepositoryFactory());
        }

        public FabricRequestResult<List<GridChanges>> ProcessGridChanges(ItbUpdatePrameters parameters, SessionData sessionData)
        {
            return Execute(sessionData, () => ProcessGridChanges(parameters, CSession.User));
        }

        private FabricRequestResult<List<GridChanges>> ProcessGridChanges(ItbUpdatePrameters parameters, User user)
        {
            var factory = new ItbChangeProcessorObjectFactory();
            var checklistLoader = new ItbChecklistLoader(Portfolio.Loader);
            var changeProcessor = new ItbChangeProcessor(factory, user);
            var processor = new ItbGridChangesProcessor(changeProcessor, checklistLoader);
            return new FabricRequestResult<List<GridChanges>> { Value = processor.Process(parameters) };
        }
    }
}
