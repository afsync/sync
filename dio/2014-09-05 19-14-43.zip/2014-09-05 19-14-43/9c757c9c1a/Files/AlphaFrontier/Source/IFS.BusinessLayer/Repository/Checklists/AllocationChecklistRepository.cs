﻿using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Common;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Common;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class AllocationChecklistRepository : ImmutableRepositoryBase<AllocationChecklist, AllocationChecklistData>
    {
        private readonly DbRepositoryFactory _dbRepositoryFactory;

        public AllocationChecklistRepository(IMapper<AllocationChecklist, AllocationChecklistData> mapper,
                                            AuditLogger<AllocationChecklist> auditLogger,
                                            ISequenceProvider sequence,
                                            DbRepositoryFactory dbRepositoryFactory)
            : base(mapper, auditLogger, sequence)
        {
            _dbRepositoryFactory = dbRepositoryFactory;
        }

        public virtual AllocationChecklist GetByAllocationId(int allocationId)
        {
            using (var dbRepository = _dbRepositoryFactory.GetAllocationChecklistDbRepository())
            {
                var entity = (AllocationChecklistData)dbRepository.GetAllocationChecklist(allocationId) ??
                             new AllocationChecklistData { AllocationId = allocationId };
                return _mapper.GetImmutableFromEntity(entity);
            }
        }

    }
}
