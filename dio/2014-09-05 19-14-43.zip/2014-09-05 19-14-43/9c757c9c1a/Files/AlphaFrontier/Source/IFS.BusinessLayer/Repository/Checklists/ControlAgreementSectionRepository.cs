﻿using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Common;
using IFS.DataAccess.Entity;
using IFS.Interfaces.Common;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.Repository.Checklists
{
    public class ControlAgreementSectionRepository : ImmutableRepositoryBase<ControlAgreementSection, ControlAgreementSectionData>
    {
        private readonly DbRepositoryFactory _dbRepositoryFactory;

        public ControlAgreementSectionRepository(IMapper<ControlAgreementSection, ControlAgreementSectionData> mapper,
                                                 AuditLogger<ControlAgreementSection> auditLogger,
                                                 ISequenceProvider sequence,
                                                 DbRepositoryFactory dbRepositoryFactory)
            :base(mapper, auditLogger, sequence)
        {
            _dbRepositoryFactory = dbRepositoryFactory;
        }

        public virtual ControlAgreementSection GetByChecklistId(int checklistId)
        {
            using (var dbRepository = _dbRepositoryFactory.GetChecklistSectionsDbRepository())
            {
                var entity = (ControlAgreementSectionData)dbRepository.GetControlAgreementSection(checklistId) ??
                             new ControlAgreementSectionData { ChecklistId = checklistId };
                return _mapper.GetImmutableFromEntity(entity);
            }
        }
    }
}
