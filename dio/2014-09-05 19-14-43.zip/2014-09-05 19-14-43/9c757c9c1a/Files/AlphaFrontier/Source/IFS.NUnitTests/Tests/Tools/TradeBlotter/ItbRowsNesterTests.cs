﻿using System.Collections.Generic;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Repository.Checklists;
using IFS.Interfaces.Factories;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbRowsNesterTests
    {
        [Test]
        public void TestGetAllocationRows()
        {
            //given
            var allocation = Mock.Of<Allocation>();
            var checklistRow = Mock.Of<ChecklistRow>();
            var tradeRow = Mock.Of<AllocationRow>();
            var mockFilter = new Mock<ItbAllocationsLoader>(null, null);
            mockFilter.Setup(m => m.GetAllocationsWithOpenChecklist()).Returns(new List<Allocation>{allocation});
            var mockChecklistLoader = new Mock<AllocationChecklistRepository>(Mock.Of<AllocationChecklistMapper>(),
                                                                                Mock.Of<AuditLogger<AllocationChecklist>>(), 
                                                                                Mock.Of<AllocationChecklistSequenceProvider>(),
                                                                                Mock.Of<DbRepositoryFactory>());
            var mockChecklistSectionLoader = new Mock<ControlAgreementSectionRepository>(Mock.Of<ControlAgreementSectionMapper>(),
                                                                                Mock.Of<AuditLogger<ControlAgreementSection>>(),
                                                                                Mock.Of<ControlAgreementSectionSequenceProvider>(),
                                                                                Mock.Of<DbRepositoryFactory>());
            var mockChecklistGenerator = new Mock<ChecklistRowGenerator>(User.Loader, EnumValue.Loader,mockChecklistLoader.Object,mockChecklistSectionLoader.Object);
            mockChecklistGenerator.Setup(m => m.GetRow(allocation)).Returns(checklistRow);
            var mockTradeGenerator = new Mock<AllocationRowGenerator>();
            mockTradeGenerator.Setup(m => m.GetRow(allocation)).Returns(tradeRow);
            var generator = new ItbRowsNester(mockFilter.Object, mockTradeGenerator.Object, mockChecklistGenerator.Object);

            //when
            var result = generator.GetAllocationRows();

            //then
            Assert.AreEqual(1, result.Count);
            Assert.AreSame(tradeRow, result[0]);
            Assert.AreSame(checklistRow, result[0].ChecklistRow);
            mockFilter.Verify(m => m.GetAllocationsWithOpenChecklist(), Times.Once());
        }
    }
}
