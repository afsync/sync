using System;
using System.Globalization;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.DataVisualization.Charting;
using Common.Logging;
using HedgeFrontier.Common;
using IFS.BusinessLayer;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.HighChart;
using IFS.BusinessLayer.IFSUser.userPreferences;
using IFS.BusinessLayer.Reports.Liquidity.Layout;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.Liquidity;
using IFS.Interfaces.CloudContracts.Reports;
using IFS.Interfaces.Rounding;
using WebUtilities;
using AntiXssEncoder = Microsoft.Security.Application.Encoder;
using System.Web.UI.WebControls;
using System.Web.Services;

public partial class pages_report_ReportLiquidityProfile : CBasePage
{
    private static readonly ILog _log = LogManager.GetLogger("IFS");
    private const string EXCEL_EXPORT_FILE_NAME = "LiquidityProfile.xlsx";

    protected string ReliefMethod
    {
        get { return IFSSession.Portfolio.ReliefMethodologyString; }
    }

    private int SelectedLayoutId
    {
        get { return ViewState["selectedLayoutId"] != null ? (int) ViewState["selectedLayoutId"] : -1; }
        set { ViewState["selectedLayoutId"] = value; }
    }

    private static IReportLiquidity GetReportLiqudityService()
    {
        return SpringUtil.GetObject<IReportLiquidity>(ServiceNames.REPORT_LIQUIDITY_SERVICE_SPRING_NAME);
    }

    private static List<string> SessionSelectedColumnsIds
    {
        get { return IFSSession.CurrentLiquidityReportLayout.Properties.Columns; }
        set { SetColumns(value); }
    }

    private bool _isPortfolioChanged;

    private int _portfolioId;
    private int SelectedPortfolioId
    {
        get
        {
            if (_portfolioId == 0)
            {
                if (ddlPortfolio.SelectedItem == null || !int.TryParse(ddlPortfolio.SelectedItem.Value, out _portfolioId))
                    _portfolioId = IFSSession.PortfolioId;
                CheckAccessRight(Portfolio.IsPortfolioAccessibleForUser(_portfolioId), CSession.User);
            }
            return _portfolioId;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        _log.Info("ReportLiquidityProfile Page_Load");
        ValidateSinglePortfolioReport();
        chkIncludeGeneralFee.Enabled = !string.IsNullOrEmpty(txtRedFeeUpToAndIncluding.Text);

        if (!Page.IsPostBack)
        {
            SetDefaultContolValues();
        }
    }

    private void SetDefaultContolValues()
    {
        dtSelector.DateTime = dtSelectorOptions.DateTime = DateTime.Today;
        if (SelectedPortfolioId != -1)
        {
            RefreshPortfolioDropdownList();
        }
    }



    private void RefreshPortfolioDropdownList()
    {
        var pageData = GetReportLiqudityService().GetPageData(CSession.GetSessionData());
        if (pageData.Failed)
        {
            _log.Error("Error loading Report Liquidity page data.", pageData.InnerException);
            ErrorLabel.Text = @"Error loading page data.";
            ExMessage.Text = pageData.InnerException.Message;
        }
        else
        {
            BindPortfolios(ddlPortfolio, pageData.Portfolios);
            BindPortfolios(ddlPortfolioOptions, pageData.Portfolios);
        }
    }

    private static void BindPortfolios(ListControl portfolioSelector, List<PortfolioView> portfolioViews)
    {
        portfolioSelector.DataSource = portfolioViews;
        portfolioSelector.SelectedValue = IFSSession.PortfolioId.ToString(CultureInfo.InvariantCulture);
        portfolioSelector.DataBind();
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        //Put state into session
        if (!IsPostBack)
            IFSSession.NextEligible = int.Parse(hdnRefresh.Value);
        if (hdnRefresh.Value != "0")
        {
            IFSSession.NextEligible = IFSSession.NextEligible + int.Parse(hdnRefresh.Value);
            hdnRefresh.Value = "0";
        }
        HighchartsHelper.IncludeJsScript(Page);
        Display();
    }

    private void Display()
    {
        // Set the NextEligible indicator
        if (!IsPostBack)
            PopulateLayouts();

        if (SelectedPortfolioId != -1)
        {
            var selectedDate = dtSelector.DateTime;
            if (selectedDate != IFSSession.OldReportDate)
                IFSSession.NextEligible = 0;

            _isPortfolioChanged = IFSSession.PortfolioId != SelectedPortfolioId;
            IFSSession.PortfolioId = SelectedPortfolioId;

            RefreshReliefMethodMessage();
            RefreshGrid(selectedDate);

            //Set the OldReportDate
            IFSSession.OldReportDate = selectedDate;
        }
    }

    private void RefreshReliefMethodMessage()
    {
        lblReliefMethodWarning.Visible = ReliefMethod == EnumValue.RM_AVERAGE;
    }

    private void RefreshGrid(DateTime selectedDate)
    {
        var requestResult = GetReportLiqudityService().GetReport(new FabricLiquidityReportParameters
        {
            PortfolioId = SelectedPortfolioId,
            AnalisysAsOfDate = selectedDate,
            RedemptionPolicyType = ddlRedemptionPolicyType.ValueInt,
            SessionNextEligible = IFSSession.NextEligible,
            ShouldGenerateGraphData = true,
            SelectedColumnsIds = SessionSelectedColumnsIds,
            SelectedAggregationKeys = GetAggregationKeys(),
            FeeTolerance = GetFeeTolerance(),
            IncludeGeneralRedemptionFee = chkIncludeGeneralFee.Checked
        }, CSession.GetSessionData());

        if (requestResult.Failed)
        {
            _log.Error("Error generating Report Liquidity.", requestResult.InnerException);
            ErrorLabel.Text = @"Error generating Report Liquidity.";
            ExMessage.Text = requestResult.InnerException.Message;
            return;
        }

        hdnGridData.Value = requestResult.ReportXml;
        SessionSelectedColumnsIds = requestResult.ReportColumns.Select(i => i.Key).ToList();

        PopulateAvailableAndSelectedColumns(requestResult);
        hdnPreviousNonPerfectFunds.Value = _isPortfolioChanged ? string.Empty : hdnNonPerfectFunds.Value;
        hdnNonPerfectFunds.Value = GetFundNames(requestResult.NonPerfectFundNames);
        hdnNonPerfectFunds.Value += GetNotConfiguredSidePockets(requestResult);

        PopulateComponents(requestResult.ChartData);

        var reportHelper = new ReportHelper(ViewState);
        reportHelper.StoreInCacheAndGetKey(requestResult.ChartData);
    }

    private List<string> GetAggregationKeys()
    {
        return chkAggregate.Checked ? new List<string> { Attrib.LR_LIQUIDITY_LOT } : new List<string>();
    }

    private double GetFeeTolerance()
    {
        return CPercent.Parse(txtRedFeeUpToAndIncluding.Text).Value;
    }

    private string GetNotConfiguredSidePockets(ReportLiquidityResult requestResult)
    {
        if (requestResult.NonPerfectSidePocketFundNames.Count == 0)
            return "";
        return "</br></br><font color=#000000><b>Side Pocket Positions:</b></font></br>" +
               GetFundNames(requestResult.NonPerfectSidePocketFundNames);
    }

    private string GetFundNames(IEnumerable<string> fundNames)
    {
        return string.Join("", fundNames.Select(name => "<li>" + name + "</li>"));
    }

    private void PopulateAvailableAndSelectedColumns(ReportLiquidityResult reportResult)
    {
        var availableColumns = reportResult.AvailableColumns;
        var selectedColumnsIds = SessionSelectedColumnsIds;

        InitAvailableColumns(availableColumns, selectedColumnsIds);
        InitSelectedColumns(availableColumns, selectedColumnsIds);
    }

    private void InitSelectedColumns(Dictionary<string, string> availableColumns, List<string> selectedColumnsIds)
    {
        lbSelectedColumns.Items.Clear();
        lbSelectedColumns.Items.AddRange(selectedColumnsIds.Select(c => new ListItem(availableColumns[c], c)).ToArray());
        hdnOrderedColumns.Value = string.Join(",", selectedColumnsIds);
    }

    private void InitAvailableColumns(Dictionary<string, string> availableColumns, List<string> selectedColumnsIds)
    {
        ddlAvailableColumns.Items.Clear();
        ddlAvailableColumns.Items.AddRange(GetLiquidityColumnsOrdered(availableColumns, selectedColumnsIds));
    }

    private ListItem[] GetLiquidityColumnsOrdered(Dictionary<string, string> availableColumns, List<string> selectedColumnsIds)
    {
        var columns = availableColumns.OrderBy(t => t.Value).Select(c => GetListItem(c.Value, c.Key, selectedColumnsIds.Contains(c.Key)));
        return columns.ToArray();
    }

    private ListItem GetListItem(string text, string value, bool selected)
    {
        var listItem = new ListItem(text, value) { Selected = selected };
        if (value.Equals(Attrib.LR_FUND_NAME))
            listItem.Attributes.Add("disabled", "disabled");
        return listItem;
    }

    protected void ApplySelectedColumnsClick(object sender, EventArgs e)
    {
        SessionSelectedColumnsIds = hdnOrderedColumns.Value.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
    }


    private void PopulateComponents(ChartGraphData reportData)
    {
        _liquidityHardGraph.Visible = false;
        BindHighChart(reportData);
    }

    private void BindAspnetChart(ChartGraphData reportData)
    {
        if (reportData.Graph2.Count > 0)
        {
            _liquidityHardGraph.ChartAreas[0].AxisY.Maximum = (double)decimal.Round((decimal)reportData.Graph2.Last().GraphPct, 1);
            _liquidityHardGraph.Series["_seriesLiquiditySoftGraph"].Points.DataBind(reportData.Graph2, "GraphDate", "GraphPct", "");
        }

        if (reportData.Graph1.Count > 0)
        {
            _liquidityHardGraph.ChartAreas[0].AxisY.Maximum = (double)decimal.Round((decimal)reportData.Graph1.Last().GraphPct, 1);
            _liquidityHardGraph.Series["_seriesLiquidityHardGraph"].Points.DataBind(reportData.Graph1, "GraphDate", "GraphPct", "");
        }
    }

    protected void BtnExcelExportClick(object sender, EventArgs e)
    {
        try
        {
            var reportParameters = GenerateReportAndGraphExportParameters();
            var exportResult = GenerateExportResult(reportParameters);
            OpenXmlExportHelper.WriteXlsContent(exportResult.Exported, EXCEL_EXPORT_FILE_NAME);
        }
        catch (Exception ex)
        {
            _log.Error("Error generating Report Liquidity Export.", ex);
            CPopup.Alert(Page, "Error generating Export. Please try again.");
        }
    }

    private FabricExportLiquidityReportParameters GenerateReportAndGraphExportParameters()
    {
        var reportParameters = GenerateReportExportParameters();
        reportParameters.ShouldGenerateGraphData = true;
        var chartData = GenerateChartData(reportParameters);
        reportParameters.ChartBitmap = GenerateGraph(chartData);
        reportParameters.ShouldGenerateGraphData = false;
        return reportParameters;
    }

    private FabricExportLiquidityReportParameters GenerateReportExportParameters()
    {
        return new FabricExportLiquidityReportParameters
        {
            PortfolioId = SelectedPortfolioId,
            AnalisysAsOfDate = dtSelector.DateTime,
            RedemptionPolicyType = ddlRedemptionPolicyType.ValueInt,
            SessionNextEligible = IFSSession.NextEligible,
            SelectedColumnsIds = SessionSelectedColumnsIds,
            SelectedAggregationKeys = GetAggregationKeys(),
            FeeTolerance = GetFeeTolerance(),
            IncludeGeneralRedemptionFee = chkIncludeGeneralFee.Checked
        };
    }

    private ChartGraphData GenerateChartData(FabricExportLiquidityReportParameters reportParameters)
    {
        var chartData = new ReportHelper(ViewState).GetReport() as ChartGraphData;
        if (chartData == null)
        {
            var requestResult = GetReportLiqudityService().GetReport(reportParameters, CSession.GetSessionData());
            if (requestResult.Failed)
                throw requestResult.InnerException;

            chartData = requestResult.ChartData;
        }
        return chartData;
    }

    private byte[] GenerateGraph(ChartGraphData chartData)
    {
        var haveGraph = chartData.Graph1.Any() || chartData.Graph2.Any();
        if (haveGraph)
        {
            BindAspnetChart(chartData);
            var graph = new MemoryStream();
            _liquidityHardGraph.SaveImage(graph, ChartImageFormat.Png);
            return graph.ToArray();
        }
        return null;
    }

    private ExportResult GenerateExportResult(FabricExportLiquidityReportParameters reportParameters)
    {
        var exportResult = GetReportLiqudityService().ExportToExcel(reportParameters, CSession.GetSessionData());
        if (exportResult.Failed)
            throw exportResult.InnerException;
        return exportResult;
    }

    [WebMethod(EnableSession = true)]
    public static string LayoutNameExists(string enteredName)
    {
        var util = new LiquidityLayoutUtil();
        var layouts = util.GetUserLayouts(CSession.UserID);
        return layouts.Exists(l => l.Layout.Name == enteredName).ToString();
    }

    private void BindHighChart(ChartGraphData reportData)
    {
        var data = new HighchartsData(reportData);
        _graphMaxY.Text = data.GetMaxYValue();
        _graph1Data.Text = data.GetDataForChart1();
        _graph2Data.Text = data.GetDataForChart2();
    }

    protected void btnOptionsSubmit_OnClick(object sender, EventArgs e)
    {
        dtSelector.DateTime = dtSelectorOptions.DateTime;
        ddlPortfolio.SelectedValue = ddlPortfolioOptions.SelectedValue;
        ddlRedemptionPolicyType.Value = ddlRedemptionPolicyTypeOptions.Value;

        var feeTolerance = txtRedFeeUpToAndIncluding.Text;
        var isGeneralFeeIncluded = chkIncludeGeneralFee.Checked.ToString(CultureInfo.InvariantCulture);

        hdnFeeTolerance.Value = feeTolerance;
        hdnIncludeGeneralFee.Value = isGeneralFeeIncluded;
    }

    protected void DateChangedOnThePage(object sender, EventArgs e)
    {
        dtSelectorOptions.DateTime = dtSelector.DateTime;
    }

    protected void PortfolioChangedOnThePage(object sender, EventArgs e)
    {
        ddlPortfolioOptions.SelectedValue = ddlPortfolio.SelectedValue;
    }

    protected void RedemptionPolicyTypeChangedOnThePage(object sender, EventArgs e)
    {
        ddlRedemptionPolicyTypeOptions.Value = ddlRedemptionPolicyType.Value;
    }

    protected void btnLayoutSubmit_OnClick(object sender, EventArgs e)
    {
        var newLayoutName = txtLayoutName.Text;
        var selectedColumns = hdnOrderedColumns.Value;
        var util = new LiquidityLayoutUtil();
        var layout = util.CreateNewLayout(newLayoutName, selectedColumns, CSession.UserID);
        SelectedLayoutId = util.SaveLayout(layout);
        PopulateLayouts();
    }

    protected void ddlLayouts_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        SelectedLayoutId = int.Parse(ddlLayouts.SelectedValue);
        var layouts = GetLayouts();
        SetSessionLayout(layouts, SelectedLayoutId);
    }

    protected void btnDeleteLayout_OnClick(object sender, EventArgs e)
    {
        var deletedLayoutId = int.Parse(ddlLayouts.SelectedValue);
        var util = new LiquidityLayoutUtil();
        util.DeleteLayout(deletedLayoutId, CSession.UserID);
        SelectedLayoutId = -1;
        PopulateLayouts();
    }

    private void PopulateLayouts()
    {
        var layouts = GetLayouts();
        ddlLayouts.DataSource = from l in layouts select new { l.Layout.Id, l.Layout.Name };
        ddlLayouts.DataBind();
        SetSessionLayout(layouts, SelectedLayoutId);
    }

    [WebMethod(EnableSession = true)]
    public static string SaveLayout(string layoutId)
    {
        var currentLayout = IFSSession.CurrentLiquidityReportLayout;
        var util = new LiquidityLayoutUtil();
        util.SaveLayout(currentLayout);
        return "Succeeded";
    }

    private void SetSessionLayout(List<LiquidityLayout> layouts, int selectedLayoutId)
    {
        IFSSession.CurrentLiquidityReportLayout = selectedLayoutId != -1
            ? layouts.Find(l => l.Layout.Id == selectedLayoutId)
            : layouts[0];
        ddlLayouts.SelectedValue = IFSSession.CurrentLiquidityReportLayout.Layout.Id.ToString();
    }


    private List<LiquidityLayout> GetLayouts()
    {
        var saver = new LiquidityLayoutUtil();
        return saver.GetUserLayouts(CSession.UserID);
    }

    private static void SetColumns(List<string> columns)
    {
        var saver = new LiquidityLayoutUtil();
        IFSSession.CurrentLiquidityReportLayout = saver.SaveColumnsToLayout(IFSSession.CurrentLiquidityReportLayout,
            columns);
    }

    [WebMethod(EnableSession = true)]
    public static void ReorderColumns(string firstColumn, string nextColumn)
    {
        var columns = new List<string>(SessionSelectedColumnsIds);
        var util = new LiquidityLayoutUtil();
        columns = util.RearrangeColumns(columns, nextColumn, firstColumn);
        SessionSelectedColumnsIds = columns;
    }

    [WebMethod(EnableSession = true)]
    public static void RemoveColumn(string column)
    {
        SessionSelectedColumnsIds.Remove(column);
    }

    [WebMethod(EnableSession = true)]
    public static string GetSessionColumns()
    {
        return string.Join(",", SessionSelectedColumnsIds);
    }

    
}