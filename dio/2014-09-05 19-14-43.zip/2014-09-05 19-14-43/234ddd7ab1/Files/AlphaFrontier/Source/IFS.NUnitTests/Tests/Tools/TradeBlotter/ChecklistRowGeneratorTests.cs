﻿using System;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.FundProperty.PortfolioProperty;
using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Repository.Checklists;
using IFS.Interfaces.Factories;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ChecklistRowGeneratorTests
    {
        private const int ALLOCATION_ID = 12345;
        private const int CHECKLIST_ID = 67890;

        [Test]
        public void TestGetRowVerifyCreditProviderField()
        {
            //given
            var creditProviderProperties = new CreditProviderProperties
                                     {
                                         CreditProviderName = "Credit Provider 12354",
                                         PerformedBy = 1
                                     };
            var allocation = GetAllocation(creditProviderProperties);
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, GetChecklistRepository(), checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual("Credit Provider 12354", result.CreditProvider);
            Assert.AreEqual("FirstName LastName", result.CreditProviderBy);
        }


        [Test]
        public void TestGetRowVerifyTypeOfNoticeField()
        {
            //given
            var creditProviderProperties = new CreditProviderProperties
            {
                NoticeType = 8,
                PerformedBy = 1
            };
            var allocation = GetAllocation(creditProviderProperties);
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual("Test", result.TypeOfNotice);
            Assert.AreEqual("FirstName LastName", result.TypeOfNoticeBy);
        }

        [Test]
        public void TestGetRowVerifyEffectiveDateField()
        {
            //given
            //given
            var creditProviderProperties = new CreditProviderProperties
            {
                NoticeDate = new DateTime(2014, 1, 15),
                PerformedBy = 1
            };
            var allocation = GetAllocation(creditProviderProperties);
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual(new DateTime(2014, 1, 15), result.EffectiveDate);
            Assert.AreEqual("FirstName LastName", result.EffectiveDateBy);
        }


        [Test]
        public void TestGetRowVerifyCommentsField()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, "SomeComments", 1, null, null, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, GetChecklistRepository(), checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual("SomeComments", result.Comments);
            Assert.AreEqual("FirstName LastName", result.CommentsBy);
        }


        [Test]
        public void TestGetRowVerifyConfirmedField()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var moclChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, new DateTime(2014, 8, 15), 1, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(moclChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual(new DateTime(2014, 8, 15), result.ConfirmedDate);
            Assert.AreEqual("FirstName LastName", result.ConfirmedBy);
        }

        [Test]
        public void TestGetRowVerifyReviewedField()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, new DateTime(2014, 8, 15), 1);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual(new DateTime(2014, 8, 15), result.ReviewedDate);
            Assert.AreEqual("FirstName LastName", result.ReviewedBy);
        }

        [Test]
        public void TestGetRowVerifyChecklistIdField()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, CHECKLIST_ID, null, null, null, null, null, null);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.AreEqual(CHECKLIST_ID, result.ChecklistId);
        }

        [Test]
        public void TestGetRowVerifyIsControlAgreementSectionEditableFieldIsTrue()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            mockChecklistSection.Setup(c => c.AreConfirmedAndCommentsFieldsEnabled()).Returns(true);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.IsTrue(result.IsControlAgreementSectionEditable);
        }

        [Test]
        public void TestGetRowVerifyIsControlAgreementSectionEditableFieldIsFalse()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            mockChecklistSection.Setup(c => c.AreConfirmedAndCommentsFieldsEnabled()).Returns(false);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader,GetChecklistRepository(),checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.IsFalse(result.IsControlAgreementSectionEditable);
        }

        [Test]
        public void TestGetRowVerifyIsReviewedEditableIsFalse()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            mockChecklistSection.Setup(c => c.IsReviewedFieldEnabled()).Returns(false);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, GetChecklistRepository(), checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.IsFalse(result.IsReviewedEditable);
        }

        [Test]
        public void TestGetRowVerifyIsReviewedEditableIsTrue()
        {
            //given
            var allocation = GetAllocation(new CreditProviderProperties());
            var mockChecklistSection = new Mock<ControlAgreementSection>(null, null, null, null, null, null, null, null);
            mockChecklistSection.Setup(c => c.IsReviewedFieldEnabled()).Returns(true);
            var checklistSectionLoader = GetChecklistSectionRepository(mockChecklistSection.Object);
            var generator = new ChecklistRowGenerator(User.Loader, EnumValue.Loader, GetChecklistRepository(), checklistSectionLoader);

            //when
            var result = generator.GetRow(allocation);

            //then
            Assert.IsTrue(result.IsReviewedEditable);
        }

        private Allocation GetAllocation(CreditProviderProperties creditProviderProperties)
        {
            var portfolioProperties = Mock.Of<PortfolioProperties>(pp => pp.CreditProvider == creditProviderProperties);
            var portfolio = Mock.Of<Portfolio>(p => p.PortfolioProperties == portfolioProperties);
            var investement = Mock.Of<Investment>(i => i.Portfolio == portfolio);

            var allocation = Mock.Of<Allocation>(a => a.Investment == investement);
            allocation.AllocationID = ALLOCATION_ID;
            return allocation;
        }

        private AllocationChecklistRepository GetChecklistRepository()
        {
            var checklist = new AllocationChecklist(CHECKLIST_ID, ALLOCATION_ID, 0, DateTime.MinValue, 0, DateTime.MinValue,0);
            var repository = new Mock<AllocationChecklistRepository>(Mock.Of<AllocationChecklistMapper>(),
                Mock.Of<AuditLogger<AllocationChecklist>>(), Mock.Of<AllocationChecklistSequenceProvider>(),
                Mock.Of<DbRepositoryFactory>());
            repository.Setup(r => r.GetByAllocationId(ALLOCATION_ID)).Returns(checklist);
            return repository.Object;
        }

        private ControlAgreementSectionRepository GetChecklistSectionRepository(ControlAgreementSection checklistSection)
        {
            var repository = new Mock<ControlAgreementSectionRepository>(Mock.Of<ControlAgreementSectionMapper>(),
                Mock.Of<AuditLogger<ControlAgreementSection>>(), Mock.Of<ControlAgreementSectionSequenceProvider>(),
                Mock.Of<DbRepositoryFactory>());
            repository.Setup(r => r.GetByChecklistId(CHECKLIST_ID)).Returns(checklistSection);
            return repository.Object;
        }
    }
}
