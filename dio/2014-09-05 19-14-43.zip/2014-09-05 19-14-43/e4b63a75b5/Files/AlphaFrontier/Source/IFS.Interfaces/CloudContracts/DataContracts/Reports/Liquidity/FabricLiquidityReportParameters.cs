﻿using System;
using System.Collections.Generic;

namespace IFS.Interfaces.CloudContracts.DataContracts.Reports.Liquidity
{
    [Serializable]
    public class FabricLiquidityReportParameters
    {
        public int PortfolioId { get; set; }
        public DateTime AnalisysAsOfDate { get; set; }
        public int SessionNextEligible { get; set; }
        public int RedemptionPolicyType { get; set; }
        public bool ShouldGenerateGraphData { get; set; }
        public List<string> SelectedColumnsIds { get; set; }
        public List<string> SelectedAggregationKeys { get; set; }
        public double FeeTolerance { get; set; }
        public bool IncludeGeneralRedemptionFee { get; set; }
    }
}