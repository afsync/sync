﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Reports.Liquidity.LiquidityColumns;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.Liquidity;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Reports.Liquidity.LiquidityColumns
{
    [TestFixture]
    public class LiquidityGridColumnsGeneratorTests
    {
        [Test]
        public void TestGetReportColumnsWithDefaultStaticOnlyColumns()
        {
            //Given
            var expected = GetStaticColumnNames();
            var gridColumnsGenerator = new LiquidityGridColumnsGenerator();

            //When
            var result = gridColumnsGenerator.GetReportColumns(new FabricLiquidityReportParameters { SelectedColumnsIds = new List<string>()}, 0);

            //Then 
            CollectionAssert.AreEqual(expected, result.DefaultColumns);
        }

        [Test]
        public void TestGetReportColumnsWithDefaultDynamicColumnsWhenSelectedListIsEmpty()
        {
            //Given
            var expected = GetStaticColumnNames();
            expected.Add("PaymentPctRed1", "Payment % Redem 1");
            expected.Add("PaymentDate1","Payment date 1");
            expected.Add("PaymentPctRed2", "Payment % Redem 2");
            expected.Add("PaymentDate2","Payment date 2");
            expected.Add("PaymentPctRed3","Payment % Redem 3");
            expected.Add("PaymentDate3", "Payment date 3");

            var gridColumnsGenerator = new LiquidityGridColumnsGenerator();

            //When
            var result = gridColumnsGenerator.GetReportColumns(new FabricLiquidityReportParameters { SelectedColumnsIds = new List<string>() }, 3);

            //Then 
            CollectionAssert.AreEqual(expected, result.DefaultColumns);
        }

        [Test]
        public void TestGetReportColumnsWithDefaultDynamicColumnsWhenPortfolioChanged()
        {
            //Given
            var expected = GetStaticColumnNames();
            expected.Add("PaymentPctRed1", "Payment % Redem 1");
            expected.Add("PaymentDate1", "Payment date 1");
            expected.Add("PaymentPctRed2", "Payment % Redem 2");
            expected.Add("PaymentDate2", "Payment date 2");
            expected.Add("PaymentPctRed3", "Payment % Redem 3");
            expected.Add("PaymentDate3", "Payment date 3");

            var selected = new List<string> { "PaymentPctRed2" };

            var gridColumnsGenerator = new LiquidityGridColumnsGenerator();

            //When
            var result = gridColumnsGenerator.GetReportColumns(new FabricLiquidityReportParameters { SelectedColumnsIds = selected }, 3);

            //Then 
            CollectionAssert.AreEqual(expected, result.DefaultColumns);
        }

        [Test]
        public void TestGetReportColumnsWithWithoutDynamicSections()
        {
            //Given
            var selected = new List<string>
            {
                "FundName",
                "Currency",
                "RedPolicyType",
                "RedemptionMethod",
                "OriginalCost",
                "AmountBase",
                "LockupType",
                "LockupExpiredate",
                "Expirationdateredemptionallowed",
                "GeneralRedemFeePct",
                "GeneralRedemFeeCur",
                "AcceleratedRedemFeePct",
                "NextEligibleRedemDate",
                "NoticeDays",
                "DaystoGiveNotice",
                "PaymentPctRed1",
                "PaymentDate1",
                "PaymentPctRed2",
                "PaymentDate2",
                "PaymentPctRed3",
                "PaymentDate3",
            };
            var expected = new Dictionary<string, string>
            {
                {"FundName", "Fund Name"},
                {"Currency", "Currency"},
                {"RedPolicyType", "Red Policy Type"},
                {"RedemptionMethod", "Redemption Method"},
                {"OriginalCost", "Original Cost"},
                {"AmountBase", "Current Cost"},
                {"LockupType", "Lockup Type"},
                {"LockupExpiredate", "Lockup Expire date"},
                {"Expirationdateredemptionallowed", "Expiration date redemption allowed"},
                {"GeneralRedemFeePct", "General Redem Fee %"},
                {"GeneralRedemFeeCur", "General Redem Fee $"},
                {"AcceleratedRedemFeePct", "Accelerated Redem Fee %"},
                {"NextEligibleRedemDate", "Next Eligible Redem Date"},
                {"NoticeDays", "Notice Days"},
                {"DaystoGiveNotice", "Days to Give Notice (Calendar)"}
            };
            var gridColumnsGenerator = new LiquidityGridColumnsGenerator();

            //When
            var result = gridColumnsGenerator.GetReportColumns(
                new FabricLiquidityReportParameters { SelectedColumnsIds = selected }, 0);

            //Then
            CollectionAssert.AreEqual(expected, result.CurrentReportColumns);
        }

        [Test]
        public void TestGetReportColumnsWithCurrentReportColumnsWhenPortolioChanged()
        {
            //Given
            var selected = new List<string>
            {
                "FundName",
                "Currency",
                "RedPolicyType",
                "RedemptionMethod",
                "OriginalCost",
                "AmountBase",
                "LockupType",
                "LockupExpiredate",
                "Expirationdateredemptionallowed",
                "GeneralRedemFeePct",
                "GeneralRedemFeeCur",
                "AcceleratedRedemFeePct",
                "NextEligibleRedemDate",
                "NoticeDays",
                "DaystoGiveNotice",
                "PaymentPctRed1",
                "PaymentDate1",
                "PaymentPctRed2",
                "PaymentDate2",
                "PaymentPctRed3",
                "PaymentDate3",
            };
            var expected = new Dictionary<string, string>
            {
                {"FundName", "Fund Name"},
                {"Currency", "Currency"},
                {"RedPolicyType", "Red Policy Type"},
                {"RedemptionMethod", "Redemption Method"},
                {"OriginalCost", "Original Cost"},
                {"AmountBase", "Current Cost"},
                {"LockupType", "Lockup Type"},
                {"LockupExpiredate", "Lockup Expire date"},
                {"Expirationdateredemptionallowed", "Expiration date redemption allowed"},
                {"GeneralRedemFeePct", "General Redem Fee %"},
                {"GeneralRedemFeeCur", "General Redem Fee $"},
                {"AcceleratedRedemFeePct", "Accelerated Redem Fee %"},
                {"NextEligibleRedemDate", "Next Eligible Redem Date"},
                {"NoticeDays", "Notice Days"},
                {"DaystoGiveNotice", "Days to Give Notice (Calendar)"},
                {"PaymentPctRed1","Payment % Redem 1"},
                {"PaymentDate1","Payment date 1"}
            };
            var gridColumnsGenerator = new LiquidityGridColumnsGenerator();

            //When
            var result = gridColumnsGenerator.GetReportColumns(
                new FabricLiquidityReportParameters { SelectedColumnsIds = selected}, 
                1);

            //Then
            CollectionAssert.AreEqual(expected, result.CurrentReportColumns);
        }

        private static Dictionary<string, string> GetStaticColumnNames()
        {
            return new Dictionary<string, string>
            {
                {"FundName", "Fund Name"},
                {"Currency", "Currency"},
                {"RedPolicyType", "Red Policy Type"},
                {"RedemptionMethod", "Redemption Method"},
                {"OriginalCost", "Original Cost"},
                {"AmountBase", "Current Cost"},
                {"Date", "Investment Date"},
                {"MarketValueBase", "Market Value Base"},
                {"AmountRedeemedITD", "Amount redeemed MV ITD"},
                {"PercentRedeemedITD", "% Redeemed ITD"},
                {"MaxRedemption", "Max Redemption"},
                {"asof", "as of"},
                {"LockupExpired", "Lockup Expired"},
                {"LockupType", "Lockup Type"},
                {"LockupExpiredate", "Lockup Expire date"},
                {"Expirationdateredemptionallowed", "Expiration date redemption allowed"},
                {"SoftLockRedemFeePct", "Soft Lock Redem Fee %"},
                {"SoftLockRedemFeeCur", "Soft Lock Redem Fee $"},
                {"GeneralRedemFeePct", "General Redem Fee %"},
                {"GeneralRedemFeeCur", "General Redem Fee $"},
                {"AcceleratedRedemFeePct", "Accelerated Redem Fee %"},
                {"AcceleratedRedemFeeCur", "Accelerated Redem Fee $"},
                {"Gate", "Gate"},
                {"DaystoLockupExp", "Days to Lockup Exp (Calendar)"},
                {"Liquidity", "Liquidity"},
                {"NextEligibleRedemDate", "Next Eligible Redem Date"},
                {"NoticeDays", "Notice Days"},
                {"DatetoGiveNotice", "Date to Give Notice"},
                {"DaystoGiveNotice", "Days to Give Notice (Calendar)"}
            };
        }

    }
}