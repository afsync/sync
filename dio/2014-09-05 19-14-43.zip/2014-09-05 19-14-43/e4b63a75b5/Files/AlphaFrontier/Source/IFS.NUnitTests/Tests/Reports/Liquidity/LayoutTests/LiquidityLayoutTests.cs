﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.IFSUser.userPreferences;
using IFS.BusinessLayer.Reports.Liquidity.Layout;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Reports.Liquidity.LayoutTests
{
    [TestFixture]
    public class LiquidityLayoutTests
    {
        [Test]
        public void TestLiquidityLayoutConstructor()
        {
            var meta = new LayoutMetadata(-1, string.Empty, -1);
            var cols = new LiquidityLayoutProperties(-1, -1, null);
            var layout = new LiquidityLayout(meta, cols);

            Assert.That(layout.Layout, Is.EqualTo(meta));
            Assert.That(layout.Properties, Is.EqualTo(cols));
        }

        [Test]
        public void TestLayoutMetadataGetAuditXml()
        {
            var layout = new LayoutMetadata(34, "test", 18);
            var str = layout.GetAuditXml();

            Assert.That(str, Is.EqualTo("<Audit><Id>34</Id><Name>test</Name><Owner>18</Owner></Audit>"));
        }

        [Test]
        public void TestLiquidityPropertiesGetAuditXml()
        {
            var layout = new LiquidityLayoutProperties(1, 11, new List<string> { "c1", "c2" });
            var str = layout.GetAuditXml();

            Assert.That(str, Is.EqualTo("<Audit><Id>1</Id><layoutMetaDataId>11</layoutMetaDataId><Cols>c1, c2</Cols></Audit>"));
        }

        [Test]
        public void TestCreateLiquidityLayoutProperties()
        {
            var layoutProperties = new LiquidityLayoutProperties(1, 11, new List<string>() {"col1"});
            Assert.That(layoutProperties.Id,Is.EqualTo(1));
            Assert.That(layoutProperties.LayoutMetaDataId,Is.EqualTo(11));
            Assert.That(layoutProperties.Columns[0],Is.EqualTo("col1"));
        }

        [Test]
        public void TestDefaultLiquidityLayout()
        {
            var saver = new LiquidityLayoutUtil();
            var layout = saver.GetDefaultLayout(1);

            var columns = new List<string>()
            {
                Attrib.LR_FUND_NAME,
                Attrib.LR_CURRENCY,
                Attrib.LR_RED_POLICY_TYPE,
                Attrib.LR_RED_METHOD,
                Attrib.LR_ORIGINAL_COST,
                Attrib.LR_AMOUNT,
                Attrib.LR_INVESTMENT_DATE,
                Attrib.LR_MARKET_VALUE,
                Attrib.LR_AMOUNT_REDEEMED_ITD,
                Attrib.LR_PERCENT_REDEEMED_ITD,
                Attrib.LR_MAX_REDEMPTION,
                Attrib.LR_AS_OF,
                Attrib.LR_LOCKUP_EXPIRED,
                Attrib.LR_LOCKUP_TYPE,
                Attrib.LR_LOCKUP_EXPIRE_DATE,
                Attrib.LR_EXPIRATION_DATE_REDEMPTION_ALLOWED,
                Attrib.LR_SOFT_LOCK_REDEM_FEE_PCT,
                Attrib.LR_GENERAL_REDEM_FEE_PCT,
                Attrib.LR_ACCELERATED_REDEM_FEE_PCT,
                Attrib.LR_SOFR_LOCK_REDEM_FEE,
                Attrib.LR_GENERAL_REDEM_FEE,
                Attrib.LR_ACCELERATED_REDEM_FEE,
                Attrib.LR_GATE,
                Attrib.LR_DAYS_LOCKUP_EXP,
                Attrib.LR_LIQUIDITY,
                Attrib.LR_NEXT_REDEM_DATE,
                Attrib.LR_NOTICE_DAYS,
                Attrib.LR_DATE_TO_GIVE_NOTICE,
                Attrib.LR_DAYS_TO_GIVE_NOTICE
            };

            Assert.That(layout.Layout.Name, Is.EqualTo("Default"));
            Assert.That(layout.Layout.OwnerId, Is.EqualTo(1));
            Assert.That(layout.Properties.Columns,Is.EqualTo(columns));
        }

        [Test]
        public void TestDefaultDoesNotContainPaymentColumns()
        {
            //when
            var saver = new LiquidityLayoutUtil();
            var layout = saver.GetDefaultLayout(1);

            //then
            Assert.That(layout.Properties.Columns.Any(c=>c.StartsWith(Attrib.LR_PAYMENT_DATE)), Is.False);
            Assert.That(layout.Properties.Columns.Any(c => c.StartsWith(Attrib.LR_PAYMENT_PCT_REDEM)), Is.False);
        }

        [Test]
        public void TestSavingNewColumnSelection()
        {
            var saver = new LiquidityLayoutUtil();
            var metaData = new LayoutMetadata(1, "Name", 11);
            var properties = new LiquidityLayoutProperties(11, 1, new List<string> {"col1"});
            var liquidityLayout = new LiquidityLayout(metaData, properties);

            var newLiquidityLayout = saver.SaveColumnsToLayout(liquidityLayout, new List<string>() {"col1", "col2"});

            Assert.That(newLiquidityLayout.Properties.Columns.Count, Is.EqualTo(2));
        }
    }
}