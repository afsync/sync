﻿using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Audit;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.IFSUser.userPreferences;
using IFS.BusinessLayer.Repository.Liquidity;
using IFS.DataAccess.Entity.Layout;
using IFS.Interfaces.Factories;

namespace IFS.BusinessLayer.Reports.Liquidity.Layout
{
    public class LiquidityLayoutUtil
    {
        public int SaveLayout(LiquidityLayout layout)
        {
            var metaDataSeqProvider = new GenericSequenceProvider<LayoutMetaDataSequenceData>();
            var propertiesSeqProvider = new GenericSequenceProvider<LiquidityLayoutPropertiesSequenceData>();

            var metaDataAuditLogger = new AuditLogger<LayoutMetadata>();
            var propertiesAuditLogger = new AuditLogger<LiquidityLayoutProperties>();

            var bulkSaveData = new BulkSaveData();

            var blRep = new LiquidityLayoutRepository(metaDataSeqProvider, propertiesSeqProvider,
                new LayoutMetaDataMapper(), new LiquidityLayoutPropertiesMapper(), metaDataAuditLogger,
                propertiesAuditLogger);

            var savedLayoutId = blRep.Save(layout, bulkSaveData);
            bulkSaveData.SubmitChanges();
            return savedLayoutId;
        }

        public LiquidityLayout GetDefaultLayout(int ownerId)
        {
            var metaData = new LayoutMetadata(-1, "Default", ownerId);
            var properties = new LiquidityLayoutProperties(-1, -1, GetColumns());
            var layout = new LiquidityLayout(metaData, properties);
            return layout;
        }

        private List<string> GetColumns()
        {
            return new List<string>()
            {
                Attrib.LR_FUND_NAME,
                Attrib.LR_CURRENCY,
                Attrib.LR_RED_POLICY_TYPE,
                Attrib.LR_RED_METHOD,
                Attrib.LR_ORIGINAL_COST,
                Attrib.LR_AMOUNT,
                Attrib.LR_INVESTMENT_DATE,
                Attrib.LR_MARKET_VALUE,
                Attrib.LR_AMOUNT_REDEEMED_ITD,
                Attrib.LR_PERCENT_REDEEMED_ITD,
                Attrib.LR_MAX_REDEMPTION,
                Attrib.LR_AS_OF,
                Attrib.LR_LOCKUP_EXPIRED,
                Attrib.LR_LOCKUP_TYPE,
                Attrib.LR_LOCKUP_EXPIRE_DATE,
                Attrib.LR_EXPIRATION_DATE_REDEMPTION_ALLOWED,
                Attrib.LR_SOFT_LOCK_REDEM_FEE_PCT,
                Attrib.LR_GENERAL_REDEM_FEE_PCT,
                Attrib.LR_ACCELERATED_REDEM_FEE_PCT,
                Attrib.LR_SOFR_LOCK_REDEM_FEE,
                Attrib.LR_GENERAL_REDEM_FEE,
                Attrib.LR_ACCELERATED_REDEM_FEE,
                Attrib.LR_GATE,
                Attrib.LR_DAYS_LOCKUP_EXP,
                Attrib.LR_LIQUIDITY,
                Attrib.LR_NEXT_REDEM_DATE,
                Attrib.LR_NOTICE_DAYS,
                Attrib.LR_DATE_TO_GIVE_NOTICE,
                Attrib.LR_DAYS_TO_GIVE_NOTICE
            };
        }

        public LiquidityLayout SaveColumnsToLayout(LiquidityLayout liquidityLayout, List<string> list)
        {
            var mapper = new LiquidityLayoutPropertiesMapper();
            var properties = mapper.UpdateColumns(liquidityLayout.Properties, list);
            return new LiquidityLayout(liquidityLayout.Layout, properties);
        }

        public List<LiquidityLayout> GetUserLayouts(int ownerId)
        {
            var blRep = new LiquidityLayoutBlRepository(new DbRepositoryFactory());
            var layouts = blRep.GetUserLayouts(ownerId);
            if(layouts.Count == 0)
                layouts = new List<LiquidityLayout>{GetDefaultLayout(ownerId)};
            return layouts;
        }

        public LiquidityLayout CreateNewLayout(string name, string columns, int ownerId)
        {
            var metadata = new LayoutMetadata(-1, name, ownerId);
            var columnsList = columns.Split(',').ToList();
            var properties = new LiquidityLayoutProperties(-1, -1, columnsList);
            return new LiquidityLayout(metadata, properties);
        }

        public List<string> RearrangeColumns(List<string> columns, string movedColumn, string previousColumn)
        {
            if (columns.Contains(movedColumn))
                columns.Remove(movedColumn);

            int index = columns.LastIndexOf(previousColumn);
            columns.Insert(index + 1, movedColumn);
            return columns;
        }

        public void DeleteLayout(int layoutId, int ownerId)
        {
            var metaDataSeqProvider = new GenericSequenceProvider<LayoutMetaDataSequenceData>();
            var propertiesSeqProvider = new GenericSequenceProvider<LiquidityLayoutPropertiesSequenceData>();

            var metaDataAuditLogger = new AuditLogger<LayoutMetadata>();
            var propertiesAuditLogger = new AuditLogger<LiquidityLayoutProperties>();

            var bulkSaveData = new BulkSaveData();

            var blRep = new LiquidityLayoutRepository(metaDataSeqProvider, propertiesSeqProvider,
                new LayoutMetaDataMapper(), new LiquidityLayoutPropertiesMapper(), metaDataAuditLogger,
                propertiesAuditLogger);

            var layouts = GetUserLayouts(ownerId);
            var deleteLayout = layouts.Find(l => l.Layout.Id == layoutId);
            if (deleteLayout != null)
            {
                blRep.Delete(deleteLayout, bulkSaveData);
                bulkSaveData.SubmitChanges();
            }
        }
    }
}
