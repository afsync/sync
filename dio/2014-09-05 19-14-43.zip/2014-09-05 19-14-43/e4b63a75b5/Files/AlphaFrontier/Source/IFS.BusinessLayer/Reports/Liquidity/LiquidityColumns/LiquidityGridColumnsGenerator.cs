using System.Collections.Generic;
using System.Linq;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.Liquidity;

namespace IFS.BusinessLayer.Reports.Liquidity.LiquidityColumns
{
    public class LiquidityGridColumns
    {
        public Dictionary<string, string> DefaultColumns { get; set; }
        public Dictionary<string, string> CurrentReportColumns { get; set; }
    }

    public class LiquidityGridColumnsGenerator
    {
        public virtual LiquidityGridColumns GetReportColumns(FabricLiquidityReportParameters reportParameters, int dynamicSectionCount)
        {
            var availableColumns = GetAvailableColumns(dynamicSectionCount);
            var visibleColumns = GetSelectedColumns(reportParameters, availableColumns);
            return new LiquidityGridColumns
            {
                DefaultColumns = availableColumns,
                CurrentReportColumns = visibleColumns
            };
        }

        private Dictionary<string, string> GetAvailableColumns(int dynamicSectionCount)
        {
            var availableColumns = GetDefaultColumnsNamesBySectionCount(dynamicSectionCount);
            return availableColumns;
        }

        private Dictionary<string, string> GetSelectedColumns(FabricLiquidityReportParameters reportParameters, Dictionary<string, string> availableColumns)
        {
            return !reportParameters.SelectedColumnsIds.Any()
                    ? availableColumns
                    : GetColumnNamesByColumnKeys(GetSelectedColumnsKeys(reportParameters, availableColumns), availableColumns);
        }

        private IEnumerable<string> GetSelectedColumnsKeys(FabricLiquidityReportParameters reportParameters, Dictionary<string, string> availableColumns)
        {
            return GetColumnKeysCommonWithAvailableColumns(reportParameters.SelectedColumnsIds, availableColumns);
        }

        private Dictionary<string, string> GetColumnNamesByColumnKeys(IEnumerable<string> selectedColumnsKeys, Dictionary<string, string> availableColumns)
        {
            return selectedColumnsKeys
                .Where(availableColumns.ContainsKey)
                .ToDictionary(key => key, key => availableColumns[key]);
        }

        private  IEnumerable<string> GetColumnKeysCommonWithAvailableColumns(IEnumerable<string> selectedColumnsKeys, Dictionary<string, string> availableColumns)
        {
            var availableColumnsKeys = availableColumns.Keys;
            var columnsKeys = selectedColumnsKeys.Intersect(availableColumnsKeys).ToList();
            var availableDynamicColumns = availableColumnsKeys.Where(c => c.StartsWith(Attrib.LR_PAYMENT_DATE) || c.StartsWith(Attrib.LR_PAYMENT_PCT_REDEM));
            return columnsKeys.Union(availableDynamicColumns);
        }

        private Dictionary<string, string> GetDefaultColumnsNamesBySectionCount(int dynamicSectionCount)
        {
            var columns = GetStaticColumnNames();
            for (var i = 1; i <= dynamicSectionCount; i++)
                AddDynamicSection(columns, i);
            return columns;
        }

        private Dictionary<string, string> GetStaticColumnNames()
        {
            var columns = new Dictionary<string, string>
            {
                {Attrib.LR_FUND_NAME, "Fund Name"},
                {Attrib.LR_CURRENCY, "Currency"},
                {Attrib.LR_RED_POLICY_TYPE, "Red Policy Type"},
                {Attrib.LR_RED_METHOD, "Redemption Method"},
                {Attrib.LR_ORIGINAL_COST, "Original Cost"},
                {Attrib.LR_AMOUNT, "Current Cost"},
                {Attrib.LR_INVESTMENT_DATE, "Investment Date"},
                {Attrib.LR_MARKET_VALUE, "Market Value Base"},
                {Attrib.LR_AMOUNT_REDEEMED_ITD, "Amount redeemed MV ITD"},
                {Attrib.LR_PERCENT_REDEEMED_ITD, "% Redeemed ITD"},
                {Attrib.LR_MAX_REDEMPTION, "Max Redemption"},
                {Attrib.LR_AS_OF, "as of"},
                {Attrib.LR_LOCKUP_EXPIRED, "Lockup Expired"},
                {Attrib.LR_LOCKUP_TYPE, "Lockup Type"},
                {Attrib.LR_LOCKUP_EXPIRE_DATE, "Lockup Expire date"},
                {Attrib.LR_EXPIRATION_DATE_REDEMPTION_ALLOWED, "Expiration date redemption allowed"},
                {Attrib.LR_SOFT_LOCK_REDEM_FEE_PCT, "Soft Lock Redem Fee %"},
                {Attrib.LR_GENERAL_REDEM_FEE_PCT, "General Redem Fee %"},
                {Attrib.LR_ACCELERATED_REDEM_FEE_PCT, "Accelerated Redem Fee %"},
                {Attrib.LR_SOFR_LOCK_REDEM_FEE, "Soft Lock Redem Fee $"},
                {Attrib.LR_GENERAL_REDEM_FEE, "General Redem Fee $"},
                {Attrib.LR_ACCELERATED_REDEM_FEE, "Accelerated Redem Fee $"},
                {Attrib.LR_GATE, "Gate"},
                {Attrib.LR_DAYS_LOCKUP_EXP, "Days to Lockup Exp (Calendar)"},
                {Attrib.LR_LIQUIDITY, "Liquidity"},
                {Attrib.LR_NEXT_REDEM_DATE, "Next Eligible Redem Date"},
                {Attrib.LR_NOTICE_DAYS, "Notice Days"},
                {Attrib.LR_DATE_TO_GIVE_NOTICE, "Date to Give Notice"},
                {Attrib.LR_DAYS_TO_GIVE_NOTICE, "Days to Give Notice (Calendar)"},
            };
            return columns;
        }

        private void AddDynamicSection(IDictionary<string, string> columns, int sectionNumber)
        {
            AddDynamicRedemColumn(columns, sectionNumber);
            AddDynamicDateColumn(columns, sectionNumber);
        }

        private static void AddDynamicRedemColumn(IDictionary<string, string> availableColumns, int sectionIndex)
        {
            availableColumns[Attrib.LR_PAYMENT_PCT_REDEM + sectionIndex] = "Payment % Redem " + sectionIndex;
        }

        private static void AddDynamicDateColumn(IDictionary<string, string> availableColumns, int sectionIndex)
        {
            availableColumns[Attrib.LR_PAYMENT_DATE + sectionIndex] = "Payment date " + sectionIndex;
        }
    }
}