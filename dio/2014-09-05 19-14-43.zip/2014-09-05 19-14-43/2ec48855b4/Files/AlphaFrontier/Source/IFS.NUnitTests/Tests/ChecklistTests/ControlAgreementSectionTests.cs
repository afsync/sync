﻿using System;
using IFS.BusinessLayer.Checklists;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.ChecklistTests
{
    [TestFixture]
    public class ControlAgreementSectionTests
    {
        [Test]
        public void TestConstructor()
        {
            //Given

            //When
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            //Then
            Assert.That(controlAgreementSection.Id, Is.EqualTo(1));
            Assert.That(controlAgreementSection.ChecklistId, Is.EqualTo(2));
            Assert.That(controlAgreementSection.Comments, Is.EqualTo("Text"));
            Assert.That(controlAgreementSection.CommentsEnteredBy, Is.EqualTo(3));
            Assert.That(controlAgreementSection.Confirmed, Is.EqualTo(new DateTime(2010, 1, 1)));
            Assert.That(controlAgreementSection.ConfirmedBy, Is.EqualTo(4));
            Assert.That(controlAgreementSection.Reviewed, Is.EqualTo(new DateTime(2011, 1, 1)));
            Assert.That(controlAgreementSection.ReviewedBy, Is.EqualTo(5));
        }


        [Test]
        public void TestGetAuditXml()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            //When
            var auditXml = controlAgreementSection.GetAuditXml();

            //Then
            Assert.That(auditXml, Is.EqualTo("<Audit><Id>1</Id><ChecklistId>2</ChecklistId><Comments>Text</Comments><CommentsEnteredBy>3</CommentsEnteredBy>" +
                "<Confirmed>01/01/2010</Confirmed><ConfirmedBy>4</ConfirmedBy><Reviewed>01/01/2011</Reviewed><ReviewedBy>5</ReviewedBy></Audit>"));
        }

        [Test]
        public void TestIsNewReturnsTrue()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(0, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);
            //When
            var result = controlAgreementSection.IsNew();
            //Then
            Assert.That(result, Is.True);
        }

        [Test]
        public void TestIsNewReturnsFalse()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);
            //When
            var result = controlAgreementSection.IsNew();
            //Then
            Assert.That(result, Is.False);
        }

        [Test]
        public void TestAreConfirmedAndCommentsFieldsEnabledWhenReviewedNotEntered()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, DateTime.MinValue, 5);

            //when
            var result = controlAgreementSection.AreConfirmedAndCommentsFieldsEnabled();

            //then
            Assert.IsTrue(result);
        }

        [Test]
        public void TestAreConfirmedAndCommentsFieldsDisabledWhenReviewedEntered()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            //when
            var result = controlAgreementSection.AreConfirmedAndCommentsFieldsEnabled();

            //then
            Assert.IsFalse(result);
        }


        [Test]
        public void TestIsReviewedFieldDisabledWhenAllFieldsAreEntered()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5);

            //when
            var result = controlAgreementSection.IsReviewedFieldEnabled();

            //then
            Assert.IsFalse(result);
        }

        [Test]
        public void TestIsReviewedFieldDisabledWhenAllFieldsAreEmpty()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, string.Empty, 3, DateTime.MinValue, 4, DateTime.MinValue, 5);

            //when
            var result = controlAgreementSection.IsReviewedFieldEnabled();

            //then
            Assert.IsFalse(result);
        }

        [Test]
        public void TestIsReviewedFieldEnabledWhenConfirmedAndCommentsAreEntered()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, DateTime.MinValue, 5);


            //when
            var result = controlAgreementSection.IsReviewedFieldEnabled();

            //then
            Assert.IsTrue(result);
        }

        [Test]
        public void TestIsReviewedFieldDisabledWhenCommentsIsEmpty()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, string.Empty, 3, new DateTime(2010, 1, 1), 4, DateTime.MinValue, 5);


            //when
            var result = controlAgreementSection.IsReviewedFieldEnabled();

            //then
            Assert.IsFalse(result);
        }

        [Test]
        public void TestIsReviewedFieldDisabledWhenConfirmedIsEmpty()
        {
            //Given
            var controlAgreementSection = new ControlAgreementSection(1, 2, "Text", 3, DateTime.MinValue, 4, DateTime.MinValue, 5);


            //when
            var result = controlAgreementSection.IsReviewedFieldEnabled();

            //then
            Assert.IsFalse(result);
        }
    }
}
