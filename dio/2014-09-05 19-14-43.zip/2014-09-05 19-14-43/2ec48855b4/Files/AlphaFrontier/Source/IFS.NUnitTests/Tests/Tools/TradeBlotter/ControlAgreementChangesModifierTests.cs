﻿using System;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Checklists;
using IFS.BusinessLayer.Itb;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ControlAgreementChangesModifierTests
    {

        [Test]
        public void TestUserNameIsUpdatedWhenReviewedDateIsChanged()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.IsReviewedDateChanged()).Returns(true);
            var user = Mock.Of<User>(u => u.UserFullName == "User 1");
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, user);

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.SetReviewedModifiedUser("User 1"), Times.Once());
        }

        [Test]
        public void TestUserNameIsUpdatedWhenConfirmedDateIsChanged()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.IsConfirmedDateChanged()).Returns(true);
            var user = Mock.Of<User>(u => u.UserFullName == "User 1");
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, user);

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.SetConfirmedModifiedUser("User 1"), Times.Once());
        }

        [Test]
        public void TestUserNameIsUpdatedWhenCommentsIsChanged()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.AreCommentsChanged()).Returns(true);
            var user = Mock.Of<User>(u => u.UserFullName == "User 1");
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, user);

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.SetCommentsModifiedUser("User 1"), Times.Once());
        }

        [Test]
        public void TestEditableFieldsAreDisabledWhenReviewedDateIsChanged()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.IsReviewedDateChanged()).Returns(true);
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.DisableConfirmedAndCommentsFields(), Times.Once());
        }

        [Test]
        public void TestReviewedValidationErrorsAreClearedWhenReviewedDateIsChanged()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.ClearReviewedValidationErrors(), Times.Once());
        }

        [Test]
        public void TestReviewedFieldIsEnabled()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            checklist.Setup(p => p.IsReviewedFieldEnabled()).Returns(true);
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.EnableReviewedField(), Times.Once());
        }

        [Test]
        public void TestReviewedFieldIsDisabled()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            checklist.Setup(p => p.IsReviewedFieldEnabled()).Returns(false);
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.DisableReviewedField(), Times.Once());
        }

        [Test]
        public void TestConfirmedAndCommentsFieldsAreDisabled()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.IsReviewedDateChanged()).Returns(true);
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.DisableConfirmedAndCommentsFields(), Times.Once());
        }

        [Test]
        public void TestConfirmedAndCommentsFieldsAreNotDisabled()
        {
            //Given
            var checklist = new Mock<ControlAgreementSection>(1, 2, "Text", 3, new DateTime(2010, 1, 1), 4, new DateTime(2011, 1, 1), 5); 
            var mockViewer = new Mock<ItbChangesViewer>(It.IsAny<RowChanges>());
            mockViewer.Setup(v => v.IsReviewedDateChanged()).Returns(false);
            var modifier = new ControlAgreementChangesModifier(mockViewer.Object, Mock.Of<User>());

            //When
            modifier.ModifyFromChecklist(checklist.Object);

            //Then
            mockViewer.Verify(p => p.DisableConfirmedAndCommentsFields(), Times.Never());
        }
    }
}
