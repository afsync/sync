﻿using System;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Itb;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;
using Moq;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Tools.TradeBlotter
{
    [TestFixture]
    public class ItbChangeProcessorTests
    {
        [Test]
        [Ignore]
        public void TestProcessVerifyFactoryBehaviorWhenValidationPassed()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object,user);
            mockValidator.Setup(v => v.Validate(It.IsAny<TradeChecklist>())).Returns(true);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockChangeModifier = new Mock<ControlAgreementChangesModifier>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            mockObjectFactory.Setup(f => f.GetChangesModifier(mockViewer.Object, user)).Returns(mockChangeModifier.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, new TradeChecklist());

            //then
            mockObjectFactory.Verify(m => m.GetViewer(rowChanges), Times.Once());
            mockObjectFactory.Verify(m => m.GetValidator(mockViewer.Object, user), Times.Once());
            mockObjectFactory.Verify(m => m.GetSaver(mockViewer.Object, user), Times.Once());
            mockObjectFactory.Verify(m => m.GetChangesModifier(mockViewer.Object, user), Times.Once());
        }
        [Test]
        public void TestProcessVerifyFactoryBehaviorWhenValidationDidNotPass()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            mockValidator.Setup(v => v.Validate(It.IsAny<TradeChecklist>())).Returns(false);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, new TradeChecklist());

            //then
            mockObjectFactory.Verify(m => m.GetViewer(rowChanges), Times.Once());
            mockObjectFactory.Verify(m => m.GetValidator(mockViewer.Object, user), Times.Once());
            mockObjectFactory.Verify(m => m.GetSaver(mockViewer.Object, user), Times.Never());
            mockObjectFactory.Verify(m => m.GetChangesModifier(mockViewer.Object, user), Times.Never());
        }

        [Test]
        public void TestProcessVerifyValidatorBehavior()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var checklist = Mock.Of<TradeChecklist>();
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, checklist);

            //then
            mockValidator.Verify(m => m.Validate(checklist), Times.Once());
        }

        [Test]
        public void TestProcessVerifySaverBehaviorWhenValidationPassed()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var checklist = Mock.Of<TradeChecklist>();
          
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            mockValidator.Setup(v => v.Validate(checklist)).Returns(true);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockChangeModifier = new Mock<ControlAgreementChangesModifier>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            mockObjectFactory.Setup(f => f.GetChangesModifier(mockViewer.Object, user)).Returns(mockChangeModifier.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, checklist);

            //then
            mockSaver.Verify(m => m.Save(checklist, It.IsAny<DateTime>() ), Times.Once());
            mockViewer.Verify(m => m.SetChangesAsAccepted(), Times.Once());
        }

        [Test]
        public void TestProcessVerifySaverBehaviorWhenValidationDidNotPass()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var checklist = Mock.Of<TradeChecklist>();
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            mockValidator.Setup(v => v.Validate(checklist)).Returns(false);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, checklist);

            //then
            mockSaver.Verify(m => m.Save(checklist, It.IsAny<DateTime>()), Times.Never());
            mockViewer.Verify(m => m.SetChangesAsAccepted(), Times.Never());
        }

        [Test]
        public void TestProcessVerifyChangesModifierBehaviorWhenValidationPassed()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var checklist = Mock.Of<TradeChecklist>();

            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            mockValidator.Setup(v => v.Validate(checklist)).Returns(true);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockChangesModifier = new Mock<ControlAgreementChangesModifier>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            mockObjectFactory.Setup(f => f.GetChangesModifier(mockViewer.Object, user)).Returns(mockChangesModifier.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, checklist);

            //then
        //    mockChangesModifier.Verify(m => m.ModifyFromChecklist(checklist), Times.Once());
        }

        [Test]
        public void TestProcessVerifyChangesModifierBehaviorWhenValidationDidNotPass()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var checklist = Mock.Of<TradeChecklist>();
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            mockValidator.Setup(v => v.Validate(checklist)).Returns(false);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockChangesModifier = new Mock<ControlAgreementChangesModifier>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            mockObjectFactory.Setup(f => f.GetChangesModifier(mockViewer.Object, user)).Returns(mockChangesModifier.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            processor.Process(rowChanges, checklist);

            //then
         //   mockChangesModifier.Verify(m => m.ModifyFromChecklist(checklist), Times.Never());
        }

        [Test]
        public void TestProcessVerifyReturnResult()
        {
            //given
            var user = Mock.Of<User>();
            var rowChanges = new RowChanges();
            var mockViewer = new Mock<ItbChangesViewer>(rowChanges);
            var savedChanges = new RowChanges();
            mockViewer.Setup(v => v.GetChanges()).Returns(savedChanges);
            var checklist = Mock.Of<TradeChecklist>();
            var mockValidator = new Mock<ItbChangesValidator>(mockViewer.Object, user);
            var mockSaver = new Mock<ItbChangesSaver>(mockViewer.Object, user);
            var mockObjectFactory = new Mock<ItbChangeProcessorObjectFactory>();
            mockObjectFactory.Setup(f => f.GetViewer(rowChanges)).Returns(mockViewer.Object);
            mockObjectFactory.Setup(f => f.GetValidator(mockViewer.Object, user)).Returns(mockValidator.Object);
            mockObjectFactory.Setup(f => f.GetSaver(mockViewer.Object, user)).Returns(mockSaver.Object);
            var processor = new ItbChangeProcessor(mockObjectFactory.Object, user);

            //when
            var result = processor.Process(rowChanges, checklist);

            //then
            Assert.AreSame(savedChanges, result);
        }
    }
}
