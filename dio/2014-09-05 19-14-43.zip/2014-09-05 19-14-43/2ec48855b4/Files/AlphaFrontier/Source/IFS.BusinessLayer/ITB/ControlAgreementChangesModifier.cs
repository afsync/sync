﻿using IFS.BusinessLayer.Checklists;

namespace IFS.BusinessLayer.Itb
{
    public class ControlAgreementChangesModifier
    {
        private readonly ItbChangesViewer _viewer;
        private readonly User _user;

        public ControlAgreementChangesModifier(ItbChangesViewer viewer, User user)
        {
            _viewer = viewer;
            _user = user;
        }

        public virtual void ModifyFromChecklist(ControlAgreementSection controlAgreementSection)
        {
            UpdateReviewedFieldChanges(controlAgreementSection);

            if (_viewer.IsConfirmedDateChanged())
                _viewer.SetConfirmedModifiedUser(_user.UserFullName);

            if (_viewer.AreCommentsChanged())
                _viewer.SetCommentsModifiedUser(_user.UserFullName);
        }

        private void UpdateReviewedFieldChanges(ControlAgreementSection controlAgreementSection)
        {
            if (_viewer.IsReviewedDateChanged())
            {
                _viewer.SetReviewedModifiedUser(_user.UserFullName);
                _viewer.DisableConfirmedAndCommentsFields();
            }
            _viewer.ClearReviewedValidationErrors();
            if (controlAgreementSection.IsReviewedFieldEnabled())
                _viewer.EnableReviewedField();
            else
                _viewer.DisableReviewedField();
        }
    }
}
