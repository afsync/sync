﻿using System;
using IFS.BusinessLayer.Trade.TradeExecution.TradeChecklist;
using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangeProcessor
    {
        private readonly ItbChangeProcessorObjectFactory _factory;
        private readonly User _user;

        public ItbChangeProcessor(ItbChangeProcessorObjectFactory factory, User user)
        {
            _factory = factory;
            _user = user;
        }

        public virtual RowChanges Process(RowChanges changes,TradeChecklist checklist)
        {
            var viewer = _factory.GetViewer(changes);
            if (AreChangesValid(viewer, checklist))
            {
                SaveChanges(viewer, checklist);
                UpdateSavedChanges(viewer, checklist);
            }
            return viewer.GetChanges();
        }

        private bool AreChangesValid(ItbChangesViewer viewer, TradeChecklist checklist)
        {
            return _factory.GetValidator(viewer, _user).Validate(checklist);
        }

        private void SaveChanges(ItbChangesViewer viewer, TradeChecklist checklist)
        {
            _factory.GetSaver(viewer, _user).Save(checklist, DateTime.Now);
            viewer.SetChangesAsAccepted();
        }

        private void UpdateSavedChanges(ItbChangesViewer viewer, TradeChecklist checklist)
        {
   //         _factory.GetChangesModifier(viewer, _user).ModifyFromChecklist(checklist);
        }
    }
}
