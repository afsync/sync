﻿using IFS.Interfaces.CloudContracts.DataContracts.Tools.TradeBlotter;

namespace IFS.BusinessLayer.Itb
{
    public class ItbChangeProcessorObjectFactory
    {
        public virtual ItbChangesViewer GetViewer(RowChanges changes)
        {
            return new ItbChangesViewer(changes);
        }

        public virtual ItbChangesSaver GetSaver(ItbChangesViewer viewer, User user)
        {
            return new ItbChangesSaver(viewer, user);
        }

        public virtual ItbChangesValidator GetValidator(ItbChangesViewer viewer, User user)
        {
            return new ItbChangesValidator(viewer, user);
        }

        public virtual ControlAgreementChangesModifier GetChangesModifier(ItbChangesViewer viewer, User user)
        {
            return new ControlAgreementChangesModifier(viewer, user);
        }
    }
}
