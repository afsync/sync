﻿using System.Collections.Generic;
using System.Linq;
using IFS.DataAccess.Entity.Layout;
using IFS.Interfaces.DbRepository;
using IFS.Interfaces.DbRepository.Layout;

namespace IFS.DbRepository.Layout
{
    public class LiquidityLayoutDbRepository:DbRepository, ILiquidityLayoutDbRepository
    {
        public List<ILiquidityLayoutContainer> GetLayoutsByUserId(int userId)
        {
            return (from llp in Context.GetTable<LiquidityLayoutPropertiesData>()
                join lm in Context.GetTable<LayoutMetaDataData>() on llp.LayoutMetaDataId equals lm.Id
                where lm.OwnerId == userId
                select new LiquidityLayoutContainer {LayoutMetaDataData = lm, LiquidityLayoutPropertiesData = llp})
                .Cast<ILiquidityLayoutContainer>().ToList();
        }
    }

    public class LiquidityLayoutContainer : ILiquidityLayoutContainer
    {
        public ILayoutMetaDataData LayoutMetaDataData { get; set; }
        public ILiquidityLayoutPropertiesData LiquidityLayoutPropertiesData { get; set; }
    }
}
